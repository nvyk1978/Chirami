package com.chirami.viewer;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ComponentName;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.provider.OpenableColumns;
import android.widget.Toast;

import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * One OS-facing entry point for every supported image MIME. Android chooses one
 * preferred component (this gateway); Chirami then applies per-format enable/disable
 * policy internally. This avoids relying on Android to maintain separate defaults
 * for image/png, image/gif, etc.
 */
public class ImageGatewayActivity extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        route(getIntent());
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        route(intent);
    }

    private void route(Intent incoming) {
        if (incoming == null || !Intent.ACTION_VIEW.equals(incoming.getAction())) {
            finish();
            return;
        }
        Uri uri = incoming.getData();
        if (uri == null) {
            finish();
            return;
        }

        String suppliedMime = incoming.getType();
        String resolverMime = safeResolverMime(uri);
        String displayName = resolveDisplayName(uri);
        String key = OpenFormatPrefs.keyFromMime(suppliedMime);
        if (key == null) key = OpenFormatPrefs.keyFromMime(resolverMime);
        if (key == null) key = OpenFormatPrefs.keyFromName(displayName);
        if (key == null) key = sniffFormat(uri);

        AppLog.d(this, "GATEWAY route suppliedMime=" + suppliedMime
                + " resolverMime=" + resolverMime
                + " name=" + displayName
                + " key=" + key
                + " enabled=" + OpenFormatPrefs.isEnabled(this, key)
                + " uri=" + uri);

        // Probe used by MainActivity to establish the OS preferred handler. It only
        // needs to resolve into Chirami; never show the synthetic 1x1 image.
        if (isDefaultProbe(uri, displayName)) {
            AppLog.d(this, "GATEWAY default probe consumed without viewer");
            finish();
            return;
        }

        if (!OpenFormatPrefs.isEnabled(this, key)) {
            showAlternateApps(incoming, key);
            return;
        }

        Intent viewer = new Intent(this, ViewerActivity.class);
        viewer.setAction(Intent.ACTION_VIEW);
        String normalizedMime = OpenFormatPrefs.mimeForKey(key,
                suppliedMime != null ? suppliedMime : resolverMime);
        viewer.setDataAndType(uri, normalizedMime);
        viewer.setFlags(incoming.getFlags());
        if (incoming.getClipData() != null) viewer.setClipData(incoming.getClipData());
        try {
            startActivity(viewer);
        } catch (Throwable e) {
            AppLog.d(this, "GATEWAY viewer launch failed " + e);
            Toast.makeText(this, "画像を開けませんでした", Toast.LENGTH_SHORT).show();
        }
        finish();
    }

    private String safeResolverMime(Uri uri) {
        try { return getContentResolver().getType(uri); }
        catch (Throwable ignored) { return null; }
    }

    private String resolveDisplayName(Uri uri) {
        if (uri == null) return null;
        if ("file".equalsIgnoreCase(uri.getScheme())) {
            String path = uri.getPath();
            if (path == null) return null;
            int slash = path.lastIndexOf('/');
            return slash >= 0 ? path.substring(slash + 1) : path;
        }
        try (Cursor c = getContentResolver().query(uri,
                new String[]{OpenableColumns.DISPLAY_NAME}, null, null, null)) {
            if (c != null && c.moveToFirst()) {
                int idx = c.getColumnIndex(OpenableColumns.DISPLAY_NAME);
                if (idx >= 0) return c.getString(idx);
            }
        } catch (Throwable ignored) {}
        String seg = uri.getLastPathSegment();
        return seg == null ? null : seg;
    }

    private boolean isDefaultProbe(Uri uri, String displayName) {
        if (displayName != null && displayName.startsWith("chirami_default_test")) return true;
        String s = uri == null ? "" : uri.toString();
        return s.contains("default_probe") || s.contains("default-probe")
                || s.contains("chirami_default_test");
    }

    private String sniffFormat(Uri uri) {
        byte[] h = new byte[32];
        int count;
        try (InputStream in = getContentResolver().openInputStream(uri)) {
            if (in == null) return null;
            count = in.read(h);
        } catch (Throwable e) {
            AppLog.d(this, "GATEWAY sniff failed " + e.getClass().getSimpleName());
            return null;
        }
        if (count >= 8
                && (h[0] & 0xff) == 0x89 && h[1] == 0x50 && h[2] == 0x4e && h[3] == 0x47
                && h[4] == 0x0d && h[5] == 0x0a && h[6] == 0x1a && h[7] == 0x0a) {
            return OpenFormatPrefs.PNG;
        }
        if (count >= 6 && h[0] == 'G' && h[1] == 'I' && h[2] == 'F'
                && h[3] == '8' && (h[4] == '7' || h[4] == '9') && h[5] == 'a') {
            return OpenFormatPrefs.GIF;
        }
        if (count >= 3 && (h[0] & 0xff) == 0xff && (h[1] & 0xff) == 0xd8
                && (h[2] & 0xff) == 0xff) {
            return OpenFormatPrefs.JPEG;
        }
        if (count >= 2 && h[0] == 'B' && h[1] == 'M') return OpenFormatPrefs.BMP;
        if (count >= 12 && h[0] == 'R' && h[1] == 'I' && h[2] == 'F' && h[3] == 'F'
                && h[8] == 'W' && h[9] == 'E' && h[10] == 'B' && h[11] == 'P') {
            return OpenFormatPrefs.WEBP;
        }
        if (count >= 12 && h[4] == 'f' && h[5] == 't' && h[6] == 'y' && h[7] == 'p') {
            String brand = new String(h, 8, 4, java.nio.charset.StandardCharsets.US_ASCII)
                    .toLowerCase(Locale.ROOT);
            if (brand.equals("avif") || brand.equals("avis")) return OpenFormatPrefs.AVIF;
            if (brand.equals("heic") || brand.equals("heix") || brand.equals("hevc")
                    || brand.equals("hevx") || brand.equals("heim") || brand.equals("heis")
                    || brand.equals("mif1") || brand.equals("msf1")) return OpenFormatPrefs.HEIC;
        }
        return null;
    }

    private void showAlternateApps(Intent incoming, String key) {
        Intent probe = new Intent(Intent.ACTION_VIEW);
        probe.setDataAndType(incoming.getData(), incoming.getType());
        probe.addFlags(incoming.getFlags() & (Intent.FLAG_GRANT_READ_URI_PERMISSION
                | Intent.FLAG_GRANT_WRITE_URI_PERMISSION
                | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION
                | Intent.FLAG_GRANT_PREFIX_URI_PERMISSION));

        PackageManager pm = getPackageManager();
        List<ResolveInfo> all;
        try {
            all = pm.queryIntentActivities(probe, PackageManager.MATCH_ALL);
        } catch (Throwable e) {
            all = pm.queryIntentActivities(probe, 0);
        }
        final List<ResolveInfo> others = new ArrayList<>();
        final List<String> labels = new ArrayList<>();
        if (all != null) {
            for (ResolveInfo ri : all) {
                if (ri == null || ri.activityInfo == null) continue;
                if (getPackageName().equals(ri.activityInfo.packageName)) continue;
                others.add(ri);
                CharSequence label = ri.loadLabel(pm);
                labels.add(label == null ? ri.activityInfo.packageName : label.toString());
            }
        }
        if (others.isEmpty()) {
            Toast.makeText(this, "この形式を開ける他のアプリがありません", Toast.LENGTH_SHORT).show();
            finish();
            return;
        }

        String title = "この形式はChiramiで開かない設定です";
        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle(title)
                .setItems(labels.toArray(new String[0]), (d, which) -> {
                    ResolveInfo ri = others.get(which);
                    Intent out = new Intent(probe);
                    out.setComponent(new ComponentName(ri.activityInfo.packageName, ri.activityInfo.name));
                    if (incoming.getClipData() != null) out.setClipData(incoming.getClipData());
                    AppLog.d(this, "GATEWAY alternate key=" + key + " component="
                            + ri.activityInfo.packageName + "/" + ri.activityInfo.name);
                    try { startActivity(out); }
                    catch (Throwable e) {
                        AppLog.d(this, "GATEWAY alternate launch failed " + e);
                        Toast.makeText(this, "別アプリで開けませんでした", Toast.LENGTH_SHORT).show();
                    }
                    finish();
                })
                .setOnCancelListener(d -> finish())
                .create();
        dialog.show();
    }
}
