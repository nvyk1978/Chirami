package com.chirami.viewer;

import android.content.Context;
import android.provider.MediaStore;

final class SortPrefs {
    static final String PREFS = "chirami_prefs";
    static final String KEY_FIELD = "slide_sort_field";
    static final String KEY_ASC = "slide_sort_asc";

    static final String FIELD_NAME = "name";
    static final String FIELD_SIZE = "size";
    static final String FIELD_TYPE = "type";
    static final String FIELD_CREATED = "created";
    static final String FIELD_MODIFIED = "modified";

    static String field(Context context) {
        return context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
                .getString(KEY_FIELD, FIELD_NAME);
    }

    static boolean ascending(Context context) {
        return context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
                .getBoolean(KEY_ASC, true);
    }

    static void save(Context context, String field, boolean ascending) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
                .putString(KEY_FIELD, field)
                .putBoolean(KEY_ASC, ascending)
                .apply();
    }

    static String sqlColumn(String field) {
        if (FIELD_SIZE.equals(field)) return MediaStore.Images.Media.SIZE;
        if (FIELD_TYPE.equals(field)) return MediaStore.Images.Media.DISPLAY_NAME;
        if (FIELD_CREATED.equals(field)) return MediaStore.Images.Media.DATE_ADDED;
        if (FIELD_MODIFIED.equals(field)) return MediaStore.Images.Media.DATE_MODIFIED;
        return MediaStore.Images.Media.DISPLAY_NAME;
    }

    static String fieldLabel(String field) {
        if (FIELD_SIZE.equals(field)) return "サイズ";
        if (FIELD_TYPE.equals(field)) return "種類";
        if (FIELD_CREATED.equals(field)) return "作成日";
        if (FIELD_MODIFIED.equals(field)) return "最終更新日";
        return "名前";
    }

    private SortPrefs() {}
}
