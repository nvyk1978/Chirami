package com.chirami.viewer;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.os.storage.StorageManager;
import android.os.storage.StorageVolume;
import android.text.InputType;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.PopupMenu;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.List;

/** N-colored self-contained folder browser shared by settings and viewer menu. */
public class FolderPickerActivity extends Activity {
    private static final int BG = Color.rgb(48,48,48);       // #303030
    private static final int DARK = Color.rgb(37,32,32);     // #252020
    private static final int GRAY = Color.rgb(69,64,64);     // #454040
    private static final int LGRAY = Color.rgb(101,96,96);   // #656060
    private static final int BLUE = Color.rgb(34,51,85);     // #223355
    private static final int LBLUE = Color.rgb(68,85,119);   // #445577
    private static final int WHITE_UI = Color.rgb(169,169,153); // #A9A999
    private static final int TEXT = Color.WHITE;

    private File currentDir;
    private File rootLimit;
    private TextView pathView;
    private TextView storageView;
    private LinearLayout folderList;
    private GripScrollHost scrollHost;
    private final List<StorageTarget> storages = new ArrayList<>();

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setTitle("保存先");
        buildStorageTargets();
        File selected = SavePrefs.directory(this);
        File start = selected == null ? null : selected;
        if (start == null) start = Environment.getExternalStorageDirectory();
        currentDir = start;
        rootLimit = matchingRoot(start);
        buildUi();
        refresh();
    }

    private int dp(float v) { return Math.round(v * getResources().getDisplayMetrics().density); }

    private void buildUi() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(16), dp(16), dp(16), dp(14));
        root.setBackgroundColor(BG);

        storageView = label("", 16, TEXT);
        storageView.setGravity(Gravity.CENTER_VERTICAL);
        storageView.setPadding(dp(14),0,dp(14),0);
        storageView.setBackground(roundRect(GRAY, 10));
        storageView.setOnClickListener(v -> showStorageMenu());
        root.addView(storageView, new LinearLayout.LayoutParams(-1, dp(44)));

        pathView = label("", 12, TEXT);
        pathView.setSingleLine(true);
        pathView.setEllipsize(android.text.TextUtils.TruncateAt.START);
        pathView.setPadding(dp(4),dp(8),dp(4),dp(8));
        root.addView(pathView, new LinearLayout.LayoutParams(-1, dp(38)));

        LinearLayout nav = new LinearLayout(this);
        nav.setOrientation(LinearLayout.HORIZONTAL);
        Button back = button("‹  戻る", GRAY);
        Button make = button("＋  新規フォルダ", GRAY);
        nav.addView(back, new LinearLayout.LayoutParams(0, dp(46), 1f));
        LinearLayout.LayoutParams mlp = new LinearLayout.LayoutParams(0, dp(46), 1f); mlp.leftMargin = dp(8);
        nav.addView(make, mlp);
        root.addView(nav);

        folderList = new LinearLayout(this);
        folderList.setOrientation(LinearLayout.VERTICAL);
        scrollHost = new GripScrollHost(this, folderList);
        LinearLayout.LayoutParams slp = new LinearLayout.LayoutParams(-1, 0, 1f); slp.topMargin = dp(10); slp.bottomMargin = dp(10);
        root.addView(scrollHost, slp);

        LinearLayout footer = new LinearLayout(this);
        footer.setOrientation(LinearLayout.HORIZONTAL);
        Button reset = button("Pictures/Chirami", GRAY);
        Button use = button("このフォルダを使用", BLUE);
        footer.addView(reset, new LinearLayout.LayoutParams(0, dp(50), 1f));
        LinearLayout.LayoutParams ulp = new LinearLayout.LayoutParams(0, dp(50), 1.15f); ulp.leftMargin = dp(8);
        footer.addView(use, ulp);
        root.addView(footer);

        back.setOnClickListener(v -> {
            File parent = currentDir == null ? null : currentDir.getParentFile();
            if (parent == null) return;
            if (rootLimit != null && !isWithin(parent, rootLimit)) return;
            currentDir = parent;
            refresh();
        });
        make.setOnClickListener(v -> showCreateFolder());
        reset.setOnClickListener(v -> {
            SavePrefs.reset(this);
            File target = SavePrefs.defaultDirectory();
            File start = nearestExistingDirectory(target);
            if (start != null) {
                currentDir = start;
                rootLimit = matchingRoot(start);
            }
            Toast.makeText(this, "保存先を Pictures/Chirami に戻しました", Toast.LENGTH_SHORT).show();
            setResult(RESULT_OK);
            finish();
        });
        use.setOnClickListener(v -> {
            if (currentDir == null) return;
            SavePrefs.setDirectory(this, currentDir);
            Toast.makeText(this, "保存先を設定しました", Toast.LENGTH_SHORT).show();
            setResult(RESULT_OK);
            finish();
        });

        setContentView(root);
    }

    private void refresh() {
        if (currentDir == null) return;
        pathView.setText(currentDir.getAbsolutePath());
        StorageTarget t = findStorage(currentDir);
        storageView.setText((t == null ? "ストレージ" : t.label) + "  ▾");
        folderList.removeAllViews();
        File[] dirs;
        try { dirs = currentDir.listFiles(file -> file != null && file.isDirectory() && !file.isHidden()); }
        catch (Throwable e) { dirs = null; }
        if (dirs == null) {
            TextView empty = label(currentDir.exists() ? "フォルダを読み込めません" : "このフォルダは保存時に作成されます", 14, WHITE_UI);
            empty.setPadding(dp(12),dp(20),dp(12),dp(20));
            folderList.addView(empty);
        } else {
            Arrays.sort(dirs, Comparator.comparing(File::getName, String.CASE_INSENSITIVE_ORDER));
            if (dirs.length == 0) {
                TextView empty = label("フォルダはありません", 14, WHITE_UI);
                empty.setPadding(dp(12),dp(20),dp(12),dp(20));
                folderList.addView(empty);
            }
            for (File dir : dirs) addFolderRow(dir);
        }
        scrollHost.post(() -> { scrollHost.scroll.scrollTo(0,0); scrollHost.updateThumb(); });
    }

    private void addFolderRow(File dir) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(dp(12),0,dp(10),0);
        row.setBackground(roundRect(DARK, 8));
        TextView icon = label("▸", 20, WHITE_UI);
        icon.setGravity(Gravity.CENTER);
        row.addView(icon, new LinearLayout.LayoutParams(dp(34), -1));
        TextView name = label(dir.getName(), 16, TEXT);
        name.setSingleLine(true);
        name.setEllipsize(android.text.TextUtils.TruncateAt.END);
        row.addView(name, new LinearLayout.LayoutParams(0, -1, 1f));
        row.setOnClickListener(v -> { currentDir = dir; refresh(); });
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, dp(48)); lp.bottomMargin = dp(2);
        folderList.addView(row, lp);
    }

    private void showStorageMenu() {
        PopupMenu menu = new PopupMenu(this, storageView);
        for (int i=0;i<storages.size();i++) menu.getMenu().add(0, i+1, i, storages.get(i).label);
        menu.setOnMenuItemClickListener(item -> {
            int index = item.getItemId()-1;
            if (index < 0 || index >= storages.size()) return false;
            StorageTarget target = storages.get(index);
            currentDir = target.root;
            rootLimit = target.root;
            refresh();
            return true;
        });
        menu.show();
    }

    private void showCreateFolder() {
        EditText input = new EditText(this);
        input.setTextColor(TEXT); input.setHintTextColor(LGRAY); input.setHint("フォルダ名"); input.setSingleLine(true);
        input.setInputType(InputType.TYPE_CLASS_TEXT);
        LinearLayout box = new LinearLayout(this); box.setPadding(dp(18),dp(8),dp(18),0); box.addView(input,new LinearLayout.LayoutParams(-1,dp(56)));
        AlertDialog dialog = new AlertDialog.Builder(this).setTitle("新規フォルダ").setView(box)
                .setNegativeButton("キャンセル", null).setPositiveButton("作成", null).create();
        dialog.setOnShowListener(v -> dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v2 -> {
            String name = input.getText().toString().trim().replaceAll("[\\\\/:*?\"<>|]", "_");
            if (name.isEmpty()) { input.setError("フォルダ名を入力してください"); return; }
            File out = new File(currentDir, name);
            if (out.exists()) { input.setError("同名フォルダがあります"); return; }
            boolean ok = false;
            try { ok = out.mkdir(); } catch (Throwable ignored) { }
            if (!ok) { Toast.makeText(this, "この場所にはフォルダを作成できません", Toast.LENGTH_LONG).show(); return; }
            dialog.dismiss(); refresh();
        }));
        dialog.show();
    }

    private void buildStorageTargets() {
        File primary = Environment.getExternalStorageDirectory();
        if (primary != null) storages.add(new StorageTarget("内部ストレージ", primary));
        if (Build.VERSION.SDK_INT >= 30) {
            try {
                StorageManager sm = (StorageManager)getSystemService(STORAGE_SERVICE);
                if (sm != null) {
                    for (StorageVolume v : sm.getStorageVolumes()) {
                        File dir = v.getDirectory();
                        if (dir == null) continue;
                        boolean duplicate = false;
                        for (StorageTarget t : storages) if (samePath(t.root, dir)) duplicate = true;
                        if (duplicate) continue;
                        String label = v.getDescription(this);
                        if (label == null || label.trim().isEmpty()) label = v.isRemovable() ? "外部ストレージ" : "ストレージ";
                        storages.add(new StorageTarget(label, dir));
                    }
                }
            } catch (Throwable ignored) { }
        }
    }

    private File matchingRoot(File f) {
        StorageTarget t = findStorage(f); return t == null ? Environment.getExternalStorageDirectory() : t.root;
    }
    private StorageTarget findStorage(File f) {
        if (f == null) return null;
        StorageTarget best = null;
        int bestLen = -1;
        for (StorageTarget t : storages) {
            if (isWithin(f,t.root)) {
                int len = t.root.getAbsolutePath().length();
                if (len > bestLen) { best=t; bestLen=len; }
            }
        }
        return best;
    }
    private File nearestExistingDirectory(File f) {
        File c=f;
        while (c!=null && (!c.exists() || !c.isDirectory())) c=c.getParentFile();
        return c;
    }
    private boolean isWithin(File child, File root) {
        try {
            String c=child.getCanonicalPath(); String r=root.getCanonicalPath();
            return c.equals(r) || c.startsWith(r + File.separator);
        } catch (Throwable e) { return false; }
    }
    private boolean samePath(File a, File b) { try { return a.getCanonicalFile().equals(b.getCanonicalFile()); } catch(Throwable e){return a.equals(b);} }

    private TextView label(String s,float size,int color){ TextView t=new TextView(this); t.setText(s); t.setTextSize(size); t.setTextColor(color); t.setGravity(Gravity.CENTER_VERTICAL); return t; }
    private Button button(String s,int color){ Button b=new Button(this); b.setText(s); b.setTextColor(TEXT); b.setTextSize(14); b.setAllCaps(false); b.setBackground(roundRect(color,10)); b.setStateListAnimator(null); return b; }
    private GradientDrawable roundRect(int color,float radiusDp){ GradientDrawable d=new GradientDrawable(); d.setColor(color); d.setCornerRadius(dp(radiusDp)); return d; }

    private static final class StorageTarget { final String label; final File root; StorageTarget(String l, File r){label=l;root=r;} }

    /** ScrollView with a visible N-white thumb that can be grabbed directly. */
    private final class GripScrollHost extends FrameLayout {
        final TrackingScrollView scroll;
        final View thumb;
        final View hit;
        final Handler handler = new Handler(Looper.getMainLooper());
        final Runnable fade = () -> thumb.animate().alpha(0f).setDuration(260).start();
        int thumbHeight;
        boolean dragging;

        GripScrollHost(Context context, View child) {
            super(context);
            scroll = new TrackingScrollView(context);
            scroll.setVerticalScrollBarEnabled(false);
            scroll.addView(child, new ScrollView.LayoutParams(-1,-2));
            addView(scroll, new FrameLayout.LayoutParams(-1,-1));

            thumb = new View(context);
            thumb.setBackground(roundRect(WHITE_UI,2));
            FrameLayout.LayoutParams tp = new FrameLayout.LayoutParams(dp(4),dp(40),Gravity.END|Gravity.TOP); tp.rightMargin=dp(2);
            addView(thumb,tp);

            hit = new View(context);
            FrameLayout.LayoutParams hp = new FrameLayout.LayoutParams(dp(30),-1,Gravity.END);
            addView(hit,hp);
            hit.setOnTouchListener((v,e)->handleGrip(e));
            post(this::updateThumb);
        }

        void showThumb(){ handler.removeCallbacks(fade); thumb.animate().cancel(); thumb.setAlpha(1f); if(!dragging) handler.postDelayed(fade,900); }
        void updateThumb(){
            if (scroll.getChildCount()==0 || getHeight()<=0) return;
            int content = scroll.getChildAt(0).getHeight();
            int viewport = scroll.getHeight();
            int range = Math.max(0, content-viewport);
            if (range<=0) { thumb.setVisibility(View.GONE); return; }
            thumb.setVisibility(View.VISIBLE);
            thumbHeight = Math.max(dp(36), Math.round(viewport * (viewport/(float)Math.max(viewport,content))));
            thumbHeight = Math.min(viewport, thumbHeight);
            int track = Math.max(1, viewport-thumbHeight);
            float ratio = scroll.getScrollY()/(float)Math.max(1,range);
            FrameLayout.LayoutParams lp=(FrameLayout.LayoutParams)thumb.getLayoutParams();
            lp.height=thumbHeight; lp.topMargin=Math.round(track*ratio); lp.gravity=Gravity.END|Gravity.TOP; lp.rightMargin=dp(2);
            thumb.setLayoutParams(lp);
        }
        boolean handleGrip(MotionEvent e){
            if(thumb.getVisibility()!=View.VISIBLE) return false;
            switch(e.getActionMasked()){
                case MotionEvent.ACTION_DOWN: dragging=true; showThumb(); moveTo(e.getY()); return true;
                case MotionEvent.ACTION_MOVE: moveTo(e.getY()); return true;
                case MotionEvent.ACTION_UP:
                case MotionEvent.ACTION_CANCEL: dragging=false; showThumb(); return true;
            }
            return false;
        }
        void moveTo(float y){
            if(scroll.getChildCount()==0) return;
            int content=scroll.getChildAt(0).getHeight(), viewport=scroll.getHeight(), range=Math.max(0,content-viewport);
            int track=Math.max(1,viewport-thumbHeight);
            float ratio=Math.max(0f,Math.min(1f,(y-thumbHeight/2f)/track));
            scroll.scrollTo(0,Math.round(range*ratio));
            updateThumb();
        }
        final class TrackingScrollView extends ScrollView {
            TrackingScrollView(Context c){super(c);}
            @Override protected void onScrollChanged(int l,int t,int oldl,int oldt){ super.onScrollChanged(l,t,oldl,oldt); updateThumb(); showThumb(); }
            @Override protected void onSizeChanged(int w,int h,int oldw,int oldh){ super.onSizeChanged(w,h,oldw,oldh); post(GripScrollHost.this::updateThumb); }
        }
    }
}
