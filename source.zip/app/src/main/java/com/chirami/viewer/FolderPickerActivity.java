package com.chirami.viewer;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.os.storage.StorageManager;
import android.os.storage.StorageVolume;
import android.text.InputType;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.PopupWindow;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * N Explorer / save-destination mode.
 *
 * The UI and navigation rules intentionally follow ViewerActivity's existing
 * copy/move destination explorer.  Save mode only changes the final action:
 * the current folder is persisted as Chirami's non-overwrite save destination.
 */
public class FolderPickerActivity extends Activity {
    // N palette
    private static final int BG = Color.rgb(48, 48, 48);          // #303030
    private static final int DARK = Color.rgb(37, 32, 32);        // #252020
    private static final int GRAY = Color.rgb(69, 64, 64);        // #454040
    private static final int LGRAY = Color.rgb(101, 96, 96);      // #656060
    private static final int LBLUE = Color.rgb(68, 85, 119);      // #445577
    private static final int WHITE_UI = Color.rgb(169, 169, 153); // #A9A999
    private static final int TEXT = Color.WHITE;

    private final Handler mainHandler = new Handler(Looper.getMainLooper());
    private final ExecutorService io = Executors.newSingleThreadExecutor();
    private final AtomicInteger listGeneration = new AtomicInteger();

    private File currentDir;
    private File rootLimit;
    private TextView pathView;
    private TextView storageView;
    private LinearLayout folderList;
    private GripScrollHost scrollHost;
    private final ArrayList<StorageTarget> storages = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        configureWindow();
        buildStorageTargets();

        File requested = SavePrefs.directory(this);
        File start = nearestExistingDirectory(requested);
        if (start == null) start = Environment.getExternalStorageDirectory();
        currentDir = start;
        rootLimit = storageRootFor(start);

        buildUi();
        refresh();
    }

    @Override
    protected void onDestroy() {
        listGeneration.incrementAndGet();
        io.shutdownNow();
        super.onDestroy();
    }

    private void configureWindow() {
        Window w = getWindow();
        if (w == null) return;
        w.setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        w.addFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND);
        WindowManager.LayoutParams lp = w.getAttributes();
        lp.dimAmount = 0.58f;
        w.setAttributes(lp);
        w.setGravity(Gravity.CENTER);
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (!hasFocus) return;
        Window w = getWindow();
        if (w == null) return;
        int screenWidth = getResources().getDisplayMetrics().widthPixels;
        w.setLayout(Math.min(screenWidth - dp(20), Math.round(screenWidth * 0.92f)), WindowManager.LayoutParams.WRAP_CONTENT);
    }

    private int dp(float value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }

    private void buildUi() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(14), dp(10), dp(14), dp(8));
        root.setBackground(roundRect(BG, 12));

        TextView title = text("保存先", 20, TEXT);
        title.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        title.setPadding(dp(4), dp(3), dp(4), dp(10));
        root.addView(title, new LinearLayout.LayoutParams(-1, dp(48)));

        storageView = text("", 16, TEXT);
        storageView.setGravity(Gravity.CENTER_VERTICAL);
        storageView.setPadding(dp(12), 0, dp(12), 0);
        storageView.setBackground(roundRect(GRAY, 10));
        storageView.setOnClickListener(v -> showStorageMenu());
        root.addView(storageView, new LinearLayout.LayoutParams(-1, dp(42)));

        pathView = text("", 12, WHITE_UI);
        pathView.setSingleLine(true);
        pathView.setEllipsize(TextUtils.TruncateAt.START);
        pathView.setPadding(dp(4), dp(7), dp(4), dp(7));
        root.addView(pathView, new LinearLayout.LayoutParams(-1, dp(36)));

        LinearLayout nav = new LinearLayout(this);
        nav.setOrientation(LinearLayout.HORIZONTAL);
        nav.setGravity(Gravity.CENTER_VERTICAL);
        TextView parentButton = managerButton("‹  戻る");
        TextView newFolderButton = managerButton("＋  新規フォルダ");
        nav.addView(parentButton, new LinearLayout.LayoutParams(0, dp(44), 1f));
        nav.addView(newFolderButton, new LinearLayout.LayoutParams(0, dp(44), 1f));
        root.addView(nav);

        folderList = new LinearLayout(this);
        folderList.setOrientation(LinearLayout.VERTICAL);
        scrollHost = new GripScrollHost(this, folderList);
        int screenHeight = getResources().getDisplayMetrics().heightPixels;
        int listHeight = Math.min(dp(440), Math.max(dp(250), screenHeight - dp(300)));
        root.addView(scrollHost, new LinearLayout.LayoutParams(-1, listHeight));

        LinearLayout actions = new LinearLayout(this);
        actions.setOrientation(LinearLayout.HORIZONTAL);
        actions.setGravity(Gravity.END | Gravity.CENTER_VERTICAL);
        TextView cancel = actionText("キャンセル");
        TextView confirm = actionText("このフォルダを保存先にする");
        actions.addView(cancel, new LinearLayout.LayoutParams(0, dp(48), 0.32f));
        actions.addView(confirm, new LinearLayout.LayoutParams(0, dp(48), 0.68f));
        root.addView(actions, new LinearLayout.LayoutParams(-1, dp(52)));

        parentButton.setOnClickListener(v -> {
            File parent = currentDir == null ? null : currentDir.getParentFile();
            if (parent == null) return;
            if (rootLimit != null && !isWithinRoot(parent, rootLimit)) return;
            currentDir = parent;
            refresh();
        });
        newFolderButton.setOnClickListener(v -> showCreateFolder());
        cancel.setOnClickListener(v -> finish());
        confirm.setOnClickListener(v -> {
            if (currentDir == null) return;
            SavePrefs.setDirectory(this, currentDir);
            AppLog.d(this, "NEXPLORER save destination selected path=" + currentDir.getAbsolutePath());
            Toast.makeText(this, "保存先を設定しました", Toast.LENGTH_SHORT).show();
            setResult(RESULT_OK);
            finish();
        });

        setContentView(root);
    }

    private void refresh() {
        if (currentDir == null) return;
        final File dir = currentDir;
        final int generation = listGeneration.incrementAndGet();

        pathView.setText(dir.getAbsolutePath());
        StorageTarget selected = findStorageTarget(rootLimit);
        storageView.setText((selected == null ? storageLabelForRoot(rootLimit) : selected.label) + "  ▾");

        folderList.removeAllViews();
        TextView loading = text("読み込み中…", 14, WHITE_UI);
        loading.setPadding(dp(12), dp(20), dp(12), dp(20));
        folderList.addView(loading);

        AppLog.d(this, "NEXPLORER list begin path=" + dir.getAbsolutePath());
        io.execute(() -> {
            ArrayList<String> names = listDirectoryFolders(dir);
            mainHandler.post(() -> {
                if (isFinishing() || generation != listGeneration.get() || !samePath(currentDir, dir)) return;
                folderList.removeAllViews();
                if (names.isEmpty()) {
                    TextView empty = text("フォルダはありません", 14, WHITE_UI);
                    empty.setPadding(dp(12), dp(22), dp(12), dp(22));
                    folderList.addView(empty);
                } else {
                    for (String name : names) addFolderRow(new File(dir, name));
                }
                scrollHost.post(() -> {
                    scrollHost.scroll.scrollTo(0, 0);
                    scrollHost.updateThumb();
                });
                AppLog.d(this, "NEXPLORER list ready path=" + dir.getAbsolutePath() + " folders=" + names.size());
            });
        });
    }

    private void addFolderRow(File dir) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(dp(8), 0, dp(8), 0);
        row.setBackgroundColor(DARK);

        ImageView icon = new ImageView(this);
        icon.setImageResource(R.drawable.ic_chirami_folder);
        icon.setPadding(dp(6), dp(6), dp(6), dp(6));
        icon.setBackground(roundRect(LBLUE, 9));
        row.addView(icon, new LinearLayout.LayoutParams(dp(32), dp(32)));

        TextView name = text(dir.getName(), 14, TEXT);
        name.setSingleLine(true);
        name.setEllipsize(TextUtils.TruncateAt.END);
        name.setPadding(dp(10), 0, 0, 0);
        row.addView(name, new LinearLayout.LayoutParams(0, dp(38), 1f));

        row.setOnClickListener(v -> {
            currentDir = dir;
            refresh();
        });
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, dp(46));
        lp.bottomMargin = dp(1);
        folderList.addView(row, lp);
    }

    private void showStorageMenu() {
        if (storages.isEmpty()) return;
        LinearLayout list = new LinearLayout(this);
        list.setOrientation(LinearLayout.VERTICAL);
        list.setBackgroundColor(GRAY);
        final PopupWindow[] holder = new PopupWindow[1];
        for (StorageTarget target : storages) {
            TextView row = text(target.label, 16, TEXT);
            row.setGravity(Gravity.CENTER_VERTICAL);
            row.setPadding(dp(16), 0, dp(16), 0);
            row.setOnClickListener(v -> {
                if (holder[0] != null) holder[0].dismiss();
                rootLimit = target.root;
                currentDir = target.root;
                AppLog.d(this, "NEXPLORER storage selected label=" + target.label + " root=" + target.root.getAbsolutePath());
                refresh();
            });
            list.addView(row, new LinearLayout.LayoutParams(dp(260), dp(52)));
        }
        PopupWindow popup = new PopupWindow(list, dp(260), -2, true);
        holder[0] = popup;
        popup.setBackgroundDrawable(new ColorDrawable(GRAY));
        popup.setOutsideTouchable(true);
        if (Build.VERSION.SDK_INT >= 21) popup.setElevation(dp(8));
        popup.showAsDropDown(storageView, 0, dp(2));
    }

    private void showCreateFolder() {
        if (currentDir == null) return;
        EditText input = new EditText(this);
        input.setTextColor(TEXT);
        input.setHintTextColor(LGRAY);
        input.setHint("フォルダ名");
        input.setSingleLine(true);
        input.setInputType(InputType.TYPE_CLASS_TEXT);
        input.setBackground(roundRect(DARK, 8));
        input.setPadding(dp(12), 0, dp(12), 0);

        LinearLayout box = new LinearLayout(this);
        box.setPadding(dp(18), dp(8), dp(18), 0);
        box.addView(input, new LinearLayout.LayoutParams(-1, dp(52)));

        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle("新規フォルダ")
                .setView(box)
                .setNegativeButton("キャンセル", null)
                .setPositiveButton("作成", null)
                .create();
        dialog.setOnShowListener(v -> {
            styleDialog(dialog);
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v2 -> {
                String raw = input.getText().toString().trim();
                if (raw.isEmpty()) {
                    input.setError("フォルダ名を入力してください");
                    return;
                }
                String clean = raw.replaceAll("[\\\\/:*?\"<>|]", "_");
                File out = new File(currentDir, clean);
                if (out.exists()) {
                    input.setError("同名フォルダがあります");
                    return;
                }
                boolean ok = false;
                try { ok = out.mkdir(); } catch (Throwable ignored) { }
                if (!ok) {
                    Toast.makeText(this, "この場所にはフォルダを作成できません", Toast.LENGTH_LONG).show();
                    return;
                }
                AppLog.d(this, "NEXPLORER mkdir path=" + out.getAbsolutePath());
                dialog.dismiss();
                refresh();
            });
        });
        dialog.show();
    }

    private void styleDialog(AlertDialog dialog) {
        if (dialog == null) return;
        Window w = dialog.getWindow();
        if (w != null) {
            w.setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
            View decor = w.getDecorView();
            decor.setBackground(roundRect(GRAY, 10));
            if (Build.VERSION.SDK_INT >= 21) decor.setClipToOutline(true);
        }
        int titleId = getResources().getIdentifier("alertTitle", "id", "android");
        TextView title = dialog.findViewById(titleId);
        if (title != null) title.setTextColor(TEXT);
        if (dialog.getButton(AlertDialog.BUTTON_NEGATIVE) != null) {
            dialog.getButton(AlertDialog.BUTTON_NEGATIVE).setTextColor(TEXT);
            dialog.getButton(AlertDialog.BUTTON_NEGATIVE).setAllCaps(false);
            dialog.getButton(AlertDialog.BUTTON_NEGATIVE).setBackgroundColor(Color.TRANSPARENT);
        }
        if (dialog.getButton(AlertDialog.BUTTON_POSITIVE) != null) {
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setTextColor(TEXT);
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setAllCaps(false);
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setBackgroundColor(Color.TRANSPARENT);
        }
    }

    private void buildStorageTargets() {
        storages.clear();
        HashMap<String, Boolean> seen = new HashMap<>();
        try {
            StorageManager sm = (StorageManager) getSystemService(STORAGE_SERVICE);
            if (sm != null && Build.VERSION.SDK_INT >= 30) {
                int externalNo = 1;
                for (StorageVolume volume : sm.getStorageVolumes()) {
                    File dir = volume.getDirectory();
                    if (dir == null || !dir.exists() || !dir.canRead()) continue;
                    String key = dir.getAbsolutePath();
                    if (seen.put(key, Boolean.TRUE) != null) continue;
                    String label;
                    if (volume.isPrimary()) {
                        label = "内蔵ストレージ";
                    } else {
                        String desc = volume.getDescription(this);
                        String lower = desc == null ? "" : desc.toLowerCase(Locale.ROOT);
                        if (lower.contains("sd") || (desc != null && desc.contains("カード"))) {
                            label = "SDカード";
                        } else {
                            label = externalNo++ == 1 ? "外部ストレージ" : "外部ストレージ " + (externalNo - 1);
                        }
                    }
                    storages.add(new StorageTarget(label, dir));
                }
            }
        } catch (Throwable e) {
            AppLog.d(this, "NEXPLORER storage enumerate error " + e.getClass().getSimpleName());
        }
        if (storages.isEmpty()) {
            File fallback = Environment.getExternalStorageDirectory();
            if (fallback != null) storages.add(new StorageTarget("内蔵ストレージ", fallback));
        }
    }

    private ArrayList<String> listDirectoryFolders(File dir) {
        ArrayList<String> out = new ArrayList<>();
        if (dir == null) return out;
        try {
            String[] names = dir.list();
            if (names == null) return out;
            for (String name : names) {
                if (name == null || name.isEmpty()) continue;
                try {
                    if (new File(dir, name).isDirectory()) out.add(name);
                } catch (Throwable ignored) { }
            }
            Collections.sort(out, String.CASE_INSENSITIVE_ORDER);
        } catch (Throwable e) {
            AppLog.d(this, "NEXPLORER list error path=" + dir.getAbsolutePath() + " " + e);
        }
        return out;
    }

    private File storageRootFor(File dir) {
        if (dir == null) return null;
        String path = dir.getAbsolutePath().replace('\\', '/');
        if (path.startsWith("/storage/emulated/0")) return new File("/storage/emulated/0");
        if (path.startsWith("/storage/")) {
            String rest = path.substring("/storage/".length());
            int slash = rest.indexOf('/');
            String volume = slash >= 0 ? rest.substring(0, slash) : rest;
            if (!volume.isEmpty()) return new File("/storage/" + volume);
        }
        return dir;
    }

    private String storageLabelForRoot(File root) {
        if (root == null) return "ストレージ";
        String path = root.getAbsolutePath();
        if (path.startsWith("/storage/emulated/0")) return "内蔵ストレージ";
        return "SDカード";
    }

    private StorageTarget findStorageTarget(File root) {
        if (root == null) return null;
        for (StorageTarget target : storages) {
            if (samePath(target.root, root)) return target;
        }
        return null;
    }

    private File nearestExistingDirectory(File file) {
        File current = file;
        while (current != null && (!current.exists() || !current.isDirectory())) current = current.getParentFile();
        return current;
    }

    private boolean isWithinRoot(File candidate, File root) {
        if (candidate == null || root == null) return false;
        try {
            String c = candidate.getCanonicalPath();
            String r = root.getCanonicalPath();
            return c.equals(r) || c.startsWith(r + File.separator);
        } catch (Throwable e) {
            return false;
        }
    }

    private boolean samePath(File a, File b) {
        if (a == null || b == null) return false;
        try { return a.getCanonicalFile().equals(b.getCanonicalFile()); }
        catch (Throwable e) { return a.getAbsolutePath().equals(b.getAbsolutePath()); }
    }

    private TextView text(String value, float size, int color) {
        TextView view = new TextView(this);
        view.setText(value);
        view.setTextSize(size);
        view.setTextColor(color);
        view.setGravity(Gravity.CENTER_VERTICAL);
        return view;
    }

    private TextView managerButton(String value) {
        TextView view = text(value, 14, TEXT);
        view.setGravity(Gravity.CENTER);
        return view;
    }

    private TextView actionText(String value) {
        TextView view = text(value, 14, TEXT);
        view.setGravity(Gravity.CENTER);
        view.setSingleLine(true);
        view.setPadding(dp(4), 0, dp(4), 0);
        return view;
    }

    private GradientDrawable roundRect(int color, float radiusDp) {
        GradientDrawable drawable = new GradientDrawable();
        drawable.setColor(color);
        drawable.setCornerRadius(dp(radiusDp));
        return drawable;
    }

    private static final class StorageTarget {
        final String label;
        final File root;
        StorageTarget(String label, File root) {
            this.label = label;
            this.root = root;
        }
    }

    /** Price Rec. diagnostic-log rule: thin visible thumb + 30dp direct-grab hit area. */
    private final class GripScrollHost extends FrameLayout {
        final TrackingScrollView scroll;
        final View thumb;
        final View hit;
        final Handler handler = new Handler(Looper.getMainLooper());
        final Runnable fade = () -> thumb.animate().alpha(0f).setDuration(260).start();
        int thumbHeight;
        boolean dragging;

        GripScrollHost(Context context, View child) {
            super(context);
            scroll = new TrackingScrollView(context);
            scroll.setVerticalScrollBarEnabled(false);
            scroll.addView(child, new ScrollView.LayoutParams(-1, -2));
            addView(scroll, new FrameLayout.LayoutParams(-1, -1));

            thumb = new View(context);
            thumb.setBackground(roundRect(WHITE_UI, 2));
            FrameLayout.LayoutParams thumbParams = new FrameLayout.LayoutParams(dp(4), dp(40), Gravity.END | Gravity.TOP);
            thumbParams.rightMargin = dp(2);
            addView(thumb, thumbParams);

            hit = new View(context);
            FrameLayout.LayoutParams hitParams = new FrameLayout.LayoutParams(dp(30), -1, Gravity.END);
            addView(hit, hitParams);
            hit.setOnTouchListener((v, event) -> handleGrip(event));
            post(this::updateThumb);
        }

        void showThumb() {
            handler.removeCallbacks(fade);
            thumb.animate().cancel();
            thumb.setAlpha(1f);
            if (!dragging) handler.postDelayed(fade, 900);
        }

        void updateThumb() {
            if (scroll.getChildCount() == 0 || getHeight() <= 0) return;
            int content = scroll.getChildAt(0).getHeight();
            int viewport = scroll.getHeight();
            int range = Math.max(0, content - viewport);
            if (range <= 0) {
                thumb.setVisibility(View.GONE);
                return;
            }
            thumb.setVisibility(View.VISIBLE);
            thumbHeight = Math.max(dp(36), Math.round(viewport * (viewport / (float) Math.max(viewport, content))));
            thumbHeight = Math.min(viewport, thumbHeight);
            int track = Math.max(1, viewport - thumbHeight);
            float ratio = scroll.getScrollY() / (float) Math.max(1, range);
            FrameLayout.LayoutParams lp = (FrameLayout.LayoutParams) thumb.getLayoutParams();
            lp.height = thumbHeight;
            lp.topMargin = Math.round(track * ratio);
            lp.gravity = Gravity.END | Gravity.TOP;
            lp.rightMargin = dp(2);
            thumb.setLayoutParams(lp);
        }

        boolean handleGrip(MotionEvent event) {
            if (thumb.getVisibility() != View.VISIBLE) return false;
            switch (event.getActionMasked()) {
                case MotionEvent.ACTION_DOWN:
                    dragging = true;
                    showThumb();
                    moveTo(event.getY());
                    return true;
                case MotionEvent.ACTION_MOVE:
                    moveTo(event.getY());
                    return true;
                case MotionEvent.ACTION_UP:
                case MotionEvent.ACTION_CANCEL:
                    dragging = false;
                    showThumb();
                    return true;
                default:
                    return false;
            }
        }

        void moveTo(float y) {
            if (scroll.getChildCount() == 0) return;
            int content = scroll.getChildAt(0).getHeight();
            int viewport = scroll.getHeight();
            int range = Math.max(0, content - viewport);
            int track = Math.max(1, viewport - thumbHeight);
            float ratio = Math.max(0f, Math.min(1f, (y - thumbHeight / 2f) / track));
            scroll.scrollTo(0, Math.round(range * ratio));
            updateThumb();
        }

        final class TrackingScrollView extends ScrollView {
            TrackingScrollView(Context context) { super(context); }

            @Override
            protected void onScrollChanged(int l, int t, int oldl, int oldt) {
                super.onScrollChanged(l, t, oldl, oldt);
                updateThumb();
                showThumb();
            }

            @Override
            protected void onSizeChanged(int w, int h, int oldw, int oldh) {
                super.onSizeChanged(w, h, oldw, oldh);
                post(GripScrollHost.this::updateThumb);
            }
        }
    }
}
