package com.chirami.viewer;

import android.app.Activity;
import android.app.AlertDialog;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.Environment;
import android.os.storage.StorageManager;
import android.os.storage.StorageVolume;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.PopupWindow;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * One shared Chirami folder explorer dialog.
 * Settings save destination, Viewer save destination, Copy and Move all use this component.
 */
public final class SaveDestinationExplorer {
    private static final int PANEL = Color.rgb(42, 34, 34);      // viewer explorer #2A2222
    private static final int ROW_PANEL = Color.rgb(58, 51, 51);  // viewer explorer #3A3333
    private static final int ACCENT = Color.rgb(68, 85, 119);    // N light blue #445577
    private static final int MUTED = Color.rgb(185, 180, 180);
    private static final int DISABLED = Color.rgb(160, 155, 155);
    private static final ExecutorService IO = Executors.newSingleThreadExecutor();

    public interface OnChanged { void onChanged(); }
    public interface OnFolderSelected { void onSelected(File folder); }
    public interface CreateFolderHandler { void show(File parent, Runnable refresh); }

    private SaveDestinationExplorer() { }

    /** Settings / Viewer-menu save destination. */
    public static void show(Activity activity, OnChanged onChanged) {
        File configured = SavePrefs.directory(activity);
        File start = nearestExistingDirectory(configured);
        if (start == null) start = Environment.getExternalStorageDirectory();
        final File initial = start;
        showInternal(activity, initial, "保存先", "このフォルダを使用", "Pictures/Chirami",
                folder -> {
                    SavePrefs.setDirectory(activity, folder);
                    Toast.makeText(activity, "保存先を設定しました", Toast.LENGTH_SHORT).show();
                    if (onChanged != null) onChanged.onChanged();
                },
                () -> {
                    SavePrefs.reset(activity);
                    Toast.makeText(activity, "保存先を Pictures/Chirami に戻しました", Toast.LENGTH_SHORT).show();
                    if (onChanged != null) onChanged.onChanged();
                },
                null);
    }

    /** Viewer copy / move. Same explorer component; only title and completion action differ. */
    public static void showForTransfer(Activity activity, File start, boolean move,
                                       OnFolderSelected onSelected, CreateFolderHandler createFolderHandler) {
        showInternal(activity, start, move ? "移動先" : "コピー先", move ? "移動" : "コピー", null,
                onSelected, null, createFolderHandler);
    }

    private static void showInternal(Activity activity, File requestedStart,
                                     String titleText, String positiveText, String neutralText,
                                     OnFolderSelected onSelected, Runnable onNeutral,
                                     CreateFolderHandler createFolderHandler) {
        if (activity == null || activity.isFinishing()) return;
        File start = nearestExistingDirectory(requestedStart);
        if (start == null) start = Environment.getExternalStorageDirectory();
        if (start == null) return;

        final File[] currentDir = new File[]{start};
        final File[] rootLimit = new File[]{storageRootFor(start)};
        final ArrayList<StorageTarget> storageTargets = discoverStorageTargets(activity, start);
        final AtomicInteger generation = new AtomicInteger();

        LinearLayout content = new LinearLayout(activity);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(dp(activity, 14), dp(activity, 2), dp(activity, 14), dp(activity, 8));
        content.setBackgroundColor(PANEL);

        TextView storageSelector = new TextView(activity);
        storageSelector.setTextColor(Color.WHITE);
        storageSelector.setTextSize(16);
        storageSelector.setGravity(Gravity.CENTER_VERTICAL);
        storageSelector.setPadding(dp(activity, 12), 0, dp(activity, 12), 0);
        GradientDrawable selectorBg = new GradientDrawable();
        selectorBg.setColor(ROW_PANEL);
        selectorBg.setCornerRadius(dp(activity, 10));
        storageSelector.setBackground(selectorBg);
        content.addView(storageSelector, new LinearLayout.LayoutParams(-1, dp(activity, 42)));

        TextView pathView = new TextView(activity);
        pathView.setTextColor(MUTED);
        pathView.setTextSize(12);
        pathView.setSingleLine(true);
        pathView.setEllipsize(TextUtils.TruncateAt.START);
        pathView.setPadding(dp(activity, 4), dp(activity, 7), dp(activity, 4), dp(activity, 7));
        content.addView(pathView, new LinearLayout.LayoutParams(-1, dp(activity, 36)));

        LinearLayout nav = new LinearLayout(activity);
        nav.setOrientation(LinearLayout.HORIZONTAL);
        nav.setGravity(Gravity.CENTER_VERTICAL);
        TextView parentButton = makeManagerButton(activity, "‹  戻る");
        TextView newFolderButton = makeManagerButton(activity, "＋  新規フォルダ");
        nav.addView(parentButton, new LinearLayout.LayoutParams(0, dp(activity, 44), 1f));
        nav.addView(newFolderButton, new LinearLayout.LayoutParams(0, dp(activity, 44), 1f));
        content.addView(nav);

        ScrollView scroll = new ScrollView(activity);
        scroll.setVerticalScrollBarEnabled(true);
        scroll.setScrollBarStyle(View.SCROLLBARS_INSIDE_OVERLAY);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            GradientDrawable thumb = new GradientDrawable();
            thumb.setColor(Color.rgb(90, 85, 85));
            thumb.setCornerRadius(dp(activity, 2));
            thumb.setSize(dp(activity, 3), dp(activity, 36));
            scroll.setVerticalScrollbarThumbDrawable(thumb);
            GradientDrawable track = new GradientDrawable();
            track.setColor(Color.TRANSPARENT);
            scroll.setVerticalScrollbarTrackDrawable(track);
        }
        LinearLayout folders = new LinearLayout(activity);
        folders.setOrientation(LinearLayout.VERTICAL);
        scroll.addView(folders, new ScrollView.LayoutParams(-1, -2));
        content.addView(scroll, new LinearLayout.LayoutParams(-1, dp(activity, 440)));

        final Runnable[] refresh = new Runnable[1];
        final Runnable updateStorageLabel = () -> {
            StorageTarget selected = findStorageTarget(storageTargets, rootLimit[0]);
            storageSelector.setText((selected == null ? storageLabelForRoot(rootLimit[0]) : selected.label) + "  ▾");
        };

        refresh[0] = () -> {
            final File dir = currentDir[0];
            final int token = generation.incrementAndGet();
            pathView.setText(dir.getAbsolutePath());
            updateStorageLabel.run();
            folders.removeAllViews();
            TextView loading = new TextView(activity);
            loading.setText("読み込み中…");
            loading.setTextColor(DISABLED);
            loading.setPadding(dp(activity, 12), dp(activity, 20), dp(activity, 12), dp(activity, 20));
            folders.addView(loading);

            IO.execute(() -> {
                final ArrayList<String> names = listDirectoryFolders(dir);
                activity.runOnUiThread(() -> {
                    if (activity.isFinishing() || token != generation.get()) return;
                    if (!sameFilePath(currentDir[0], dir)) return;
                    folders.removeAllViews();
                    if (names.isEmpty()) {
                        TextView empty = new TextView(activity);
                        empty.setText("フォルダはありません");
                        empty.setTextColor(DISABLED);
                        empty.setPadding(dp(activity, 12), dp(activity, 22), dp(activity, 12), dp(activity, 22));
                        folders.addView(empty);
                    }
                    for (String name : names) {
                        File child = new File(dir, name);
                        LinearLayout row = makeFolderRow(activity, name);
                        row.setOnClickListener(v -> {
                            currentDir[0] = child;
                            refresh[0].run();
                        });
                        LinearLayout.LayoutParams rp = new LinearLayout.LayoutParams(-1, dp(activity, 46));
                        rp.bottomMargin = dp(activity, 1);
                        folders.addView(row, rp);
                    }
                });
            });
        };

        storageSelector.setOnClickListener(v -> showStorageSelectorPopup(activity, storageSelector, storageTargets, target -> {
            if (target == null || target.root == null) return;
            rootLimit[0] = target.root;
            currentDir[0] = target.root;
            refresh[0].run();
        }));

        parentButton.setOnClickListener(v -> {
            File parent = currentDir[0].getParentFile();
            if (parent == null) return;
            if (rootLimit[0] != null && !isWithinRoot(parent, rootLimit[0])) return;
            currentDir[0] = parent;
            refresh[0].run();
        });

        newFolderButton.setOnClickListener(v -> {
            if (createFolderHandler != null) createFolderHandler.show(currentDir[0], refresh[0]);
            else showCreateFolderDialog(activity, currentDir[0], refresh[0]);
        });

        AlertDialog.Builder builder = new AlertDialog.Builder(activity)
                .setTitle(titleText)
                .setView(content)
                .setNegativeButton("キャンセル", null)
                .setPositiveButton(positiveText, null);
        if (neutralText != null) builder.setNeutralButton(neutralText, null);
        AlertDialog dialog = builder.create();
        prepareDialog(activity, dialog);
        dialog.setCanceledOnTouchOutside(true);
        dialog.setOnShowListener(v -> {
            int titleId = activity.getResources().getIdentifier("alertTitle", "id", "android");
            TextView title = dialog.findViewById(titleId);
            if (title != null) {
                title.setTextColor(Color.WHITE);
                title.setTextSize(18);
            }
            styleTextAction(dialog.getButton(AlertDialog.BUTTON_NEGATIVE));
            styleTextAction(dialog.getButton(AlertDialog.BUTTON_POSITIVE));
            if (neutralText != null) styleTextAction(dialog.getButton(AlertDialog.BUTTON_NEUTRAL));

            if (neutralText != null && onNeutral != null) {
                dialog.getButton(AlertDialog.BUTTON_NEUTRAL).setOnClickListener(v2 -> {
                    onNeutral.run();
                    dialog.dismiss();
                });
            }
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v2 -> {
                File chosen = currentDir[0];
                if (chosen == null) return;
                if (onSelected != null) onSelected.onSelected(chosen);
                dialog.dismiss();
            });
            refresh[0].run();
        });
        dialog.setOnDismissListener(v -> generation.incrementAndGet());
        dialog.show();
    }

    private static void prepareDialog(Activity activity, AlertDialog dialog) {
        if (dialog.getWindow() == null) return;
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        dialog.getWindow().setWindowAnimations(R.style.Animation_Chirami_Dialog);
        View decor = dialog.getWindow().getDecorView();
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(PANEL);
        bg.setCornerRadius(dp(activity, 10));
        decor.setBackground(bg);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) decor.setClipToOutline(true);
        WindowManager.LayoutParams lp = new WindowManager.LayoutParams();
        lp.copyFrom(dialog.getWindow().getAttributes());
        lp.width = (int) (activity.getResources().getDisplayMetrics().widthPixels * 0.94f);
        dialog.getWindow().setAttributes(lp);
    }

    private static void styleTextAction(TextView button) {
        if (button == null) return;
        button.setTextColor(Color.WHITE);
        button.setAllCaps(false);
        button.setBackground(new ColorDrawable(Color.TRANSPARENT));
        button.setStateListAnimator(null);
    }

    private static TextView makeManagerButton(Activity activity, String text) {
        TextView b = new TextView(activity);
        b.setText(text);
        b.setTextColor(Color.WHITE);
        b.setTextSize(14);
        b.setGravity(Gravity.CENTER);
        return b;
    }

    private static LinearLayout makeFolderRow(Activity activity, String name) {
        LinearLayout row = new LinearLayout(activity);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(dp(activity, 8), 0, dp(activity, 8), 0);
        row.setBackgroundColor(ROW_PANEL);

        ImageView icon = new ImageView(activity);
        icon.setImageResource(R.drawable.ic_chirami_folder);
        icon.setPadding(dp(activity, 6), dp(activity, 6), dp(activity, 6), dp(activity, 6));
        GradientDrawable ibg = new GradientDrawable();
        ibg.setColor(ACCENT);
        ibg.setCornerRadius(dp(activity, 9));
        icon.setBackground(ibg);
        row.addView(icon, new LinearLayout.LayoutParams(dp(activity, 32), dp(activity, 32)));

        LinearLayout textBox = new LinearLayout(activity);
        textBox.setOrientation(LinearLayout.VERTICAL);
        textBox.setGravity(Gravity.CENTER_VERTICAL);
        textBox.setPadding(dp(activity, 10), 0, 0, 0);
        TextView title = new TextView(activity);
        title.setText(name);
        title.setTextColor(Color.WHITE);
        title.setTextSize(14);
        title.setSingleLine(true);
        title.setEllipsize(TextUtils.TruncateAt.END);
        textBox.addView(title, new LinearLayout.LayoutParams(-1, dp(activity, 30)));
        row.addView(textBox, new LinearLayout.LayoutParams(0, dp(activity, 38), 1f));
        return row;
    }

    private static void showCreateFolderDialog(Activity activity, File parent, Runnable refresh) {
        if (parent == null) return;
        EditText input = new EditText(activity);
        input.setTextColor(Color.WHITE);
        input.setHintTextColor(DISABLED);
        input.setHint("フォルダ名");
        input.setSingleLine(true);
        input.setSelectAllOnFocus(false);
        input.setPadding(dp(activity, 12), 0, dp(activity, 12), 0);
        GradientDrawable fieldBg = new GradientDrawable();
        fieldBg.setColor(Color.rgb(37, 32, 32));
        fieldBg.setCornerRadius(dp(activity, 8));
        input.setBackground(fieldBg);

        LinearLayout box = new LinearLayout(activity);
        box.setPadding(dp(activity, 18), dp(activity, 8), dp(activity, 18), 0);
        box.addView(input, new LinearLayout.LayoutParams(-1, dp(activity, 52)));

        AlertDialog dialog = new AlertDialog.Builder(activity)
                .setTitle("新規フォルダ")
                .setView(box)
                .setNegativeButton("キャンセル", null)
                .setPositiveButton("作成", null)
                .create();
        prepareDialog(activity, dialog);
        dialog.setOnShowListener(v -> {
            int titleId = activity.getResources().getIdentifier("alertTitle", "id", "android");
            TextView title = dialog.findViewById(titleId);
            if (title != null) title.setTextColor(Color.WHITE);
            styleTextAction(dialog.getButton(AlertDialog.BUTTON_NEGATIVE));
            styleTextAction(dialog.getButton(AlertDialog.BUTTON_POSITIVE));
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v2 -> {
                String raw = input.getText().toString().trim();
                if (raw.isEmpty()) {
                    input.setError("フォルダ名を入力してください");
                    return;
                }
                String clean = raw.replaceAll("[\\\\/:*?\"<>|]", "_");
                File out = new File(parent, clean);
                if (out.exists()) {
                    input.setError("同名フォルダがあります");
                    return;
                }
                boolean ok = false;
                try { ok = out.mkdir(); } catch (Throwable ignored) { }
                if (!ok) {
                    Toast.makeText(activity, "この場所にはフォルダを作成できません", Toast.LENGTH_LONG).show();
                    return;
                }
                dialog.dismiss();
                if (refresh != null) refresh.run();
            });
        });
        dialog.show();
    }

    private interface StorageSelection { void onSelected(StorageTarget target); }

    private static void showStorageSelectorPopup(Activity activity, View anchor, List<StorageTarget> targets, StorageSelection callback) {
        if (targets == null || targets.isEmpty()) return;
        LinearLayout list = new LinearLayout(activity);
        list.setOrientation(LinearLayout.VERTICAL);
        list.setBackgroundColor(ROW_PANEL);
        final PopupWindow[] holder = new PopupWindow[1];
        for (StorageTarget target : targets) {
            TextView row = new TextView(activity);
            row.setText(target.label);
            row.setTextColor(Color.WHITE);
            row.setTextSize(16);
            row.setGravity(Gravity.CENTER_VERTICAL);
            row.setPadding(dp(activity, 16), 0, dp(activity, 16), 0);
            row.setOnClickListener(v -> {
                if (holder[0] != null) holder[0].dismiss();
                if (callback != null) callback.onSelected(target);
            });
            list.addView(row, new LinearLayout.LayoutParams(dp(activity, 260), dp(activity, 52)));
        }
        PopupWindow popup = new PopupWindow(list, dp(activity, 260), -2, true);
        holder[0] = popup;
        popup.setBackgroundDrawable(new ColorDrawable(ROW_PANEL));
        popup.setOutsideTouchable(true);
        popup.setElevation(dp(activity, 8));
        popup.showAsDropDown(anchor, 0, dp(activity, 2));
    }

    private static ArrayList<StorageTarget> discoverStorageTargets(Activity activity, File current) {
        ArrayList<StorageTarget> out = new ArrayList<>();
        Set<String> seen = new HashSet<>();
        try {
            StorageManager sm = (StorageManager) activity.getSystemService(Activity.STORAGE_SERVICE);
            if (sm != null && Build.VERSION.SDK_INT >= 30) {
                int externalNo = 1;
                for (StorageVolume volume : sm.getStorageVolumes()) {
                    File dir = volume.getDirectory();
                    if (dir == null || !dir.exists() || !dir.canRead()) continue;
                    String key = dir.getAbsolutePath();
                    if (!seen.add(key)) continue;
                    String label;
                    if (volume.isPrimary()) label = "内蔵ストレージ";
                    else {
                        String desc = volume.getDescription(activity);
                        String lower = desc == null ? "" : desc.toLowerCase(Locale.ROOT);
                        if (lower.contains("sd") || (desc != null && desc.contains("カード"))) label = "SDカード";
                        else label = externalNo++ == 1 ? "外部ストレージ" : "外部ストレージ " + (externalNo - 1);
                    }
                    out.add(new StorageTarget(label, dir));
                }
            }
        } catch (Throwable ignored) { }
        File currentRoot = storageRootFor(current);
        if (currentRoot != null && currentRoot.exists()) {
            String key = currentRoot.getAbsolutePath();
            if (!seen.contains(key)) out.add(0, new StorageTarget(storageLabelForRoot(currentRoot), currentRoot));
        }
        if (out.isEmpty()) {
            File fallback = Environment.getExternalStorageDirectory();
            if (fallback != null) out.add(new StorageTarget("内蔵ストレージ", fallback));
        }
        return out;
    }

    private static StorageTarget findStorageTarget(List<StorageTarget> targets, File root) {
        if (targets == null || root == null) return null;
        for (StorageTarget target : targets) if (target != null && sameFilePath(target.root, root)) return target;
        return null;
    }

    private static ArrayList<String> listDirectoryFolders(File dir) {
        ArrayList<String> out = new ArrayList<>();
        if (dir == null) return out;
        try {
            String[] names = dir.list();
            if (names == null) return out;
            for (String name : names) {
                if (name == null || name.isEmpty()) continue;
                File child = new File(dir, name);
                try { if (child.isDirectory() && !child.isHidden()) out.add(name); }
                catch (Throwable ignored) { }
            }
            Collections.sort(out, String.CASE_INSENSITIVE_ORDER);
        } catch (Throwable ignored) { }
        return out;
    }

    private static File nearestExistingDirectory(File file) {
        File current = file;
        while (current != null && (!current.exists() || !current.isDirectory())) current = current.getParentFile();
        return current;
    }

    private static String storageLabelForRoot(File root) {
        if (root == null) return "ストレージ";
        String path = root.getAbsolutePath();
        if (path.startsWith("/storage/emulated/0")) return "内蔵ストレージ";
        return "SDカード";
    }

    private static File storageRootFor(File dir) {
        if (dir == null) return null;
        String path = dir.getAbsolutePath().replace('\\', '/');
        if (path.startsWith("/storage/emulated/0")) return new File("/storage/emulated/0");
        if (path.startsWith("/storage/")) {
            String rest = path.substring("/storage/".length());
            int slash = rest.indexOf('/');
            String volume = slash >= 0 ? rest.substring(0, slash) : rest;
            if (!volume.isEmpty()) return new File("/storage/" + volume);
        }
        return dir;
    }

    private static boolean sameFilePath(File a, File b) {
        if (a == null || b == null) return false;
        try { return a.getCanonicalFile().equals(b.getCanonicalFile()); }
        catch (Throwable ignored) { return a.getAbsolutePath().equals(b.getAbsolutePath()); }
    }

    private static boolean isWithinRoot(File candidate, File root) {
        if (candidate == null || root == null) return false;
        try {
            String c = candidate.getCanonicalPath();
            String r = root.getCanonicalPath();
            return c.equals(r) || c.startsWith(r + File.separator);
        } catch (Throwable ignored) { return false; }
    }

    private static int dp(Activity activity, float value) {
        return Math.round(value * activity.getResources().getDisplayMetrics().density);
    }

    private static final class StorageTarget {
        final String label;
        final File root;
        StorageTarget(String label, File root) { this.label = label; this.root = root; }
    }
}
