package com.chirami.viewer;

import android.content.Context;
import android.os.Environment;
import java.io.File;

public final class SavePrefs {
    private static final String PREFS = "chirami_save_prefs";
    private static final String KEY_PATH = "save_directory";

    private SavePrefs() { }

    public static File defaultDirectory() {
        return new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES), "Chirami");
    }

    public static File directory(Context context) {
        String stored = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(KEY_PATH, null);
        if (stored == null || stored.trim().isEmpty()) return defaultDirectory();
        return new File(stored);
    }

    public static void setDirectory(Context context, File directory) {
        if (directory == null) return;
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
                .putString(KEY_PATH, directory.getAbsolutePath()).apply();
    }

    public static void reset(Context context) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().remove(KEY_PATH).apply();
    }

    public static boolean isDefault(Context context) {
        try { return directory(context).getCanonicalFile().equals(defaultDirectory().getCanonicalFile()); }
        catch (Throwable e) { return directory(context).getAbsolutePath().equals(defaultDirectory().getAbsolutePath()); }
    }
}
