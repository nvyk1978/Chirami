package com.chirami.viewer;

import android.graphics.Bitmap;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.util.HashMap;

/** Lightweight single-frame GIF89a encoder used only for static GIF edits. */
final class StaticGifEncoder {
    private StaticGifEncoder() { }

    static void encode(Bitmap bitmap, OutputStream out) throws IOException {
        if (bitmap == null || out == null) throw new IOException("GIF output unavailable");
        int width = bitmap.getWidth();
        int height = bitmap.getHeight();
        if (width < 1 || height < 1 || width > 65535 || height > 65535) throw new IOException("GIF dimensions unsupported");

        byte[] indices = new byte[width * height];
        int[] pixels = new int[width];
        boolean transparent = false;
        int p = 0;
        for (int y = 0; y < height; y++) {
            bitmap.getPixels(pixels, 0, width, 0, y, width, 1);
            for (int x = 0; x < width; x++) {
                int c = pixels[x];
                int a = (c >>> 24) & 0xff;
                if (a < 128) {
                    indices[p++] = 0;
                    transparent = true;
                } else {
                    int r6 = Math.min(5, (((c >>> 16) & 0xff) * 6) >>> 8);
                    int g6 = Math.min(5, (((c >>> 8) & 0xff) * 6) >>> 8);
                    int b6 = Math.min(5, ((c & 0xff) * 6) >>> 8);
                    indices[p++] = (byte)(1 + r6 * 36 + g6 * 6 + b6);
                }
            }
        }

        writeAscii(out, "GIF89a");
        writeLE16(out, width);
        writeLE16(out, height);
        out.write(0xF7); // GCT flag + 8-bit color resolution + 256-entry table
        out.write(0);    // background color index
        out.write(0);    // pixel aspect ratio

        // index 0 is transparent black. indices 1..216 are a 6x6x6 palette.
        out.write(0); out.write(0); out.write(0);
        for (int r = 0; r < 6; r++) {
            for (int g = 0; g < 6; g++) {
                for (int b = 0; b < 6; b++) {
                    out.write(Math.round(r * 255f / 5f));
                    out.write(Math.round(g * 255f / 5f));
                    out.write(Math.round(b * 255f / 5f));
                }
            }
        }
        for (int i = 217; i < 256; i++) { out.write(0); out.write(0); out.write(0); }

        if (transparent) {
            out.write(0x21); out.write(0xF9); out.write(4);
            out.write(1); // transparency flag
            writeLE16(out, 0);
            out.write(0); // transparent index
            out.write(0);
        }

        out.write(0x2C);
        writeLE16(out, 0); writeLE16(out, 0);
        writeLE16(out, width); writeLE16(out, height);
        out.write(0); // no local color table
        out.write(8); // LZW minimum code size
        writeLzwBlocks(indices, out);
        out.write(0x3B);
        out.flush();
    }

    private static void writeLzwBlocks(byte[] data, OutputStream out) throws IOException {
        final int clear = 256;
        final int end = 257;
        int nextCode = 258;
        int codeSize = 9;
        int codeLimit = 1 << codeSize;
        HashMap<Integer, Integer> dict = new HashMap<>();
        BitWriter bits = new BitWriter();
        bits.write(clear, codeSize);
        if (data.length == 0) {
            bits.write(end, codeSize);
            writeSubBlocks(bits.finish(), out);
            return;
        }
        int prefix = data[0] & 0xff;
        for (int i = 1; i < data.length; i++) {
            int k = data[i] & 0xff;
            int key = (prefix << 8) | k;
            Integer code = dict.get(key);
            if (code != null) {
                prefix = code;
                continue;
            }
            bits.write(prefix, codeSize);
            if (nextCode < 4096) {
                dict.put(key, nextCode++);
                if (nextCode > codeLimit && codeSize < 12) {
                    codeSize++;
                    codeLimit = 1 << codeSize;
                }
            } else {
                bits.write(clear, codeSize);
                dict.clear();
                nextCode = 258;
                codeSize = 9;
                codeLimit = 1 << codeSize;
            }
            prefix = k;
        }
        bits.write(prefix, codeSize);
        bits.write(end, codeSize);
        writeSubBlocks(bits.finish(), out);
    }

    private static void writeSubBlocks(byte[] bytes, OutputStream out) throws IOException {
        int offset = 0;
        while (offset < bytes.length) {
            int count = Math.min(255, bytes.length - offset);
            out.write(count);
            out.write(bytes, offset, count);
            offset += count;
        }
        out.write(0);
    }

    private static final class BitWriter {
        private final ByteArrayOutputStream bytes = new ByteArrayOutputStream();
        private int bitBuffer;
        private int bitCount;
        void write(int code, int bits) {
            bitBuffer |= (code << bitCount);
            bitCount += bits;
            while (bitCount >= 8) {
                bytes.write(bitBuffer & 0xff);
                bitBuffer >>>= 8;
                bitCount -= 8;
            }
        }
        byte[] finish() {
            if (bitCount > 0) bytes.write(bitBuffer & 0xff);
            return bytes.toByteArray();
        }
    }

    private static void writeAscii(OutputStream out, String s) throws IOException {
        for (int i = 0; i < s.length(); i++) out.write((byte)s.charAt(i));
    }
    private static void writeLE16(OutputStream out, int value) throws IOException {
        out.write(value & 0xff); out.write((value >>> 8) & 0xff);
    }
}
