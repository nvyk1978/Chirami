package com.chirami.viewer;

import android.content.Context;
import android.content.SharedPreferences;

import java.util.Locale;

final class OpenFormatPrefs {
    static final String JPEG = "jpeg";
    static final String PNG = "png";
    static final String GIF = "gif";
    static final String BMP = "bmp";
    static final String WEBP = "webp";
    static final String HEIC = "heic";
    static final String AVIF = "avif";

    static final String[] KEYS = new String[]{JPEG, PNG, GIF, BMP, WEBP, HEIC, AVIF};
    static final String[] LABELS = new String[]{
            "JPEG  (.jpg / .jpeg)",
            "PNG  (.png)",
            "GIF  (.gif)",
            "BMP  (.bmp)",
            "WebP  (.webp)",
            "HEIC / HEIF",
            "AVIF  (.avif)"
    };

    private static final String PREFS = "open_format_prefs";

    private OpenFormatPrefs() {}

    static boolean isEnabled(Context context, String key) {
        if (key == null || key.isEmpty()) return true;
        return prefs(context).getBoolean("enabled_" + key, true);
    }

    static void setEnabled(Context context, String key, boolean enabled) {
        if (key == null || key.isEmpty()) return;
        prefs(context).edit().putBoolean("enabled_" + key, enabled).apply();
    }

    static String keyFromMime(String mime) {
        if (mime == null) return null;
        String m = mime.toLowerCase(Locale.ROOT);
        if (m.equals("image/jpeg") || m.equals("image/jpg") || m.equals("image/pjpeg")) return JPEG;
        if (m.equals("image/png") || m.equals("image/x-png")) return PNG;
        if (m.equals("image/gif") || m.equals("image/x-gif")) return GIF;
        if (m.equals("image/bmp") || m.equals("image/x-bmp") || m.equals("image/x-ms-bmp")
                || m.equals("image/x-bitmap") || m.equals("image/x-win-bitmap")
                || m.equals("application/bmp") || m.equals("application/x-bmp")) return BMP;
        if (m.equals("image/webp") || m.equals("image/x-webp")) return WEBP;
        if (m.equals("image/heic") || m.equals("image/heif") || m.equals("image/heic-sequence")
                || m.equals("image/heif-sequence")) return HEIC;
        if (m.equals("image/avif")) return AVIF;
        return null;
    }

    static String keyFromName(String name) {
        if (name == null) return null;
        String n = name.toLowerCase(Locale.ROOT);
        if (n.endsWith(".jpg") || n.endsWith(".jpeg") || n.endsWith(".jpe")) return JPEG;
        if (n.endsWith(".png")) return PNG;
        if (n.endsWith(".gif")) return GIF;
        if (n.endsWith(".bmp") || n.endsWith(".dib")) return BMP;
        if (n.endsWith(".webp")) return WEBP;
        if (n.endsWith(".heic") || n.endsWith(".heif")) return HEIC;
        if (n.endsWith(".avif")) return AVIF;
        return null;
    }

    static String mimeForKey(String key, String originalMime) {
        if (JPEG.equals(key)) return "image/jpeg";
        if (PNG.equals(key)) return "image/png";
        if (GIF.equals(key)) return "image/gif";
        if (BMP.equals(key)) return "image/bmp";
        if (WEBP.equals(key)) return "image/webp";
        if (HEIC.equals(key)) return "image/heic";
        if (AVIF.equals(key)) return "image/avif";
        return originalMime;
    }

    private static SharedPreferences prefs(Context context) {
        return context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }
}
