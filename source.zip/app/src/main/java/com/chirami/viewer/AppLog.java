package com.chirami.viewer;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Build;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public final class AppLog {
    private static final String PREF = "chirami_diag";
    private static final String KEY = "log";
    private static final int MAX_CHARS = 60000;
    private static final SimpleDateFormat TIME = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS", Locale.US);

    private AppLog() {}

    public static synchronized void d(Context context, String message) {
        String line = TIME.format(new Date()) + " [" + Thread.currentThread().getName() + "] " + message;
        SharedPreferences p = context.getSharedPreferences(PREF, Context.MODE_PRIVATE);
        String old = p.getString(KEY, "");
        String next = old.isEmpty() ? line : old + "\n" + line;
        if (next.length() > MAX_CHARS) next = next.substring(next.length() - MAX_CHARS);
        p.edit().putString(KEY, next).apply();
    }

    public static synchronized String report(Context context) {
        String versionName = "?";
        int versionCode = 0;
        try {
            android.content.pm.PackageInfo info = context.getPackageManager().getPackageInfo(context.getPackageName(), 0);
            versionName = info.versionName;
            if (Build.VERSION.SDK_INT >= 28) versionCode = (int) info.getLongVersionCode();
            else versionCode = info.versionCode;
        } catch (Throwable ignored) { }

        String log = context.getSharedPreferences(PREF, Context.MODE_PRIVATE).getString(KEY, "");
        return "Chirami diagnostic report\n" +
                "Generated: " + TIME.format(new Date()) + "\n" +
                "Device: " + Build.MANUFACTURER + " " + Build.MODEL + "\n" +
                "Android: " + Build.VERSION.RELEASE + " (SDK " + Build.VERSION.SDK_INT + ")\n" +
                "App: " + versionName + " (" + versionCode + ")\n\n" +
                "--- LOG ---\n" + log;
    }

    public static synchronized void clear(Context context) {
        context.getSharedPreferences(PREF, Context.MODE_PRIVATE).edit().remove(KEY).apply();
    }
}
