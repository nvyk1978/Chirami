package com.chirami.viewer;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Intent;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.view.Gravity;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.core.content.FileProvider;

import java.io.File;
import java.io.FileOutputStream;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends Activity {
    private static final int BLUE = Color.rgb(68, 85, 119);
    private static final int LIGHT_TEXT = Color.rgb(203, 197, 197);

    private static class FormatItem {
        final String label;
        final String extension;
        final String mime;
        FormatItem(String label, String extension, String mime) {
            this.label = label; this.extension = extension; this.mime = mime;
        }
    }

    private final List<FormatItem> formats = new ArrayList<>();
    private final List<FormatItem> setupQueue = new ArrayList<>();
    private int setupIndex = 0;
    private boolean setupRunning = false;
    private boolean leftForSetup = false;
    private int setupAwayReason = 0;
    private static final int SETUP_AWAY_NONE = 0;
    private static final int SETUP_AWAY_PROBE = 1;
    private static final int SETUP_AWAY_DEFAULT_SETTINGS = 2;
    private LinearLayout sortFieldGrid;
    private RadioGroup sortOrderGroup;
    private RadioButton sortByName;
    private RadioButton sortBySize;
    private RadioButton sortByType;
    private RadioButton sortByCreated;
    private RadioButton sortByModified;
    private RadioButton sortAscending;
    private RadioButton sortDescending;
    private boolean syncingSortUi = false;

    private int dp(float value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }

    private android.graphics.drawable.GradientDrawable makeRoundedDialogPanel(int color) {
        android.graphics.drawable.GradientDrawable bg = new android.graphics.drawable.GradientDrawable();
        bg.setColor(color);
        bg.setCornerRadius(dp(10));
        return bg;
    }

    private void prepareRoundedDialog(AlertDialog dialog, int panelColor) {
        if (dialog == null || dialog.getWindow() == null) return;
        dialog.getWindow().setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(Color.TRANSPARENT));
        dialog.getWindow().setWindowAnimations(R.style.Animation_Chirami_Dialog);
        android.view.View decor = dialog.getWindow().getDecorView();
        decor.setBackground(makeRoundedDialogPanel(panelColor));
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.LOLLIPOP) decor.setClipToOutline(true);
    }

    private void styleRoundedDialogButtons(AlertDialog dialog) {
        Button negative = dialog.getButton(AlertDialog.BUTTON_NEGATIVE);
        Button neutral = dialog.getButton(AlertDialog.BUTTON_NEUTRAL);
        Button positive = dialog.getButton(AlertDialog.BUTTON_POSITIVE);
        if (negative != null) {
            negative.setTextColor(Color.WHITE); negative.setAllCaps(false);
            negative.setBackground(new android.graphics.drawable.ColorDrawable(Color.TRANSPARENT));
            negative.setStateListAnimator(null);
        }
        if (neutral != null) {
            neutral.setTextColor(Color.WHITE); neutral.setAllCaps(false);
            neutral.setBackground(new android.graphics.drawable.ColorDrawable(Color.TRANSPARENT));
            neutral.setStateListAnimator(null);
        }
        if (positive != null) {
            positive.setTextColor(Color.WHITE); positive.setAllCaps(false);
            positive.setBackground(new android.graphics.drawable.ColorDrawable(Color.TRANSPARENT));
            positive.setStateListAnimator(null);
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        AppLog.d(this, "SETTINGS onCreate");
        // Android default ownership is intentionally only two buckets now:
        // all images through one image/* gateway, and PDF separately.
        formats.add(new FormatItem("画像全般  (image/*)", ".png", "image/*"));
        formats.add(new FormatItem("PDF  (.pdf)", ".pdf", "application/pdf"));
        buildUi();
    }

    @Override
    protected void onResume() {
        super.onResume();
        syncSortUiFromPrefs();
        if (setupRunning && leftForSetup) {
            final int awayReason = setupAwayReason;
            leftForSetup = false;
            setupAwayReason = SETUP_AWAY_NONE;
            // Resolver / Settings state is not always committed synchronously when the
            // external activity closes. Re-check after a short delay instead of blindly
            // advancing to the next extension.
            new android.os.Handler(getMainLooper()).postDelayed(
                    () -> verifyCurrentSetupItemAfterReturn(awayReason), 550);
        }
    }

    private void buildUi() {
        ScrollView scroll = new ScrollView(this);
        scroll.setBackgroundColor(Color.rgb(48, 48, 48)); // #303030
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(24), dp(28), dp(24), dp(28));
        root.setBackgroundColor(Color.rgb(48, 48, 48)); // #303030
        scroll.addView(root, new ScrollView.LayoutParams(-1, -2));

        // Keep the title visually about 100 px lower on the current device, but express
        // the spacing through dp so the layout remains density-aware.
        int titleOffsetDp = Math.max(1, Math.round(100f / getResources().getDisplayMetrics().density));
        android.view.View titleSpacer = new android.view.View(this);
        root.addView(titleSpacer, new LinearLayout.LayoutParams(1, dp(titleOffsetDp)));

        TextView title = new TextView(this);
        title.setText("Chirami   v" + getVersionName());
        title.setTextColor(Color.WHITE);
        title.setTextSize(30);
        title.setTypeface(null, android.graphics.Typeface.BOLD);
        root.addView(title);

        TextView defaultTitle = text("デフォルト起動", 18, Color.WHITE);
        defaultTitle.setTypeface(null, android.graphics.Typeface.BOLD);
        root.addView(defaultTitle);

        TextView hint = text("Android側では画像を1つの入口（image/*）でChiramiに関連付けます。PNG/GIFなどの個別ON/OFFは、その後Chirami内部で判定します。", 13, LIGHT_TEXT);
        hint.setPadding(0, dp(5), 0, dp(8));
        root.addView(hint);

        ColorStateList checkTint = new ColorStateList(
                new int[][]{ new int[]{android.R.attr.state_checked}, new int[]{} },
                new int[]{BLUE, Color.rgb(90,85,85)});

        LinearLayout formatList = new LinearLayout(this);
        formatList.setOrientation(LinearLayout.VERTICAL);
        for (FormatItem item : formats) {
            LinearLayout row = new LinearLayout(this);
            row.setOrientation(LinearLayout.HORIZONTAL);
            row.setGravity(Gravity.CENTER_VERTICAL);

            TextView label = text(item.label, 14, Color.WHITE);
            row.addView(label, new LinearLayout.LayoutParams(0, dp(46), 1f));

            Button setupOne = makeButton("設定");
            setupOne.setTextSize(13);
            setupOne.setOnClickListener(v -> beginDefaultSetup(item));
            LinearLayout.LayoutParams setupParams = new LinearLayout.LayoutParams(dp(86), dp(38));
            setupParams.leftMargin = dp(10);
            row.addView(setupOne, setupParams);

            formatList.addView(row, new LinearLayout.LayoutParams(-1, dp(48)));
        }
        root.addView(formatList, new LinearLayout.LayoutParams(-1, -2));

        TextView perFormatTitle = text("Chiramiで開く画像形式", 16, Color.WHITE);
        perFormatTitle.setTypeface(null, android.graphics.Typeface.BOLD);
        perFormatTitle.setPadding(0, dp(12), 0, dp(4));
        root.addView(perFormatTitle);

        for (int i = 0; i < OpenFormatPrefs.KEYS.length; i++) {
            final String key = OpenFormatPrefs.KEYS[i];
            LinearLayout row = new LinearLayout(this);
            row.setOrientation(LinearLayout.HORIZONTAL);
            row.setGravity(Gravity.CENTER_VERTICAL);
            TextView label = text(OpenFormatPrefs.LABELS[i], 14, Color.WHITE);
            row.addView(label, new LinearLayout.LayoutParams(0, dp(46), 1f));

            android.widget.Switch toggle = new android.widget.Switch(this);
            toggle.setShowText(true);
            toggle.setTextOn("ON");
            toggle.setTextOff("OFF");
            toggle.setTextColor(Color.WHITE);
            toggle.setChecked(OpenFormatPrefs.isEnabled(this, key));
            toggle.setThumbTintList(new ColorStateList(
                    new int[][]{new int[]{android.R.attr.state_checked}, new int[]{}},
                    new int[]{Color.rgb(169,169,153), Color.rgb(101,96,96)}));
            toggle.setTrackTintList(new ColorStateList(
                    new int[][]{new int[]{android.R.attr.state_checked}, new int[]{}},
                    new int[]{BLUE, Color.rgb(37,32,32)}));
            toggle.setOnCheckedChangeListener((buttonView, checked) -> {
                OpenFormatPrefs.setEnabled(this, key, checked);
                AppLog.d(this, "OPEN_FORMAT key=" + key + " enabled=" + checked);
            });
            row.addView(toggle, new LinearLayout.LayoutParams(dp(92), dp(46)));
            root.addView(row, new LinearLayout.LayoutParams(-1, dp(48)));
        }

        TextView osHint = text("画像の形式判定は MIME → ファイル名 → ファイル先頭の実データ（PNG/GIF/JPEG/BMP/WebP/HEIC/AVIF）の順で行います。OFFの形式はChiramiで表示せず、他の対応アプリを選べます。", 12, LIGHT_TEXT);
        osHint.setPadding(0, dp(9), 0, dp(26));
        root.addView(osHint);

        TextView sortTitle = text("スライド順", 18, Color.WHITE);
        sortTitle.setTypeface(null, android.graphics.Typeface.BOLD);
        root.addView(sortTitle);

        TextView sortHint = text("画像を横スワイプするときの並び順です。画像表示中のメニューからも変更できます。", 13, LIGHT_TEXT);
        sortHint.setPadding(0, dp(5), 0, dp(8));
        root.addView(sortHint);

        sortFieldGrid = new LinearLayout(this);
        sortFieldGrid.setOrientation(LinearLayout.VERTICAL);
        sortByName = makeSortRadio("名前", false, checkTint);
        sortBySize = makeSortRadio("サイズ", false, checkTint);
        sortByType = makeSortRadio("種類", false, checkTint);
        sortByCreated = makeSortRadio("作成日", false, checkTint);
        sortByModified = makeSortRadio("最終更新日", false, checkTint);
        RadioButton[] fieldButtons = new RadioButton[]{
                sortByName, sortBySize, sortByType, sortByCreated, sortByModified
        };
        for (int i = 0; i < fieldButtons.length; i += 2) {
            LinearLayout row = new LinearLayout(this);
            row.setOrientation(LinearLayout.HORIZONTAL);
            for (int col = 0; col < 2; col++) {
                int index = i + col;
                if (index < fieldButtons.length) {
                    RadioButton button = fieldButtons[index];
                    row.addView(button, new LinearLayout.LayoutParams(0, dp(44), 1f));
                    button.setOnClickListener(v -> selectSortField((RadioButton) v, true));
                } else {
                    row.addView(new android.view.View(this), new LinearLayout.LayoutParams(0, dp(44), 1f));
                }
            }
            sortFieldGrid.addView(row, new LinearLayout.LayoutParams(-1, dp(44)));
        }
        root.addView(sortFieldGrid, new LinearLayout.LayoutParams(-1, -2));

        TextView directionLabel = text("方向", 13, LIGHT_TEXT);
        directionLabel.setPadding(0, dp(8), 0, dp(1));
        root.addView(directionLabel);

        sortOrderGroup = new RadioGroup(this);
        sortOrderGroup.setOrientation(RadioGroup.HORIZONTAL);
        sortAscending = makeSortRadio("左から", false, checkTint);
        sortDescending = makeSortRadio("右から", false, checkTint);
        sortOrderGroup.addView(sortAscending, new RadioGroup.LayoutParams(0, dp(46), 1f));
        sortOrderGroup.addView(sortDescending, new RadioGroup.LayoutParams(0, dp(46), 1f));
        LinearLayout.LayoutParams orderParams = new LinearLayout.LayoutParams(-1, dp(46));
        orderParams.bottomMargin = dp(26);
        root.addView(sortOrderGroup, orderParams);

        sortOrderGroup.setOnCheckedChangeListener((g, id) -> persistSortFromUi());
        syncSortUiFromPrefs();

        Button diagEntry = makeButton("診断ログ");
        diagEntry.setOnClickListener(v -> showDiagnosticLogDialog());
        LinearLayout.LayoutParams diagParams = new LinearLayout.LayoutParams(-1, dp(52));
        diagParams.topMargin = dp(2);
        root.addView(diagEntry, diagParams);

        String versionName = getVersionName();
        TextView version = text("v" + versionName, 12, Color.rgb(145,140,140));
        version.setGravity(Gravity.END);
        version.setPadding(0, dp(28), 0, 0);
        root.addView(version);

        setContentView(scroll);
    }

    private TextView text(String s, float size, int color) {
        TextView t = new TextView(this);
        t.setText(s); t.setTextSize(size); t.setTextColor(color);
        return t;
    }

    private RadioButton makeSortRadio(String label, boolean checked, ColorStateList tint) {
        RadioButton b = new RadioButton(this);
        b.setId(android.view.View.generateViewId());
        b.setText(label); b.setTextColor(Color.WHITE); b.setTextSize(15); b.setChecked(checked);
        b.setButtonTintList(tint); b.setGravity(Gravity.CENTER_VERTICAL);
        b.setPadding(0, dp(2), 0, dp(2));
        return b;
    }

    private void syncSortUiFromPrefs() {
        if (sortFieldGrid == null || sortOrderGroup == null) return;
        syncingSortUi = true;
        String field = SortPrefs.field(this);
        RadioButton selected = SortPrefs.FIELD_SIZE.equals(field) ? sortBySize
                : (SortPrefs.FIELD_TYPE.equals(field) ? sortByType
                : (SortPrefs.FIELD_CREATED.equals(field) ? sortByCreated
                : (SortPrefs.FIELD_MODIFIED.equals(field) ? sortByModified : sortByName)));
        selectSortField(selected, false);
        sortOrderGroup.check((SortPrefs.ascending(this) ? sortAscending : sortDescending).getId());
        syncingSortUi = false;
    }

    private void selectSortField(RadioButton selected, boolean persist) {
        if (selected == null) return;
        boolean wasSyncing = syncingSortUi;
        syncingSortUi = true;
        sortByName.setChecked(selected == sortByName);
        sortBySize.setChecked(selected == sortBySize);
        sortByType.setChecked(selected == sortByType);
        sortByCreated.setChecked(selected == sortByCreated);
        sortByModified.setChecked(selected == sortByModified);
        syncingSortUi = wasSyncing;
        if (persist && !syncingSortUi) persistSortFromUi();
    }

    private void persistSortFromUi() {
        if (syncingSortUi || sortFieldGrid == null || sortOrderGroup == null) return;
        if (sortOrderGroup.getCheckedRadioButtonId() == -1) return;
        String field = sortBySize.isChecked() ? SortPrefs.FIELD_SIZE
                : (sortByType.isChecked() ? SortPrefs.FIELD_TYPE
                : (sortByCreated.isChecked() ? SortPrefs.FIELD_CREATED
                : (sortByModified.isChecked() ? SortPrefs.FIELD_MODIFIED : SortPrefs.FIELD_NAME)));
        SortPrefs.save(this, field, sortAscending.isChecked());
        AppLog.d(this, "SORT settings field=" + field + " asc=" + sortAscending.isChecked());
    }

    private Button makeButton(String label) {
        Button b = new Button(this);
        b.setText(label); b.setTextColor(Color.WHITE); b.setTextSize(15); b.setAllCaps(false);
        b.setBackgroundTintList(ColorStateList.valueOf(BLUE));
        return b;
    }

    private void beginDefaultSetup(FormatItem item) {
        if (item == null) return;
        setupQueue.clear();
        setupQueue.add(item);
        setupIndex = 0;
        setupRunning = true;
        leftForSetup = false;
        setupAwayReason = SETUP_AWAY_NONE;
        AppLog.d(this, "DEFAULT_SETUP start single=" + item.label + " mime=" + item.mime);
        launchCurrentSetupItem();
    }

    private static class DefaultResolveState {
        final Intent intent;
        final Uri uri;
        final java.util.List<android.content.pm.ResolveInfo> candidates;
        final android.content.pm.ResolveInfo resolved;
        final boolean chiramiCandidate;
        final boolean chiramiDefault;
        final String resolvedPackage;
        final String resolvedComponent;

        DefaultResolveState(Intent intent, Uri uri,
                            java.util.List<android.content.pm.ResolveInfo> candidates,
                            android.content.pm.ResolveInfo resolved,
                            boolean chiramiCandidate, boolean chiramiDefault,
                            String resolvedPackage, String resolvedComponent) {
            this.intent = intent;
            this.uri = uri;
            this.candidates = candidates;
            this.resolved = resolved;
            this.chiramiCandidate = chiramiCandidate;
            this.chiramiDefault = chiramiDefault;
            this.resolvedPackage = resolvedPackage;
            this.resolvedComponent = resolvedComponent;
        }
    }

    private DefaultResolveState inspectDefaultSetupItem(FormatItem item) throws Exception {
        Uri uri = makeProbeFile(item);
        Intent intent = new Intent(Intent.ACTION_VIEW);
        intent.setDataAndType(uri, item.mime);
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);

        android.content.pm.PackageManager pm = getPackageManager();
        java.util.List<android.content.pm.ResolveInfo> candidates =
                pm.queryIntentActivities(intent, android.content.pm.PackageManager.MATCH_DEFAULT_ONLY);
        android.content.pm.ResolveInfo resolved =
                pm.resolveActivity(intent, android.content.pm.PackageManager.MATCH_DEFAULT_ONLY);

        boolean chiramiCandidate = false;
        if (candidates != null) {
            for (android.content.pm.ResolveInfo ri : candidates) {
                if (ri == null || ri.activityInfo == null) continue;
                String component = ri.activityInfo.packageName + "/" + ri.activityInfo.name;
                AppLog.d(this, "DEFAULT_SETUP candidate " + item.label
                        + " component=" + component
                        + " match=0x" + Integer.toHexString(ri.match)
                        + " priority=" + ri.priority
                        + " preferredOrder=" + ri.preferredOrder);
                if (getPackageName().equals(ri.activityInfo.packageName)) {
                    chiramiCandidate = true;
                }
            }
        }
        String resolvedPackage = resolved == null || resolved.activityInfo == null
                ? null : resolved.activityInfo.packageName;
        String resolvedComponent = resolved == null || resolved.activityInfo == null
                ? "none" : resolved.activityInfo.packageName + "/" + resolved.activityInfo.name;
        boolean chiramiDefault = getPackageName().equals(resolvedPackage);

        AppLog.d(this, "DEFAULT_SETUP resolve " + item.label + " mime=" + item.mime
                + " candidates=" + (candidates == null ? 0 : candidates.size())
                + " chiramiCandidate=" + chiramiCandidate
                + " chiramiDefault=" + chiramiDefault
                + " resolved=" + resolvedComponent);
        return new DefaultResolveState(intent, uri, candidates, resolved, chiramiCandidate,
                chiramiDefault, resolvedPackage, resolvedComponent);
    }

    private void launchCurrentSetupItem() {
        if (!setupRunning || setupIndex >= setupQueue.size()) return;
        FormatItem item = setupQueue.get(setupIndex);
        try {
            DefaultResolveState state = inspectDefaultSetupItem(item);
            if (state.chiramiDefault) {
                AppLog.d(this, "DEFAULT_SETUP already default " + item.label);
                advanceDefaultSetupItem();
                return;
            }
            if (!state.chiramiCandidate) {
                AppLog.d(this, "DEFAULT_SETUP chirami missing from candidates " + item.label);
                showChiramiMissingDialog(item, state);
                return;
            }
            if (isSpecificOtherDefault(state)) {
                AppLog.d(this, "DEFAULT_SETUP other default " + item.label
                        + " package=" + state.resolvedPackage);
                showOtherDefaultDialog(item, state.resolvedPackage);
                return;
            }
            AppLog.d(this, "DEFAULT_SETUP launch resolver " + item.label
                    + " mime=" + item.mime + " uri=" + state.uri);
            leftForSetup = true;
            setupAwayReason = SETUP_AWAY_PROBE;
            startActivity(state.intent);
        } catch (Throwable e) {
            AppLog.d(this, "DEFAULT_SETUP error " + item.label + " " + e);
            showSetupFailureDialog(item, "起動確認に失敗しました。\n" + e.getClass().getSimpleName());
        }
    }

    private boolean isSpecificOtherDefault(DefaultResolveState state) {
        if (state == null || state.resolvedPackage == null) return false;
        if (getPackageName().equals(state.resolvedPackage)) return false;
        // With multiple handlers and no preferred app Android normally resolves to the
        // framework resolver (package android / a resolver activity). A concrete third-party
        // package here means that package currently owns the preferred association.
        if ("android".equals(state.resolvedPackage)
                || "com.android.intentresolver".equals(state.resolvedPackage)) return false;
        return state.chiramiCandidate;
    }

    private void verifyCurrentSetupItemAfterReturn(int awayReason) {
        if (!setupRunning || setupIndex >= setupQueue.size()) return;
        FormatItem item = setupQueue.get(setupIndex);
        try {
            DefaultResolveState state = inspectDefaultSetupItem(item);
            if (state.chiramiDefault) {
                AppLog.d(this, "DEFAULT_SETUP confirmed " + item.label
                        + " after=" + awayReasonName(awayReason));
                advanceDefaultSetupItem();
                return;
            }
            if (!state.chiramiCandidate) {
                showChiramiMissingDialog(item, state);
                return;
            }
            if (isSpecificOtherDefault(state)) {
                showOtherDefaultDialog(item, state.resolvedPackage);
                return;
            }
            if (awayReason == SETUP_AWAY_DEFAULT_SETTINGS) {
                // The competing preferred app has just been cleared. Do not make the user
                // press another retry button: immediately reopen the probe for this same format.
                AppLog.d(this, "DEFAULT_SETUP competing default cleared; relaunch resolver "
                        + item.label);
                new android.os.Handler(getMainLooper()).postDelayed(this::launchCurrentSetupItem, 250);
                return;
            }
            AppLog.d(this, "DEFAULT_SETUP not confirmed " + item.label
                    + " after=" + awayReasonName(awayReason));
            showNotConfirmedDialog(item);
        } catch (Throwable e) {
            AppLog.d(this, "DEFAULT_SETUP verify error " + item.label + " " + e);
            showSetupFailureDialog(item, "既定状態の確認に失敗しました。\n" + e.getClass().getSimpleName());
        }
    }

    private String awayReasonName(int reason) {
        if (reason == SETUP_AWAY_PROBE) return "resolver";
        if (reason == SETUP_AWAY_DEFAULT_SETTINGS) return "default-settings";
        return "unknown";
    }

    private void advanceDefaultSetupItem() {
        setupIndex++;
        leftForSetup = false;
        setupAwayReason = SETUP_AWAY_NONE;
        if (setupIndex < setupQueue.size()) {
            new android.os.Handler(getMainLooper()).postDelayed(this::launchCurrentSetupItem, 300);
        } else {
            setupRunning = false;
            AppLog.d(this, "DEFAULT_SETUP sequence finished");
            Toast.makeText(this, "この形式はChiramiで開く設定になっています", Toast.LENGTH_SHORT).show();
        }
    }

    private void skipDefaultSetupItem() {
        if (!setupRunning || setupIndex >= setupQueue.size()) return;
        AppLog.d(this, "DEFAULT_SETUP skipped " + setupQueue.get(setupIndex).label);
        setupRunning = false;
        leftForSetup = false;
        setupAwayReason = SETUP_AWAY_NONE;
        Toast.makeText(this, "この形式の設定をスキップしました", Toast.LENGTH_SHORT).show();
    }

    private String appLabelForPackage(String packageName) {
        if (packageName == null || packageName.isEmpty()) return "別のアプリ";
        try {
            android.content.pm.ApplicationInfo ai = getPackageManager().getApplicationInfo(packageName, 0);
            CharSequence label = getPackageManager().getApplicationLabel(ai);
            if (label != null && label.length() > 0) return label.toString();
        } catch (Throwable ignored) {}
        return packageName;
    }

    private void showOtherDefaultDialog(FormatItem item, String packageName) {
        if (!setupRunning) return;
        String appLabel = appLabelForPackage(packageName);
        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle(item.label + " の既定アプリ")
                .setMessage("現在は「" + appLabel + "」が既定になっています。\n\n"
                        + "Androidの設定でこのアプリの既定設定を解除してから戻ってください。戻るとChiramiが自動で再確認します。")
                .setNegativeButton("キャンセル", (d, w) -> cancelDefaultSetup())
                .setNeutralButton("スキップ", (d, w) -> skipDefaultSetupItem())
                .setPositiveButton("設定を開く", (d, w) -> openDefaultSettingsForPackage(packageName))
                .create();
        prepareRoundedDialog(dialog, Color.rgb(58, 51, 51));
        dialog.setOnShowListener(v -> styleRoundedDialogButtons(dialog));
        dialog.show();
    }

    private void openDefaultSettingsForPackage(String packageName) {
        try {
            Uri packageUri = Uri.parse("package:" + packageName);
            Intent settingsIntent = null;
            if (android.os.Build.VERSION.SDK_INT >= 31) {
                Intent direct = new Intent("android.settings.APP_OPEN_BY_DEFAULT_SETTINGS", packageUri);
                if (direct.resolveActivity(getPackageManager()) != null) settingsIntent = direct;
            }
            if (settingsIntent == null) {
                settingsIntent = new Intent(android.provider.Settings.ACTION_APPLICATION_DETAILS_SETTINGS, packageUri);
            }
            AppLog.d(this, "DEFAULT_SETUP open settings package=" + packageName
                    + " action=" + settingsIntent.getAction());
            leftForSetup = true;
            setupAwayReason = SETUP_AWAY_DEFAULT_SETTINGS;
            startActivity(settingsIntent);
        } catch (Throwable e) {
            leftForSetup = false;
            setupAwayReason = SETUP_AWAY_NONE;
            AppLog.d(this, "DEFAULT_SETUP settings error package=" + packageName + " " + e);
            Toast.makeText(this, "既定アプリ設定を開けませんでした", Toast.LENGTH_SHORT).show();
        }
    }

    private void showNotConfirmedDialog(FormatItem item) {
        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle(item.label + " を確認")
                .setMessage("Chiramiがまだ「常時」の既定アプリになっていません。\n\nもう一度開いて、アプリ選択画面で「Chirami」→「常時」を選んでください。")
                .setNegativeButton("キャンセル", (d, w) -> cancelDefaultSetup())
                .setNeutralButton("スキップ", (d, w) -> skipDefaultSetupItem())
                .setPositiveButton("もう一度", (d, w) -> launchCurrentSetupItem())
                .create();
        prepareRoundedDialog(dialog, Color.rgb(58, 51, 51));
        dialog.setOnShowListener(v -> styleRoundedDialogButtons(dialog));
        dialog.show();
    }

    private void showChiramiMissingDialog(FormatItem item, DefaultResolveState state) {
        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle(item.label + " を開けません")
                .setMessage("この形式のアプリ候補にChiramiが含まれていません。診断ログに候補数とMIMEを記録しました。\n\nこの形式はスキップするか、キャンセルして診断ログを共有してください。")
                .setNegativeButton("キャンセル", (d, w) -> cancelDefaultSetup())
                .setPositiveButton("スキップ", (d, w) -> skipDefaultSetupItem())
                .create();
        prepareRoundedDialog(dialog, Color.rgb(58, 51, 51));
        dialog.setOnShowListener(v -> styleRoundedDialogButtons(dialog));
        dialog.show();
    }

    private void showSetupFailureDialog(FormatItem item, String message) {
        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle(item.label + " の設定エラー")
                .setMessage(message)
                .setNegativeButton("キャンセル", (d, w) -> cancelDefaultSetup())
                .setPositiveButton("スキップ", (d, w) -> skipDefaultSetupItem())
                .create();
        prepareRoundedDialog(dialog, Color.rgb(58, 51, 51));
        dialog.setOnShowListener(v -> styleRoundedDialogButtons(dialog));
        dialog.show();
    }

    private void cancelDefaultSetup() {
        AppLog.d(this, "DEFAULT_SETUP cancelled index=" + setupIndex);
        setupRunning = false;
        leftForSetup = false;
        setupAwayReason = SETUP_AWAY_NONE;
    }

    private Uri makeProbeFile(FormatItem item) throws Exception {
        File dir = new File(getCacheDir(), "default-probe");
        if (!dir.exists() && !dir.mkdirs()) throw new IllegalStateException("cache mkdir failed");
        File f = new File(dir, "chirami_default_test" + item.extension);
        try (FileOutputStream out = new FileOutputStream(f)) {
            writeProbePayload(out, item);
        }
        return FileProvider.getUriForFile(this, getPackageName() + ".fileprovider", f);
    }

    private void writeProbePayload(FileOutputStream out, FormatItem item) throws Exception {
        String ext = item.extension == null ? "" : item.extension.toLowerCase(java.util.Locale.ROOT);
        if (".png".equals(ext)) {
            writeBase64(out, "iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR4nGP4//8/AwAI/AL+p5qgoAAAAABJRU5ErkJggg==");
            return;
        }
        if (".gif".equals(ext)) {
            // Valid 1x1 GIF89a. Some file managers sniff the probe bytes before launching VIEW.
            writeBase64(out, "R0lGODlhAQABAIEAAP///wAAAAAAAAAAACH5BAEAAAAALAAAAAABAAEAAAgEAAEEBAA7");
            return;
        }
        if (".jpg".equals(ext) || ".jpeg".equals(ext)) {
            writeBase64(out, "/9j/4AAQSkZJRgABAQAAAQABAAD/2wBDAAgGBgcGBQgHBwcJCQgKDBQNDAsLDBkSEw8UHRofHh0aHBwgJC4nICIsIxwcKDcpLDAxNDQ0Hyc5PTgyPC4zNDL/2wBDAQkJCQwLDBgNDRgyIRwhMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjL/wAARCAABAAEDASIAAhEBAxEB/8QAHwAAAQUBAQEBAQEAAAAAAAAAAAECAwQFBgcICQoL/8QAtRAAAgEDAwIEAwUFBAQAAAF9AQIDAAQRBRIhMUEGE1FhByJxFDKBkaEII0KxwRVS0fAkM2JyggkKFhcYGRolJicoKSo0NTY3ODk6Q0RFRkdISUpTVFVWV1hZWmNkZWZnaGlqc3R1dnd4eXqDhIWGh4iJipKTlJWWl5iZmqKjpKWmp6ipqrKztLW2t7i5usLDxMXGx8jJytLT1NXW19jZ2uHi4+Tl5ufo6erx8vP09fb3+Pn6/8QAHwEAAwEBAQEBAQEBAQAAAAAAAAECAwQFBgcICQoL/8QAtREAAgECBAQDBAcFBAQAAQJ3AAECAxEEBSExBhJBUQdhcRMiMoEIFEKRobHBCSMzUvAVYnLRChYkNOEl8RcYGRomJygpKjU2Nzg5OkNERUZHSElKU1RVVldYWVpjZGVmZ2hpanN0dXZ3eHl6goOEhYaHiImKkpOUlZaXmJmaoqOkpaanqKmqsrO0tba3uLm6wsPExcbHyMnK0tPU1dbX2Nna4uPk5ebn6Onq8vP09fb3+Pn6/9oADAMBAAIRAxEAPwD3+iiigD//2Q==");
            return;
        }
        if (".bmp".equals(ext)) {
            // Minimal 1x1 24-bit BMP.
            byte[] bmp = new byte[] {
                    0x42,0x4d,58,0,0,0,0,0,0,0,54,0,0,0,
                    40,0,0,0,1,0,0,0,1,0,0,0,1,0,24,0,
                    0,0,0,0,4,0,0,0,0,0,0,0,0,0,0,0,
                    0,0,0,0,0,0,0,0,(byte)255,(byte)255,(byte)255,0
            };
            out.write(bmp);
            return;
        }
        if (".webp".equals(ext)) {
            // Valid tiny lossless WebP.
            writeBase64(out, "UklGRkAAAABXRUJQVlA4WAoAAAAQAAAAAAAAAAAAQUxQSAIAAAAAAFZQOCAYAAAAMAEAnQEqAQABAAFAJiWkAANwAP789AAA");
            return;
        }
        if (".heic".equals(ext)) {
            // Lightweight HEIC signature; MIME is still supplied explicitly to ACTION_VIEW.
            out.write(new byte[]{0,0,0,24,0x66,0x74,0x79,0x70,0x68,0x65,0x69,0x63,0,0,0,0,0x68,0x65,0x69,0x63,0x6d,0x69,0x66,0x31});
            return;
        }
        if (".avif".equals(ext)) {
            writeBase64(out, "AAAAIGZ0eXBhdmlmAAAAAGF2aWZtaWYxbWlhZk1BMUEAAAD5bWV0YQAAAAAAAAAvaGRscgAAAAAAAAAAcGljdAAAAAAAAAAAAAAAAFBpY3R1cmVIYW5kbGVyAAAAAA5waXRtAAAAAAABAAAAHmlsb2MAAAAARAAAAQABAAAAAQAAASEAAAAfAAAAKGlpbmYAAAAAAAEAAAAaaW5mZQIAAAAAAQAAYXYwMUNvbG9yAAAAAGppcHJwAAAAS2lwY28AAAAUaXNwZQAAAAAAAAACAAAAAgAAABBwaXhpAAAAAAMICAgAAAAMYXYxQ4EgAAAAAAATY29scm5jbHgAAgACAACAAAAAF2lwbWEAAAAAAAAAAQABBAECgwQAAAAnbWRhdAoHOAA20BDQAjIUGAAAAFAAAAAAsBKahxTNljHiiug=");
            return;
        }
        if (".pdf".equals(ext) || "application/pdf".equals(item.mime)) {
            out.write("%PDF-1.4\n1 0 obj<</Type/Catalog>>endobj\ntrailer<</Root 1 0 R>>\n%%EOF\n".getBytes(StandardCharsets.US_ASCII));
            return;
        }
        // Last-resort signature for any future image type.
        out.write(new byte[]{0});
    }

    private void writeBase64(FileOutputStream out, String base64) throws Exception {
        out.write(android.util.Base64.decode(base64, android.util.Base64.DEFAULT));
    }

    private TextView makeDialogAction(String label) {
        TextView action = text(label, 15, Color.rgb(170, 205, 205));
        action.setGravity(Gravity.CENTER);
        action.setPadding(dp(8), 0, dp(8), 0);
        action.setBackground(new android.graphics.drawable.ColorDrawable(Color.TRANSPARENT));
        return action;
    }

    private void showDiagnosticLogDialog() {
        AppLog.d(this, "LOG dialog open");

        LinearLayout panel = new LinearLayout(this);
        panel.setOrientation(LinearLayout.VERTICAL);
        panel.setPadding(dp(16), dp(14), dp(16), dp(10));
        panel.setBackground(makeRoundedDialogPanel(Color.rgb(70, 70, 70)));

        TextView reportView = text(AppLog.report(this), 12.5f, Color.rgb(235, 235, 235));
        reportView.setTypeface(android.graphics.Typeface.MONOSPACE);
        reportView.setTextIsSelectable(true);
        reportView.setPadding(dp(2), dp(2), dp(2), dp(8));

        ScrollView logScroll = new ScrollView(this);
        logScroll.setFillViewport(true);
        logScroll.setVerticalScrollBarEnabled(true);
        logScroll.setScrollBarStyle(android.view.View.SCROLLBARS_INSIDE_OVERLAY);
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.Q) {
            android.graphics.drawable.GradientDrawable thumb = new android.graphics.drawable.GradientDrawable();
            thumb.setColor(Color.rgb(90, 85, 85)); // #5A5555 Chirami light gray
            thumb.setCornerRadius(dp(2));
            thumb.setSize(dp(3), dp(36));
            logScroll.setVerticalScrollbarThumbDrawable(thumb);
            android.graphics.drawable.GradientDrawable track = new android.graphics.drawable.GradientDrawable();
            track.setColor(Color.TRANSPARENT);
            logScroll.setVerticalScrollbarTrackDrawable(track);
        }
        logScroll.addView(reportView, new ScrollView.LayoutParams(-1, -2));
        int desiredLogHeight = Math.max(dp(320), Math.round(getResources().getDisplayMetrics().heightPixels * 0.62f));
        panel.addView(logScroll, new LinearLayout.LayoutParams(-1, desiredLogHeight));

        LinearLayout actions = new LinearLayout(this);
        actions.setOrientation(LinearLayout.HORIZONTAL);
        actions.setGravity(Gravity.CENTER_VERTICAL);
        TextView clearAction = makeDialogAction("ログ消去");
        TextView copyAction = makeDialogAction("コピー");
        TextView closeAction = makeDialogAction("閉じる");
        clearAction.setGravity(Gravity.CENTER_VERTICAL | Gravity.START);
        LinearLayout rightActions = new LinearLayout(this);
        rightActions.setOrientation(LinearLayout.HORIZONTAL);
        rightActions.setGravity(Gravity.CENTER_VERTICAL | Gravity.END);
        rightActions.addView(copyAction, new LinearLayout.LayoutParams(dp(92), dp(48)));
        rightActions.addView(closeAction, new LinearLayout.LayoutParams(dp(92), dp(48)));
        actions.addView(clearAction, new LinearLayout.LayoutParams(0, dp(48), 1f));
        actions.addView(rightActions, new LinearLayout.LayoutParams(-2, dp(48)));
        panel.addView(actions, new LinearLayout.LayoutParams(-1, dp(48)));

        AlertDialog dialog = new AlertDialog.Builder(this)
                .setView(panel)
                .create();
        prepareRoundedDialog(dialog, Color.TRANSPARENT);

        clearAction.setOnClickListener(v -> {
            AppLog.clear(this);
            reportView.setText(AppLog.report(this));
            Toast.makeText(this, "診断ログを消去しました", Toast.LENGTH_SHORT).show();
        });
        copyAction.setOnClickListener(v -> copyLog());
        closeAction.setOnClickListener(v -> dialog.dismiss());
        dialog.show();
    }

    private void copyLog() {
        String report = AppLog.report(this);
        ClipboardManager cm = (ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
        cm.setPrimaryClip(ClipData.newPlainText("Chirami diagnostic report", report));
        Toast.makeText(this, "診断ログをコピーしました", Toast.LENGTH_SHORT).show();
    }

    private void shareLog() {
        try {
            Intent i = new Intent(Intent.ACTION_SEND);
            i.setType("text/plain");
            i.putExtra(Intent.EXTRA_TEXT, AppLog.report(this));
            startActivity(Intent.createChooser(i, "診断ログを共有"));
        } catch (Throwable e) {
            Toast.makeText(this, "診断ログを共有できませんでした", Toast.LENGTH_SHORT).show();
        }
    }
    private String getVersionName() {
        try { return getPackageManager().getPackageInfo(getPackageName(), 0).versionName; }
        catch (Throwable ignored) { return "?"; }
    }

}
