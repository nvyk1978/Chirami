package com.chirami.viewer;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {
    private int dp(float value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(24), dp(28), dp(24), dp(28));
        root.setBackgroundColor(Color.rgb(42, 34, 34));

        TextView title = new TextView(this);
        title.setText("Chirami");
        title.setTextColor(Color.WHITE);
        title.setTextSize(30);
        title.setTypeface(null, android.graphics.Typeface.BOLD);
        root.addView(title, new LinearLayout.LayoutParams(-1, -2));

        TextView subtitle = new TextView(this);
        subtitle.setText("ファイルをタップして、すぐ見る。\nChirami本体を開いたときは設定だけを表示します。");
        subtitle.setTextColor(Color.rgb(203, 197, 197));
        subtitle.setTextSize(15);
        subtitle.setPadding(0, dp(8), 0, dp(28));
        root.addView(subtitle, new LinearLayout.LayoutParams(-1, -2));

        Button defaultButton = new Button(this);
        defaultButton.setText("デフォルト起動の設定");
        defaultButton.setTextColor(Color.WHITE);
        defaultButton.setTextSize(16);
        defaultButton.setAllCaps(false);
        defaultButton.setBackgroundTintList(android.content.res.ColorStateList.valueOf(Color.rgb(68, 85, 119)));
        defaultButton.setOnClickListener(v -> openDefaultSettings());
        root.addView(defaultButton, new LinearLayout.LayoutParams(-1, dp(52)));

        TextView hint = new TextView(this);
        hint.setText("Androidの仕様上、画像ビューアー専用の「既定アプリ」役割はありません。\n対応ファイルを開いてChiramiを選び「常時」を選択すると、その形式の既定アプリとして使えます。");
        hint.setTextColor(Color.rgb(203, 197, 197));
        hint.setTextSize(13);
        hint.setPadding(0, dp(10), 0, dp(26));
        root.addView(hint, new LinearLayout.LayoutParams(-1, -2));

        TextView supportedTitle = new TextView(this);
        supportedTitle.setText("対応形式");
        supportedTitle.setTextColor(Color.WHITE);
        supportedTitle.setTextSize(18);
        supportedTitle.setTypeface(null, android.graphics.Typeface.BOLD);
        root.addView(supportedTitle, new LinearLayout.LayoutParams(-1, -2));

        TextView formats = new TextView(this);
        formats.setText("JPEG / PNG / GIF / BMP / WebP / HEIC・HEIF / AVIF / PDF");
        formats.setTextColor(Color.rgb(203, 197, 197));
        formats.setTextSize(15);
        formats.setPadding(0, dp(8), 0, 0);
        root.addView(formats, new LinearLayout.LayoutParams(-1, -2));

        TextView version = new TextView(this);
        version.setText("v0.1.0");
        version.setTextColor(Color.rgb(145, 140, 140));
        version.setGravity(Gravity.END);
        LinearLayout.LayoutParams versionParams = new LinearLayout.LayoutParams(-1, -2);
        versionParams.weight = 1;
        versionParams.gravity = Gravity.BOTTOM;
        root.addView(version, versionParams);

        setContentView(root);
    }

    private void openDefaultSettings() {
        try {
            Intent intent = new Intent(Settings.ACTION_MANAGE_DEFAULT_APPS_SETTINGS);
            startActivity(intent);
        } catch (Exception first) {
            try {
                Intent intent = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                        Uri.parse("package:" + getPackageName()));
                startActivity(intent);
            } catch (Exception second) {
                Toast.makeText(this, "設定画面を開けませんでした", Toast.LENGTH_SHORT).show();
            }
        }
    }
}
