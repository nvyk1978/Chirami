package com.chirami.viewer;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Intent;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.view.Gravity;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.core.content.FileProvider;

import java.io.File;
import java.io.FileOutputStream;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends Activity {
    private static final int BLUE = Color.rgb(68, 85, 119);
    private static final int LIGHT_TEXT = Color.rgb(203, 197, 197);

    private static class FormatItem {
        final String label;
        final String extension;
        final String mime;
        CheckBox checkBox;
        FormatItem(String label, String extension, String mime) {
            this.label = label; this.extension = extension; this.mime = mime;
        }
    }

    private final List<FormatItem> formats = new ArrayList<>();
    private final List<FormatItem> setupQueue = new ArrayList<>();
    private int setupIndex = 0;
    private boolean setupRunning = false;
    private boolean leftForSetup = false;
    private RadioGroup sortFieldGroup;
    private RadioGroup sortOrderGroup;
    private RadioButton sortByName;
    private RadioButton sortBySize;
    private RadioButton sortByType;
    private RadioButton sortByCreated;
    private RadioButton sortByModified;
    private RadioButton sortAscending;
    private RadioButton sortDescending;
    private boolean syncingSortUi = false;

    private int dp(float value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }

    private android.graphics.drawable.GradientDrawable makeRoundedDialogPanel(int color) {
        android.graphics.drawable.GradientDrawable bg = new android.graphics.drawable.GradientDrawable();
        bg.setColor(color);
        bg.setCornerRadius(dp(10));
        return bg;
    }

    private void prepareRoundedDialog(AlertDialog dialog, int panelColor) {
        if (dialog == null || dialog.getWindow() == null) return;
        dialog.getWindow().setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(Color.TRANSPARENT));
        dialog.getWindow().setWindowAnimations(R.style.Animation_Chirami_Dialog);
        android.view.View decor = dialog.getWindow().getDecorView();
        decor.setBackground(makeRoundedDialogPanel(panelColor));
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.LOLLIPOP) decor.setClipToOutline(true);
    }

    private void styleRoundedDialogButtons(AlertDialog dialog) {
        Button negative = dialog.getButton(AlertDialog.BUTTON_NEGATIVE);
        Button positive = dialog.getButton(AlertDialog.BUTTON_POSITIVE);
        if (negative != null) {
            negative.setTextColor(Color.WHITE); negative.setAllCaps(false);
            negative.setBackground(new android.graphics.drawable.ColorDrawable(Color.TRANSPARENT));
            negative.setStateListAnimator(null);
        }
        if (positive != null) {
            positive.setTextColor(Color.WHITE); positive.setAllCaps(false);
            positive.setBackground(new android.graphics.drawable.ColorDrawable(Color.TRANSPARENT));
            positive.setStateListAnimator(null);
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        AppLog.d(this, "SETTINGS onCreate");
        formats.add(new FormatItem("JPEG  (.jpg / .jpeg)", ".jpg", "image/jpeg"));
        formats.add(new FormatItem("PNG  (.png)", ".png", "image/png"));
        formats.add(new FormatItem("GIF  (.gif)", ".gif", "image/gif"));
        formats.add(new FormatItem("BMP  (.bmp)", ".bmp", "image/bmp"));
        formats.add(new FormatItem("WebP  (.webp)", ".webp", "image/webp"));
        formats.add(new FormatItem("HEIC / HEIF", ".heic", "image/heic"));
        formats.add(new FormatItem("AVIF  (.avif)", ".avif", "image/avif"));
        formats.add(new FormatItem("PDF  (.pdf)", ".pdf", "application/pdf"));
        buildUi();
    }

    @Override
    protected void onResume() {
        super.onResume();
        syncSortUiFromPrefs();
        if (setupRunning && leftForSetup) {
            leftForSetup = false;
            setupIndex++;
            if (setupIndex < setupQueue.size()) {
                new android.os.Handler(getMainLooper()).postDelayed(this::launchCurrentSetupItem, 350);
            } else {
                setupRunning = false;
                AppLog.d(this, "DEFAULT_SETUP sequence finished");
                Toast.makeText(this, "選択した形式の設定を確認しました", Toast.LENGTH_SHORT).show();
            }
        }
    }

    private void buildUi() {
        ScrollView scroll = new ScrollView(this);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(24), dp(28), dp(24), dp(28));
        root.setBackgroundColor(Color.rgb(42, 34, 34));
        scroll.addView(root, new ScrollView.LayoutParams(-1, -2));

        TextView title = new TextView(this);
        title.setText("Chirami   v" + getVersionName());
        title.setTextColor(Color.WHITE);
        title.setTextSize(30);
        title.setTypeface(null, android.graphics.Typeface.BOLD);
        root.addView(title);

        TextView subtitle = text("ファイルをタップして、すぐ見る。\n通常起動時は設定画面だけを表示します。", 15, LIGHT_TEXT);
        subtitle.setPadding(0, dp(8), 0, dp(24));
        root.addView(subtitle);

        TextView defaultTitle = text("デフォルト起動", 18, Color.WHITE);
        defaultTitle.setTypeface(null, android.graphics.Typeface.BOLD);
        root.addView(defaultTitle);

        TextView hint = text("Chiramiで開きたい形式にチェックを付けてください。", 13, LIGHT_TEXT);
        hint.setPadding(0, dp(5), 0, dp(8));
        root.addView(hint);

        ColorStateList checkTint = new ColorStateList(
                new int[][]{ new int[]{android.R.attr.state_checked}, new int[]{} },
                new int[]{BLUE, Color.rgb(90,85,85)});
        for (FormatItem item : formats) {
            CheckBox cb = new CheckBox(this);
            cb.setText(item.label);
            cb.setTextColor(Color.WHITE);
            cb.setTextSize(15);
            cb.setChecked(true);
            cb.setButtonTintList(checkTint);
            cb.setPadding(0, dp(2), 0, dp(2));
            item.checkBox = cb;
            root.addView(cb, new LinearLayout.LayoutParams(-1, dp(44)));
        }

        Button setup = makeButton("チェックした形式をデフォルト起動に設定");
        setup.setOnClickListener(v -> beginDefaultSetup());
        LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(-1, dp(52));
        bp.topMargin = dp(10);
        root.addView(setup, bp);

        TextView osHint = text("Androidの制限により、Chiramiが勝手に既定アプリを書き換えることはできません。チェックした形式を順番に開くので、表示された選択画面で「Chirami」→「常時」を選んでください。すでに別アプリが既定の場合は、その既定設定を先に解除する必要があります。", 12, LIGHT_TEXT);
        osHint.setPadding(0, dp(9), 0, dp(26));
        root.addView(osHint);

        TextView sortTitle = text("スライド順", 18, Color.WHITE);
        sortTitle.setTypeface(null, android.graphics.Typeface.BOLD);
        root.addView(sortTitle);

        TextView sortHint = text("画像を横スワイプするときの並び順です。画像表示中のメニューからも変更できます。", 13, LIGHT_TEXT);
        sortHint.setPadding(0, dp(5), 0, dp(8));
        root.addView(sortHint);

        sortFieldGroup = new RadioGroup(this);
        sortFieldGroup.setOrientation(RadioGroup.VERTICAL);
        sortByName = makeSortRadio("名前", false, checkTint);
        sortBySize = makeSortRadio("サイズ", false, checkTint);
        sortByType = makeSortRadio("種類", false, checkTint);
        sortByCreated = makeSortRadio("作成日", false, checkTint);
        sortByModified = makeSortRadio("最終更新日", false, checkTint);
        sortFieldGroup.addView(sortByName);
        sortFieldGroup.addView(sortBySize);
        sortFieldGroup.addView(sortByType);
        sortFieldGroup.addView(sortByCreated);
        sortFieldGroup.addView(sortByModified);
        root.addView(sortFieldGroup);

        sortOrderGroup = new RadioGroup(this);
        sortOrderGroup.setOrientation(RadioGroup.HORIZONTAL);
        sortAscending = makeSortRadio("左から", false, checkTint);
        sortDescending = makeSortRadio("右から", false, checkTint);
        sortOrderGroup.addView(sortAscending, new RadioGroup.LayoutParams(0, dp(48), 1f));
        sortOrderGroup.addView(sortDescending, new RadioGroup.LayoutParams(0, dp(48), 1f));
        LinearLayout.LayoutParams orderParams = new LinearLayout.LayoutParams(-1, dp(48));
        orderParams.bottomMargin = dp(26);
        root.addView(sortOrderGroup, orderParams);

        sortFieldGroup.setOnCheckedChangeListener((g, id) -> persistSortFromUi());
        sortOrderGroup.setOnCheckedChangeListener((g, id) -> persistSortFromUi());
        syncSortUiFromPrefs();

        TextView diagTitle = text("診断ログ", 18, Color.WHITE);
        diagTitle.setTypeface(null, android.graphics.Typeface.BOLD);
        root.addView(diagTitle);

        Button copy = makeButton("診断ログをコピー");
        copy.setOnClickListener(v -> copyLog());
        LinearLayout.LayoutParams p1 = new LinearLayout.LayoutParams(-1, dp(50));
        p1.topMargin = dp(10);
        root.addView(copy, p1);

        Button share = makeButton("診断ログを共有");
        share.setOnClickListener(v -> shareLog());
        LinearLayout.LayoutParams p2 = new LinearLayout.LayoutParams(-1, dp(50));
        p2.topMargin = dp(8);
        root.addView(share, p2);

        Button clear = makeButton("診断ログを消去");
        clear.setBackgroundTintList(ColorStateList.valueOf(Color.rgb(58,51,51)));
        clear.setOnClickListener(v -> {
            AppLog.clear(this);
            AppLog.d(this, "LOG cleared");
            Toast.makeText(this, "診断ログを消去しました", Toast.LENGTH_SHORT).show();
        });
        LinearLayout.LayoutParams p3 = new LinearLayout.LayoutParams(-1, dp(50));
        p3.topMargin = dp(8);
        root.addView(clear, p3);

        String versionName = getVersionName();
        TextView version = text("v" + versionName, 12, Color.rgb(145,140,140));
        version.setGravity(Gravity.END);
        version.setPadding(0, dp(28), 0, 0);
        root.addView(version);

        setContentView(scroll);
    }

    private TextView text(String s, float size, int color) {
        TextView t = new TextView(this);
        t.setText(s); t.setTextSize(size); t.setTextColor(color);
        return t;
    }

    private RadioButton makeSortRadio(String label, boolean checked, ColorStateList tint) {
        RadioButton b = new RadioButton(this);
        b.setId(android.view.View.generateViewId());
        b.setText(label); b.setTextColor(Color.WHITE); b.setTextSize(15); b.setChecked(checked);
        b.setButtonTintList(tint); b.setGravity(Gravity.CENTER_VERTICAL);
        b.setPadding(0, dp(2), 0, dp(2));
        return b;
    }

    private void syncSortUiFromPrefs() {
        if (sortFieldGroup == null || sortOrderGroup == null) return;
        syncingSortUi = true;
        String field = SortPrefs.field(this);
        if (SortPrefs.FIELD_SIZE.equals(field)) sortFieldGroup.check(sortBySize.getId());
        else if (SortPrefs.FIELD_TYPE.equals(field)) sortFieldGroup.check(sortByType.getId());
        else if (SortPrefs.FIELD_CREATED.equals(field)) sortFieldGroup.check(sortByCreated.getId());
        else if (SortPrefs.FIELD_MODIFIED.equals(field)) sortFieldGroup.check(sortByModified.getId());
        else sortFieldGroup.check(sortByName.getId());
        sortOrderGroup.check((SortPrefs.ascending(this) ? sortAscending : sortDescending).getId());
        syncingSortUi = false;
    }

    private void persistSortFromUi() {
        if (syncingSortUi || sortFieldGroup == null || sortOrderGroup == null) return;
        if (sortFieldGroup.getCheckedRadioButtonId() == -1 || sortOrderGroup.getCheckedRadioButtonId() == -1) return;
        String field = sortBySize.isChecked() ? SortPrefs.FIELD_SIZE
                : (sortByType.isChecked() ? SortPrefs.FIELD_TYPE
                : (sortByCreated.isChecked() ? SortPrefs.FIELD_CREATED
                : (sortByModified.isChecked() ? SortPrefs.FIELD_MODIFIED : SortPrefs.FIELD_NAME)));
        SortPrefs.save(this, field, sortAscending.isChecked());
        AppLog.d(this, "SORT settings field=" + field + " asc=" + sortAscending.isChecked());
    }

    private Button makeButton(String label) {
        Button b = new Button(this);
        b.setText(label); b.setTextColor(Color.WHITE); b.setTextSize(15); b.setAllCaps(false);
        b.setBackgroundTintList(ColorStateList.valueOf(BLUE));
        return b;
    }

    private void beginDefaultSetup() {
        setupQueue.clear();
        for (FormatItem item : formats) if (item.checkBox.isChecked()) setupQueue.add(item);
        if (setupQueue.isEmpty()) {
            Toast.makeText(this, "形式を1つ以上選んでください", Toast.LENGTH_SHORT).show();
            return;
        }
        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle("デフォルト起動の設定")
                .setMessage("チェックした形式を1つずつ開きます。アプリ選択画面が表示されたら「Chirami」を選び、「常時」をタップしてください。\n\nすでに別のアプリが直接開く場合は、そのアプリの既定設定を解除してからもう一度実行してください。")
                .setNegativeButton("キャンセル", null)
                .setPositiveButton("開始", (d, w) -> {
                    setupIndex = 0;
                    setupRunning = true;
                    leftForSetup = false;
                    AppLog.d(this, "DEFAULT_SETUP start count=" + setupQueue.size());
                    launchCurrentSetupItem();
                }).create();
        prepareRoundedDialog(dialog, Color.rgb(58, 51, 51));
        dialog.setOnShowListener(v -> styleRoundedDialogButtons(dialog));
        dialog.show();
    }

    private void launchCurrentSetupItem() {
        if (!setupRunning || setupIndex >= setupQueue.size()) return;
        FormatItem item = setupQueue.get(setupIndex);
        try {
            Uri uri = makeProbeFile(item);
            Intent intent = new Intent(Intent.ACTION_VIEW);
            intent.setDataAndType(uri, item.mime);
            intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            AppLog.d(this, "DEFAULT_SETUP launch " + item.label + " mime=" + item.mime);
            leftForSetup = true;
            startActivity(intent);
        } catch (Throwable e) {
            AppLog.d(this, "DEFAULT_SETUP error " + item.label + " " + e);
            leftForSetup = false;
            setupIndex++;
            if (setupIndex < setupQueue.size()) launchCurrentSetupItem();
            else setupRunning = false;
        }
    }

    private Uri makeProbeFile(FormatItem item) throws Exception {
        File dir = new File(getCacheDir(), "default-probe");
        if (!dir.exists() && !dir.mkdirs()) throw new IllegalStateException("cache mkdir failed");
        File f = new File(dir, "chirami_default_test" + item.extension);
        try (FileOutputStream out = new FileOutputStream(f)) {
            if ("application/pdf".equals(item.mime)) {
                out.write("%PDF-1.4\n1 0 obj<</Type/Catalog>>endobj\ntrailer<</Root 1 0 R>>\n%%EOF\n".getBytes(StandardCharsets.US_ASCII));
            } else {
                // Valid 1x1 transparent PNG. Resolver selection is based on the explicit MIME type.
                byte[] png = android.util.Base64.decode("iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVQIHWP4z8DwHwAFgAI/ScL5WQAAAABJRU5ErkJggg==", android.util.Base64.DEFAULT);
                out.write(png);
            }
        }
        return FileProvider.getUriForFile(this, getPackageName() + ".fileprovider", f);
    }

    private void copyLog() {
        String report = AppLog.report(this);
        ClipboardManager cm = (ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
        cm.setPrimaryClip(ClipData.newPlainText("Chirami diagnostic report", report));
        Toast.makeText(this, "診断ログをコピーしました", Toast.LENGTH_SHORT).show();
    }

    private void shareLog() {
        try {
            Intent i = new Intent(Intent.ACTION_SEND);
            i.setType("text/plain");
            i.putExtra(Intent.EXTRA_TEXT, AppLog.report(this));
            startActivity(Intent.createChooser(i, "診断ログを共有"));
        } catch (Throwable e) {
            Toast.makeText(this, "診断ログを共有できませんでした", Toast.LENGTH_SHORT).show();
        }
    }
    private String getVersionName() {
        try { return getPackageManager().getPackageInfo(getPackageName(), 0).versionName; }
        catch (Throwable ignored) { return "?"; }
    }

}
