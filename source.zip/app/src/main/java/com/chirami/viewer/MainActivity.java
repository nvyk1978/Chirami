package com.chirami.viewer;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Intent;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.view.Gravity;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;



public class MainActivity extends Activity {
    private static final int BLUE = Color.rgb(68, 85, 119);
    private static final int LIGHT_TEXT = Color.rgb(203, 197, 197);
    private static final int REQ_REAL_FILE_DIAG = 2201;

    private LinearLayout sortFieldGrid;
    private RadioGroup sortOrderGroup;
    private RadioButton sortByName;
    private RadioButton sortBySize;
    private RadioButton sortByType;
    private RadioButton sortByCreated;
    private RadioButton sortByModified;
    private RadioButton sortAscending;
    private RadioButton sortDescending;
    private boolean syncingSortUi = false;
    private TextView savePathValue;

    private int dp(float value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }

    private android.graphics.drawable.GradientDrawable makeRoundedDialogPanel(int color) {
        android.graphics.drawable.GradientDrawable bg = new android.graphics.drawable.GradientDrawable();
        bg.setColor(color);
        bg.setCornerRadius(dp(10));
        return bg;
    }

    private void prepareRoundedDialog(AlertDialog dialog, int panelColor) {
        if (dialog == null || dialog.getWindow() == null) return;
        dialog.getWindow().setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(Color.TRANSPARENT));
        dialog.getWindow().setWindowAnimations(R.style.Animation_Chirami_Dialog);
        android.view.View decor = dialog.getWindow().getDecorView();
        decor.setBackground(makeRoundedDialogPanel(panelColor));
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.LOLLIPOP) decor.setClipToOutline(true);
    }

    private void styleRoundedDialogButtons(AlertDialog dialog) {
        Button negative = dialog.getButton(AlertDialog.BUTTON_NEGATIVE);
        Button neutral = dialog.getButton(AlertDialog.BUTTON_NEUTRAL);
        Button positive = dialog.getButton(AlertDialog.BUTTON_POSITIVE);
        if (negative != null) {
            negative.setTextColor(Color.WHITE); negative.setAllCaps(false);
            negative.setBackground(new android.graphics.drawable.ColorDrawable(Color.TRANSPARENT));
            negative.setStateListAnimator(null);
        }
        if (neutral != null) {
            neutral.setTextColor(Color.WHITE); neutral.setAllCaps(false);
            neutral.setBackground(new android.graphics.drawable.ColorDrawable(Color.TRANSPARENT));
            neutral.setStateListAnimator(null);
        }
        if (positive != null) {
            positive.setTextColor(Color.WHITE); positive.setAllCaps(false);
            positive.setBackground(new android.graphics.drawable.ColorDrawable(Color.TRANSPARENT));
            positive.setStateListAnimator(null);
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        AppLog.d(this, "SETTINGS onCreate");
        buildUi();
    }

    @Override
    protected void onResume() {
        super.onResume();
        syncSortUiFromPrefs();
        refreshSaveDestinationUi();
    }

    private void buildUi() {
        ScrollView scroll = new ScrollView(this);
        scroll.setBackgroundColor(Color.rgb(48, 48, 48)); // #303030
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(24), dp(28), dp(24), dp(28));
        root.setBackgroundColor(Color.rgb(48, 48, 48)); // #303030
        scroll.addView(root, new ScrollView.LayoutParams(-1, -2));

        // Keep the title visually about 100 px lower on the current device, but express
        // the spacing through dp so the layout remains density-aware.
        int titleOffsetDp = Math.max(1, Math.round(100f / getResources().getDisplayMetrics().density));
        android.view.View titleSpacer = new android.view.View(this);
        root.addView(titleSpacer, new LinearLayout.LayoutParams(1, dp(titleOffsetDp)));

        TextView title = new TextView(this);
        title.setText("Chirami   v" + getVersionName());
        title.setTextColor(Color.WHITE);
        title.setTextSize(30);
        title.setTypeface(null, android.graphics.Typeface.BOLD);
        root.addView(title);

        ColorStateList checkTint = new ColorStateList(
                new int[][]{ new int[]{android.R.attr.state_checked}, new int[]{} },
                new int[]{BLUE, Color.rgb(90,85,85)});

        TextView saveTitle = text("保存先", 18, Color.WHITE);
        saveTitle.setTypeface(null, android.graphics.Typeface.BOLD);
        root.addView(saveTitle);

        TextView saveHint = text("トリミング／リサイズで上書きしない場合の保存先です。", 13, LIGHT_TEXT);
        saveHint.setPadding(0, dp(5), 0, dp(7));
        root.addView(saveHint);

        savePathValue = text("", 14, Color.WHITE);
        savePathValue.setSingleLine(true);
        savePathValue.setEllipsize(android.text.TextUtils.TruncateAt.START);
        savePathValue.setPadding(dp(10), dp(8), dp(10), dp(8));
        android.graphics.drawable.GradientDrawable savePathBg = new android.graphics.drawable.GradientDrawable();
        savePathBg.setColor(Color.rgb(37, 32, 32)); // N dark gray
        savePathBg.setCornerRadius(dp(8));
        savePathValue.setBackground(savePathBg);
        root.addView(savePathValue, new LinearLayout.LayoutParams(-1, dp(42)));

        Button saveDestination = makeButton("保存先を変更");
        saveDestination.setOnClickListener(v -> startActivity(new Intent(this, FolderPickerActivity.class)));
        LinearLayout.LayoutParams saveButtonParams = new LinearLayout.LayoutParams(-1, dp(48));
        saveButtonParams.topMargin = dp(8);
        saveButtonParams.bottomMargin = dp(24);
        root.addView(saveDestination, saveButtonParams);
        refreshSaveDestinationUi();

        TextView sortTitle = text("スライド順", 18, Color.WHITE);
        sortTitle.setTypeface(null, android.graphics.Typeface.BOLD);
        root.addView(sortTitle);

        TextView sortHint = text("画像を横スワイプするときの並び順です。画像表示中のメニューからも変更できます。", 13, LIGHT_TEXT);
        sortHint.setPadding(0, dp(5), 0, dp(8));
        root.addView(sortHint);

        sortFieldGrid = new LinearLayout(this);
        sortFieldGrid.setOrientation(LinearLayout.VERTICAL);
        sortByName = makeSortRadio("名前", false, checkTint);
        sortBySize = makeSortRadio("サイズ", false, checkTint);
        sortByType = makeSortRadio("種類", false, checkTint);
        sortByCreated = makeSortRadio("作成日", false, checkTint);
        sortByModified = makeSortRadio("最終更新日", false, checkTint);
        RadioButton[] fieldButtons = new RadioButton[]{
                sortByName, sortBySize, sortByType, sortByCreated, sortByModified
        };
        for (int i = 0; i < fieldButtons.length; i += 2) {
            LinearLayout row = new LinearLayout(this);
            row.setOrientation(LinearLayout.HORIZONTAL);
            for (int col = 0; col < 2; col++) {
                int index = i + col;
                if (index < fieldButtons.length) {
                    RadioButton button = fieldButtons[index];
                    row.addView(button, new LinearLayout.LayoutParams(0, dp(44), 1f));
                    button.setOnClickListener(v -> selectSortField((RadioButton) v, true));
                } else {
                    row.addView(new android.view.View(this), new LinearLayout.LayoutParams(0, dp(44), 1f));
                }
            }
            sortFieldGrid.addView(row, new LinearLayout.LayoutParams(-1, dp(44)));
        }
        root.addView(sortFieldGrid, new LinearLayout.LayoutParams(-1, -2));

        TextView directionLabel = text("方向", 13, LIGHT_TEXT);
        directionLabel.setPadding(0, dp(8), 0, dp(1));
        root.addView(directionLabel);

        sortOrderGroup = new RadioGroup(this);
        sortOrderGroup.setOrientation(RadioGroup.HORIZONTAL);
        sortAscending = makeSortRadio("左から", false, checkTint);
        sortDescending = makeSortRadio("右から", false, checkTint);
        sortOrderGroup.addView(sortAscending, new RadioGroup.LayoutParams(0, dp(46), 1f));
        sortOrderGroup.addView(sortDescending, new RadioGroup.LayoutParams(0, dp(46), 1f));
        LinearLayout.LayoutParams orderParams = new LinearLayout.LayoutParams(-1, dp(46));
        orderParams.bottomMargin = dp(26);
        root.addView(sortOrderGroup, orderParams);

        sortOrderGroup.setOnCheckedChangeListener((g, id) -> persistSortFromUi());
        syncSortUiFromPrefs();

        Button diagEntry = makeButton("診断ログ");
        diagEntry.setOnClickListener(v -> showDiagnosticLogDialog());
        LinearLayout.LayoutParams diagParams = new LinearLayout.LayoutParams(-1, dp(52));
        diagParams.topMargin = dp(2);
        root.addView(diagEntry, diagParams);

        String versionName = getVersionName();
        TextView version = text("v" + versionName, 12, Color.rgb(145,140,140));
        version.setGravity(Gravity.END);
        version.setPadding(0, dp(28), 0, 0);
        root.addView(version);

        setContentView(scroll);
    }

    private void refreshSaveDestinationUi() {
        if (savePathValue != null) savePathValue.setText(SavePrefs.directory(this).getAbsolutePath());
    }

    private TextView text(String s, float size, int color) {
        TextView t = new TextView(this);
        t.setText(s); t.setTextSize(size); t.setTextColor(color);
        return t;
    }

    private RadioButton makeSortRadio(String label, boolean checked, ColorStateList tint) {
        RadioButton b = new RadioButton(this);
        b.setId(android.view.View.generateViewId());
        b.setText(label); b.setTextColor(Color.WHITE); b.setTextSize(15); b.setChecked(checked);
        b.setButtonTintList(tint); b.setGravity(Gravity.CENTER_VERTICAL);
        b.setPadding(0, dp(2), 0, dp(2));
        return b;
    }

    private void syncSortUiFromPrefs() {
        if (sortFieldGrid == null || sortOrderGroup == null) return;
        syncingSortUi = true;
        String field = SortPrefs.field(this);
        RadioButton selected = SortPrefs.FIELD_SIZE.equals(field) ? sortBySize
                : (SortPrefs.FIELD_TYPE.equals(field) ? sortByType
                : (SortPrefs.FIELD_CREATED.equals(field) ? sortByCreated
                : (SortPrefs.FIELD_MODIFIED.equals(field) ? sortByModified : sortByName)));
        selectSortField(selected, false);
        sortOrderGroup.check((SortPrefs.ascending(this) ? sortAscending : sortDescending).getId());
        syncingSortUi = false;
    }

    private void selectSortField(RadioButton selected, boolean persist) {
        if (selected == null) return;
        boolean wasSyncing = syncingSortUi;
        syncingSortUi = true;
        sortByName.setChecked(selected == sortByName);
        sortBySize.setChecked(selected == sortBySize);
        sortByType.setChecked(selected == sortByType);
        sortByCreated.setChecked(selected == sortByCreated);
        sortByModified.setChecked(selected == sortByModified);
        syncingSortUi = wasSyncing;
        if (persist && !syncingSortUi) persistSortFromUi();
    }

    private void persistSortFromUi() {
        if (syncingSortUi || sortFieldGrid == null || sortOrderGroup == null) return;
        if (sortOrderGroup.getCheckedRadioButtonId() == -1) return;
        String field = sortBySize.isChecked() ? SortPrefs.FIELD_SIZE
                : (sortByType.isChecked() ? SortPrefs.FIELD_TYPE
                : (sortByCreated.isChecked() ? SortPrefs.FIELD_CREATED
                : (sortByModified.isChecked() ? SortPrefs.FIELD_MODIFIED : SortPrefs.FIELD_NAME)));
        SortPrefs.save(this, field, sortAscending.isChecked());
        AppLog.d(this, "SORT settings field=" + field + " asc=" + sortAscending.isChecked());
    }

    private Button makeButton(String label) {
        Button b = new Button(this);
        b.setText(label); b.setTextColor(Color.WHITE); b.setTextSize(15); b.setAllCaps(false);
        b.setBackgroundTintList(ColorStateList.valueOf(BLUE));
        return b;
    }

    private void pickRealFileForDiagnostic() {
        try {
            Intent pick = new Intent(Intent.ACTION_OPEN_DOCUMENT);
            pick.addCategory(Intent.CATEGORY_OPENABLE);
            pick.setType("*/*");
            AppLog.d(this, "REAL_FILE_DIAG picker open");
            startActivityForResult(pick, REQ_REAL_FILE_DIAG);
        } catch (Throwable e) {
            AppLog.d(this, "REAL_FILE_DIAG picker failed error=" + e);
            Toast.makeText(this, "ファイル選択を開けませんでした", Toast.LENGTH_LONG).show();
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != REQ_REAL_FILE_DIAG) return;
        if (resultCode != RESULT_OK || data == null || data.getData() == null) {
            AppLog.d(this, "REAL_FILE_DIAG picker cancelled result=" + resultCode);
            return;
        }
        Uri uri = data.getData();
        try {
            int flags = data.getFlags() & (Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
            try { getContentResolver().takePersistableUriPermission(uri, flags); } catch (Throwable ignored) {}
            diagnoseRealFile(uri, data);
        } catch (Throwable e) {
            AppLog.d(this, "REAL_FILE_DIAG failed uri=" + uri + " error=" + e);
            Toast.makeText(this, "実ファイル診断に失敗しました: " + e.getClass().getSimpleName(), Toast.LENGTH_LONG).show();
        }
    }

    private void diagnoseRealFile(Uri uri, Intent pickerResult) {
        String resolverMime = null;
        try { resolverMime = getContentResolver().getType(uri); } catch (Throwable ignored) {}
        String displayName = queryDisplayName(uri);
        long size = queryOpenableSize(uri);
        String extensionMime = mimeFromName(displayName);

        AppLog.d(this, "REAL_FILE_DIAG begin uri=" + uri
                + " scheme=" + uri.getScheme()
                + " authority=" + uri.getAuthority()
                + " pickerType=" + pickerResult.getType()
                + " resolverMime=" + resolverMime
                + " displayName=" + displayName
                + " size=" + size
                + " extensionMime=" + extensionMime
                + " pickerFlags=0x" + Integer.toHexString(pickerResult.getFlags()));

        DiagnosticResult actual = diagnoseViewIntent("resolver-mime", uri, resolverMime);
        DiagnosticResult canonical = null;
        if (extensionMime != null && !extensionMime.equalsIgnoreCase(resolverMime == null ? "" : resolverMime)) {
            canonical = diagnoseViewIntent("extension-mime", uri, extensionMime);
        } else if (extensionMime != null) {
            AppLog.d(this, "REAL_FILE_DIAG extension-mime same-as-resolver mime=" + extensionMime);
        }
        DiagnosticResult untyped = diagnoseViewIntent("untyped", uri, null);

        StringBuilder summary = new StringBuilder();
        summary.append("ファイル: ").append(displayName == null ? "(不明)" : displayName).append('\n');
        summary.append("Resolver MIME: ").append(resolverMime == null ? "(null)" : resolverMime).append('\n');
        summary.append("拡張子推定 MIME: ").append(extensionMime == null ? "(不明)" : extensionMime).append("\n\n");
        appendDiagnosticSummary(summary, "Resolver MIME", actual);
        if (canonical != null) appendDiagnosticSummary(summary, "拡張子 MIME", canonical);
        appendDiagnosticSummary(summary, "型なし", untyped);
        summary.append("\n詳細は診断ログに記録しました。");

        final String launchMime = resolverMime != null ? resolverMime : extensionMime;
        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle("実ファイル診断")
                .setMessage(summary.toString())
                .setNegativeButton("閉じる", null)
                .setNeutralButton("診断ログ", (d, w) -> showDiagnosticLogDialog())
                .setPositiveButton("同条件で開く", (d, w) -> launchRealFileImplicit(uri, launchMime))
                .create();
        prepareRoundedDialog(dialog, Color.rgb(58, 51, 51));
        dialog.setOnShowListener(v -> styleRoundedDialogButtons(dialog));
        dialog.show();
    }

    private void launchRealFileImplicit(Uri uri, String mime) {
        try {
            Intent view = new Intent(Intent.ACTION_VIEW);
            if (mime == null || mime.trim().isEmpty()) view.setData(uri);
            else view.setDataAndType(uri, mime);
            view.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            view.setClipData(ClipData.newRawUri("Chirami real-file diagnostic", uri));
            AppLog.d(this, "REAL_FILE_DIAG launch uri=" + uri + " mime=" + mime);
            startActivity(view);
        } catch (Throwable e) {
            AppLog.d(this, "REAL_FILE_DIAG launch failed uri=" + uri + " mime=" + mime + " error=" + e);
            Toast.makeText(this, "同条件で開けませんでした", Toast.LENGTH_LONG).show();
        }
    }

    private String queryDisplayName(Uri uri) {
        android.database.Cursor c = null;
        try {
            c = getContentResolver().query(uri, new String[]{android.provider.OpenableColumns.DISPLAY_NAME}, null, null, null);
            if (c != null && c.moveToFirst()) {
                int idx = c.getColumnIndex(android.provider.OpenableColumns.DISPLAY_NAME);
                if (idx >= 0 && !c.isNull(idx)) return c.getString(idx);
            }
        } catch (Throwable e) {
            AppLog.d(this, "REAL_FILE_DIAG displayName query error=" + e);
        } finally {
            if (c != null) try { c.close(); } catch (Throwable ignored) {}
        }
        String last = uri.getLastPathSegment();
        return last == null ? null : last;
    }

    private long queryOpenableSize(Uri uri) {
        android.database.Cursor c = null;
        try {
            c = getContentResolver().query(uri, new String[]{android.provider.OpenableColumns.SIZE}, null, null, null);
            if (c != null && c.moveToFirst()) {
                int idx = c.getColumnIndex(android.provider.OpenableColumns.SIZE);
                if (idx >= 0 && !c.isNull(idx)) return c.getLong(idx);
            }
        } catch (Throwable e) {
            AppLog.d(this, "REAL_FILE_DIAG size query error=" + e);
        } finally {
            if (c != null) try { c.close(); } catch (Throwable ignored) {}
        }
        return -1L;
    }

    private String mimeFromName(String name) {
        if (name == null) return null;
        String lower = name.toLowerCase(java.util.Locale.ROOT);
        if (lower.endsWith(".jpg") || lower.endsWith(".jpeg")) return "image/jpeg";
        if (lower.endsWith(".png")) return "image/png";
        if (lower.endsWith(".gif")) return "image/gif";
        if (lower.endsWith(".bmp") || lower.endsWith(".dib")) return "image/bmp";
        if (lower.endsWith(".webp")) return "image/webp";
        if (lower.endsWith(".heic")) return "image/heic";
        if (lower.endsWith(".heif")) return "image/heif";
        if (lower.endsWith(".avif")) return "image/avif";
        if (lower.endsWith(".pdf")) return "application/pdf";
        return null;
    }

    private DiagnosticResult diagnoseViewIntent(String mode, Uri uri, String mime) {
        Intent intent = new Intent(Intent.ACTION_VIEW);
        if (mime == null || mime.trim().isEmpty()) intent.setData(uri);
        else intent.setDataAndType(uri, mime);
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        intent.setClipData(ClipData.newRawUri("Chirami diagnostic", uri));

        android.content.pm.PackageManager pm = getPackageManager();
        java.util.List<android.content.pm.ResolveInfo> list;
        android.content.pm.ResolveInfo resolved;
        try {
            list = pm.queryIntentActivities(intent, android.content.pm.PackageManager.MATCH_DEFAULT_ONLY);
            resolved = pm.resolveActivity(intent, android.content.pm.PackageManager.MATCH_DEFAULT_ONLY);
        } catch (Throwable e) {
            AppLog.d(this, "REAL_FILE_DIAG mode=" + mode + " query failed mime=" + mime + " error=" + e);
            return new DiagnosticResult(0, false, null, null);
        }

        int count = list == null ? 0 : list.size();
        boolean chirami = false;
        AppLog.d(this, "REAL_FILE_DIAG mode=" + mode + " action=VIEW uri=" + uri + " mime=" + mime + " candidates=" + count);
        if (list != null) {
            for (android.content.pm.ResolveInfo ri : list) {
                if (ri == null || ri.activityInfo == null) continue;
                String pkg = ri.activityInfo.packageName;
                String cls = ri.activityInfo.name;
                boolean ours = getPackageName().equals(pkg);
                if (ours) chirami = true;
                CharSequence label = null;
                try { label = ri.loadLabel(pm); } catch (Throwable ignored) {}
                AppLog.d(this, "REAL_FILE_DIAG candidate mode=" + mode
                        + " pkg=" + pkg
                        + " cls=" + cls
                        + " label=" + (label == null ? "" : label)
                        + " match=0x" + Integer.toHexString(ri.match)
                        + " priority=" + ri.priority
                        + " preferredOrder=" + ri.preferredOrder
                        + " ours=" + ours);
            }
        }
        String resolvedPkg = null;
        String resolvedLabel = null;
        if (resolved != null && resolved.activityInfo != null) {
            resolvedPkg = resolved.activityInfo.packageName;
            try {
                CharSequence label = resolved.loadLabel(pm);
                resolvedLabel = label == null ? null : label.toString();
            } catch (Throwable ignored) {}
            AppLog.d(this, "REAL_FILE_DIAG resolved mode=" + mode
                    + " pkg=" + resolvedPkg
                    + " cls=" + resolved.activityInfo.name
                    + " label=" + resolvedLabel
                    + " match=0x" + Integer.toHexString(resolved.match)
                    + " ours=" + getPackageName().equals(resolvedPkg));
        } else {
            AppLog.d(this, "REAL_FILE_DIAG resolved mode=" + mode + " none");
        }
        return new DiagnosticResult(count, chirami, resolvedPkg, resolvedLabel);
    }

    private void appendDiagnosticSummary(StringBuilder out, String label, DiagnosticResult r) {
        out.append(label).append(": 候補").append(r.candidateCount)
                .append(" / Chirami=").append(r.chiramiCandidate ? "あり" : "なし")
                .append(" / resolve=");
        if (r.resolvedLabel != null && !r.resolvedLabel.isEmpty()) out.append(r.resolvedLabel);
        else if (r.resolvedPackage != null && !r.resolvedPackage.isEmpty()) out.append(r.resolvedPackage);
        else out.append("なし");
        out.append('\n');
    }

    private static class DiagnosticResult {
        final int candidateCount;
        final boolean chiramiCandidate;
        final String resolvedPackage;
        final String resolvedLabel;
        DiagnosticResult(int candidateCount, boolean chiramiCandidate, String resolvedPackage, String resolvedLabel) {
            this.candidateCount = candidateCount;
            this.chiramiCandidate = chiramiCandidate;
            this.resolvedPackage = resolvedPackage;
            this.resolvedLabel = resolvedLabel;
        }
    }

    private TextView makeDialogAction(String label) {
        TextView action = text(label, 15, Color.rgb(170, 205, 205));
        action.setGravity(Gravity.CENTER);
        action.setPadding(dp(8), 0, dp(8), 0);
        action.setBackground(new android.graphics.drawable.ColorDrawable(Color.TRANSPARENT));
        return action;
    }

    private void showDiagnosticLogDialog() {
        AppLog.d(this, "LOG dialog open");

        LinearLayout panel = new LinearLayout(this);
        panel.setOrientation(LinearLayout.VERTICAL);
        panel.setPadding(dp(16), dp(14), dp(16), dp(10));
        panel.setBackground(makeRoundedDialogPanel(Color.rgb(70, 70, 70)));

        TextView reportView = text(AppLog.report(this), 12.5f, Color.rgb(235, 235, 235));
        reportView.setTypeface(android.graphics.Typeface.MONOSPACE);
        reportView.setTextIsSelectable(true);
        reportView.setPadding(dp(2), dp(2), dp(2), dp(8));

        ScrollView logScroll = new ScrollView(this);
        logScroll.setFillViewport(true);
        logScroll.setVerticalScrollBarEnabled(true);
        logScroll.setScrollBarStyle(android.view.View.SCROLLBARS_INSIDE_OVERLAY);
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.Q) {
            android.graphics.drawable.GradientDrawable thumb = new android.graphics.drawable.GradientDrawable();
            thumb.setColor(Color.rgb(90, 85, 85)); // #5A5555 Chirami light gray
            thumb.setCornerRadius(dp(2));
            thumb.setSize(dp(3), dp(36));
            logScroll.setVerticalScrollbarThumbDrawable(thumb);
            android.graphics.drawable.GradientDrawable track = new android.graphics.drawable.GradientDrawable();
            track.setColor(Color.TRANSPARENT);
            logScroll.setVerticalScrollbarTrackDrawable(track);
        }
        logScroll.addView(reportView, new ScrollView.LayoutParams(-1, -2));
        int desiredLogHeight = Math.max(dp(320), Math.round(getResources().getDisplayMetrics().heightPixels * 0.62f));
        panel.addView(logScroll, new LinearLayout.LayoutParams(-1, desiredLogHeight));

        LinearLayout actions = new LinearLayout(this);
        actions.setOrientation(LinearLayout.HORIZONTAL);
        actions.setGravity(Gravity.CENTER_VERTICAL);
        TextView clearAction = makeDialogAction("ログ消去");
        TextView copyAction = makeDialogAction("コピー");
        TextView closeAction = makeDialogAction("閉じる");
        clearAction.setGravity(Gravity.CENTER_VERTICAL | Gravity.START);
        LinearLayout rightActions = new LinearLayout(this);
        rightActions.setOrientation(LinearLayout.HORIZONTAL);
        rightActions.setGravity(Gravity.CENTER_VERTICAL | Gravity.END);
        rightActions.addView(copyAction, new LinearLayout.LayoutParams(dp(92), dp(48)));
        rightActions.addView(closeAction, new LinearLayout.LayoutParams(dp(92), dp(48)));
        actions.addView(clearAction, new LinearLayout.LayoutParams(0, dp(48), 1f));
        actions.addView(rightActions, new LinearLayout.LayoutParams(-2, dp(48)));
        panel.addView(actions, new LinearLayout.LayoutParams(-1, dp(48)));

        AlertDialog dialog = new AlertDialog.Builder(this)
                .setView(panel)
                .create();
        prepareRoundedDialog(dialog, Color.TRANSPARENT);

        clearAction.setOnClickListener(v -> {
            AppLog.clear(this);
            reportView.setText(AppLog.report(this));
            Toast.makeText(this, "診断ログを消去しました", Toast.LENGTH_SHORT).show();
        });
        copyAction.setOnClickListener(v -> copyLog());
        closeAction.setOnClickListener(v -> dialog.dismiss());
        dialog.show();
    }

    private void copyLog() {
        String report = AppLog.report(this);
        ClipboardManager cm = (ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
        cm.setPrimaryClip(ClipData.newPlainText("Chirami diagnostic report", report));
        Toast.makeText(this, "診断ログをコピーしました", Toast.LENGTH_SHORT).show();
    }

    private void shareLog() {
        try {
            Intent i = new Intent(Intent.ACTION_SEND);
            i.setType("text/plain");
            i.putExtra(Intent.EXTRA_TEXT, AppLog.report(this));
            startActivity(Intent.createChooser(i, "診断ログを共有"));
        } catch (Throwable e) {
            Toast.makeText(this, "診断ログを共有できませんでした", Toast.LENGTH_SHORT).show();
        }
    }
    private String getVersionName() {
        try { return getPackageManager().getPackageInfo(getPackageName(), 0).versionName; }
        catch (Throwable ignored) { return "?"; }
    }

}
