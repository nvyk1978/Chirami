package com.chirami.viewer;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.WallpaperManager;
import android.content.ContentUris;
import android.content.ContentValues;
import android.content.ContentResolver;
import android.content.ClipData;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ShortcutInfo;
import android.content.pm.ShortcutManager;
import android.content.res.ColorStateList;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Color;
import android.graphics.ImageDecoder;
import android.graphics.Matrix;
import android.animation.ValueAnimator;
import android.graphics.RectF;
import android.graphics.drawable.AnimatedImageDrawable;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.Icon;
import android.graphics.pdf.PdfRenderer;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.CancellationSignal;
import android.os.Handler;
import android.os.Looper;
import android.os.ParcelFileDescriptor;
import android.os.SystemClock;
import android.os.Environment;
import android.os.storage.StorageManager;
import android.os.storage.StorageVolume;
import android.provider.MediaStore;
import android.provider.DocumentsContract;
import android.provider.OpenableColumns;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.animation.PathInterpolator;
import android.view.animation.DecelerateInterpolator;
import android.view.ScaleGestureDetector;
import android.view.VelocityTracker;
import android.view.View;
import android.view.ViewConfiguration;
import android.text.InputType;
import android.util.LruCache;
import android.text.Editable;
import android.text.TextWatcher;
import android.widget.FrameLayout;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.EditText;
import android.widget.CheckBox;
import android.widget.ScrollView;
import android.widget.PopupWindow;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import java.io.IOException;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileInputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Locale;
import java.util.Random;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicReference;
import java.nio.file.Files;
import java.nio.file.attribute.BasicFileAttributes;

public class ViewerActivity extends Activity {
    private static final int REQ_MEDIA = 1001;
    private static final int REQ_SAF_TREE = 1002;
    private static final int REQ_MOVE_DELETE = 1003;
    private static final long DOUBLE_TAP_MS = 300;

    // v0.1.20 experiment: use a direct shared-storage directory index whenever the incoming
    // URI exposes a real path. MediaStore seed resolution remains the generic fallback.
    private static final boolean ENABLE_DIRECT_FILE_ENUM_EXPERIMENT = true;
    private static final boolean ENABLE_CURSOR_OUT_EXPERIMENT = true;
    private static final boolean ENABLE_CENTER_OUT_EXPERIMENT = true;
    private static final boolean ENABLE_EXTERNAL_FAST_PATH_EXPERIMENT = true;
    // This is only a UI merge chunk now; it is NOT a MediaStore query LIMIT.
    private static final int CURSOR_MERGE_CHUNK_SIZE = 24;
    private static final int CENTER_OUT_BATCH_SIZE = 24;
    private static final long FOLDER_CACHE_TTL_MS = 2 * 60 * 1000L;

    private FrameLayout rootView;
    private LinearLayout topBar;
    private LinearLayout bottomBar;
    private ChromeShadeOverlay shadeOverlay;
    private FrameLayout cropEditorRoot;
    private CropOverlayView cropOverlayView;
    private boolean cropEditing = false;
    private static final int CROP_RATIO_1_1 = 0;
    private static final int CROP_RATIO_4_3 = 1;
    private static final int CROP_RATIO_16_9 = 2;
    private static final int CROP_RATIO_DEVICE = 3;
    private static final int CROP_RATIO_FULL = 4;
    private static final int CROP_RATIO_FREE = 5;
    private int cropRatioMode = CROP_RATIO_FULL;
    private boolean cropPortrait = true;
    private TextView[] cropRatioChoices;
    private TextView[] cropOrientationChoices;
    private LinearLayout cropOrientationRow;
    private TextView cropFreeChoice;
    private CheckBox cropFreeLockCheck;
    private boolean cropFreeAspectLocked = false;
    private float cropFreeLockedAspect = 1f;
    private RotationSliderView cropRotationSlider;
    private float cropFineRotationDegrees = 0f;
    private boolean restoreCropEditorAfterLaunch = false;
    private RectF restoreCropNormalized;
    private static final String STATE_CROP_EDITING = "crop_editing";
    private static final String STATE_CROP_RATIO_MODE = "crop_ratio_mode";
    private static final String STATE_CROP_PORTRAIT = "crop_portrait";
    private static final String STATE_CROP_NORMALIZED = "crop_normalized";
    private static final String STATE_CROP_FREE_LOCKED = "crop_free_locked";
    private static final String STATE_CROP_FREE_ASPECT = "crop_free_aspect";
    private static final String STATE_CROP_FINE_ROTATION = "crop_fine_rotation";
    private static final String STATE_PENDING_ROTATION_DEGREES = "pending_rotation_degrees";
    private ZoomImageView imageView;
    private ImageView pagePreviewView;
    private TextView titleView;
    private TextView pageView;
    private View rotateButton;
    private View saveRotationButton;
    private PopupWindow rotationPopup;
    private volatile int pendingRotationDegrees = 0;
    private volatile Bitmap pendingRotationBitmap;
    private final AtomicInteger rotationGeneration = new AtomicInteger();
    private boolean rotationAnimating = false;
    // Session-only confirmations. These are never persisted across ViewerActivity sessions.
    private boolean skipDeleteConfirmationThisSession = false;
    private static final int CONFLICT_ASK = 0;
    private static final int CONFLICT_OVERWRITE = 1;
    private static final int CONFLICT_RENAME = 2;
    private int conflictPolicyThisSession = CONFLICT_ASK;
    // One-shot state used while Android's Storage Access Framework picker is in front.
    // Persisted URI permissions themselves are owned by ContentResolver and survive restarts.
    private File pendingSafDestinationDir;
    private File pendingSafRequestedPath;
    private boolean pendingSafMove;
    private int pendingSafPolicy = CONFLICT_OVERWRITE;

    // One-shot state while Android asks for permission to delete the original after a move.
    private PendingMoveDelete pendingMoveDelete;

    // Wallpaper editor is an in-viewer editing surface, separate from crop editing.
    private FrameLayout wallpaperEditorRoot;
    private WallpaperEditorView wallpaperEditorView;
    private boolean wallpaperEditing = false;
    private int wallpaperRatioMode = 0; // 0=portrait device, 1=landscape device, 2=1:1
    private int wallpaperRotationDegrees = 0;
    private WallpaperRatioIconView wallpaperRatioControl;

    // Slideshow is session-only. It never persists settings or creates a library.
    private boolean slideshowRunning = false;
    private long slideshowIntervalMs = 5000L;
    private boolean slideshowRandom = false;
    private boolean slideshowReverse = false;
    private boolean slideshowRepeat = false;
    private final ArrayList<MediaItem> slideshowItems = new ArrayList<>();
    private int slideshowCursor = -1;
    private FrameLayout slideshowTouchLayer;
    private View slideshowStopButton;
    private final Random slideshowRng = new Random();
    private Runnable slideshowTick;
    private boolean slideshowTransitioning = false;

    private ParcelFileDescriptor pdfFd;
    private PdfRenderer pdfRenderer;
    private PdfRenderer.Page pdfPage;

    private final List<MediaItem> siblings = new ArrayList<>();
    private int currentIndex = -1;
    private Uri currentUri;
    private String currentMime;
    private String currentName;

    private final ExecutorService decodeExecutor = Executors.newSingleThreadExecutor();
    // Editing/encoding is isolated so a rotation save/share never blocks the next image decode.
    private final ExecutorService editExecutor = Executors.newSingleThreadExecutor();
    // Folder enumeration must never block the UI thread.
    private final ExecutorService fileManagerExecutor = Executors.newSingleThreadExecutor();
    private final AtomicInteger fileManagerGeneration = new AtomicInteger();
    private final ExecutorService scanExecutor = Executors.newSingleThreadExecutor();
    private final ExecutorService neighborExecutor = Executors.newFixedThreadPool(2);
    private final ExecutorService providerDirectoryExecutor = Executors.newSingleThreadExecutor();
    private final ExecutorService fullScanExecutor = Executors.newSingleThreadExecutor();
    private final ExecutorService prefetchExecutor = Executors.newFixedThreadPool(2);
    private final Handler mainHandler = new Handler(Looper.getMainLooper());
    private final AtomicInteger decodeGeneration = new AtomicInteger();
    private final AtomicInteger prefetchGeneration = new AtomicInteger();
    private final AtomicInteger siblingGeneration = new AtomicInteger();
    // CancellationSignals matter because interrupting an Executor thread does not reliably
    // abort a slow ContentResolver query. A new viewer/search cancels the provider work itself.
    private volatile CancellationSignal seedResolveSignal;
    private volatile CancellationSignal previousCursorSignal;
    private volatile CancellationSignal nextCursorSignal;
    // Small screen-sized preview cache. This avoids re-decoding the same adjacent image
    // when the user swipes back and forth. Full-resolution images are not retained here.
    private final LruCache<String, Drawable> previewCache = new LruCache<>(6);
    private long launchStartedMs;
    private boolean firstFrameLogged = false;
    private boolean pageAnimating = false;
    private volatile Drawable previousPreviewDrawable;
    private volatile Drawable nextPreviewDrawable;
    private volatile MediaItem quickPreviousItem;
    private volatile MediaItem quickNextItem;
    private volatile boolean fullListReady = false;
    private volatile boolean progressiveListActive = false;
    private volatile boolean progressivePrevComplete = false;
    private volatile boolean progressiveNextComplete = false;
    private volatile int progressivePrevLoaded = 0;
    private volatile int progressiveNextLoaded = 0;
    private int topShadeExtentPx;
    private int bottomShadeExtentPx;

    private static class MediaItem {
        final Uri uri;
        final String name;
        final String mime;
        final long size;
        final long created;
        final long modified;
        MediaItem(Uri uri, String name, String mime, long size, long created, long modified) {
            this.uri = uri; this.name = name; this.mime = mime; this.size = size; this.created = created; this.modified = modified;
        }
        MediaItem(Uri uri, String name, String mime, long size, long modified) {
            this(uri, name, mime, size, modified, modified);
        }
    }

    private static class FolderCacheEntry {
        final long createdAt;
        final ArrayList<MediaItem> items;
        FolderCacheEntry(long createdAt, List<MediaItem> items) {
            this.createdAt = createdAt;
            this.items = new ArrayList<>(items);
        }
    }

    // Process-only cache: no library/database is created. It disappears when Android kills
    // Chirami's process. Cache stores order-independent folder metadata; each request sorts
    // a copy in RAM, so changing slide sort never throws away a warm folder index.
    private static final Object FOLDER_CACHE_LOCK = new Object();
    private static final LruCache<String, FolderCacheEntry> FOLDER_INDEX_CACHE = new LruCache<>(4);
    private static final Object DIRECTORY_CACHE_LOCK = new Object();
    private static final long DIRECTORY_CACHE_TTL_MS = 30 * 1000L;
    private static final LruCache<String, DirectoryCacheEntry> DIRECTORY_CACHE = new LruCache<>(32);

    private static class DirectoryCacheEntry {
        final long createdAt;
        final ArrayList<String> folderNames;
        DirectoryCacheEntry(long createdAt, List<String> folderNames) {
            this.createdAt = createdAt;
            this.folderNames = new ArrayList<>(folderNames);
        }
    }

    private int dp(float value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        launchStartedMs = SystemClock.elapsedRealtime();
        super.onCreate(savedInstanceState);
        AppLog.d(this, "VIEWER onCreate action=" + getIntent().getAction() + " type=" + getIntent().getType() + " data=" + getIntent().getData());
        logLaunchIntentDetails();
        getWindow().setStatusBarColor(Color.BLACK);
        getWindow().setNavigationBarColor(Color.BLACK);
        buildUi();

        Uri uri = getIntent().getData();
        if (uri == null) {
            AppLog.d(this, "VIEWER no URI");
            Toast.makeText(this, "ファイルを開けませんでした", Toast.LENGTH_SHORT).show();
            finish();
            return;
        }

        currentUri = uri;
        currentName = resolveDisplayName(uri);
        currentMime = getIntent().getType();
        if (currentMime == null) currentMime = getContentResolver().getType(uri);
        if (savedInstanceState != null) {
            pendingRotationDegrees = savedInstanceState.getInt(STATE_PENDING_ROTATION_DEGREES, pendingRotationDegrees);
            restoreCropEditorAfterLaunch = savedInstanceState.getBoolean(STATE_CROP_EDITING, false);
            cropRatioMode = savedInstanceState.getInt(STATE_CROP_RATIO_MODE, CROP_RATIO_FULL);
            cropPortrait = savedInstanceState.getBoolean(STATE_CROP_PORTRAIT, true);
            cropFreeAspectLocked = savedInstanceState.getBoolean(STATE_CROP_FREE_LOCKED, false);
            cropFreeLockedAspect = savedInstanceState.getFloat(STATE_CROP_FREE_ASPECT, 1f);
            cropFineRotationDegrees = Math.max(-180f, Math.min(180f, savedInstanceState.getFloat(STATE_CROP_FINE_ROTATION, 0f)));
            RectF restored = savedInstanceState.getParcelable(STATE_CROP_NORMALIZED);
            restoreCropNormalized = restored == null ? null : new RectF(restored);
        }
        AppLog.d(this, "VIEWER open +" + elapsed() + "ms name=" + currentName + " mime=" + currentMime + " uri=" + currentUri);

        // Most important rule in Chirami: render the tapped file first. Folder scanning is never allowed to delay it.
        showCurrentUri(false, 0);

        if (!isPdf(currentMime, uri)) {
            if (hasMediaPermission()) discoverSiblingImagesAsync();
            else requestMediaPermission();
        }
        if (restoreCropEditorAfterLaunch) {
            rootView.post(() -> restoreCropEditorWhenReady(0));
        }
    }

    private long elapsed() { return SystemClock.elapsedRealtime() - launchStartedMs; }


    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        outState.putInt(STATE_PENDING_ROTATION_DEGREES, pendingRotationDegrees);
        outState.putBoolean(STATE_CROP_EDITING, cropEditing);
        outState.putInt(STATE_CROP_RATIO_MODE, cropRatioMode);
        outState.putBoolean(STATE_CROP_PORTRAIT, cropPortrait);
        outState.putBoolean(STATE_CROP_FREE_LOCKED, cropFreeAspectLocked);
        outState.putFloat(STATE_CROP_FREE_ASPECT, cropFreeLockedAspect);
        outState.putFloat(STATE_CROP_FINE_ROTATION, cropFineRotationDegrees);
        RectF currentCrop = null;
        if (cropOverlayView != null) currentCrop = cropOverlayView.getNormalizedCrop();
        else if (restoreCropNormalized != null) currentCrop = new RectF(restoreCropNormalized);
        if (currentCrop != null) outState.putParcelable(STATE_CROP_NORMALIZED, currentCrop);
    }

    private void restoreCropEditorWhenReady(int attempts) {
        if (!restoreCropEditorAfterLaunch) return;
        if (cropEditing) {
            applyRestoredCropIfNeeded();
            return;
        }
        Drawable drawable = imageView == null ? null : imageView.getDrawable();
        if (drawable != null && drawable.getIntrinsicWidth() > 0 && drawable.getIntrinsicHeight() > 0) {
            startCropEditor();
            applyRestoredCropIfNeeded();
            return;
        }
        if (attempts >= 40 || rootView == null || isFinishing()) {
            restoreCropEditorAfterLaunch = false;
            restoreCropNormalized = null;
            AppLog.d(this, "CROP restore abandoned attempts=" + attempts);
            return;
        }
        rootView.postDelayed(() -> restoreCropEditorWhenReady(attempts + 1), 60L);
    }

    private void applyRestoredCropIfNeeded() {
        if (cropOverlayView != null && restoreCropNormalized != null) {
            cropOverlayView.setNormalizedCrop(restoreCropNormalized);
            AppLog.d(this, "CROP restore applied rect=" + restoreCropNormalized);
        }
        restoreCropEditorAfterLaunch = false;
        restoreCropNormalized = null;
    }

    private void buildUi() {
        rootView = new FrameLayout(this);
        rootView.setBackgroundColor(Color.BLACK);

        pagePreviewView = new ImageView(this);
        pagePreviewView.setBackgroundColor(Color.BLACK);
        pagePreviewView.setScaleType(ImageView.ScaleType.FIT_CENTER);
        pagePreviewView.setVisibility(View.GONE);
        rootView.addView(pagePreviewView, new FrameLayout.LayoutParams(-1, -1));

        imageView = new ZoomImageView();
        imageView.setBackgroundColor(Color.BLACK);
        imageView.setPageListener(new ZoomImageView.PageListener() {
            @Override public boolean canPage(int direction) { return canMoveSibling(direction); }
            @Override public void onPageDrag(int direction, float translationX) { showPagePreview(direction, translationX); }
            @Override public void onPageReset() { animatePageReset(); }
            @Override public void onPage(int direction, float velocityX) { animateToSibling(direction, velocityX); }
            @Override public void onSingleTap() { toggleChrome(); }
        });
        rootView.addView(imageView, new FrameLayout.LayoutParams(-1, -1));

        // Chrome is intentionally fully transparent: no top/bottom alpha-gray overlay.
        final int chromeInset = dp(50);
        shadeOverlay = null;

        topBar = new LinearLayout(this);
        topBar.setOrientation(LinearLayout.HORIZONTAL);
        topBar.setGravity(Gravity.CENTER_VERTICAL);
        topBar.setPadding(dp(4), 0, dp(4), 0);
        topBar.setBackgroundColor(Color.TRANSPARENT);

        final int topControlHeight = dp(58);
        final int roundIconDiameter = dp(38);

        // Draw the chrome icons ourselves instead of relying on font glyph baselines.
        // This keeps every control on the exact same visual center line on different fonts/devices.
        View back = new ToolbarIconView(this, ToolbarIconView.BACK, roundIconDiameter);
        back.setOnClickListener(v -> returnToCaller());
        topBar.addView(back, new LinearLayout.LayoutParams(dp(44), topControlHeight));

        titleView = new TextView(this);
        titleView.setTextColor(Color.WHITE); titleView.setTextSize(17); titleView.setSingleLine(true);
        titleView.setIncludeFontPadding(false);
        titleView.setEllipsize(android.text.TextUtils.TruncateAt.END); titleView.setGravity(Gravity.CENTER_VERTICAL);
        topBar.addView(titleView, new LinearLayout.LayoutParams(0, topControlHeight, 1f));

        pageView = new TextView(this);
        pageView.setTextColor(Color.rgb(210, 210, 210));
        pageView.setTextSize(12);
        pageView.setSingleLine(true);
        pageView.setIncludeFontPadding(false);
        pageView.setGravity(Gravity.CENTER);
        pageView.setPadding(dp(5), 0, dp(5), 0);
        pageView.setVisibility(View.VISIBLE);
        topBar.addView(pageView, new LinearLayout.LayoutParams(-2, topControlHeight));

        saveRotationButton = new ToolbarIconView(this, ToolbarIconView.CHECK, roundIconDiameter);
        saveRotationButton.setContentDescription("回転を確定");
        saveRotationButton.setVisibility(View.GONE);
        saveRotationButton.setOnClickListener(v -> {
            dismissRotationPopup();
            showSaveRotatedDialog();
        });
        topBar.addView(saveRotationButton, new LinearLayout.LayoutParams(dp(38), topControlHeight));

        rotateButton = new ToolbarIconView(this, ToolbarIconView.ROTATE, roundIconDiameter);
        rotateButton.setOnClickListener(this::showRotatePopup);
        topBar.addView(rotateButton, new LinearLayout.LayoutParams(dp(46), topControlHeight));

        View info = new ToolbarIconView(this, ToolbarIconView.INFO, roundIconDiameter);
        info.setOnClickListener(v -> showPropertiesDialog());
        topBar.addView(info, new LinearLayout.LayoutParams(dp(46), topControlHeight));

        View more = new ToolbarIconView(this, ToolbarIconView.MORE, roundIconDiameter);
        more.setOnClickListener(v -> showViewerMenu());
        topBar.addView(more, new LinearLayout.LayoutParams(dp(44), topControlHeight));
        FrameLayout.LayoutParams topParams = new FrameLayout.LayoutParams(-1, topControlHeight, Gravity.TOP);
        topParams.topMargin = chromeInset;
        rootView.addView(topBar, topParams);


        bottomBar = new LinearLayout(this);
        bottomBar.setOrientation(LinearLayout.HORIZONTAL); bottomBar.setGravity(Gravity.CENTER);
        bottomBar.setPadding(dp(38), 0, dp(38), 0); bottomBar.setBackgroundColor(Color.TRANSPARENT);

        View share = makeBottomIconAction(BottomActionIconView.SHARE, "共有", v -> shareCurrent());
        bottomBar.addView(share, new LinearLayout.LayoutParams(0, dp(72), 1f));

        View delete = makeBottomIconAction(BottomActionIconView.DELETE, "削除", v -> requestDeleteCurrent());
        bottomBar.addView(delete, new LinearLayout.LayoutParams(0, dp(72), 1f));
        FrameLayout.LayoutParams bottomParams = new FrameLayout.LayoutParams(-1, dp(72), Gravity.BOTTOM);
        bottomParams.bottomMargin = chromeInset;
        rootView.addView(bottomBar, bottomParams);

        setContentView(rootView);
        AppLog.d(this, "VIEWER UI ready +" + elapsed() + "ms");
    }

    private void returnToCaller() {
        AppLog.d(this, "VIEWER returnToCaller taskRoot=" + isTaskRoot());
        try {
            // ViewerActivity has an empty taskAffinity, so finishing its affinity never
            // walks back into Chirami's launcher/settings task. It reveals the app that
            // launched ACTION_VIEW (file manager, browser, etc.).
            if (isTaskRoot()) finishAndRemoveTask();
            else finishAffinity();
        } catch (Throwable ignored) {
            finish();
        }
    }

    @Override
    public void onBackPressed() {
        if (slideshowRunning) {
            stopSlideshow();
            return;
        }
        if (wallpaperEditing) {
            exitWallpaperEditor();
            return;
        }
        if (cropEditing) {
            exitCropEditor();
            return;
        }
        returnToCaller();
    }

    private boolean supportsBitmapEditingCurrent() {
        return currentUri != null && !isPdf(currentMime, currentUri);
    }

    private boolean isAnimatedGifCurrent() {
        if (currentUri == null) return false;
        String ext = extensionOf(currentName);
        boolean gif = "gif".equals(ext) || "image/gif".equalsIgnoreCase(currentMime);
        return gif && imageView != null && imageView.getDrawable() instanceof AnimatedImageDrawable;
    }

    private boolean supportsCropResizeCurrent() {
        if (!supportsBitmapEditingCurrent() || isAnimatedGifCurrent()) return false;
        String ext = extensionOf(currentName);
        if (ext.isEmpty()) ext = extensionFromMime(currentMime);
        return isWritableEditExtension(ext);
    }

    private String extensionFromMime(String mime) {
        if (mime == null) return "";
        String m = mime.toLowerCase(Locale.ROOT);
        if ("image/jpeg".equals(m)) return "jpg";
        if ("image/png".equals(m) || "image/x-png".equals(m)) return "png";
        if ("image/gif".equals(m)) return "gif";
        if ("image/webp".equals(m)) return "webp";
        return "";
    }

    private void updateCurrentFormatCapabilities() {
        boolean bitmapOps = supportsBitmapEditingCurrent();
        if (rotateButton != null) {
            rotateButton.setEnabled(bitmapOps);
            rotateButton.setClickable(bitmapOps);
            rotateButton.setAlpha(1f);
            rotateButton.invalidate();
            rotateButton.setContentDescription(bitmapOps ? "回転" : "回転（この形式では利用できません）");
        }
        if (!bitmapOps) {
            dismissRotationPopup();
            if (saveRotationButton != null) saveRotationButton.setVisibility(View.GONE);
        }
    }

    private void setViewerMenuRowEnabled(FrameLayout row, boolean enabled) {
        if (row == null) return;
        row.setEnabled(enabled);
        row.setClickable(enabled);
        row.setFocusable(enabled);
        if (row.getChildCount() > 0 && row.getChildAt(0) instanceof TextView) {
            TextView label = (TextView) row.getChildAt(0);
            label.setEnabled(enabled);
            label.setTextColor(enabled ? Color.WHITE : Color.rgb(90, 85, 85));
        }
    }

    private void showViewerMenu() {
        final int panel = Color.rgb(58, 51, 51);
        LinearLayout content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(0, dp(6), 0, dp(6));
        content.setMinimumWidth(dp(252));
        content.setBackground(makeRoundedPanel(panel));

        FrameLayout sort = makeViewerMenuRow("スライド順");
        FrameLayout copy = makeViewerMenuRow("コピー");
        FrameLayout move = makeViewerMenuRow("移動");
        FrameLayout shortcut = makeViewerMenuRow("ショートカットを作成");
        FrameLayout wallpaper = makeViewerMenuRow("壁紙に設定する");
        FrameLayout crop = makeViewerMenuRow("トリミング");
        FrameLayout resize = makeViewerMenuRow("リサイズ");
        FrameLayout saveDestination = makeViewerMenuRow("保存先");
        FrameLayout slideshow = makeViewerMenuRow("スライドショー");

        content.addView(sort, new LinearLayout.LayoutParams(-1, dp(52)));
        content.addView(copy, new LinearLayout.LayoutParams(-1, dp(52)));
        content.addView(move, new LinearLayout.LayoutParams(-1, dp(52)));
        content.addView(shortcut, new LinearLayout.LayoutParams(-1, dp(52)));
        content.addView(wallpaper, new LinearLayout.LayoutParams(-1, dp(52)));
        content.addView(crop, new LinearLayout.LayoutParams(-1, dp(52)));
        content.addView(resize, new LinearLayout.LayoutParams(-1, dp(52)));
        content.addView(saveDestination, new LinearLayout.LayoutParams(-1, dp(52)));
        content.addView(slideshow, new LinearLayout.LayoutParams(-1, dp(52)));

        boolean bitmapOps = supportsBitmapEditingCurrent();
        boolean cropResize = supportsCropResizeCurrent();
        setViewerMenuRowEnabled(shortcut, bitmapOps);
        setViewerMenuRowEnabled(wallpaper, bitmapOps);
        setViewerMenuRowEnabled(crop, cropResize);
        setViewerMenuRowEnabled(resize, cropResize);

        AlertDialog dialog = new AlertDialog.Builder(this).setView(content).create();
        dialog.setCanceledOnTouchOutside(true);
        prepareDialogBeforeShow(dialog, panel);
        sort.setOnClickListener(v -> { dialog.dismiss(); showSortDialog(); });
        copy.setOnClickListener(v -> { dialog.dismiss(); showDestinationManager(false); });
        move.setOnClickListener(v -> { dialog.dismiss(); showDestinationManager(true); });
        shortcut.setOnClickListener(v -> { dialog.dismiss(); requestPinnedImageShortcut(); });
        wallpaper.setOnClickListener(v -> { dialog.dismiss(); startWallpaperEditor(); });
        crop.setOnClickListener(v -> { dialog.dismiss(); startCropEditor(); });
        resize.setOnClickListener(v -> { dialog.dismiss(); showResizeDialog(); });
        saveDestination.setOnClickListener(v -> { dialog.dismiss(); startActivity(new Intent(this, FolderPickerActivity.class)); });
        slideshow.setOnClickListener(v -> { dialog.dismiss(); showSlideshowDialog(); });
        AppLog.d(this, "DIALOG viewer-menu show-prepared rows=9");
        dialog.show();
    }

    private FrameLayout makeViewerMenuRow(String text) {
        FrameLayout row = new FrameLayout(this);
        row.setClickable(true);
        row.setFocusable(true);

        TextView label = new TextView(this);
        label.setText(text);
        label.setTextColor(Color.WHITE);
        label.setTextSize(17);
        label.setGravity(Gravity.CENTER_VERTICAL);
        label.setPadding(dp(18), 0, dp(18), 0);
        // The container owns the click target; the label is visual content only.
        label.setClickable(false);
        row.addView(label, new FrameLayout.LayoutParams(-1, -1));
        return row;
    }

    private void requestPinnedImageShortcut() {
        if (currentUri == null || currentName == null) return;
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) {
            Toast.makeText(this, "この端末ではショートカットを作成できません", Toast.LENGTH_SHORT).show();
            return;
        }
        ShortcutManager manager = getSystemService(ShortcutManager.class);
        if (manager == null || !manager.isRequestPinShortcutSupported()) {
            Toast.makeText(this, "ホーム画面への追加に対応していません", Toast.LENGTH_SHORT).show();
            return;
        }
        try {
            Uri launchUri = currentUri;
            if ("content".equalsIgnoreCase(currentUri.getScheme())) {
                try {
                    int flags = getIntent().getFlags() &
                            (Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
                    if ((getIntent().getFlags() & Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION) != 0) {
                        getContentResolver().takePersistableUriPermission(currentUri,
                                flags == 0 ? Intent.FLAG_GRANT_READ_URI_PERMISSION : flags);
                    }
                } catch (Throwable ignored) { }
                String path = inferAbsolutePathFromAnyUri(currentUri);
                if (path != null && !path.isEmpty()) {
                    try {
                        launchUri = androidx.core.content.FileProvider.getUriForFile(
                                this, getPackageName() + ".fileprovider", new File(path));
                    } catch (Throwable ignored) { }
                }
            }

            Intent launch = new Intent(this, ViewerActivity.class);
            launch.setAction(Intent.ACTION_VIEW);
            launch.setDataAndType(launchUri, currentMime == null ? mimeFromName(currentName) : currentMime);
            launch.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_ACTIVITY_NEW_TASK);

            Bitmap iconBitmap = renderShortcutIcon(currentUri);
            String id = "image_" + Integer.toHexString(launchUri.toString().hashCode());
            String shortcutLabel = currentName.length() > 40 ? currentName.substring(0, 39) + "…" : currentName;
            ShortcutInfo.Builder builder = new ShortcutInfo.Builder(this, id)
                    .setShortLabel(shortcutLabel)
                    .setLongLabel(currentName)
                    .setIntent(launch);
            if (iconBitmap != null) builder.setIcon(Icon.createWithBitmap(iconBitmap));
            boolean requested = manager.requestPinShortcut(builder.build(), null);
            AppLog.d(this, "SHORTCUT request name=" + currentName + " requested=" + requested + " uri=" + launchUri);
            if (!requested) Toast.makeText(this, "ショートカットを作成できませんでした", Toast.LENGTH_SHORT).show();
        } catch (Throwable e) {
            AppLog.d(this, "SHORTCUT error " + e);
            Toast.makeText(this, "ショートカットを作成できませんでした", Toast.LENGTH_SHORT).show();
        }
    }

    private Bitmap renderShortcutIcon(Uri sourceUri) throws IOException {
        if (sourceUri == null) return null;
        final int iconSize = 192;
        final int preferredShortSide = 256;
        final int maxDecodeSide = 768;
        ImageDecoder.Source source = createImageSource(sourceUri);
        Bitmap decoded = ImageDecoder.decodeBitmap(source, (decoder, info, src) -> {
            int iw = Math.max(1, info.getSize().getWidth());
            int ih = Math.max(1, info.getSize().getHeight());
            int shortSide = Math.max(1, Math.min(iw, ih));
            int longSide = Math.max(iw, ih);
            float scale = Math.min(1f, Math.min(preferredShortSide / (float) shortSide,
                    maxDecodeSide / (float) longSide));
            int targetW = Math.max(1, Math.round(iw * scale));
            int targetH = Math.max(1, Math.round(ih * scale));
            decoder.setAllocator(ImageDecoder.ALLOCATOR_SOFTWARE);
            decoder.setTargetSize(targetW, targetH);
        });
        int side = Math.max(1, Math.min(decoded.getWidth(), decoded.getHeight()));
        int left = Math.max(0, (decoded.getWidth() - side) / 2);
        int top = Math.max(0, (decoded.getHeight() - side) / 2);
        Bitmap icon = Bitmap.createBitmap(iconSize, iconSize, Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(icon);
        Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG);
        android.graphics.Rect srcRect = new android.graphics.Rect(left, top, left + side, top + side);
        android.graphics.Rect dstRect = new android.graphics.Rect(0, 0, iconSize, iconSize);
        canvas.drawBitmap(decoded, srcRect, dstRect, paint);
        AppLog.d(this, "SHORTCUT icon ready size=" + icon.getWidth() + "x" + icon.getHeight() +
                " source=" + decoded.getWidth() + "x" + decoded.getHeight() + " config=" + decoded.getConfig());
        return icon;
    }

    private void showResizeDialog() {
        if (!supportsCropResizeCurrent()) {
            Toast.makeText(this, isAnimatedGifCurrent() ? "アニメーションGIFはリサイズできません" : "このファイルはリサイズできません", Toast.LENGTH_SHORT).show();
            return;
        }
        Drawable d = imageView == null ? null : imageView.getDrawable();
        if (d == null || d.getIntrinsicWidth() <= 0 || d.getIntrinsicHeight() <= 0) {
            Toast.makeText(this, "画像サイズを取得できませんでした", Toast.LENGTH_SHORT).show();
            return;
        }
        int iw = d.getIntrinsicWidth();
        int ih = d.getIntrinsicHeight();
        int normalizedRotation = ((pendingRotationDegrees % 360) + 360) % 360;
        final int sourceW = normalizedRotation % 180 == 0 ? iw : ih;
        final int sourceH = normalizedRotation % 180 == 0 ? ih : iw;
        final double aspect = sourceW / (double)Math.max(1, sourceH);
        final int panel = Color.rgb(58, 51, 51);
        final int secondary = Color.rgb(180, 180, 190);

        LinearLayout content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(dp(22), dp(8), dp(22), dp(8));
        content.setBackgroundColor(panel);

        LinearLayout sizeRow = new LinearLayout(this);
        sizeRow.setOrientation(LinearLayout.HORIZONTAL);
        sizeRow.setGravity(Gravity.CENTER_VERTICAL);
        EditText width = makeSaveField("幅", String.valueOf(sourceW));
        EditText height = makeSaveField("高さ", String.valueOf(sourceH));
        width.setInputType(InputType.TYPE_CLASS_NUMBER);
        height.setInputType(InputType.TYPE_CLASS_NUMBER);
        TextView colon = new TextView(this);
        colon.setText(":"); colon.setTextColor(Color.WHITE); colon.setTextSize(20); colon.setGravity(Gravity.CENTER);
        sizeRow.addView(width, new LinearLayout.LayoutParams(0, dp(58), 1f));
        sizeRow.addView(colon, new LinearLayout.LayoutParams(dp(36), dp(58)));
        sizeRow.addView(height, new LinearLayout.LayoutParams(0, dp(58), 1f));
        content.addView(sizeRow, new LinearLayout.LayoutParams(-1, -2));

        TextView folder = new TextView(this);
        folder.setTextColor(Color.WHITE); folder.setTextSize(14); folder.setPadding(dp(4), dp(12), dp(4), dp(10));
        content.addView(folder, new LinearLayout.LayoutParams(-1, -2));

        EditText name = makeSaveField("ファイル名", baseNameOf(currentName));
        content.addView(name, new LinearLayout.LayoutParams(-1, dp(58)));

        OverwriteToggleView overwriteToggle = new OverwriteToggleView();
        LinearLayout overwriteRow = makeOverwriteRow(overwriteToggle);
        LinearLayout.LayoutParams orp = new LinearLayout.LayoutParams(-1, dp(46)); orp.topMargin = dp(8);
        content.addView(overwriteRow, orp);
        Runnable refreshFolder = () -> folder.setText("保存先\n" + editDestinationDescription(overwriteToggle.isChecked()));
        overwriteToggle.setOnCheckedChanged(refreshFolder);
        refreshFolder.run();

        TextView fixed = new TextView(this);
        fixed.setText("縦横比は固定"); fixed.setTextColor(secondary); fixed.setTextSize(13);
        fixed.setPadding(dp(4), dp(4), 0, 0);
        content.addView(fixed, new LinearLayout.LayoutParams(-1, -2));

        final boolean[] syncing = {false};
        width.addTextChangedListener(new TextWatcher() {
            public void beforeTextChanged(CharSequence s, int st, int c, int a) { }
            public void onTextChanged(CharSequence s, int st, int b, int c) {
                if (syncing[0]) return;
                try { int w = Integer.parseInt(s.toString()); if (w <= 0) return; syncing[0]=true; height.setText(String.valueOf(Math.max(1,(int)Math.round(w/aspect)))); height.setSelection(height.length()); }
                catch (Throwable ignored) { } finally { syncing[0]=false; }
            }
            public void afterTextChanged(Editable e) { }
        });
        height.addTextChangedListener(new TextWatcher() {
            public void beforeTextChanged(CharSequence s, int st, int c, int a) { }
            public void onTextChanged(CharSequence s, int st, int b, int c) {
                if (syncing[0]) return;
                try { int h = Integer.parseInt(s.toString()); if (h <= 0) return; syncing[0]=true; width.setText(String.valueOf(Math.max(1,(int)Math.round(h*aspect)))); width.setSelection(width.length()); }
                catch (Throwable ignored) { } finally { syncing[0]=false; }
            }
            public void afterTextChanged(Editable e) { }
        });

        AlertDialog dialog = new AlertDialog.Builder(this).setTitle("リサイズ").setView(content)
                .setNegativeButton("キャンセル", null).setPositiveButton("OK", null).create();
        prepareDialogBeforeShow(dialog, panel);
        dialog.setOnShowListener(v -> {
            int titleId = getResources().getIdentifier("alertTitle", "id", "android");
            TextView title = dialog.findViewById(titleId); if (title != null) title.setTextColor(Color.WHITE);
            styleDialogButton(dialog, AlertDialog.BUTTON_NEGATIVE, Color.WHITE, panel);
            styleDialogButton(dialog, AlertDialog.BUTTON_POSITIVE, Color.WHITE, panel);
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v2 -> {
                int w,h;
                try { w=Integer.parseInt(width.getText().toString()); h=Integer.parseInt(height.getText().toString()); }
                catch(Throwable e){ width.setError("数値を入力してください"); return; }
                if (w<1 || h<1 || w>32768 || h>32768 || (long)w*h>100_000_000L) { width.setError("サイズが大きすぎます"); return; }
                String base=name.getText().toString().trim();
                if(base.isEmpty()){ name.setError("ファイル名を入力してください"); return; }
                dialog.dismiss();
                saveResizedCurrent(base,w,h,overwriteToggle.isChecked());
            });
        });
        dialog.show();
        AppLog.d(this, "RESIZE dialog source="+sourceW+"x"+sourceH+" destination="+SavePrefs.directory(this));
    }

    private void saveResizedCurrent(String base, int width, int height, boolean overwriteSource) {
        final Uri sourceUri = currentUri;
        final int degrees = pendingRotationDegrees;
        final String sourceName = currentName;
        if (sourceUri == null) return;
        Toast.makeText(this, "保存しています", Toast.LENGTH_SHORT).show();
        safeExecute(editExecutor, () -> {
            try {
                Bitmap source = decodeRotatedBitmap(sourceUri, degrees);
                Bitmap resized = Bitmap.createScaledBitmap(source, width, height, true);
                String ext = editableSourceExtension(sourceName);
                EditSaveResult result = saveEditedBitmap(resized, base, ext, sourceUri, sourceName, overwriteSource);
                mainHandler.post(() -> {
                    currentUri = result.uri; currentName = result.name; currentMime = result.mime;
                    clearPendingRotationState(); titleView.setText(currentName); openImageAsync(result.uri,false,0); discoverSiblingImagesAsync();
                    Toast.makeText(this, "保存しました", Toast.LENGTH_SHORT).show();
                    AppLog.d(this, "RESIZE saved name="+result.name+" size="+width+"x"+height+" overwrite="+overwriteSource);
                });
            } catch (Throwable e) {
                AppLog.d(this, "RESIZE error " + e);
                mainHandler.post(() -> Toast.makeText(this, "リサイズ画像を保存できませんでした", Toast.LENGTH_LONG).show());
            }
        });
    }

    private void showSlideshowDialog() {
        final int panel = Color.rgb(58, 51, 51);
        LinearLayout content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(dp(22), dp(8), dp(22), dp(8));
        content.setBackgroundColor(panel);

        LinearLayout intervalRow = new LinearLayout(this);
        intervalRow.setOrientation(LinearLayout.HORIZONTAL);
        intervalRow.setGravity(Gravity.CENTER_VERTICAL);
        TextView intervalLabel = new TextView(this);
        intervalLabel.setText("間隔"); intervalLabel.setTextColor(Color.WHITE); intervalLabel.setTextSize(17);
        EditText seconds = makeSaveField("秒", "5");
        seconds.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL);
        intervalRow.addView(intervalLabel, new LinearLayout.LayoutParams(0, dp(58), 1f));
        intervalRow.addView(seconds, new LinearLayout.LayoutParams(dp(110), dp(58)));
        content.addView(intervalRow);

        CheckBox random = makeSlideshowCheck("ランダム");
        CheckBox reverse = makeSlideshowCheck("逆再生");
        CheckBox repeat = makeSlideshowCheck("リピート再生");
        content.addView(random, new LinearLayout.LayoutParams(-1, dp(54)));
        content.addView(reverse, new LinearLayout.LayoutParams(-1, dp(54)));
        content.addView(repeat, new LinearLayout.LayoutParams(-1, dp(54)));

        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle("スライドショー")
                .setView(content)
                .setNegativeButton("キャンセル", null)
                .setPositiveButton("OK", null)
                .create();
        prepareDialogBeforeShow(dialog, panel);
        dialog.setOnShowListener(v -> {
            int titleId = getResources().getIdentifier("alertTitle", "id", "android");
            TextView title = dialog.findViewById(titleId); if (title != null) title.setTextColor(Color.WHITE);
            styleDialogButton(dialog, AlertDialog.BUTTON_NEGATIVE, Color.WHITE, panel);
            styleDialogButton(dialog, AlertDialog.BUTTON_POSITIVE, Color.WHITE, panel);
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v2 -> {
                float sec;
                try { sec = Float.parseFloat(seconds.getText().toString()); }
                catch (Throwable e) { seconds.setError("秒数を入力してください"); return; }
                if (sec < 0.2f || sec > 3600f) { seconds.setError("0.2～3600秒で指定してください"); return; }
                dialog.dismiss();
                startSlideshow(Math.max(200L, Math.round(sec * 1000f)), random.isChecked(), reverse.isChecked(), repeat.isChecked());
            });
        });
        dialog.show();
    }

    private CheckBox makeSlideshowCheck(String label) {
        CheckBox box = new CheckBox(this);
        box.setText(label); box.setTextColor(Color.WHITE); box.setTextSize(17); box.setGravity(Gravity.CENTER_VERTICAL);
        box.setButtonTintList(new ColorStateList(
                new int[][]{new int[]{android.R.attr.state_checked}, new int[]{}},
                new int[]{Color.rgb(68, 85, 119), Color.rgb(90, 85, 85)}));
        return box;
    }

    private void startSlideshow(long intervalMs, boolean random, boolean reverse, boolean repeat) {
        stopSlideshowInternal(false);
        slideshowIntervalMs = intervalMs;
        slideshowRandom = random;
        slideshowReverse = reverse;
        slideshowRepeat = repeat;
        slideshowItems.clear();
        if (!siblings.isEmpty()) slideshowItems.addAll(siblings);
        if (slideshowItems.isEmpty()) {
            MediaItem current = currentMediaItem();
            if (current != null) slideshowItems.add(current);
            else slideshowItems.add(new MediaItem(currentUri, currentName, currentMime, -1L, -1L, -1L));
        }
        if (random) {
            Collections.shuffle(slideshowItems, slideshowRng);
            int current = findSlideshowCurrentIndex();
            if (current > 0) Collections.swap(slideshowItems, 0, current);
        } else if (reverse) Collections.reverse(slideshowItems);
        slideshowCursor = findSlideshowCurrentIndex();
        if (slideshowCursor < 0) slideshowCursor = 0;
        slideshowRunning = true;
        slideshowTransitioning = false;
        topBar.setVisibility(View.GONE);
        bottomBar.setVisibility(View.GONE);
        getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_FULLSCREEN | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION);
        installSlideshowTouchLayer();
        prefetchNextSlideshowPreview();
        scheduleNextSlideshowTick(slideshowIntervalMs);
        AppLog.d(this, "SLIDESHOW start intervalMs=" + intervalMs + " random=" + random + " reverse=" + reverse + " repeat=" + repeat + " count=" + slideshowItems.size());
    }

    private void scheduleNextSlideshowTick(long delayMs) {
        if (slideshowTick != null) mainHandler.removeCallbacks(slideshowTick);
        slideshowTick = () -> {
            slideshowTick = null;
            if (!slideshowRunning) return;
            if (slideshowTransitioning) {
                scheduleNextSlideshowTick(120L);
                return;
            }
            advanceSlideshow();
        };
        mainHandler.postDelayed(slideshowTick, Math.max(50L, delayMs));
    }

    private int findSlideshowCurrentIndex() {
        for (int i = 0; i < slideshowItems.size(); i++) {
            MediaItem item = slideshowItems.get(i);
            if (item != null && ((item.uri != null && item.uri.equals(currentUri)) || sameName(item.name, currentName))) return i;
        }
        return -1;
    }

    private int nextSlideshowCursor(boolean allowWrap) {
        int next = slideshowCursor + 1;
        if (next < slideshowItems.size()) return next;
        if (!allowWrap || !slideshowRepeat || slideshowItems.isEmpty()) return -1;
        return 0;
    }

    private void advanceSlideshow() {
        if (slideshowItems.size() <= 1) {
            if (fullListReady && siblings.size() > 1) {
                slideshowItems.clear(); slideshowItems.addAll(siblings);
                if (slideshowRandom) {
                    Collections.shuffle(slideshowItems, slideshowRng);
                    int current = findSlideshowCurrentIndex();
                    if (current > 0) Collections.swap(slideshowItems, 0, current);
                } else if (slideshowReverse) Collections.reverse(slideshowItems);
                slideshowCursor = findSlideshowCurrentIndex();
                if (slideshowCursor < 0) slideshowCursor = 0;
            } else {
                scheduleNextSlideshowTick(slideshowIntervalMs);
                return;
            }
        }
        int next = nextSlideshowCursor(true);
        if (next < 0) { stopSlideshow(); return; }
        if (next == 0 && slideshowCursor == slideshowItems.size() - 1 && slideshowRandom && slideshowRepeat) {
            Collections.shuffle(slideshowItems, slideshowRng);
            slideshowCursor = findSlideshowCurrentIndex();
            if (slideshowCursor < 0) slideshowCursor = slideshowItems.size() - 1;
            next = nextSlideshowCursor(true);
            if (next < 0) { stopSlideshow(); return; }
        }
        MediaItem item = slideshowItems.get(next);
        if (item == null || item.uri == null) {
            slideshowCursor = next;
            scheduleNextSlideshowTick(slideshowIntervalMs);
            return;
        }
        slideshowTransitioning = true;
        final int targetCursor = next;
        final int physicalDirection = slideshowReverse && !slideshowRandom ? -1 : 1;
        Drawable preview = getCachedPreview(item.uri);
        if (preview != null) {
            animateSlideshowToItem(item, targetCursor, physicalDirection, preview);
            return;
        }
        final MediaItem targetItem = item;
        prefetchExecutor.execute(() -> {
            try {
                Drawable decoded = decodePreviewDrawable(targetItem.uri);
                putCachedPreview(targetItem.uri, decoded);
                mainHandler.post(() -> {
                    if (!slideshowRunning || !slideshowTransitioning) return;
                    animateSlideshowToItem(targetItem, targetCursor, physicalDirection, decoded);
                });
            } catch (Throwable e) {
                AppLog.d(this, "SLIDESHOW preview error " + e);
                mainHandler.post(() -> {
                    if (!slideshowRunning) return;
                    slideshowTransitioning = false;
                    scheduleNextSlideshowTick(250L);
                });
            }
        });
    }

    private void animateSlideshowToItem(MediaItem item, int targetCursor, int direction, Drawable preview) {
        if (!slideshowRunning || item == null || preview == null || pagePreviewView == null || imageView == null) return;
        int width = Math.max(1, imageView.getWidth());
        float outgoingTarget = direction > 0 ? -width : width;
        float incomingStart = direction > 0 ? width : -width;
        long duration = 165L;

        imageView.animate().cancel();
        pagePreviewView.animate().cancel();
        imageView.setLayerType(View.LAYER_TYPE_HARDWARE, null);
        pagePreviewView.setLayerType(View.LAYER_TYPE_HARDWARE, null);
        imageView.setTranslationX(0f);
        pagePreviewView.setImageDrawable(preview);
        pagePreviewView.setTranslationX(incomingStart);
        pagePreviewView.setAlpha(1f);
        pagePreviewView.setVisibility(View.VISIBLE);

        pagePreviewView.animate().translationX(0f).setDuration(duration).setInterpolator(pageInterpolator).start();
        imageView.animate().translationX(outgoingTarget).setDuration(duration).setInterpolator(pageInterpolator).withEndAction(() -> {
            if (!slideshowRunning) {
                imageView.setTranslationX(0f);
                hidePagePreview();
                slideshowTransitioning = false;
                return;
            }
            slideshowCursor = targetCursor;
            currentUri = item.uri; currentName = item.name; currentMime = item.mime;
            clearPendingRotationState();
            updateCurrentFormatCapabilities();
            for (int i = 0; i < siblings.size(); i++) {
                MediaItem s = siblings.get(i);
                if (s != null && ((s.uri != null && s.uri.equals(item.uri)) || sameName(s.name, item.name))) { currentIndex = i; break; }
            }
            imageView.setImageForViewerKeepingTranslation(preview);
            imageView.setTranslationX(0f);
            titleView.setText(currentName);
            updatePositionLabel();
            pagePreviewView.postOnAnimation(() -> {
                hidePagePreview();
                slideshowTransitioning = false;
                AppLog.d(this, "SLIDESHOW swipe cursor=" + slideshowCursor + " direction=" + direction + " name=" + currentName);
                openImageAsync(currentUri, false, 0);
                if (hasIndexedSiblingWindow()) prefetchAdjacent();
                prefetchNextSlideshowPreview();
                scheduleNextSlideshowTick(slideshowIntervalMs);
            });
        }).start();
    }

    private void prefetchNextSlideshowPreview() {
        if (!slideshowRunning || slideshowItems.isEmpty()) return;
        int next = nextSlideshowCursor(true);
        if (next < 0 || next >= slideshowItems.size()) return;
        MediaItem item = slideshowItems.get(next);
        if (item == null || item.uri == null || getCachedPreview(item.uri) != null) return;
        prefetchExecutor.execute(() -> {
            try {
                Drawable decoded = decodePreviewDrawable(item.uri);
                putCachedPreview(item.uri, decoded);
                AppLog.d(this, "SLIDESHOW prefetch ready cursor=" + next + " name=" + item.name);
            } catch (Throwable e) {
                AppLog.d(this, "SLIDESHOW prefetch error " + e);
            }
        });
    }

    private void installSlideshowTouchLayer() {
        if (rootView == null) return;
        slideshowTouchLayer = new FrameLayout(this);
        slideshowTouchLayer.setBackgroundColor(Color.TRANSPARENT);
        slideshowTouchLayer.setClickable(true);
        slideshowTouchLayer.setOnClickListener(v -> {
            if (slideshowStopButton != null) slideshowStopButton.setVisibility(View.VISIBLE);
        });
        slideshowStopButton = new SlideshowStopView(this);
        slideshowStopButton.setContentDescription("スライドショーを停止");
        slideshowStopButton.setVisibility(View.GONE);
        slideshowStopButton.setOnClickListener(v -> stopSlideshow());
        FrameLayout.LayoutParams stopLp = new FrameLayout.LayoutParams(dp(104), dp(104), Gravity.CENTER);
        slideshowTouchLayer.addView(slideshowStopButton, stopLp);
        rootView.addView(slideshowTouchLayer, new FrameLayout.LayoutParams(-1, -1));
    }

    private void stopSlideshow() { stopSlideshowInternal(true); }

    private void stopSlideshowInternal(boolean restoreChrome) {
        if (slideshowTick != null) mainHandler.removeCallbacks(slideshowTick);
        slideshowTick = null;
        slideshowRunning = false;
        slideshowTransitioning = false;
        slideshowItems.clear();
        imageView.animate().cancel();
        if (pagePreviewView != null) pagePreviewView.animate().cancel();
        imageView.setTranslationX(0f);
        hidePagePreview();
        if (slideshowTouchLayer != null && rootView != null) rootView.removeView(slideshowTouchLayer);
        slideshowTouchLayer = null;
        slideshowStopButton = null;
        if (restoreChrome) {
            topBar.setVisibility(View.VISIBLE);
            bottomBar.setVisibility(View.VISIBLE);
            getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_VISIBLE);
        }
        AppLog.d(this, "SLIDESHOW stop");
    }

    private void startWallpaperEditor() {
        if (wallpaperEditing || currentUri == null) return;
        if (isPdf(currentMime, currentUri)) {
            Toast.makeText(this, "PDFは壁紙に設定できません", Toast.LENGTH_SHORT).show();
            return;
        }
        Drawable drawable = imageView == null ? null : imageView.getDrawable();
        if (drawable == null || drawable.getIntrinsicWidth() <= 0 || drawable.getIntrinsicHeight() <= 0) {
            Toast.makeText(this, "画像を準備できませんでした", Toast.LENGTH_SHORT).show();
            return;
        }
        dismissRotationPopup();
        cancelPageAnimationsForTouch();
        wallpaperRatioMode = 0;
        wallpaperRotationDegrees = 0;

        wallpaperEditorRoot = new FrameLayout(this);
        wallpaperEditorRoot.setBackgroundColor(Color.BLACK);
        wallpaperEditorRoot.setClickable(true);
        wallpaperEditorRoot.setFocusable(true);

        wallpaperEditorView = new WallpaperEditorView(drawable, pendingRotationDegrees);
        FrameLayout.LayoutParams canvasLp = new FrameLayout.LayoutParams(-1, -1);
        canvasLp.topMargin = dp(112);
        canvasLp.bottomMargin = dp(150);
        wallpaperEditorRoot.addView(wallpaperEditorView, canvasLp);

        LinearLayout top = new LinearLayout(this);
        top.setOrientation(LinearLayout.HORIZONTAL);
        top.setGravity(Gravity.CENTER_VERTICAL);
        top.setPadding(dp(4), 0, dp(4), 0);
        View back = new ToolbarIconView(this, ToolbarIconView.BACK, dp(38));
        back.setContentDescription("壁紙編集をキャンセル");
        back.setOnClickListener(v -> exitWallpaperEditor());
        top.addView(back, new LinearLayout.LayoutParams(dp(44), dp(58)));
        TextView title = new TextView(this);
        title.setText("壁紙に設定"); title.setTextColor(Color.WHITE); title.setTextSize(18); title.setGravity(Gravity.CENTER_VERTICAL);
        title.setSingleLine(true); title.setIncludeFontPadding(false);
        top.addView(title, new LinearLayout.LayoutParams(0, dp(58), 1f));
        View check = new ToolbarIconView(this, ToolbarIconView.CHECK_LARGE, dp(38));
        check.setContentDescription("壁紙を設定");
        check.setOnClickListener(v -> applyWallpaperFromEditor());
        top.addView(check, new LinearLayout.LayoutParams(dp(44), dp(58)));
        FrameLayout.LayoutParams topLp = new FrameLayout.LayoutParams(-1, dp(58), Gravity.TOP);
        topLp.topMargin = dp(50);
        wallpaperEditorRoot.addView(top, topLp);

        LinearLayout controls = new LinearLayout(this);
        controls.setOrientation(LinearLayout.HORIZONTAL);
        controls.setGravity(Gravity.CENTER);
        controls.setPadding(dp(38), 0, dp(38), 0);
        controls.setBackgroundColor(Color.TRANSPARENT);
        wallpaperRatioControl = new WallpaperRatioIconView(this);
        wallpaperRatioControl.setContentDescription("壁紙の選択範囲を切り替え");
        wallpaperRatioControl.setMode(wallpaperRatioMode);
        View rotate = new ToolbarIconView(this, ToolbarIconView.ROTATE, dp(38));
        rotate.setContentDescription("壁紙画像を90度回転");
        wallpaperRatioControl.setOnClickListener(v -> {
            wallpaperRatioMode = (wallpaperRatioMode + 1) % 3;
            wallpaperRatioControl.setMode(wallpaperRatioMode);
            if (wallpaperEditorView != null) wallpaperEditorView.resetForModeChange();
            AppLog.d(this, "WALLPAPER ratio mode=" + wallpaperRatioMode);
        });
        rotate.setOnClickListener(v -> {
            wallpaperRotationDegrees = (wallpaperRotationDegrees + 90) % 360;
            if (wallpaperEditorView != null) wallpaperEditorView.resetForModeChange();
            AppLog.d(this, "WALLPAPER rotate=" + wallpaperRotationDegrees);
        });
        controls.addView(wallpaperRatioControl, new LinearLayout.LayoutParams(0, dp(72), 1f));
        controls.addView(rotate, new LinearLayout.LayoutParams(0, dp(72), 1f));
        FrameLayout.LayoutParams controlsLp = new FrameLayout.LayoutParams(-1, dp(72), Gravity.BOTTOM);
        controlsLp.bottomMargin = dp(50);
        wallpaperEditorRoot.addView(controls, controlsLp);

        wallpaperEditing = true;
        topBar.setVisibility(View.GONE);
        bottomBar.setVisibility(View.GONE);
        pagePreviewView.setVisibility(View.GONE);
        imageView.setVisibility(View.INVISIBLE);
        rootView.addView(wallpaperEditorRoot, new FrameLayout.LayoutParams(-1, -1));
        AppLog.d(this, "WALLPAPER editor open");
    }

    private void exitWallpaperEditor() {
        if (!wallpaperEditing) return;
        if (wallpaperEditorRoot != null && rootView != null) rootView.removeView(wallpaperEditorRoot);
        wallpaperEditorRoot = null;
        wallpaperEditorView = null;
        wallpaperRatioControl = null;
        wallpaperEditing = false;
        if (imageView != null) imageView.setVisibility(View.VISIBLE);
        if (topBar != null) topBar.setVisibility(View.VISIBLE);
        if (bottomBar != null) bottomBar.setVisibility(View.VISIBLE);
        AppLog.d(this, "WALLPAPER editor close");
    }

    private float wallpaperTargetAspect() {
        android.util.DisplayMetrics dm = getResources().getDisplayMetrics();
        float shortSide = Math.max(1f, Math.min(dm.widthPixels, dm.heightPixels));
        float longSide = Math.max(shortSide, Math.max(dm.widthPixels, dm.heightPixels));
        if (wallpaperRatioMode == 2) return 1f;
        return wallpaperRatioMode == 0 ? shortSide / longSide : longSide / shortSide;
    }

    private int[] wallpaperTargetPixels() {
        android.util.DisplayMetrics dm = getResources().getDisplayMetrics();
        int shortSide = Math.max(1, Math.min(dm.widthPixels, dm.heightPixels));
        int longSide = Math.max(shortSide, Math.max(dm.widthPixels, dm.heightPixels));
        if (wallpaperRatioMode == 2) return new int[]{shortSide, shortSide};
        return wallpaperRatioMode == 0 ? new int[]{shortSide, longSide} : new int[]{longSide, shortSide};
    }

    private void applyWallpaperFromEditor() {
        if (wallpaperEditorView == null || currentUri == null) return;
        final RectF crop = wallpaperEditorView.getNormalizedCrop();
        if (crop == null) {
            Toast.makeText(this, "壁紙範囲を取得できませんでした", Toast.LENGTH_SHORT).show();
            return;
        }
        final Uri sourceUri = currentUri;
        final float degrees = pendingRotationDegrees + wallpaperRotationDegrees;
        final int[] target = wallpaperTargetPixels();
        Toast.makeText(this, "壁紙を設定しています", Toast.LENGTH_SHORT).show();
        safeExecute(editExecutor, () -> {
            try {
                Bitmap cropped = decodeCroppedBitmap(sourceUri, degrees, crop);
                Bitmap output = Bitmap.createScaledBitmap(cropped, target[0], target[1], true);
                WallpaperManager manager = WallpaperManager.getInstance(this);
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                    manager.setBitmap(output, null, true, WallpaperManager.FLAG_SYSTEM);
                } else {
                    manager.setBitmap(output);
                }
                mainHandler.post(() -> {
                    exitWallpaperEditor();
                    Toast.makeText(this, "壁紙に設定しました", Toast.LENGTH_SHORT).show();
                });
                AppLog.d(this, "WALLPAPER applied size=" + target[0] + "x" + target[1] + " rotation=" + degrees + " crop=" + crop);
            } catch (Throwable e) {
                AppLog.d(this, "WALLPAPER error " + e);
                mainHandler.post(() -> Toast.makeText(this, "壁紙に設定できませんでした", Toast.LENGTH_LONG).show());
            }
        });
    }

    private void showSortDialog() {
        final String initialField = SortPrefs.field(this);
        final boolean initialAsc = SortPrefs.ascending(this);
        final int panel = Color.rgb(58, 51, 51);       // #3A3333
        final int selected = Color.rgb(68, 85, 119);  // #445577
        final int unselected = Color.rgb(90, 85, 85); // #5A5555
        ColorStateList tint = new ColorStateList(
                new int[][]{new int[]{android.R.attr.state_checked}, new int[]{}},
                new int[]{selected, unselected});

        LinearLayout content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(dp(22), dp(6), dp(22), dp(8));
        content.setBackgroundColor(panel);

        RadioGroup fieldGroup = new RadioGroup(this);
        fieldGroup.setOrientation(RadioGroup.VERTICAL);
        RadioButton byName = makeDialogRadio("名前", false, tint);
        RadioButton bySize = makeDialogRadio("サイズ", false, tint);
        RadioButton byType = makeDialogRadio("種類", false, tint);
        RadioButton byCreated = makeDialogRadio("作成日", false, tint);
        RadioButton byModified = makeDialogRadio("最終更新日", false, tint);
        fieldGroup.addView(byName, new RadioGroup.LayoutParams(-1, dp(50)));
        fieldGroup.addView(bySize, new RadioGroup.LayoutParams(-1, dp(50)));
        fieldGroup.addView(byType, new RadioGroup.LayoutParams(-1, dp(50)));
        fieldGroup.addView(byCreated, new RadioGroup.LayoutParams(-1, dp(50)));
        fieldGroup.addView(byModified, new RadioGroup.LayoutParams(-1, dp(50)));
        if (SortPrefs.FIELD_SIZE.equals(initialField)) fieldGroup.check(bySize.getId());
        else if (SortPrefs.FIELD_TYPE.equals(initialField)) fieldGroup.check(byType.getId());
        else if (SortPrefs.FIELD_CREATED.equals(initialField)) fieldGroup.check(byCreated.getId());
        else if (SortPrefs.FIELD_MODIFIED.equals(initialField)) fieldGroup.check(byModified.getId());
        else fieldGroup.check(byName.getId());
        content.addView(fieldGroup);

        View divider = new View(this);
        divider.setBackgroundColor(Color.rgb(90, 85, 85));
        LinearLayout.LayoutParams dividerParams = new LinearLayout.LayoutParams(-1, dp(1));
        dividerParams.topMargin = dp(8);
        dividerParams.bottomMargin = dp(8);
        content.addView(divider, dividerParams);

        RadioGroup orderGroup = new RadioGroup(this);
        orderGroup.setOrientation(RadioGroup.HORIZONTAL);
        RadioButton ascending = makeDialogRadio("左から", false, tint);
        RadioButton descending = makeDialogRadio("右から", false, tint);
        orderGroup.addView(ascending, new RadioGroup.LayoutParams(0, dp(52), 1f));
        orderGroup.addView(descending, new RadioGroup.LayoutParams(0, dp(52), 1f));
        orderGroup.check((initialAsc ? ascending : descending).getId());
        content.addView(orderGroup);

        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle("スライド順")
                .setView(content)
                .setNegativeButton("キャンセル", null)
                .setPositiveButton("OK", null)
                .create();
        prepareDialogBeforeShow(dialog, panel);

        dialog.setOnShowListener(ignored -> {
            int titleId = getResources().getIdentifier("alertTitle", "id", "android");
            TextView title = dialog.findViewById(titleId);
            if (title != null) title.setTextColor(Color.WHITE);
            styleDialogButton(dialog, AlertDialog.BUTTON_NEGATIVE, Color.WHITE, panel);
            styleDialogButton(dialog, AlertDialog.BUTTON_POSITIVE, Color.WHITE, panel);
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v -> {
                String selectedField = bySize.isChecked() ? SortPrefs.FIELD_SIZE
                        : (byType.isChecked() ? SortPrefs.FIELD_TYPE
                        : (byCreated.isChecked() ? SortPrefs.FIELD_CREATED
                        : (byModified.isChecked() ? SortPrefs.FIELD_MODIFIED : SortPrefs.FIELD_NAME)));
                boolean selectedAsc = ascending.isChecked();
                SortPrefs.save(this, selectedField, selectedAsc);
                AppLog.d(this, "SORT changed field=" + selectedField + " asc=" + selectedAsc);
                dialog.dismiss();
                if (!applySortImmediately(selectedField, selectedAsc)) discoverSiblingImagesAsync();
                Toast.makeText(this, SortPrefs.fieldLabel(selectedField) + "・" + (selectedAsc ? "左から" : "右から"), Toast.LENGTH_SHORT).show();
            });
        });
        dialog.show();
    }

    private RadioButton makeDialogRadio(String label, boolean checked, ColorStateList tint) {
        RadioButton button = new RadioButton(this);
        button.setId(View.generateViewId());
        button.setText(label);
        button.setTextColor(Color.WHITE);
        button.setTextSize(17);
        button.setChecked(checked);
        button.setButtonTintList(tint);
        button.setGravity(Gravity.CENTER_VERTICAL);
        button.setPadding(0, dp(2), 0, dp(2));
        return button;
    }

    private boolean applySortImmediately(String field, boolean ascending) {
        if (!fullListReady || siblings.isEmpty() || currentName == null) return false;
        if (!itemsSupportSort(siblings, field)) {
            AppLog.d(this, "SORT immediate miss field=" + field + " reason=metadata");
            return false;
        }
        ArrayList<MediaItem> sorted = new ArrayList<>(siblings);
        sortProviderItems(sorted, field, ascending);
        int idx = -1;
        for (int i = 0; i < sorted.size(); i++) {
            if (sameName(sorted.get(i).name, currentName)) { idx = i; break; }
        }
        if (idx < 0) {
            AppLog.d(this, "SORT immediate miss field=" + field + " reason=current-not-found");
            return false;
        }
        siblingGeneration.incrementAndGet();
        cancelSiblingQuerySignals();
        siblings.clear();
        siblings.addAll(sorted);
        currentIndex = idx;
        fullListReady = true;
        progressiveListActive = false;
        quickPreviousItem = null;
        quickNextItem = null;
        updatePositionLabel();
        prefetchAdjacent();
        AppLog.d(this, "SORT applied immediate field=" + field + " asc=" + ascending +
                " found=" + siblings.size() + " currentIndex=" + currentIndex);
        return true;
    }

    private boolean itemsSupportSort(List<MediaItem> items, String field) {
        if (items == null || items.isEmpty() || SortPrefs.FIELD_NAME.equals(field) || SortPrefs.FIELD_TYPE.equals(field)) return items != null && !items.isEmpty();
        for (MediaItem item : items) {
            if (item == null) continue;
            if (SortPrefs.FIELD_SIZE.equals(field) && item.size < 0L) return false;
            if (SortPrefs.FIELD_CREATED.equals(field) && item.created < 0L) return false;
            if (SortPrefs.FIELD_MODIFIED.equals(field) && item.modified < 0L) return false;
        }
        return true;
    }

    private TextView makeBottomAction(String icon, String label) {
        TextView view = new TextView(this);
        view.setText(icon + "\n" + label); view.setTextColor(Color.WHITE); view.setTextSize(13);
        view.setGravity(Gravity.CENTER); view.setLines(2); return view;
    }

    private View makeBottomIconAction(int kind, String contentDescription, View.OnClickListener listener) {
        BottomActionIconView icon = new BottomActionIconView(this, kind);
        icon.setContentDescription(contentDescription);
        icon.setOnClickListener(listener);
        return icon;
    }

    private GradientDrawable makeRoundedPanel(int color) {
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(color);
        bg.setCornerRadius(dp(10));
        return bg;
    }

    private void prepareDialogBeforeShow(AlertDialog dialog, int panelColor) {
        if (dialog == null || dialog.getWindow() == null) return;
        android.view.Window window = dialog.getWindow();
        window.setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(Color.TRANSPARENT));
        window.setWindowAnimations(R.style.Animation_Chirami_Dialog);
        View decor = window.getDecorView();
        decor.setBackground(makeRoundedPanel(panelColor));
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) decor.setClipToOutline(true);
    }

    /** All dialog actions are text-only: no filled/outlined button chrome. */
    private void styleDialogButton(AlertDialog dialog, int which, int textColor, int panelColor) {
        if (dialog == null) return;
        Button button = dialog.getButton(which);
        if (button == null) return;
        button.setTextColor(textColor);
        button.setAllCaps(false);
        button.setBackground(new android.graphics.drawable.ColorDrawable(Color.TRANSPARENT));
        button.setStateListAnimator(null);
    }

    /** Destination-manager actions stay text-only; the dialog itself remains rounded. */
    private void styleManagerTextAction(AlertDialog dialog, int which, int textColor) {
        if (dialog == null) return;
        Button button = dialog.getButton(which);
        if (button == null) return;
        button.setTextColor(textColor);
        button.setTextSize(14);
        button.setAllCaps(false);
        button.setBackground(new android.graphics.drawable.ColorDrawable(Color.TRANSPARENT));
    }

    private void toggleChrome() {
        boolean showing = topBar.getVisibility() == View.VISIBLE;
        topBar.setVisibility(showing ? View.GONE : View.VISIBLE);
        bottomBar.setVisibility(showing ? View.GONE : View.VISIBLE);
        if (shadeOverlay != null) {
            shadeOverlay.setChromeVisible(!showing);
        }
        if (!showing && imageView != null) imageView.notifyImageBoundsChanged();
        if (showing) {
            getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_FULLSCREEN | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION);
        } else {
            getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_VISIBLE);
        }
    }

    private void updateChromeShadeBounds(RectF imageBounds) {
        if (shadeOverlay != null) shadeOverlay.setImageBounds(imageBounds);
    }

    private class ChromeShadeOverlay extends View {
        ChromeShadeOverlay() {
            super(ViewerActivity.this);
            setClickable(false);
            setFocusable(false);
        }
        void setChromeVisible(boolean visible) { }
        void setImageBounds(RectF imageBounds) { }
        @Override protected void onDraw(Canvas canvas) { super.onDraw(canvas); }
    }

    private void requestDeleteCurrent() {
        if (currentUri == null) return;
        if (skipDeleteConfirmationThisSession) {
            deleteCurrentNow();
            return;
        }
        final int panel = Color.rgb(58, 51, 51);
        CheckBox skip = new CheckBox(this);
        skip.setText("このセッションでは再度確認しない");
        skip.setTextColor(Color.WHITE);
        skip.setPadding(dp(18), dp(4), dp(18), dp(4));
        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle("削除")
                .setMessage("この画像を削除しますか？")
                .setView(skip)
                .setNegativeButton("キャンセル", null)
                .setPositiveButton("削除", null)
                .create();
        prepareDialogBeforeShow(dialog, panel);
        dialog.setOnShowListener(v -> {
            int titleId = getResources().getIdentifier("alertTitle", "id", "android");
            TextView title = dialog.findViewById(titleId);
            if (title != null) title.setTextColor(Color.WHITE);
            int messageId = getResources().getIdentifier("message", "id", "android");
            TextView message = dialog.findViewById(messageId);
            if (message != null) message.setTextColor(Color.WHITE);
            styleDialogButton(dialog, AlertDialog.BUTTON_NEGATIVE, Color.WHITE, panel);
            styleDialogButton(dialog, AlertDialog.BUTTON_POSITIVE, Color.rgb(220, 95, 75), panel);
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v2 -> {
                skipDeleteConfirmationThisSession = skip.isChecked();
                dialog.dismiss();
                deleteCurrentNow();
            });
        });
        dialog.show();
    }

    private void deleteCurrentNow() {
        final Uri targetUri = currentUri;
        final String targetName = currentName;
        final String targetPath = inferAbsolutePathFromAnyUri(targetUri);
        final int oldIndex = currentIndex;
        if (targetUri == null) return;
        Toast.makeText(this, "削除しています", Toast.LENGTH_SHORT).show();
        safeExecute(editExecutor, () -> {
            boolean deleted = false;
            try {
                if ("content".equalsIgnoreCase(targetUri.getScheme())) {
                    try { deleted = getContentResolver().delete(targetUri, null, null) > 0; }
                    catch (Throwable ignored) { }
                }
                if (!deleted && targetPath != null) {
                    File f = new File(targetPath);
                    deleted = !f.exists() || f.delete();
                }
            } catch (Throwable e) {
                AppLog.d(this, "DELETE error " + e);
            }
            final boolean ok = deleted;
            mainHandler.post(() -> {
                if (!ok) {
                    Toast.makeText(this, "削除できませんでした", Toast.LENGTH_LONG).show();
                    return;
                }
                AppLog.d(this, "DELETE success name=" + targetName + " uri=" + targetUri);
                clearPendingRotationState();
                synchronized (FOLDER_CACHE_LOCK) { FOLDER_INDEX_CACHE.evictAll(); }
                int removeIndex = -1;
                for (int i = 0; i < siblings.size(); i++) {
                    MediaItem item = siblings.get(i);
                    if (item == null) continue;
                    if ((item.uri != null && item.uri.equals(targetUri)) ||
                            (targetName != null && targetName.equalsIgnoreCase(item.name))) {
                        removeIndex = i;
                        break;
                    }
                }
                if (removeIndex >= 0) siblings.remove(removeIndex);
                if (siblings.isEmpty()) {
                    Toast.makeText(this, "削除しました", Toast.LENGTH_SHORT).show();
                    returnToCaller();
                    return;
                }
                int nextIndex = oldIndex >= 0 ? Math.min(oldIndex, siblings.size() - 1) : 0;
                if (removeIndex >= 0) nextIndex = Math.min(removeIndex, siblings.size() - 1);
                currentIndex = Math.max(0, nextIndex);
                MediaItem next = siblings.get(currentIndex);
                currentUri = next.uri;
                currentName = next.name;
                currentMime = next.mime;
                showCurrentUri(false, 0);
                prefetchAdjacent();
                Toast.makeText(this, "削除しました", Toast.LENGTH_SHORT).show();
            });
        });
    }

    private static class BrowserStorageTarget {
        final String label;
        final File root;
        BrowserStorageTarget(String label, File root) { this.label = label; this.root = root; }
    }

    private void showDestinationManager(boolean move) {
        if (currentUri == null) return;
        String sourcePath = inferAbsolutePathFromAnyUri(currentUri);
        if (sourcePath == null) {
            Toast.makeText(this, "このファイルではコピー先を参照できません", Toast.LENGTH_LONG).show();
            return;
        }
        File sourceFile = new File(sourcePath);
        File start = sourceFile.getParentFile();
        if (start == null) {
            Toast.makeText(this, "現在のフォルダを開けません", Toast.LENGTH_SHORT).show();
            return;
        }

        final File[] currentDir = new File[]{start};
        final File[] rootLimit = new File[]{storageRootFor(start)};
        final int panel = Color.rgb(42, 34, 34);      // #2A2222
        final int rowPanel = Color.rgb(58, 51, 51);   // #3A3333
        final int accent = Color.rgb(68, 85, 119);    // #445577
        final ArrayList<BrowserStorageTarget> storageTargets = discoverBrowserStorageTargets(start);
        AppLog.d(this, "MANAGER open mode=" + (move ? "move" : "copy") + " start=" + start.getAbsolutePath() +
                " storages=" + storageTargets.size());

        LinearLayout content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(dp(14), dp(2), dp(14), dp(8));
        content.setBackgroundColor(panel);

        TextView storageSelector = new TextView(this);
        storageSelector.setTextColor(Color.WHITE);
        storageSelector.setTextSize(16);
        storageSelector.setGravity(Gravity.CENTER_VERTICAL);
        storageSelector.setPadding(dp(12), 0, dp(12), 0);
        GradientDrawable selectorBg = new GradientDrawable();
        selectorBg.setColor(rowPanel); selectorBg.setCornerRadius(dp(10));
        storageSelector.setBackground(selectorBg);
        content.addView(storageSelector, new LinearLayout.LayoutParams(-1, dp(42)));

        TextView pathView = new TextView(this);
        pathView.setTextColor(Color.rgb(185, 180, 180));
        pathView.setTextSize(12);
        pathView.setSingleLine(true);
        pathView.setEllipsize(android.text.TextUtils.TruncateAt.START);
        pathView.setPadding(dp(4), dp(7), dp(4), dp(7));
        content.addView(pathView, new LinearLayout.LayoutParams(-1, dp(36)));

        LinearLayout nav = new LinearLayout(this);
        nav.setOrientation(LinearLayout.HORIZONTAL);
        nav.setGravity(Gravity.CENTER_VERTICAL);
        TextView parentButton = makeManagerButton("‹  戻る");
        TextView newFolderButton = makeManagerButton("＋  新規フォルダ");
        nav.addView(parentButton, new LinearLayout.LayoutParams(0, dp(44), 1f));
        nav.addView(newFolderButton, new LinearLayout.LayoutParams(0, dp(44), 1f));
        content.addView(nav);

        ScrollView scroll = new ScrollView(this);
        scroll.setVerticalScrollBarEnabled(true);
        scroll.setScrollBarStyle(View.SCROLLBARS_INSIDE_OVERLAY);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            GradientDrawable thumb = new GradientDrawable();
            thumb.setColor(Color.rgb(90, 85, 85)); // #5A5555 Chirami light gray
            thumb.setCornerRadius(dp(2));
            thumb.setSize(dp(3), dp(36));
            scroll.setVerticalScrollbarThumbDrawable(thumb);
            GradientDrawable track = new GradientDrawable();
            track.setColor(Color.TRANSPARENT);
            scroll.setVerticalScrollbarTrackDrawable(track);
        }
        LinearLayout folders = new LinearLayout(this);
        folders.setOrientation(LinearLayout.VERTICAL);
        scroll.addView(folders, new ScrollView.LayoutParams(-1, -2));
        content.addView(scroll, new LinearLayout.LayoutParams(-1, dp(440)));

        final Runnable[] refresh = new Runnable[1];
        final Runnable updateStorageLabel = () -> {
            BrowserStorageTarget selected = findBrowserStorageTarget(storageTargets, rootLimit[0]);
            String label = selected == null ? storageLabelForRoot(rootLimit[0]) : selected.label;
            storageSelector.setText(label + "  ▾");
        };

        refresh[0] = () -> {
            final File dir = currentDir[0];
            final int generation = fileManagerGeneration.incrementAndGet();
            pathView.setText(dir.getAbsolutePath());
            updateStorageLabel.run();
            folders.removeAllViews();
            TextView loading = new TextView(this);
            loading.setText("読み込み中…");
            loading.setTextColor(Color.rgb(160, 155, 155));
            loading.setPadding(dp(12), dp(20), dp(12), dp(20));
            folders.addView(loading);
            AppLog.d(this, "MANAGER list begin path=" + dir.getAbsolutePath());
            boolean accepted = safeExecute(fileManagerExecutor, () -> {
                long startedAt = SystemClock.elapsedRealtime();
                ArrayList<String> names = getCachedDirectoryFolders(dir);
                boolean cacheHit = names != null;
                if (names == null) names = listDirectoryFolders(dir);
                final ArrayList<String> result = names;
                if (!cacheHit) putCachedDirectoryFolders(dir, result);
                long took = SystemClock.elapsedRealtime() - startedAt;
                AppLog.d(this, "MANAGER list ready path=" + dir.getAbsolutePath() +
                        " folders=" + result.size() + " took=" + took + "ms cache=" + cacheHit);
                mainHandler.post(() -> {
                    if (generation != fileManagerGeneration.get() || isFinishing()) return;
                    if (!sameFilePath(currentDir[0], dir)) return;
                    folders.removeAllViews();
                    if (result.isEmpty()) {
                        TextView empty = new TextView(this);
                        empty.setText("フォルダはありません");
                        empty.setTextColor(Color.rgb(160, 155, 155));
                        empty.setPadding(dp(12), dp(22), dp(12), dp(22));
                        folders.addView(empty);
                    }
                    for (String name : result) {
                        final File child = new File(dir, name);
                        LinearLayout row = makeManagerFolderRow(name, accent, rowPanel);
                        row.setOnClickListener(v -> {
                            currentDir[0] = child;
                            refresh[0].run();
                        });
                        LinearLayout.LayoutParams rp = new LinearLayout.LayoutParams(-1, dp(46));
                        rp.bottomMargin = dp(1);
                        folders.addView(row, rp);
                    }
                });
            });
            if (!accepted) {
                folders.removeAllViews();
                TextView failed = new TextView(this);
                failed.setText("フォルダを読み込めませんでした");
                failed.setTextColor(Color.rgb(190, 170, 170));
                failed.setPadding(dp(12), dp(20), dp(12), dp(20));
                folders.addView(failed);
            }
        };

        storageSelector.setOnClickListener(v -> showStorageSelectorPopup(storageSelector, storageTargets, target -> {
            if (target == null || target.root == null) return;
            rootLimit[0] = target.root;
            currentDir[0] = target.root;
            AppLog.d(this, "MANAGER storage selected label=" + target.label + " root=" + target.root.getAbsolutePath());
            refresh[0].run();
        }));

        parentButton.setOnClickListener(v -> {
            File parent = currentDir[0].getParentFile();
            if (parent == null) return;
            if (rootLimit[0] != null && !isWithinRoot(parent, rootLimit[0])) return;
            currentDir[0] = parent;
            refresh[0].run();
        });
        newFolderButton.setOnClickListener(v -> showCreateFolderDialog(currentDir[0], refresh[0]));

        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle(move ? "移動先" : "コピー先")
                .setView(content)
                .setNegativeButton("キャンセル", null)
                .setPositiveButton(move ? "移動" : "コピー", null)
                .create();
        prepareDialogBeforeShow(dialog, panel);
        if (dialog.getWindow() != null) {
            android.view.WindowManager.LayoutParams lp = new android.view.WindowManager.LayoutParams();
            lp.copyFrom(dialog.getWindow().getAttributes());
            lp.width = (int) (getResources().getDisplayMetrics().widthPixels * 0.94f);
            dialog.getWindow().setAttributes(lp);
        }
        dialog.setOnShowListener(v -> {
            int titleId = getResources().getIdentifier("alertTitle", "id", "android");
            TextView title = dialog.findViewById(titleId);
            if (title != null) {
                title.setTextColor(Color.WHITE);
                title.setTextSize(18);
            }
            styleManagerTextAction(dialog, AlertDialog.BUTTON_NEGATIVE, Color.WHITE);
            styleManagerTextAction(dialog, AlertDialog.BUTTON_POSITIVE, Color.WHITE);
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v2 -> {
                File chosen = currentDir[0];
                AppLog.d(this, "MANAGER destination selected mode=" + (move ? "move" : "copy") +
                        " path=" + chosen.getAbsolutePath());
                dialog.dismiss();
                requestFileTransfer(chosen, move);
            });
            refresh[0].run();
        });
        dialog.setOnDismissListener(v -> fileManagerGeneration.incrementAndGet());
        dialog.show();
    }

    private LinearLayout makeManagerFolderRow(String name, int accent, int rowPanel) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(dp(8), 0, dp(8), 0);
        row.setBackgroundColor(rowPanel);

        ImageView icon = new ImageView(this);
        icon.setImageResource(R.drawable.ic_chirami_folder);
        icon.setPadding(dp(6), dp(6), dp(6), dp(6));
        GradientDrawable ibg = new GradientDrawable(); ibg.setColor(accent); ibg.setCornerRadius(dp(9));
        icon.setBackground(ibg);
        row.addView(icon, new LinearLayout.LayoutParams(dp(32), dp(32)));

        LinearLayout textBox = new LinearLayout(this);
        textBox.setOrientation(LinearLayout.VERTICAL);
        textBox.setGravity(Gravity.CENTER_VERTICAL);
        textBox.setPadding(dp(10), 0, 0, 0);
        TextView title = new TextView(this);
        title.setText(name); title.setTextColor(Color.WHITE); title.setTextSize(14); title.setSingleLine(true);
        title.setEllipsize(android.text.TextUtils.TruncateAt.END);
        textBox.addView(title, new LinearLayout.LayoutParams(-1, dp(30)));
        row.addView(textBox, new LinearLayout.LayoutParams(0, dp(38), 1f));
        return row;
    }

    private ArrayList<BrowserStorageTarget> discoverBrowserStorageTargets(File current) {
        ArrayList<BrowserStorageTarget> out = new ArrayList<>();
        HashMap<String, Boolean> seen = new HashMap<>();
        try {
            StorageManager sm = (StorageManager) getSystemService(STORAGE_SERVICE);
            if (sm != null && Build.VERSION.SDK_INT >= 30) {
                int externalNo = 1;
                for (StorageVolume volume : sm.getStorageVolumes()) {
                    File dir = volume.getDirectory();
                    if (dir == null || !dir.exists() || !dir.canRead()) continue;
                    String key = dir.getAbsolutePath();
                    if (seen.put(key, Boolean.TRUE) != null) continue;
                    String label;
                    if (volume.isPrimary()) label = "内蔵ストレージ";
                    else {
                        String desc = volume.getDescription(this);
                        String lower = desc == null ? "" : desc.toLowerCase(Locale.ROOT);
                        if (lower.contains("sd") || (desc != null && desc.contains("カード"))) label = "SDカード";
                        else label = externalNo++ == 1 ? "外部ストレージ" : "外部ストレージ " + (externalNo - 1);
                    }
                    out.add(new BrowserStorageTarget(label, dir));
                }
            }
        } catch (Throwable e) {
            AppLog.d(this, "MANAGER storage enumerate error " + e.getClass().getSimpleName());
        }
        File currentRoot = storageRootFor(current);
        if (currentRoot != null && currentRoot.exists()) {
            String key = currentRoot.getAbsolutePath();
            if (!seen.containsKey(key)) out.add(0, new BrowserStorageTarget(storageLabelForRoot(currentRoot), currentRoot));
        }
        if (out.isEmpty()) {
            File fallback = Environment.getExternalStorageDirectory();
            if (fallback != null) out.add(new BrowserStorageTarget("内蔵ストレージ", fallback));
        }
        return out;
    }

    private String storageLabelForRoot(File root) {
        if (root == null) return "ストレージ";
        String p = root.getAbsolutePath();
        if (p.startsWith("/storage/emulated/0")) return "内蔵ストレージ";
        return "SDカード";
    }

    private BrowserStorageTarget findBrowserStorageTarget(List<BrowserStorageTarget> targets, File root) {
        if (targets == null || root == null) return null;
        for (BrowserStorageTarget target : targets) if (target != null && sameFilePath(target.root, root)) return target;
        return null;
    }

    private interface BrowserStorageSelection { void onSelected(BrowserStorageTarget target); }

    private void showStorageSelectorPopup(View anchor, List<BrowserStorageTarget> targets, BrowserStorageSelection callback) {
        if (targets == null || targets.isEmpty()) return;
        final int panel = Color.rgb(58, 51, 51);
        LinearLayout list = new LinearLayout(this);
        list.setOrientation(LinearLayout.VERTICAL);
        list.setBackgroundColor(panel);
        final PopupWindow[] holder = new PopupWindow[1];
        for (BrowserStorageTarget target : targets) {
            TextView row = new TextView(this);
            row.setText(target.label); row.setTextColor(Color.WHITE); row.setTextSize(16);
            row.setGravity(Gravity.CENTER_VERTICAL); row.setPadding(dp(16), 0, dp(16), 0);
            row.setOnClickListener(v -> {
                if (holder[0] != null) holder[0].dismiss();
                if (callback != null) callback.onSelected(target);
            });
            list.addView(row, new LinearLayout.LayoutParams(dp(260), dp(52)));
        }
        PopupWindow popup = new PopupWindow(list, dp(260), -2, true);
        holder[0] = popup;
        popup.setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(panel));
        popup.setOutsideTouchable(true);
        popup.setElevation(dp(8));
        popup.showAsDropDown(anchor, 0, dp(2));
    }

    private ArrayList<String> listDirectoryFolders(File dir) {
        ArrayList<String> out = new ArrayList<>();
        if (dir == null) return out;
        try {
            String[] names = dir.list();
            if (names == null) return out;
            for (String name : names) {
                if (name == null || name.isEmpty()) continue;
                try {
                    if (new File(dir, name).isDirectory()) out.add(name);
                } catch (Throwable ignored) { }
            }
            Collections.sort(out, String.CASE_INSENSITIVE_ORDER);
        } catch (Throwable e) {
            AppLog.d(this, "MANAGER list error path=" + dir.getAbsolutePath() + " " + e);
        }
        return out;
    }

    private ArrayList<String> getCachedDirectoryFolders(File dir) {
        if (dir == null) return null;
        String key = dir.getAbsolutePath();
        synchronized (DIRECTORY_CACHE_LOCK) {
            DirectoryCacheEntry entry = DIRECTORY_CACHE.get(key);
            if (entry == null) return null;
            if (SystemClock.elapsedRealtime() - entry.createdAt > DIRECTORY_CACHE_TTL_MS) {
                DIRECTORY_CACHE.remove(key);
                return null;
            }
            return new ArrayList<>(entry.folderNames);
        }
    }

    private void putCachedDirectoryFolders(File dir, List<String> names) {
        if (dir == null || names == null) return;
        synchronized (DIRECTORY_CACHE_LOCK) {
            DIRECTORY_CACHE.put(dir.getAbsolutePath(),
                    new DirectoryCacheEntry(SystemClock.elapsedRealtime(), names));
        }
    }

    private void invalidateDirectoryCache(File dir) {
        if (dir == null) return;
        synchronized (DIRECTORY_CACHE_LOCK) { DIRECTORY_CACHE.remove(dir.getAbsolutePath()); }
    }

    private boolean sameFilePath(File a, File b) {
        if (a == null || b == null) return false;
        try { return a.getCanonicalFile().equals(b.getCanonicalFile()); }
        catch (Throwable ignored) { return a.getAbsolutePath().equals(b.getAbsolutePath()); }
    }

    private TextView makeManagerButton(String text) {
        TextView b = new TextView(this);
        b.setText(text); b.setTextColor(Color.WHITE); b.setTextSize(14); b.setGravity(Gravity.CENTER);
        return b;
    }

    private File storageRootFor(File dir) {
        if (dir == null) return null;
        String path = dir.getAbsolutePath().replace('\\', '/');
        if (path.startsWith("/storage/emulated/0")) return new File("/storage/emulated/0");
        if (path.startsWith("/storage/")) {
            String rest = path.substring("/storage/".length());
            int slash = rest.indexOf('/');
            String volume = slash >= 0 ? rest.substring(0, slash) : rest;
            if (!volume.isEmpty()) return new File("/storage/" + volume);
        }
        return dir;
    }

    private boolean isWithinRoot(File candidate, File root) {
        try {
            String c = candidate.getCanonicalPath();
            String r = root.getCanonicalPath();
            return c.equals(r) || c.startsWith(r + File.separator);
        } catch (Throwable e) { return false; }
    }

    private void showCreateFolderDialog(File parent, Runnable refresh) {
        if (parent == null) return;
        final int panel = Color.rgb(58, 51, 51);
        EditText input = makeSaveField("フォルダ名", "");
        input.setSelectAllOnFocus(false);
        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle("新規フォルダ")
                .setView(input)
                .setNegativeButton("キャンセル", null)
                .setPositiveButton("作成", null)
                .create();
        prepareDialogBeforeShow(dialog, panel);
        dialog.setOnShowListener(v -> {
            int titleId = getResources().getIdentifier("alertTitle", "id", "android");
            TextView title = dialog.findViewById(titleId);
            if (title != null) title.setTextColor(Color.WHITE);
            styleDialogButton(dialog, AlertDialog.BUTTON_NEGATIVE, Color.WHITE, panel);
            styleDialogButton(dialog, AlertDialog.BUTTON_POSITIVE, Color.WHITE, panel);
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v2 -> {
                String name = input.getText().toString().trim();
                if (name.isEmpty()) { input.setError("フォルダ名を入力してください"); return; }
                String clean = sanitizeFileName(name);
                final File created = new File(parent, clean);
                dialog.getButton(AlertDialog.BUTTON_POSITIVE).setEnabled(false);
                AppLog.d(this, "MANAGER mkdir begin path=" + created.getAbsolutePath());
                safeExecute(fileManagerExecutor, () -> {
                    boolean exists;
                    boolean ok = false;
                    try {
                        exists = created.exists();
                        if (!exists) ok = created.mkdir();
                        if (!exists && !ok) {
                            Uri tree = findPersistedSafTreeForPath(parent);
                            Uri parentDoc = safDocumentUriForPath(tree, parent);
                            if (tree != null && parentDoc != null) {
                                Uri made = DocumentsContract.createDocument(getContentResolver(), parentDoc,
                                        DocumentsContract.Document.MIME_TYPE_DIR, clean);
                                ok = made != null;
                                if (ok) AppLog.d(this, "MANAGER mkdir backend=saf path=" + created.getAbsolutePath());
                            }
                        }
                    } catch (Throwable e) {
                        exists = false;
                        AppLog.d(this, "MANAGER mkdir error path=" + created.getAbsolutePath() + " " + e);
                    }
                    final boolean existed = exists;
                    final boolean made = ok;
                    mainHandler.post(() -> {
                        if (isFinishing()) return;
                        if (existed) {
                            input.setError("同名フォルダがあります");
                            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setEnabled(true);
                            return;
                        }
                        if (!made) {
                            Toast.makeText(this, "この場所にはフォルダを作成できません", Toast.LENGTH_LONG).show();
                            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setEnabled(true);
                            return;
                        }
                        AppLog.d(this, "MANAGER mkdir success path=" + created.getAbsolutePath());
                        invalidateDirectoryCache(parent);
                        dialog.dismiss();
                        if (refresh != null) refresh.run();
                    });
                });
            });
        });
        dialog.show();
    }



    private static class SafVolumePath {
        final String volumeId;
        final String relativePath;
        SafVolumePath(String volumeId, String relativePath) {
            this.volumeId = volumeId;
            this.relativePath = relativePath == null ? "" : relativePath;
        }
    }

    private SafVolumePath safVolumePathFor(File file) {
        if (file == null) return null;
        String path;
        try { path = file.getCanonicalPath(); }
        catch (Throwable e) { path = file.getAbsolutePath(); }
        if (path == null) return null;
        path = path.replace('\\', '/');
        if (!path.startsWith("/storage/")) return null;
        String rest = path.substring("/storage/".length());
        int slash = rest.indexOf('/');
        String volume = slash >= 0 ? rest.substring(0, slash) : rest;
        if (volume.isEmpty() || "emulated".equalsIgnoreCase(volume) || "self".equalsIgnoreCase(volume)) return null;
        String relative = slash >= 0 ? rest.substring(slash + 1) : "";
        while (relative.startsWith("/")) relative = relative.substring(1);
        while (relative.endsWith("/") && !relative.isEmpty()) relative = relative.substring(0, relative.length() - 1);
        return new SafVolumePath(volume, relative);
    }

    private String normalizeSafRelative(String value) {
        if (value == null) return "";
        String out = value.replace('\\', '/');
        while (out.startsWith("/")) out = out.substring(1);
        while (out.endsWith("/") && !out.isEmpty()) out = out.substring(0, out.length() - 1);
        return out;
    }

    private boolean safRelativeContains(String granted, String target) {
        String g = normalizeSafRelative(granted);
        String t = normalizeSafRelative(target);
        return g.isEmpty() || t.equals(g) || t.startsWith(g + "/");
    }

    private Uri findPersistedSafTreeForPath(File path) {
        SafVolumePath target = safVolumePathFor(path);
        if (target == null) return null;
        try {
            for (android.content.UriPermission permission : getContentResolver().getPersistedUriPermissions()) {
                if (permission == null || !permission.isWritePermission()) continue;
                Uri tree = permission.getUri();
                if (tree == null) continue;
                String treeId;
                try { treeId = DocumentsContract.getTreeDocumentId(tree); }
                catch (Throwable ignored) { continue; }
                if (treeId == null) continue;
                int colon = treeId.indexOf(':');
                String volume = colon >= 0 ? treeId.substring(0, colon) : treeId;
                String relative = colon >= 0 ? treeId.substring(colon + 1) : "";
                if (!target.volumeId.equalsIgnoreCase(volume)) continue;
                if (safRelativeContains(relative, target.relativePath)) return tree;
            }
        } catch (Throwable e) {
            AppLog.d(this, "SAF persisted permission scan error " + e);
        }
        return null;
    }

    private Uri safDocumentUriForPath(Uri treeUri, File path) {
        if (treeUri == null || path == null) return null;
        SafVolumePath target = safVolumePathFor(path);
        if (target == null) return null;
        try {
            String treeId = DocumentsContract.getTreeDocumentId(treeUri);
            if (treeId == null) return null;
            int colon = treeId.indexOf(':');
            String volume = colon >= 0 ? treeId.substring(0, colon) : treeId;
            String grantedRelative = colon >= 0 ? treeId.substring(colon + 1) : "";
            if (!target.volumeId.equalsIgnoreCase(volume)) return null;
            if (!safRelativeContains(grantedRelative, target.relativePath)) return null;
            String documentId = target.volumeId + ":" + normalizeSafRelative(target.relativePath);
            return DocumentsContract.buildDocumentUriUsingTree(treeUri, documentId);
        } catch (Throwable e) {
            AppLog.d(this, "SAF document uri error path=" + path + " " + e);
            return null;
        }
    }

    private Uri findSafChild(Uri treeUri, Uri parentDocumentUri, String name) throws IOException {
        if (treeUri == null || parentDocumentUri == null || name == null) return null;
        try {
            String parentId = DocumentsContract.getDocumentId(parentDocumentUri);
            Uri children = DocumentsContract.buildChildDocumentsUriUsingTree(treeUri, parentId);
            String[] projection = new String[]{
                    DocumentsContract.Document.COLUMN_DOCUMENT_ID,
                    DocumentsContract.Document.COLUMN_DISPLAY_NAME
            };
            try (Cursor c = getContentResolver().query(children, projection, null, null, null)) {
                if (c == null) return null;
                int idCol = c.getColumnIndex(DocumentsContract.Document.COLUMN_DOCUMENT_ID);
                int nameCol = c.getColumnIndex(DocumentsContract.Document.COLUMN_DISPLAY_NAME);
                while (c.moveToNext()) {
                    String childName = nameCol >= 0 ? c.getString(nameCol) : null;
                    if (childName != null && childName.equalsIgnoreCase(name)) {
                        String childId = idCol >= 0 ? c.getString(idCol) : null;
                        if (childId != null) return DocumentsContract.buildDocumentUriUsingTree(treeUri, childId);
                    }
                }
            }
            return null;
        } catch (Throwable e) {
            if (e instanceof IOException) throw (IOException)e;
            throw new IOException("SAF child query failed", e);
        }
    }

    private Uri copyToSaf(Uri sourceUri, File destination, Uri treeUri, boolean overwrite) throws IOException {
        File parent = destination == null ? null : destination.getParentFile();
        if (sourceUri == null || destination == null || parent == null || treeUri == null) {
            throw new IOException("invalid SAF copy request");
        }
        Uri parentUri = safDocumentUriForPath(treeUri, parent);
        if (parentUri == null) throw new IOException("SAF destination is outside granted tree");
        Uri existing = findSafChild(treeUri, parentUri, destination.getName());
        if (existing != null && !overwrite) throw new IOException("SAF destination exists");

        Uri outUri = existing;
        boolean created = false;
        if (outUri == null) {
            try {
                outUri = DocumentsContract.createDocument(getContentResolver(), parentUri,
                        mimeFromName(destination.getName()), destination.getName());
            } catch (Throwable e) {
                throw new IOException("SAF create failed", e);
            }
            if (outUri == null) throw new IOException("SAF create returned null");
            created = true;
        }

        try {
            try (InputStream in = openSourceInputStream(sourceUri)) {
                OutputStream raw;
                try { raw = getContentResolver().openOutputStream(outUri, overwrite ? "rwt" : "w"); }
                catch (Throwable modeFailure) { raw = getContentResolver().openOutputStream(outUri, "w"); }
                if (raw == null) throw new IOException("SAF output unavailable");
                try (OutputStream out = raw) { copyStream(in, out); }
            }
            AppLog.d(this, "FILE transfer backend=saf destination=" + destination.getAbsolutePath() +
                    " tree=" + treeUri);
            return outUri;
        } catch (Throwable e) {
            if (created) {
                try { DocumentsContract.deleteDocument(getContentResolver(), outUri); } catch (Throwable ignored) { }
            }
            if (e instanceof IOException) throw (IOException)e;
            throw new IOException("SAF copy failed", e);
        }
    }

    private boolean destinationLikelyNeedsSaf(File destination) {
        SafVolumePath target = safVolumePathFor(destination);
        if (target == null) return false;
        String relative = normalizeSafRelative(target.relativePath);
        int slash = relative.indexOf('/');
        String top = slash >= 0 ? relative.substring(0, slash) : relative;
        String lower = top.toLowerCase(Locale.ROOT);
        // These shared media roots remain on the existing MediaStore fast path.
        return !("pictures".equals(lower) || "dcim".equals(lower) ||
                "download".equals(lower) || "downloads".equals(lower));
    }

    private void requestSafAccessAndResume(File requestedPath, File destinationDir, boolean move, int policy) {
        SafVolumePath target = safVolumePathFor(requestedPath);
        if (target == null) return;
        pendingSafRequestedPath = requestedPath;
        pendingSafDestinationDir = destinationDir;
        pendingSafMove = move;
        pendingSafPolicy = policy;
        Intent intent = null;
        if (Build.VERSION.SDK_INT >= 29) {
            try {
                StorageManager sm = (StorageManager)getSystemService(STORAGE_SERVICE);
                if (sm != null) {
                    for (StorageVolume volume : sm.getStorageVolumes()) {
                        String uuid = volume == null ? null : volume.getUuid();
                        if (uuid != null && target.volumeId.equalsIgnoreCase(uuid)) {
                            intent = volume.createOpenDocumentTreeIntent();
                            break;
                        }
                    }
                }
            } catch (Throwable ignored) { }
        }
        if (intent == null) intent = new Intent(Intent.ACTION_OPEN_DOCUMENT_TREE);
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION |
                Intent.FLAG_GRANT_WRITE_URI_PERMISSION |
                Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION |
                Intent.FLAG_GRANT_PREFIX_URI_PERMISSION);
        if (Build.VERSION.SDK_INT >= 26) {
            try {
                Uri initial = DocumentsContract.buildDocumentUri(
                        "com.android.externalstorage.documents", target.volumeId + ":");
                intent.putExtra(DocumentsContract.EXTRA_INITIAL_URI, initial);
            } catch (Throwable ignored) { }
        }
        AppLog.d(this, "SAF permission request volume=" + target.volumeId +
                " path=" + requestedPath.getAbsolutePath());
        Toast.makeText(this, "外部ストレージのルートを選択して使用を許可してください", Toast.LENGTH_LONG).show();
        startActivityForResult(intent, REQ_SAF_TREE);
    }

    private void requestFileTransfer(File destinationDir, boolean move) {
        if (destinationDir == null || currentUri == null || currentName == null) return;
        AppLog.d(this, "FILE transfer request mode=" + (move ? "move" : "copy") +
                " source=" + currentName + " destDir=" + destinationDir.getAbsolutePath());
        String sourcePath = inferAbsolutePathFromAnyUri(currentUri);
        if (move && sourcePath != null) {
            File sourceParent = new File(sourcePath).getParentFile();
            try {
                if (sourceParent != null && sourceParent.getCanonicalFile().equals(destinationDir.getCanonicalFile())) {
                    Toast.makeText(this, "すでにこのフォルダにあります", Toast.LENGTH_SHORT).show();
                    return;
                }
            } catch (Throwable ignored) { }
        }
        File destination = new File(destinationDir, currentName);
        if (destination.exists()) {
            if (conflictPolicyThisSession == CONFLICT_ASK) {
                showConflictDialog(destinationDir, move);
                return;
            }
            performFileTransfer(destinationDir, move, conflictPolicyThisSession);
            return;
        }
        performFileTransfer(destinationDir, move, CONFLICT_OVERWRITE);
    }

    private void showConflictDialog(File destinationDir, boolean move) {
        final int panel = Color.rgb(58, 51, 51);
        CheckBox skip = new CheckBox(this);
        skip.setText("このセッションでは再度確認しない");
        skip.setTextColor(Color.WHITE);
        skip.setPadding(dp(18), dp(4), dp(18), dp(4));
        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle("同名ファイルがあります")
                .setMessage(currentName)
                .setView(skip)
                .setNegativeButton("キャンセル", null)
                .setNeutralButton("別名保存", null)
                .setPositiveButton("上書き", null)
                .create();
        prepareDialogBeforeShow(dialog, panel);
        dialog.setOnShowListener(v -> {
            int titleId = getResources().getIdentifier("alertTitle", "id", "android");
            TextView title = dialog.findViewById(titleId);
            if (title != null) title.setTextColor(Color.WHITE);
            int messageId = getResources().getIdentifier("message", "id", "android");
            TextView message = dialog.findViewById(messageId);
            if (message != null) message.setTextColor(Color.WHITE);
            styleDialogButton(dialog, AlertDialog.BUTTON_NEGATIVE, Color.WHITE, panel);
            styleDialogButton(dialog, AlertDialog.BUTTON_NEUTRAL, Color.WHITE, panel);
            styleDialogButton(dialog, AlertDialog.BUTTON_POSITIVE, Color.WHITE, panel);
            dialog.getButton(AlertDialog.BUTTON_NEUTRAL).setOnClickListener(v2 -> {
                if (skip.isChecked()) conflictPolicyThisSession = CONFLICT_RENAME;
                dialog.dismiss();
                performFileTransfer(destinationDir, move, CONFLICT_RENAME);
            });
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v2 -> {
                if (skip.isChecked()) conflictPolicyThisSession = CONFLICT_OVERWRITE;
                dialog.dismiss();
                performFileTransfer(destinationDir, move, CONFLICT_OVERWRITE);
            });
        });
        dialog.show();
    }

    private void performFileTransfer(File destinationDir, boolean move, int policy) {
        final Uri sourceUri = currentUri;
        final String sourcePath = inferAbsolutePathFromAnyUri(sourceUri);
        final String sourceName = currentName;
        if (sourceUri == null || sourceName == null) return;
        File requested = new File(destinationDir, sourceName);
        final File destination = policy == CONFLICT_RENAME ? uniqueFile(destinationDir, sourceName) : requested;
        if (sourcePath != null && policy == CONFLICT_OVERWRITE) {
            try {
                if (new File(sourcePath).getCanonicalFile().equals(destination.getCanonicalFile())) {
                    Toast.makeText(this, "同じファイルには上書きできません。別名保存を選んでください", Toast.LENGTH_LONG).show();
                    return;
                }
            } catch (Throwable ignored) { }
        }
        // A move may need write permission on the source SD card as well as the destination.
        if (move && sourcePath != null) {
            File sourceFileForSaf = new File(sourcePath);
            if (safVolumePathFor(sourceFileForSaf) != null && findPersistedSafTreeForPath(sourceFileForSaf) == null) {
                requestSafAccessAndResume(sourceFileForSaf, destinationDir, true, policy);
                return;
            }
        }
        if (destinationLikelyNeedsSaf(destination) && findPersistedSafTreeForPath(destinationDir) == null) {
            requestSafAccessAndResume(destinationDir, destinationDir, move, policy);
            return;
        }
        Toast.makeText(this, move ? "移動しています" : "コピーしています", Toast.LENGTH_SHORT).show();
        AppLog.d(this, "FILE transfer begin mode=" + (move ? "move" : "copy") +
                " source=" + sourceName + " destination=" + destination.getAbsolutePath() + " policy=" + policy);
        safeExecute(editExecutor, () -> {
            Uri copiedUri = null;
            try {
                copiedUri = copyToDestination(sourceUri, destination, policy == CONFLICT_OVERWRITE);
                if (copiedUri == null) throw new IOException("destination unavailable");
                if (!move) {
                    final Uri finalCopiedUri = copiedUri;
                    mainHandler.post(() -> finishFileTransfer(false, finalCopiedUri, destinationDir, destination,
                            sourceUri, sourcePath, sourceName));
                    return;
                }

                MoveDeleteAttempt deleteAttempt = deleteSourceForMove(sourceUri, sourcePath);
                if (deleteAttempt.deleted) {
                    final Uri finalCopiedUri = copiedUri;
                    mainHandler.post(() -> finishFileTransfer(true, finalCopiedUri, destinationDir, destination,
                            sourceUri, sourcePath, sourceName));
                    return;
                }
                if (deleteAttempt.consentIntent != null) {
                    final Uri finalCopiedUri = copiedUri;
                    final MoveDeleteAttempt finalAttempt = deleteAttempt;
                    mainHandler.post(() -> requestMoveDeleteConsent(finalAttempt, finalCopiedUri, destinationDir,
                            destination, sourceUri, sourcePath, sourceName));
                    return;
                }
                throw new IOException("source delete failed");
            } catch (Throwable e) {
                AppLog.d(this, "FILE " + (move ? "move" : "copy") + " error " + e);
                final boolean partial = copiedUri != null && move;
                mainHandler.post(() -> Toast.makeText(this,
                        partial ? "コピーは完了しましたが元ファイルを削除できませんでした" : (move ? "移動できませんでした" : "コピーできませんでした"),
                        Toast.LENGTH_LONG).show());
            }
        });
    }

    private void finishFileTransfer(boolean move, Uri resultUri, File destinationDir, File destination,
                                    Uri sourceUri, String sourcePath, String sourceName) {
        synchronized (FOLDER_CACHE_LOCK) { FOLDER_INDEX_CACHE.evictAll(); }
        invalidateDirectoryCache(destinationDir);
        if (sourcePath != null) invalidateDirectoryCache(new File(sourcePath).getParentFile());
        AppLog.d(this, "FILE " + (move ? "move" : "copy") + " success source=" + sourceName + " dest=" + destination);
        if (move) {
            currentUri = resultUri;
            currentName = destination.getName();
            currentMime = mimeFromName(currentName);
            clearPendingRotationState();
            titleView.setText(currentName);
            showCurrentUri(false, 0);
            discoverSiblingImagesAsync();
            Toast.makeText(this, "移動しました", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(this, destination.getName().equals(sourceName) ? "コピーしました" : "別名でコピーしました", Toast.LENGTH_SHORT).show();
        }
    }

    private void requestMoveDeleteConsent(MoveDeleteAttempt attempt, Uri copiedUri, File destinationDir,
                                          File destination, Uri sourceUri, String sourcePath, String sourceName) {
        if (attempt == null || attempt.consentIntent == null) {
            Toast.makeText(this, "コピーは完了しましたが元ファイルを削除できませんでした", Toast.LENGTH_LONG).show();
            return;
        }
        pendingMoveDelete = new PendingMoveDelete(copiedUri, destinationDir, destination, sourceUri,
                sourcePath, sourceName, attempt.mediaStoreUri);
        AppLog.d(this, "FILE move delete consent request source=" + sourceName +
                " media=" + attempt.mediaStoreUri);
        try {
            startIntentSenderForResult(attempt.consentIntent.getIntentSender(), REQ_MOVE_DELETE,
                    null, 0, 0, 0);
        } catch (Throwable e) {
            pendingMoveDelete = null;
            AppLog.d(this, "FILE move delete consent launch failed " + e);
            Toast.makeText(this, "コピーは完了しましたが元ファイルを削除できませんでした", Toast.LENGTH_LONG).show();
        }
    }

    private Uri copyToDestination(Uri sourceUri, File destination, boolean overwrite) throws IOException {
        File parent = destination.getParentFile();
        if (parent == null || !parent.isDirectory()) throw new IOException("missing destination directory");
        Throwable mediaFailure = null;

        // Android 10+ shared storage is MediaStore-first. This avoids relying on canWrite(),
        // which can report a path optimistically even when scoped-storage blocks FileOutputStream.
        if (Build.VERSION.SDK_INT >= 29) {
            StorageTarget target = storageTargetForPath(destination.getAbsolutePath());
            if (target != null) {
                try {
                    Uri out = copyToMediaStore(sourceUri, destination, target, overwrite);
                    if (out != null) {
                        AppLog.d(this, "FILE transfer backend=mediastore destination=" + destination.getAbsolutePath());
                        return out;
                    }
                } catch (Throwable e) {
                    mediaFailure = e;
                    AppLog.d(this, "FILE transfer mediastore failed destination=" + destination.getAbsolutePath() + " " + e);
                }
            }
        }

        // Persisted SAF permission is the third backend for arbitrary removable-SD folders.
        Uri safTree = findPersistedSafTreeForPath(parent);
        if (safTree != null) {
            try {
                return copyToSaf(sourceUri, destination, safTree, overwrite);
            } catch (Throwable safFailure) {
                AppLog.d(this, "FILE transfer saf failed destination=" + destination.getAbsolutePath() + " " + safFailure);
            }
        }

        // Direct file write is the fallback for app-writable/custom locations and older Android.
        try {
            if (destination.exists() && !overwrite) throw new IOException("destination exists");
            try (InputStream in = openSourceInputStream(sourceUri);
                 OutputStream out = new FileOutputStream(destination, false)) {
                copyStream(in, out);
            }
            AppLog.d(this, "FILE transfer backend=direct destination=" + destination.getAbsolutePath());
            return Uri.fromFile(destination);
        } catch (Throwable directFailure) {
            AppLog.d(this, "FILE transfer direct failed destination=" + destination.getAbsolutePath() + " " + directFailure);
            IOException failure = new IOException("No writable copy backend for " + destination.getAbsolutePath(), directFailure);
            if (mediaFailure != null) failure.addSuppressed(mediaFailure);
            throw failure;
        }
    }

    private Uri copyToMediaStore(Uri sourceUri, File destination, StorageTarget target, boolean overwrite) throws IOException {
        Uri collection = mediaCollectionForTarget(target, destination.getName());
        if (collection == null) return null;
        if (overwrite) deleteMediaStoreDestination(target, destination.getName(), collection);

        ContentValues values = new ContentValues();
        values.put(MediaStore.MediaColumns.DISPLAY_NAME, destination.getName());
        values.put(MediaStore.MediaColumns.MIME_TYPE, mimeFromName(destination.getName()));
        values.put(MediaStore.MediaColumns.RELATIVE_PATH, target.relativeDirectory);
        values.put(MediaStore.MediaColumns.IS_PENDING, 1);
        Uri outUri = getContentResolver().insert(collection, values);
        if (outUri == null) throw new IOException("MediaStore insert failed");
        try {
            try (InputStream in = openSourceInputStream(sourceUri);
                 OutputStream out = getContentResolver().openOutputStream(outUri, "w")) {
                if (out == null) throw new IOException("MediaStore output failed");
                copyStream(in, out);
            }
            ContentValues done = new ContentValues();
            done.put(MediaStore.MediaColumns.IS_PENDING, 0);
            getContentResolver().update(outUri, done, null, null);
            return outUri;
        } catch (Throwable e) {
            try { getContentResolver().delete(outUri, null, null); } catch (Throwable ignored) { }
            if (e instanceof IOException) throw (IOException)e;
            throw new IOException(e);
        }
    }

    private Uri mediaCollectionForTarget(StorageTarget target, String fileName) {
        if (target == null) return null;
        String rel = target.relativeDirectory == null ? "" : target.relativeDirectory.replace('\\', '/');
        String lower = rel.toLowerCase(Locale.ROOT);
        if (Build.VERSION.SDK_INT >= 29 && (lower.equals("download/") || lower.startsWith("download/"))) {
            return MediaStore.Downloads.getContentUri(target.volumeName);
        }
        if (fileName != null && fileName.toLowerCase(Locale.ROOT).endsWith(".pdf")) {
            if (Build.VERSION.SDK_INT >= 29) return MediaStore.Downloads.getContentUri(target.volumeName);
            return null;
        }
        return MediaStore.Images.Media.getContentUri(target.volumeName);
    }


    private InputStream openSourceInputStream(Uri sourceUri) throws IOException {
        String path = inferAbsolutePathFromAnyUri(sourceUri);
        if (path != null) {
            try { return new FileInputStream(new File(path)); }
            catch (Throwable ignored) { }
        }
        InputStream in = getContentResolver().openInputStream(sourceUri);
        if (in == null) throw new IOException("source stream unavailable");
        return in;
    }

    private void copyStream(InputStream in, OutputStream out) throws IOException {
        byte[] buffer = new byte[128 * 1024];
        int read;
        while ((read = in.read(buffer)) >= 0) {
            if (read > 0) out.write(buffer, 0, read);
        }
        out.flush();
    }

    private void deleteMediaStoreDestination(StorageTarget target, String name, Uri collection) {
        try {
            getContentResolver().delete(collection,
                    MediaStore.MediaColumns.RELATIVE_PATH + "=? AND " + MediaStore.MediaColumns.DISPLAY_NAME + "=? COLLATE NOCASE",
                    new String[]{target.relativeDirectory, name});
        } catch (Throwable e) {
            AppLog.d(this, "FILE overwrite delete miss " + e.getClass().getSimpleName());
        }
    }


    private MoveDeleteAttempt deleteSourceForMove(Uri uri, String path) {
        try {
            if ("content".equalsIgnoreCase(uri.getScheme())) {
                try {
                    if (getContentResolver().delete(uri, null, null) > 0) {
                        AppLog.d(this, "FILE source delete backend=content uri=" + uri);
                        return MoveDeleteAttempt.deleted();
                    }
                } catch (Throwable e) {
                    AppLog.d(this, "FILE source delete content failed uri=" + uri + " " + e.getClass().getSimpleName());
                }
            }
            if (path != null) {
                File f = new File(path);
                Uri tree = findPersistedSafTreeForPath(f);
                if (tree != null) {
                    Uri doc = safDocumentUriForPath(tree, f);
                    if (doc != null) {
                        try {
                            if (DocumentsContract.deleteDocument(getContentResolver(), doc)) {
                                AppLog.d(this, "SAF source delete success path=" + path);
                                return MoveDeleteAttempt.deleted();
                            }
                        } catch (Throwable e) {
                            AppLog.d(this, "SAF source delete failed path=" + path + " " + e);
                        }
                    }
                }
                if (!f.exists()) return MoveDeleteAttempt.deleted();
                try {
                    if (f.delete() || !f.exists()) {
                        AppLog.d(this, "FILE source delete backend=direct path=" + path);
                        return MoveDeleteAttempt.deleted();
                    }
                } catch (Throwable e) {
                    AppLog.d(this, "FILE source delete direct failed path=" + path + " " + e.getClass().getSimpleName());
                }

                // For shared internal storage, locate the real MediaStore item even when the
                // incoming content:// URI belongs to another file manager. Android 11+ may
                // require a system confirmation before deleting that item.
                if (Build.VERSION.SDK_INT >= 29) {
                    Uri mediaUri = findMediaStoreUriForAbsolutePath(path);
                    if (mediaUri != null) {
                        try {
                            if (getContentResolver().delete(mediaUri, null, null) > 0 || !f.exists()) {
                                AppLog.d(this, "FILE source delete backend=mediastore uri=" + mediaUri + " path=" + path);
                                return MoveDeleteAttempt.deleted();
                            }
                        } catch (android.app.RecoverableSecurityException recoverable) {
                            AppLog.d(this, "FILE source delete mediastore needs consent uri=" + mediaUri + " api=29");
                            return MoveDeleteAttempt.consent(mediaUri, recoverable.getUserAction().getActionIntent());
                        } catch (SecurityException security) {
                            AppLog.d(this, "FILE source delete mediastore security uri=" + mediaUri + " " + security.getClass().getSimpleName());
                        } catch (Throwable e) {
                            AppLog.d(this, "FILE source delete mediastore failed uri=" + mediaUri + " " + e);
                        }
                        if (Build.VERSION.SDK_INT >= 30 && f.exists()) {
                            try {
                                android.app.PendingIntent consent = MediaStore.createDeleteRequest(
                                        getContentResolver(), Collections.singletonList(mediaUri));
                                AppLog.d(this, "FILE source delete mediastore needs consent uri=" + mediaUri + " api=" + Build.VERSION.SDK_INT);
                                return MoveDeleteAttempt.consent(mediaUri, consent);
                            } catch (Throwable e) {
                                AppLog.d(this, "FILE source delete consent create failed uri=" + mediaUri + " " + e);
                            }
                        }
                    } else {
                        AppLog.d(this, "FILE source delete mediastore resolve miss path=" + path);
                    }
                }
            }
        } catch (Throwable e) {
            AppLog.d(this, "FILE source delete error " + e);
        }
        return MoveDeleteAttempt.failed();
    }

    private Uri findMediaStoreUriForAbsolutePath(String path) {
        if (Build.VERSION.SDK_INT < 29 || path == null) return null;
        StorageTarget target = storageTargetForPath(path);
        if (target == null || target.relativeDirectory == null) return null;
        String name = new File(path).getName();
        ArrayList<Uri> collections = new ArrayList<>();
        Uri preferred = mediaCollectionForTarget(target, name);
        if (preferred != null) collections.add(preferred);
        Uri images = MediaStore.Images.Media.getContentUri(target.volumeName);
        if (!collections.contains(images)) collections.add(images);
        Uri downloads = MediaStore.Downloads.getContentUri(target.volumeName);
        if (!collections.contains(downloads)) collections.add(downloads);
        for (Uri collection : collections) {
            try (Cursor c = getContentResolver().query(collection,
                    new String[]{MediaStore.MediaColumns._ID},
                    MediaStore.MediaColumns.RELATIVE_PATH + "=? AND " +
                            MediaStore.MediaColumns.DISPLAY_NAME + "=? COLLATE NOCASE",
                    new String[]{target.relativeDirectory, name}, null)) {
                if (c != null && c.moveToFirst()) {
                    long id = c.getLong(0);
                    Uri found = ContentUris.withAppendedId(collection, id);
                    AppLog.d(this, "FILE source mediastore resolved path=" + path + " uri=" + found);
                    return found;
                }
            } catch (Throwable e) {
                AppLog.d(this, "FILE source mediastore query failed collection=" + collection + " " + e.getClass().getSimpleName());
            }
        }
        return null;
    }

    private boolean waitUntilMoveSourceGone(PendingMoveDelete pending) {
        if (pending == null) return false;
        for (int i = 0; i < 8; i++) {
            boolean pathGone = pending.sourcePath == null || !new File(pending.sourcePath).exists();
            boolean mediaGone = pending.mediaStoreUri == null || !contentUriStillExists(pending.mediaStoreUri);
            if (pathGone && mediaGone) return true;
            if (i < 7) {
                try { Thread.sleep(150L); } catch (InterruptedException e) { Thread.currentThread().interrupt(); break; }
            }
        }
        return false;
    }

    private boolean contentUriStillExists(Uri uri) {
        if (uri == null) return false;
        try (Cursor c = getContentResolver().query(uri, new String[]{MediaStore.MediaColumns._ID}, null, null, null)) {
            return c != null && c.moveToFirst();
        } catch (Throwable e) {
            return false;
        }
    }

    private static class MoveDeleteAttempt {
        final boolean deleted;
        final Uri mediaStoreUri;
        final android.app.PendingIntent consentIntent;
        private MoveDeleteAttempt(boolean deleted, Uri mediaStoreUri, android.app.PendingIntent consentIntent) {
            this.deleted = deleted;
            this.mediaStoreUri = mediaStoreUri;
            this.consentIntent = consentIntent;
        }
        static MoveDeleteAttempt deleted() { return new MoveDeleteAttempt(true, null, null); }
        static MoveDeleteAttempt failed() { return new MoveDeleteAttempt(false, null, null); }
        static MoveDeleteAttempt consent(Uri mediaStoreUri, android.app.PendingIntent consentIntent) {
            return new MoveDeleteAttempt(false, mediaStoreUri, consentIntent);
        }
    }

    private static class PendingMoveDelete {
        final Uri copiedUri;
        final File destinationDir;
        final File destination;
        final Uri sourceUri;
        final String sourcePath;
        final String sourceName;
        final Uri mediaStoreUri;
        PendingMoveDelete(Uri copiedUri, File destinationDir, File destination, Uri sourceUri,
                          String sourcePath, String sourceName, Uri mediaStoreUri) {
            this.copiedUri = copiedUri;
            this.destinationDir = destinationDir;
            this.destination = destination;
            this.sourceUri = sourceUri;
            this.sourcePath = sourcePath;
            this.sourceName = sourceName;
            this.mediaStoreUri = mediaStoreUri;
        }
    }

    private void shareCurrent() {
        if (currentUri == null) return;
        if (pendingRotationDegrees != 0) {
            shareRotatedCurrent();
            return;
        }
        try {
            Uri shareUri = currentUri;
            if ("file".equalsIgnoreCase(currentUri.getScheme())) {
                File f = new File(currentUri.getPath());
                shareUri = androidx.core.content.FileProvider.getUriForFile(
                        this, getPackageName() + ".fileprovider", f);
            }
            android.content.Intent share = new android.content.Intent(android.content.Intent.ACTION_SEND);
            share.setType(currentMime == null ? "image/*" : currentMime);
            share.putExtra(android.content.Intent.EXTRA_STREAM, shareUri);
            share.addFlags(android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION);
            startActivity(android.content.Intent.createChooser(share, "共有"));
        } catch (Throwable e) {
            AppLog.d(this, "SHARE error " + e);
            Toast.makeText(this, "共有できませんでした", Toast.LENGTH_SHORT).show();
        }
    }

    private void shareRotatedCurrent() {
        final int degrees = pendingRotationDegrees;
        final Bitmap ready = pendingRotationBitmap;
        final Uri sourceUri = currentUri;
        final String sourceName = currentName;
        if (degrees == 0 || sourceUri == null) { shareCurrent(); return; }
        Toast.makeText(this, "回転画像を準備しています", Toast.LENGTH_SHORT).show();
        safeExecute(editExecutor, () -> {
            try {
                Bitmap bitmap = ready != null ? ready : decodeRotatedBitmap(sourceUri, degrees);
                OutputSpec spec = outputSpec(extensionOf(sourceName));
                File dir = new File(getCacheDir(), "shared-edits");
                if (!dir.exists() && !dir.mkdirs()) throw new IOException("Cannot create share cache");
                String base = baseNameOf(sourceName);
                File out = new File(dir, sanitizeFileName(base) + "_rotated." + spec.extension);
                try (OutputStream os = new FileOutputStream(out)) {
                    writeBitmap(bitmap, spec, os);
                }
                Uri shareUri = androidx.core.content.FileProvider.getUriForFile(
                        this, getPackageName() + ".fileprovider", out);
                mainHandler.post(() -> {
                    try {
                        Intent share = new Intent(Intent.ACTION_SEND);
                        share.setType(spec.mime);
                        share.putExtra(Intent.EXTRA_STREAM, shareUri);
                        share.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                        startActivity(Intent.createChooser(share, "保存せず共有"));
                    } catch (Throwable e) {
                        AppLog.d(this, "SHARE rotated chooser error " + e);
                        Toast.makeText(this, "共有できませんでした", Toast.LENGTH_SHORT).show();
                    }
                });
            } catch (Throwable e) {
                AppLog.d(this, "SHARE rotated error " + e);
                mainHandler.post(() -> Toast.makeText(this, "回転画像を共有できませんでした", Toast.LENGTH_SHORT).show());
            }
        });
    }

    private void showPropertiesDialog() {
        if (currentUri == null) return;
        final int panel = Color.rgb(58, 51, 51);
        final int label = Color.rgb(180, 180, 190);
        LinearLayout content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(dp(24), dp(18), dp(24), dp(10));
        content.setBackground(makeRoundedPanel(panel));

        TextView title = new TextView(this);
        title.setText("プロパティ");
        title.setTextColor(Color.WHITE);
        title.setTextSize(20);
        title.setTypeface(null, android.graphics.Typeface.BOLD);
        LinearLayout.LayoutParams titleParams = new LinearLayout.LayoutParams(-1, -2);
        titleParams.bottomMargin = dp(16);
        content.addView(title, titleParams);

        addPropertyRow(content, "名前", currentName == null ? resolveDisplayName(currentUri) : currentName, label);
        String absolute = inferAbsolutePathFromAnyUri(currentUri);
        String shownPath = absolute != null ? absolute : currentUri.toString();
        addPropertyRow(content, "パス", shownPath, label);

        long size = resolveCurrentSize();
        addPropertyRow(content, "サイズ", formatFileSize(size), label);
        int[] dimensions = currentImageDimensions();
        String resolution = dimensions[0] > 0 && dimensions[1] > 0
                ? String.format(Locale.ROOT, "%d × %d (%.1fMP)", dimensions[0], dimensions[1],
                (dimensions[0] * (double) dimensions[1]) / 1_000_000d)
                : "-";
        addPropertyRow(content, "解像度", resolution, label);
        long modified = resolveCurrentModified();
        addPropertyRow(content, "最終更新日時", formatModified(modified), label);

        TextView ok = new TextView(this);
        ok.setText("OK");
        ok.setTextColor(Color.WHITE);
        ok.setTextSize(15);
        ok.setGravity(Gravity.CENTER);
        ok.setBackground(new android.graphics.drawable.ColorDrawable(Color.TRANSPARENT));
        LinearLayout.LayoutParams okParams = new LinearLayout.LayoutParams(dp(64), dp(44));
        okParams.gravity = Gravity.END;
        content.addView(ok, okParams);

        AlertDialog dialog = new AlertDialog.Builder(this).setView(content).create();
        dialog.setCanceledOnTouchOutside(true);
        prepareDialogBeforeShow(dialog, panel);
        ok.setOnClickListener(v -> dialog.dismiss());
        AppLog.d(this, "DIALOG properties show-prepared");
        dialog.show();
    }

    private void addPropertyRow(LinearLayout parent, String labelText, String value, int labelColor) {
        TextView label = new TextView(this);
        label.setText(labelText);
        label.setTextColor(labelColor);
        label.setTextSize(14);
        parent.addView(label, new LinearLayout.LayoutParams(-1, -2));
        TextView valueView = new TextView(this);
        valueView.setText(value == null || value.isEmpty() ? "-" : value);
        valueView.setTextColor(Color.WHITE);
        valueView.setTextSize(17);
        valueView.setTextIsSelectable(true);
        LinearLayout.LayoutParams vp = new LinearLayout.LayoutParams(-1, -2);
        vp.bottomMargin = dp(16);
        parent.addView(valueView, vp);
    }

    private long resolveCurrentSize() {
        try {
            String path = inferAbsolutePathFromAnyUri(currentUri);
            if (path != null) {
                File f = new File(path);
                if (f.isFile()) return f.length();
            }
            try (Cursor c = getContentResolver().query(currentUri,
                    new String[]{OpenableColumns.SIZE}, null, null, null)) {
                if (c != null && c.moveToFirst()) {
                    int col = c.getColumnIndex(OpenableColumns.SIZE);
                    if (col >= 0 && !c.isNull(col)) return c.getLong(col);
                }
            }
        } catch (Throwable ignored) { }
        MediaItem item = currentMediaItem();
        return item == null ? -1L : item.size;
    }

    private long resolveCurrentModified() {
        try {
            String path = inferAbsolutePathFromAnyUri(currentUri);
            if (path != null) {
                long v = new File(path).lastModified();
                if (v > 0L) return v;
            }
            try (Cursor c = getContentResolver().query(currentUri,
                    new String[]{MediaStore.MediaColumns.DATE_MODIFIED}, null, null, null)) {
                if (c != null && c.moveToFirst()) {
                    int col = c.getColumnIndex(MediaStore.MediaColumns.DATE_MODIFIED);
                    if (col >= 0 && !c.isNull(col)) {
                        long v = c.getLong(col);
                        return v > 0L && v < 10_000_000_000L ? v * 1000L : v;
                    }
                }
            }
        } catch (Throwable ignored) { }
        MediaItem item = currentMediaItem();
        if (item == null || item.modified < 0L) return -1L;
        return item.modified < 10_000_000_000L ? item.modified * 1000L : item.modified;
    }

    private MediaItem currentMediaItem() {
        if (currentIndex >= 0 && currentIndex < siblings.size()) return siblings.get(currentIndex);
        for (MediaItem item : siblings) {
            if (item != null && currentName != null && currentName.equalsIgnoreCase(item.name)) return item;
        }
        return null;
    }

    private int[] currentImageDimensions() {
        Drawable d = imageView == null ? null : imageView.getDrawable();
        if (d != null) return new int[]{Math.max(0, d.getIntrinsicWidth()), Math.max(0, d.getIntrinsicHeight())};
        return new int[]{0, 0};
    }

    private String formatFileSize(long bytes) {
        if (bytes < 0L) return "-";
        if (bytes < 1024L) return bytes + " B";
        if (bytes < 1024L * 1024L) return String.format(Locale.ROOT, "%.1f kB", bytes / 1024d);
        if (bytes < 1024L * 1024L * 1024L) return String.format(Locale.ROOT, "%.1f MB", bytes / (1024d * 1024d));
        return String.format(Locale.ROOT, "%.2f GB", bytes / (1024d * 1024d * 1024d));
    }

    private String formatModified(long millis) {
        if (millis <= 0L) return "-";
        return new SimpleDateFormat("yyyy/MM/dd HH:mm:ss", Locale.getDefault()).format(new Date(millis));
    }


    private void startCropEditor() {
        if (cropEditing || currentUri == null) return;
        if (!supportsCropResizeCurrent()) {
            Toast.makeText(this, isAnimatedGifCurrent() ? "アニメーションGIFはトリミングできません" : "このファイルはトリミングできません", Toast.LENGTH_SHORT).show();
            return;
        }
        Drawable drawable = imageView == null ? null : imageView.getDrawable();
        if (drawable == null || drawable.getIntrinsicWidth() <= 0 || drawable.getIntrinsicHeight() <= 0) {
            Toast.makeText(this, "画像を準備できませんでした", Toast.LENGTH_SHORT).show();
            return;
        }
        dismissRotationPopup();
        cancelPageAnimationsForTouch();

        int iw = drawable.getIntrinsicWidth();
        int ih = drawable.getIntrinsicHeight();
        int normalizedRotation = ((pendingRotationDegrees % 360) + 360) % 360;
        int shownW = normalizedRotation % 180 == 0 ? iw : ih;
        int shownH = normalizedRotation % 180 == 0 ? ih : iw;
        if (!restoreCropEditorAfterLaunch) {
            cropPortrait = shownH >= shownW;
            cropRatioMode = CROP_RATIO_FULL;
            cropFreeAspectLocked = false;
            cropFreeLockedAspect = 1f;
            cropFineRotationDegrees = 0f;
        }

        cropEditorRoot = new FrameLayout(this);
        cropEditorRoot.setBackgroundColor(Color.BLACK);
        cropEditorRoot.setClickable(true);
        cropEditorRoot.setFocusable(true);

        cropOverlayView = new CropOverlayView(drawable, normalizedRotation);
        FrameLayout.LayoutParams canvasLp = new FrameLayout.LayoutParams(-1, -1);
        canvasLp.topMargin = dp(112);
        canvasLp.bottomMargin = dp(274);
        cropEditorRoot.addView(cropOverlayView, canvasLp);

        LinearLayout cropTop = new LinearLayout(this);
        cropTop.setOrientation(LinearLayout.HORIZONTAL);
        cropTop.setGravity(Gravity.CENTER_VERTICAL);
        cropTop.setPadding(dp(4), 0, dp(4), 0);
        View back = new ToolbarIconView(this, ToolbarIconView.BACK, dp(38));
        back.setContentDescription("トリミングをキャンセル");
        back.setOnClickListener(v -> exitCropEditor());
        cropTop.addView(back, new LinearLayout.LayoutParams(dp(44), dp(58)));

        TextView cropTitle = new TextView(this);
        cropTitle.setText(String.format(Locale.ROOT, "%d × %d - %.2f MP", shownW, shownH,
                (shownW * (double) shownH) / 1_000_000d));
        cropTitle.setTextColor(Color.WHITE);
        cropTitle.setTextSize(18);
        cropTitle.setGravity(Gravity.CENTER);
        cropTitle.setSingleLine(true);
        cropTitle.setIncludeFontPadding(false);
        cropTop.addView(cropTitle, new LinearLayout.LayoutParams(0, dp(58), 1f));

        View check = new ToolbarIconView(this, ToolbarIconView.CHECK_LARGE, dp(38));
        check.setContentDescription("トリミングを確定");
        check.setOnClickListener(v -> {
            if (cropOverlayView == null) return;
            RectF normalized = cropOverlayView.getNormalizedCrop();
            if (normalized == null) {
                Toast.makeText(this, "トリミング範囲を決められませんでした", Toast.LENGTH_SHORT).show();
                return;
            }
            showSaveCroppedDialog(normalized);
        });
        cropTop.addView(check, new LinearLayout.LayoutParams(dp(44), dp(58)));
        FrameLayout.LayoutParams topLp = new FrameLayout.LayoutParams(-1, dp(58), Gravity.TOP);
        topLp.topMargin = dp(50);
        cropEditorRoot.addView(cropTop, topLp);

        LinearLayout controls = buildCropControls();
        FrameLayout.LayoutParams controlsLp = new FrameLayout.LayoutParams(-1, -2, Gravity.BOTTOM);
        controlsLp.leftMargin = dp(3);
        controlsLp.rightMargin = dp(3);
        controlsLp.bottomMargin = dp(50);
        cropEditorRoot.addView(controls, controlsLp);

        cropEditing = true;
        topBar.setVisibility(View.GONE);
        bottomBar.setVisibility(View.GONE);
        pagePreviewView.setVisibility(View.GONE);
        imageView.setVisibility(View.INVISIBLE);
        rootView.addView(cropEditorRoot, new FrameLayout.LayoutParams(-1, -1));
        updateCropControlStyles();
        AppLog.d(this, "CROP editor open rotation=" + normalizedRotation + " shown=" + shownW + "x" + shownH);
    }

    private LinearLayout buildCropControls() {
        final int panel = Color.rgb(42, 34, 34); // #2A2222
        LinearLayout controls = new LinearLayout(this);
        controls.setOrientation(LinearLayout.VERTICAL);
        controls.setPadding(dp(8), dp(7), dp(8), dp(7));
        controls.setBackground(makeRoundedPanel(panel));

        LinearLayout ratioRow = makeCropControlRow("比率");
        String[] ratioLabels = new String[]{"1:1", "4:3", "16:9", "端末比", "全体"};
        cropRatioChoices = new TextView[ratioLabels.length];
        for (int i = 0; i < ratioLabels.length; i++) {
            final int index = i;
            TextView choice = makeCropChoice(ratioLabels[i]);
            cropRatioChoices[i] = choice;
            choice.setOnClickListener(v -> {
                cropRatioMode = index;
                updateCropControlStyles();
                if (cropOverlayView != null) cropOverlayView.resetForSelection();
            });
            ratioRow.addView(choice, cropChoiceParams());
        }
        controls.addView(ratioRow, new LinearLayout.LayoutParams(-1, dp(46)));

        cropOrientationRow = makeCropControlRow("向き");
        cropOrientationChoices = new TextView[]{makeCropChoice("縦"), makeCropChoice("横")};
        cropOrientationChoices[0].setOnClickListener(v -> {
            cropPortrait = true;
            updateCropControlStyles();
            if (cropOverlayView != null) cropOverlayView.resetForSelection();
        });
        cropOrientationChoices[1].setOnClickListener(v -> {
            cropPortrait = false;
            updateCropControlStyles();
            if (cropOverlayView != null) cropOverlayView.resetForSelection();
        });
        cropOrientationRow.addView(cropOrientationChoices[0], cropChoiceParams());
        cropOrientationRow.addView(cropOrientationChoices[1], cropChoiceParams());
        TextView orientationSpacer = new TextView(this);
        cropOrientationRow.addView(orientationSpacer, new LinearLayout.LayoutParams(0, dp(38), 3f));
        controls.addView(cropOrientationRow, new LinearLayout.LayoutParams(-1, dp(46)));

        // Keep the 50dp label column for alignment, but intentionally show no "フリー" heading.
        LinearLayout freeRow = makeCropControlRow("");
        cropFreeChoice = makeCropChoice("自由変形");
        cropFreeChoice.setOnClickListener(v -> {
            if (cropOverlayView != null && cropFreeAspectLocked) {
                float current = cropOverlayView.getCurrentAspect();
                if (Float.isFinite(current) && current > 0.01f) cropFreeLockedAspect = current;
            }
            cropRatioMode = CROP_RATIO_FREE;
            updateCropControlStyles();
            if (cropOverlayView != null) cropOverlayView.invalidate();
            AppLog.d(this, "CROP free transform lock=" + cropFreeAspectLocked + " aspect=" + cropFreeLockedAspect);
        });
        LinearLayout.LayoutParams freeButtonLp = new LinearLayout.LayoutParams(0, dp(36), 1.25f);
        freeButtonLp.leftMargin = dp(2);
        freeButtonLp.rightMargin = dp(6);
        freeRow.addView(cropFreeChoice, freeButtonLp);

        cropFreeLockCheck = new CheckBox(this);
        cropFreeLockCheck.setText("縦横比を固定");
        cropFreeLockCheck.setTextColor(Color.WHITE);
        cropFreeLockCheck.setTextSize(13);
        cropFreeLockCheck.setGravity(Gravity.CENTER_VERTICAL);
        cropFreeLockCheck.setButtonTintList(new ColorStateList(
                new int[][]{new int[]{android.R.attr.state_checked}, new int[]{}},
                new int[]{Color.rgb(68, 85, 119), Color.rgb(90, 85, 85)}));
        cropFreeLockCheck.setChecked(cropFreeAspectLocked);
        cropFreeLockCheck.setOnCheckedChangeListener((buttonView, isChecked) -> {
            cropFreeAspectLocked = isChecked;
            if (isChecked && cropOverlayView != null) {
                float current = cropOverlayView.getCurrentAspect();
                if (Float.isFinite(current) && current > 0.01f) cropFreeLockedAspect = current;
            }
            if (cropRatioMode == CROP_RATIO_FREE && cropOverlayView != null) cropOverlayView.invalidate();
            AppLog.d(this, "CROP free lock=" + isChecked + " aspect=" + cropFreeLockedAspect);
        });
        freeRow.addView(cropFreeLockCheck, new LinearLayout.LayoutParams(0, dp(40), 2.25f));
        controls.addView(freeRow, new LinearLayout.LayoutParams(-1, dp(46)));

        LinearLayout rotateRow = makeCropControlRow("回転");
        cropRotationSlider = new RotationSliderView();
        cropRotationSlider.setDegrees(cropFineRotationDegrees, false);
        rotateRow.addView(cropRotationSlider, new LinearLayout.LayoutParams(0, dp(72), 1f));
        controls.addView(rotateRow, new LinearLayout.LayoutParams(-1, dp(76)));
        return controls;
    }

    private LinearLayout makeCropControlRow(String labelText) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        TextView label = new TextView(this);
        label.setText(labelText);
        label.setTextColor(Color.rgb(190, 190, 198));
        label.setTextSize(13);
        label.setGravity(Gravity.CENTER_VERTICAL);
        row.addView(label, new LinearLayout.LayoutParams(dp(50), dp(38)));
        return row;
    }

    private TextView makeCropChoice(String text) {
        TextView view = new TextView(this);
        view.setText(text);
        view.setTextColor(Color.WHITE);
        view.setTextSize(13);
        view.setGravity(Gravity.CENTER);
        view.setIncludeFontPadding(false);
        view.setClickable(true);
        view.setFocusable(true);
        return view;
    }

    private LinearLayout.LayoutParams cropChoiceParams() {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, dp(36), 1f);
        lp.leftMargin = dp(2);
        lp.rightMargin = dp(2);
        return lp;
    }

    private GradientDrawable makeCropChoiceBackground(boolean selected) {
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(selected ? Color.rgb(68, 85, 119) : Color.rgb(58, 51, 51));
        bg.setCornerRadius(dp(8));
        // Crop controls are solid-fill buttons: no outline/stroke around selected or idle states.
        return bg;
    }

    private void updateCropControlStyles() {
        if (cropRatioChoices != null) {
            for (int i = 0; i < cropRatioChoices.length; i++) {
                cropRatioChoices[i].setBackground(makeCropChoiceBackground(i == cropRatioMode));
            }
        }
        if (cropOrientationChoices != null) {
            cropOrientationChoices[0].setBackground(makeCropChoiceBackground(cropPortrait));
            cropOrientationChoices[1].setBackground(makeCropChoiceBackground(!cropPortrait));
        }
        if (cropOrientationRow != null) {
            boolean ratioNeedsOrientation = cropRatioMode >= CROP_RATIO_1_1 && cropRatioMode <= CROP_RATIO_DEVICE;
            cropOrientationRow.setVisibility(ratioNeedsOrientation ? View.VISIBLE : View.GONE);
        }
        if (cropFreeChoice != null) {
            cropFreeChoice.setBackground(makeCropChoiceBackground(cropRatioMode == CROP_RATIO_FREE));
        }
    }

    private float cropLandscapeAspect(int mode) {
        if (mode == CROP_RATIO_1_1) return 1f;
        if (mode == CROP_RATIO_4_3) return 4f / 3f;
        if (mode == CROP_RATIO_16_9) return 16f / 9f;
        if (mode == CROP_RATIO_DEVICE) {
            android.util.DisplayMetrics dm = getResources().getDisplayMetrics();
            float a = Math.max(dm.widthPixels, dm.heightPixels);
            float b = Math.max(1f, Math.min(dm.widthPixels, dm.heightPixels));
            return a / b;
        }
        return 1f;
    }

    private float currentCropAspect() {
        if (cropRatioMode == CROP_RATIO_FREE) return Math.max(0.05f, cropFreeLockedAspect);
        float landscape = cropLandscapeAspect(cropRatioMode);
        if (cropRatioMode == CROP_RATIO_1_1) return 1f;
        return cropPortrait ? 1f / landscape : landscape;
    }

    private boolean cropAspectLocked() {
        if (cropRatioMode == CROP_RATIO_FULL) return false;
        if (cropRatioMode == CROP_RATIO_FREE) return cropFreeAspectLocked;
        return true;
    }

    private void exitCropEditor() {
        if (!cropEditing) return;
        if (cropEditorRoot != null && rootView != null) rootView.removeView(cropEditorRoot);
        cropEditorRoot = null;
        cropOverlayView = null;
        cropRatioChoices = null;
        cropOrientationChoices = null;
        cropOrientationRow = null;
        cropFreeChoice = null;
        cropFreeLockCheck = null;
        cropRotationSlider = null;
        cropEditing = false;
        if (imageView != null) imageView.setVisibility(View.VISIBLE);
        if (topBar != null) topBar.setVisibility(View.VISIBLE);
        if (bottomBar != null) bottomBar.setVisibility(View.VISIBLE);
        AppLog.d(this, "CROP editor close");
    }

    private void showSaveCroppedDialog(RectF normalizedCrop) {
        if (normalizedCrop == null || currentUri == null) return;
        final RectF crop = new RectF(normalizedCrop);
        final int panel = Color.rgb(58, 51, 51);
        LinearLayout content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(dp(22), dp(8), dp(22), dp(8));
        content.setBackgroundColor(panel);

        TextView pathValue = new TextView(this);
        pathValue.setTextColor(Color.WHITE); pathValue.setTextSize(14); pathValue.setPadding(dp(4),dp(2),dp(4),dp(12));
        content.addView(pathValue, new LinearLayout.LayoutParams(-1,-2));

        EditText nameInput = makeSaveField("ファイル名", baseNameOf(currentName));
        content.addView(nameInput, new LinearLayout.LayoutParams(-1, dp(58)));

        OverwriteToggleView overwriteToggle = new OverwriteToggleView();
        LinearLayout overwriteRow = makeOverwriteRow(overwriteToggle);
        LinearLayout.LayoutParams orp = new LinearLayout.LayoutParams(-1, dp(46)); orp.topMargin=dp(8);
        content.addView(overwriteRow,orp);
        Runnable refreshPath = () -> pathValue.setText("保存先\n" + editDestinationDescription(overwriteToggle.isChecked()));
        overwriteToggle.setOnCheckedChanged(refreshPath); refreshPath.run();

        AlertDialog dialog = new AlertDialog.Builder(this).setTitle("トリミング画像を保存").setView(content)
                .setNeutralButton("保存せず共有", null).setNegativeButton("キャンセル", null).setPositiveButton("OK", null).create();
        prepareDialogBeforeShow(dialog,panel);
        dialog.setOnShowListener(v -> {
            int titleId=getResources().getIdentifier("alertTitle","id","android"); TextView title=dialog.findViewById(titleId); if(title!=null)title.setTextColor(Color.WHITE);
            styleDialogButton(dialog,AlertDialog.BUTTON_NEUTRAL,Color.WHITE,panel); styleDialogButton(dialog,AlertDialog.BUTTON_NEGATIVE,Color.WHITE,panel); styleDialogButton(dialog,AlertDialog.BUTTON_POSITIVE,Color.WHITE,panel);
            dialog.getButton(AlertDialog.BUTTON_NEUTRAL).setOnClickListener(v2->{dialog.dismiss();shareCroppedCurrent(crop);});
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v2->{
                String base=nameInput.getText().toString().trim(); if(base.isEmpty()){nameInput.setError("ファイル名を入力してください");return;}
                dialog.dismiss(); saveCroppedCurrent(base,crop,overwriteToggle.isChecked());
            });
        });
        dialog.show();
        AppLog.d(this,"CROP save dialog crop="+crop+" destination="+SavePrefs.directory(this));
    }

    private Bitmap decodeCroppedBitmap(Uri uri, float degrees, RectF normalizedCrop) throws IOException {
        ImageDecoder.Source source = createImageSource(uri);
        Bitmap decoded = ImageDecoder.decodeBitmap(source, (decoder, info, src) ->
                decoder.setAllocator(ImageDecoder.ALLOCATOR_SOFTWARE));
        Bitmap rotated = decoded;
        float normalized = degrees % 360f;
        if (normalized < 0f) normalized += 360f;
        if (Math.abs(normalized) > 0.0001f && Math.abs(normalized - 360f) > 0.0001f) {
            Matrix matrix = new Matrix();
            matrix.postRotate(normalized);
            rotated = Bitmap.createBitmap(decoded, 0, 0, decoded.getWidth(), decoded.getHeight(), matrix, true);
        }
        RectF n = normalizedCrop == null ? new RectF(0f, 0f, 1f, 1f) : new RectF(normalizedCrop);
        n.left = Math.max(0f, Math.min(1f, n.left));
        n.top = Math.max(0f, Math.min(1f, n.top));
        n.right = Math.max(n.left, Math.min(1f, n.right));
        n.bottom = Math.max(n.top, Math.min(1f, n.bottom));
        int left = Math.max(0, Math.min(rotated.getWidth() - 1, Math.round(n.left * rotated.getWidth())));
        int top = Math.max(0, Math.min(rotated.getHeight() - 1, Math.round(n.top * rotated.getHeight())));
        int right = Math.max(left + 1, Math.min(rotated.getWidth(), Math.round(n.right * rotated.getWidth())));
        int bottom = Math.max(top + 1, Math.min(rotated.getHeight(), Math.round(n.bottom * rotated.getHeight())));
        return Bitmap.createBitmap(rotated, left, top, right - left, bottom - top);
    }

    private void shareCroppedCurrent(RectF normalizedCrop) {
        final Uri sourceUri = currentUri;
        final String sourceName = currentName;
        final float degrees = pendingRotationDegrees + cropFineRotationDegrees;
        if (sourceUri == null) return;
        Toast.makeText(this, "トリミング画像を準備しています", Toast.LENGTH_SHORT).show();
        safeExecute(editExecutor, () -> {
            try {
                Bitmap bitmap = decodeCroppedBitmap(sourceUri, degrees, normalizedCrop);
                OutputSpec spec = outputSpec(extensionOf(sourceName));
                File dir = new File(getCacheDir(), "shared-edits");
                if (!dir.exists() && !dir.mkdirs()) throw new IOException("Cannot create share cache");
                String base = baseNameOf(sourceName);
                File out = new File(dir, sanitizeFileName(base) + "_cropped." + spec.extension);
                try (OutputStream os = new FileOutputStream(out)) {
                    writeBitmap(bitmap, spec, os);
                }
                Uri shareUri = androidx.core.content.FileProvider.getUriForFile(
                        this, getPackageName() + ".fileprovider", out);
                mainHandler.post(() -> {
                    exitCropEditor();
                    try {
                        Intent share = new Intent(Intent.ACTION_SEND);
                        share.setType(spec.mime);
                        share.putExtra(Intent.EXTRA_STREAM, shareUri);
                        share.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                        startActivity(Intent.createChooser(share, "保存せず共有"));
                    } catch (Throwable e) {
                        AppLog.d(this, "CROP share chooser error " + e);
                        Toast.makeText(this, "共有できませんでした", Toast.LENGTH_SHORT).show();
                    }
                });
            } catch (Throwable e) {
                AppLog.d(this, "CROP share error " + e);
                mainHandler.post(() -> Toast.makeText(this, "トリミング画像を共有できませんでした", Toast.LENGTH_SHORT).show());
            }
        });
    }

    private void saveCroppedCurrent(String base, RectF normalizedCrop, boolean overwriteSource) {
        final Uri sourceUri=currentUri; final String sourceName=currentName;
        final float degrees=pendingRotationDegrees+cropFineRotationDegrees;
        if(sourceUri==null)return;
        Toast.makeText(this,"保存しています",Toast.LENGTH_SHORT).show();
        safeExecute(editExecutor,()->{
            try {
                Bitmap bitmap=decodeCroppedBitmap(sourceUri,degrees,normalizedCrop);
                String ext=editableSourceExtension(sourceName);
                EditSaveResult result=saveEditedBitmap(bitmap,base,ext,sourceUri,sourceName,overwriteSource);
                mainHandler.post(()->{
                    exitCropEditor(); currentUri=result.uri; currentName=result.name; currentMime=result.mime; titleView.setText(currentName);
                    pendingRotationDegrees=0; pendingRotationBitmap=null; rotationGeneration.incrementAndGet(); rotationAnimating=false;
                    if(saveRotationButton!=null)saveRotationButton.setVisibility(View.GONE);
                    openImageAsync(result.uri,false,0); AppLog.d(this,"CROP saved uri="+result.uri+" name="+result.name+" overwrite="+overwriteSource);
                    Toast.makeText(this,"保存しました",Toast.LENGTH_SHORT).show(); discoverSiblingImagesAsync();
                });
            } catch(Throwable e){ AppLog.d(this,"CROP save error "+e); mainHandler.post(()->Toast.makeText(this,"保存できませんでした",Toast.LENGTH_LONG).show()); }
        });
    }

    private void showRotatePopup(View anchor) {
        if (currentUri == null || isPdf(currentMime, currentUri)) {
            Toast.makeText(this, "このファイルは回転できません", Toast.LENGTH_SHORT).show();
            return;
        }
        dismissRotationPopup();
        final int panel = Color.rgb(58, 51, 51);
        LinearLayout list = new LinearLayout(this);
        list.setOrientation(LinearLayout.VERTICAL);
        list.setPadding(dp(6), dp(6), dp(6), dp(6));
        list.setBackground(makeRoundedPanel(panel));

        PopupWindow popup = new PopupWindow(list, dp(190), -2, true);
        rotationPopup = popup;
        popup.setBackgroundDrawable(makeRoundedPanel(panel));
        popup.setOutsideTouchable(true);
        popup.setTouchable(true);
        popup.setFocusable(true);
        popup.setElevation(dp(8));
        // Consume outside taps so they only dismiss this menu. If the outside tap lands on the
        // visible top-bar check icon, treat that same tap as rotation confirmation.
        popup.setTouchInterceptor((v, event) -> {
            if (event.getAction() != MotionEvent.ACTION_OUTSIDE) return false;
            boolean confirm = false;
            View check = saveRotationButton;
            if (check != null && check.getVisibility() == View.VISIBLE) {
                int[] loc = new int[2];
                check.getLocationOnScreen(loc);
                float rx = event.getRawX();
                float ry = event.getRawY();
                confirm = rx >= loc[0] && rx < loc[0] + check.getWidth()
                        && ry >= loc[1] && ry < loc[1] + check.getHeight();
            }
            dismissRotationPopup();
            if (confirm) mainHandler.post(this::showSaveRotatedDialog);
            return true;
        });
        popup.setOnDismissListener(() -> {
            if (rotationPopup == popup) rotationPopup = null;
            AppLog.d(this, "ROTATE menu dismissed");
        });
        addRotatePopupItem(list, "右に回転", 90);
        addRotatePopupItem(list, "左に回転", -90);
        addRotatePopupItem(list, "180度回転", 180);
        AppLog.d(this, "ROTATE menu show persistent");
        popup.showAsDropDown(anchor, -dp(142), -dp(6));
    }

    private void dismissRotationPopup() {
        PopupWindow popup = rotationPopup;
        rotationPopup = null;
        if (popup != null && popup.isShowing()) popup.dismiss();
    }

    private void addRotatePopupItem(LinearLayout list, String text, int degrees) {
        TextView row = new TextView(this);
        row.setText(text);
        row.setTextColor(Color.WHITE);
        row.setTextSize(18);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(dp(18), 0, dp(18), 0);
        // Keep this popup open while rotating so several rotations can be applied in succession.
        row.setOnClickListener(v -> applyRotationPreview(degrees));
        list.addView(row, new LinearLayout.LayoutParams(-1, dp(54)));
    }

    private void applyRotationPreview(int deltaDegrees) {
        if (currentUri == null || pageAnimating || rotationAnimating) return;
        final int next = ((pendingRotationDegrees + deltaDegrees) % 360 + 360) % 360;
        final int generation = rotationGeneration.incrementAndGet();
        final Uri target = currentUri;
        final float zoomMultiplier = imageView.getViewerZoomMultiplier();
        final float currentFit = imageView.getViewerFitScale();
        final float targetFit = imageView.fitScaleForViewerRotation(next);
        final float targetViewScale = currentFit > 0f && Float.isFinite(targetFit)
                ? Math.max(0.05f, targetFit / currentFit) : 1f;

        pendingRotationDegrees = next;
        pendingRotationBitmap = null;
        if (saveRotationButton != null) saveRotationButton.setVisibility(next == 0 ? View.GONE : View.VISIBLE);
        AppLog.d(this, "ROTATE smooth start delta=" + deltaDegrees + " target=" + next +
                " fit=" + currentFit + "->" + targetFit + " viewScale=" + targetViewScale);

        rotationAnimating = true;
        imageView.animate().cancel();
        imageView.setPivotX(imageView.getWidth() / 2f);
        imageView.setPivotY(imageView.getHeight() / 2f);
        imageView.setLayerType(View.LAYER_TYPE_HARDWARE, null);
        imageView.animate()
                .rotationBy(deltaDegrees)
                .scaleX(targetViewScale)
                .scaleY(targetViewScale)
                .setDuration(Math.abs(deltaDegrees) == 180 ? 300L : 240L)
                .setInterpolator(new PathInterpolator(0.20f, 0.0f, 0.0f, 1.0f))
                .withEndAction(() -> {
                    if (generation != rotationGeneration.get() || currentUri == null || !target.equals(currentUri)) {
                        rotationAnimating = false;
                        imageView.setRotation(0f);
                        imageView.setScaleX(1f);
                        imageView.setScaleY(1f);
                        imageView.setLayerType(View.LAYER_TYPE_NONE, null);
                        return;
                    }
                    // Commit the rotated FIT matrix in the same UI callback in which the temporary
                    // view transform returns to identity. There is no re-decoded drawable swap, so
                    // the last animation frame and the steady state have the same geometry.
                    imageView.commitViewerRotation(next, zoomMultiplier);
                    imageView.setRotation(0f);
                    imageView.setScaleX(1f);
                    imageView.setScaleY(1f);
                    imageView.setLayerType(View.LAYER_TYPE_NONE, null);
                    rotationAnimating = false;
                    AppLog.d(this, "ROTATE smooth committed degrees=" + next);
                })
                .start();
    }

    private Bitmap decodeRotatedBitmap(Uri uri, int degrees) throws IOException {
        ImageDecoder.Source source = createImageSource(uri);
        Bitmap sourceBitmap = ImageDecoder.decodeBitmap(source, (decoder, info, src) ->
                decoder.setAllocator(ImageDecoder.ALLOCATOR_SOFTWARE));
        if (degrees % 360 == 0) return sourceBitmap;
        Matrix matrix = new Matrix();
        matrix.postRotate(degrees);
        return Bitmap.createBitmap(sourceBitmap, 0, 0, sourceBitmap.getWidth(), sourceBitmap.getHeight(), matrix, true);
    }

    private void clearPendingRotationState() {
        pendingRotationDegrees = 0;
        pendingRotationBitmap = null;
        rotationGeneration.incrementAndGet();
        rotationAnimating = false;
        if (imageView != null) {
            imageView.animate().cancel();
            imageView.setRotation(0f);
            imageView.setScaleX(1f);
            imageView.setScaleY(1f);
            imageView.setLayerType(View.LAYER_TYPE_NONE, null);
            imageView.commitViewerRotation(0, 1f);
        }
        if (saveRotationButton != null) saveRotationButton.setVisibility(View.GONE);
    }

    private void showSaveRotatedDialog() {
        if (pendingRotationDegrees == 0) return;
        final int panel = Color.rgb(58, 51, 51);
        final int outline = Color.rgb(160, 160, 170);
        String sourcePath = inferAbsolutePathFromAnyUri(currentUri);
        String parentPath = sourcePath == null ? "元ファイルと同じフォルダ" : new File(sourcePath).getParent();
        String defaultBase = baseNameOf(currentName);
        String defaultExt = extensionOf(currentName);
        if (defaultExt.isEmpty()) defaultExt = "jpg";

        LinearLayout content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(dp(22), dp(8), dp(22), dp(8));
        content.setBackgroundColor(panel);

        TextView pathLabel = new TextView(this);
        pathLabel.setText("パス"); pathLabel.setTextColor(outline); pathLabel.setTextSize(14);
        content.addView(pathLabel);
        TextView pathValue = new TextView(this);
        pathValue.setText(parentPath); pathValue.setTextColor(Color.WHITE); pathValue.setTextSize(16);
        pathValue.setPadding(dp(12), dp(10), dp(12), dp(14));
        content.addView(pathValue, new LinearLayout.LayoutParams(-1, -2));

        EditText nameInput = makeSaveField("ファイル名", defaultBase);
        content.addView(nameInput, new LinearLayout.LayoutParams(-1, dp(58)));
        EditText extInput = makeSaveField("拡張子", defaultExt);
        LinearLayout.LayoutParams ep = new LinearLayout.LayoutParams(-1, dp(58)); ep.topMargin = dp(10);
        content.addView(extInput, ep);

        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle("名前を付けて保存")
                .setView(content)
                .setNeutralButton("保存せず共有", null)
                .setNegativeButton("キャンセル", null)
                .setPositiveButton("OK", null)
                .create();
        prepareDialogBeforeShow(dialog, panel);
        dialog.setOnShowListener(v -> {
            int titleId = getResources().getIdentifier("alertTitle", "id", "android");
            TextView title = dialog.findViewById(titleId);
            if (title != null) title.setTextColor(Color.WHITE);
            styleDialogButton(dialog, AlertDialog.BUTTON_NEUTRAL, Color.WHITE, panel);
            styleDialogButton(dialog, AlertDialog.BUTTON_NEGATIVE, Color.WHITE, panel);
            styleDialogButton(dialog, AlertDialog.BUTTON_POSITIVE, Color.WHITE, panel);
            dialog.getButton(AlertDialog.BUTTON_NEUTRAL).setOnClickListener(v2 -> {
                dialog.dismiss();
                shareRotatedCurrent();
            });
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v2 -> {
                String base = nameInput.getText().toString().trim();
                String ext = extInput.getText().toString().trim().toLowerCase(Locale.ROOT).replace(".", "");
                if (base.isEmpty()) { nameInput.setError("ファイル名を入力してください"); return; }
                if (!isWritableRotationExtension(ext)) {
                    extInput.setError("jpg / jpeg / png / webp を指定してください");
                    return;
                }
                dialog.dismiss();
                saveRotatedCurrent(base, ext);
            });
        });
        dialog.show();
    }

    private EditText makeSaveField(String hint, String value) {
        EditText field = new EditText(this);
        field.setHint(hint);
        field.setText(value);
        field.setTextColor(Color.WHITE);
        field.setHintTextColor(Color.rgb(165, 165, 175));
        field.setTextSize(17);
        field.setSingleLine(true);
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(Color.TRANSPARENT);
        bg.setStroke(dp(1), Color.rgb(160, 160, 170));
        bg.setCornerRadius(dp(10));
        field.setBackground(bg);
        field.setPadding(dp(12), 0, dp(12), 0);
        return field;
    }

    private void saveRotatedCurrent(String base, String ext) {
        final int degrees = pendingRotationDegrees;
        final Bitmap ready = pendingRotationBitmap;
        final Uri sourceUri = currentUri;
        if (degrees == 0 || sourceUri == null) return;
        Toast.makeText(this, "保存しています", Toast.LENGTH_SHORT).show();
        safeExecute(editExecutor, () -> {
            try {
                Bitmap bitmap = ready != null ? ready : decodeRotatedBitmap(sourceUri, degrees);
                OutputSpec spec = outputSpec(ext);
                String requestedName = sanitizeFileName(base) + "." + spec.extension;
                Uri saved = saveBitmapToSourceFolder(bitmap, requestedName, spec, sourceUri);
                if (saved == null) throw new IOException("No writable destination");
                mainHandler.post(() -> {
                    currentUri = saved;
                    currentName = requestedName;
                    currentMime = spec.mime;
                    titleView.setText(currentName);
                    // The saved file already contains rotated pixels. Keep the current rotated
                    // matrix on-screen until that new file is decoded, then hand off directly to
                    // an identity/FIT matrix so save does not visually snap back to the original.
                    pendingRotationDegrees = 0;
                    pendingRotationBitmap = null;
                    rotationGeneration.incrementAndGet();
                    rotationAnimating = false;
                    if (saveRotationButton != null) saveRotationButton.setVisibility(View.GONE);
                    openImageAsync(saved, false, 0);
                    AppLog.d(this, "ROTATE saved uri=" + saved + " name=" + requestedName);
                    Toast.makeText(this, "保存しました", Toast.LENGTH_SHORT).show();
                    discoverSiblingImagesAsync();
                });
            } catch (Throwable e) {
                AppLog.d(this, "ROTATE save error " + e);
                mainHandler.post(() -> Toast.makeText(this, "保存できませんでした", Toast.LENGTH_LONG).show());
            }
        });
    }

    private LinearLayout makeOverwriteRow(OverwriteToggleView toggle) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setClickable(true);
        row.addView(toggle, new LinearLayout.LayoutParams(dp(46), dp(28)));
        TextView text = new TextView(this);
        text.setText("上書き許可"); text.setTextColor(Color.WHITE); text.setTextSize(15); text.setGravity(Gravity.CENTER_VERTICAL);
        LinearLayout.LayoutParams tlp = new LinearLayout.LayoutParams(-2, dp(36)); tlp.leftMargin = dp(8);
        row.addView(text, tlp);
        row.setOnClickListener(v -> toggle.setChecked(!toggle.isChecked()));
        return row;
    }

    private String editDestinationDescription(boolean overwriteSource) {
        if (!overwriteSource) return SavePrefs.directory(this).getAbsolutePath();
        String sourcePath = inferAbsolutePathFromAnyUri(currentUri);
        if (sourcePath != null) {
            File parent = new File(sourcePath).getParentFile();
            if (parent != null) return parent.getAbsolutePath() + "  （上書き許可）";
        }
        return "元ファイル  （上書き許可）";
    }

    private static class EditSaveResult {
        final Uri uri; final String name; final String mime;
        EditSaveResult(Uri uri, String name, String mime) { this.uri=uri; this.name=name; this.mime=mime; }
    }

    private EditSaveResult saveEditedBitmap(Bitmap bitmap, String requestedBase, String ext, Uri sourceUri,
                                             String sourceName, boolean overwriteSource) throws IOException {
        OutputSpec spec = outputSpec(ext);
        String base = sanitizeFileName(requestedBase);
        File sourcePathFile = null;
        String sourcePath = inferAbsolutePathFromAnyUri(sourceUri);
        if (sourcePath != null) sourcePathFile = new File(sourcePath);
        File targetDir;
        if (overwriteSource) {
            if (base.equals(baseNameOf(sourceName)) && spec.extension.equalsIgnoreCase(extensionOf(sourceName))) {
                try (OutputStream os = getContentResolver().openOutputStream(sourceUri, "rwt")) {
                    if (os != null) {
                        writeBitmap(bitmap, spec, os);
                        AppLog.d(this, "EDIT backend=source-uri overwrite uri=" + sourceUri);
                        return new EditSaveResult(sourceUri, base + "." + spec.extension, spec.mime);
                    }
                } catch (Throwable directUriFailure) {
                    AppLog.d(this, "EDIT source-uri overwrite failed " + directUriFailure);
                }
            }
            targetDir = sourcePathFile == null ? null : sourcePathFile.getParentFile();
            if (targetDir == null) throw new IOException("Original folder is unavailable");
        } else {
            targetDir = SavePrefs.directory(this);
        }

        String name = base + "." + spec.extension;
        if (!overwriteSource) name = nextAvailableEditName(targetDir, base, spec.extension);
        File destination = new File(targetDir, name);
        Uri out = saveBitmapToDirectory(bitmap, destination, spec, overwriteSource);
        if (out == null) throw new IOException("No writable destination");
        return new EditSaveResult(out, name, spec.mime);
    }

    private String nextAvailableEditName(File dir, String base, String ext) {
        String first = base + "." + ext;
        if (!editDestinationExists(dir, first)) return first;
        for (int i=1; i<1000000; i++) {
            String suffix = i < 1000 ? String.format(Locale.ROOT, "_%03d", i) : "_" + i;
            String candidate = base + suffix + "." + ext;
            if (!editDestinationExists(dir, candidate)) return candidate;
        }
        return base + "_" + System.currentTimeMillis() + "." + ext;
    }

    private boolean editDestinationExists(File dir, String name) {
        if (dir == null || name == null) return false;
        try { if (new File(dir,name).exists()) return true; } catch (Throwable ignored) { }
        try {
            StorageTarget target = storageTargetForPath(new File(dir,name).getAbsolutePath());
            if (target != null && Build.VERSION.SDK_INT >= 29) {
                Uri collection = mediaCollectionForEditedTarget(target);
                try (Cursor c = getContentResolver().query(collection, new String[]{MediaStore.MediaColumns._ID},
                        MediaStore.MediaColumns.RELATIVE_PATH + "=? AND " + MediaStore.MediaColumns.DISPLAY_NAME + "=? COLLATE NOCASE",
                        new String[]{target.relativeDirectory,name}, null)) {
                    if (c != null && c.moveToFirst()) return true;
                }
            }
        } catch (Throwable ignored) { }
        try {
            Uri tree = findPersistedSafTreeForPath(dir);
            if (tree != null) {
                Uri parent = safDocumentUriForPath(tree, dir);
                if (parent != null && findSafChild(tree,parent,name) != null) return true;
            }
        } catch (Throwable ignored) { }
        return false;
    }

    private Uri saveBitmapToDirectory(Bitmap bitmap, File destination, OutputSpec spec, boolean overwrite) throws IOException {
        File parent = destination == null ? null : destination.getParentFile();
        if (parent == null) throw new IOException("Missing destination directory");
        Throwable mediaFailure = null;
        if (Build.VERSION.SDK_INT >= 29) {
            StorageTarget target = storageTargetForPath(destination.getAbsolutePath());
            if (target != null) {
                try { return saveBitmapToMediaStore(bitmap,destination,target,spec,overwrite); }
                catch (Throwable e) { mediaFailure=e; AppLog.d(this,"EDIT MediaStore failed destination="+destination+" "+e); }
            }
        }
        Uri tree = findPersistedSafTreeForPath(parent);
        if (tree != null) {
            try { return saveBitmapToSaf(bitmap,destination,tree,spec,overwrite); }
            catch (Throwable e) { AppLog.d(this,"EDIT SAF failed destination="+destination+" "+e); }
        }
        try {
            if (!parent.exists() && !parent.mkdirs()) throw new IOException("Cannot create destination folder");
            if (destination.exists() && !overwrite) throw new IOException("Destination exists");
            try (OutputStream os = new FileOutputStream(destination,false)) { writeBitmap(bitmap,spec,os); }
            AppLog.d(this,"EDIT backend=direct destination="+destination);
            return Uri.fromFile(destination);
        } catch (Throwable directFailure) {
            IOException io = new IOException("No writable edit backend for " + destination, directFailure);
            if (mediaFailure != null) io.addSuppressed(mediaFailure);
            throw io;
        }
    }

    private Uri mediaCollectionForEditedTarget(StorageTarget target) {
        String rel = target.relativeDirectory == null ? "" : target.relativeDirectory.toLowerCase(Locale.ROOT);
        if (Build.VERSION.SDK_INT >= 29 && (rel.startsWith("download/") || rel.equals("download/")))
            return MediaStore.Downloads.getContentUri(target.volumeName);
        if (rel.startsWith("pictures/") || rel.equals("pictures/") || rel.startsWith("dcim/") || rel.equals("dcim/"))
            return MediaStore.Images.Media.getContentUri(target.volumeName);
        return MediaStore.Files.getContentUri(target.volumeName);
    }

    private Uri saveBitmapToMediaStore(Bitmap bitmap, File destination, StorageTarget target, OutputSpec spec,
                                       boolean overwrite) throws IOException {
        Uri collection = mediaCollectionForEditedTarget(target);
        if (overwrite) {
            try { getContentResolver().delete(collection,
                    MediaStore.MediaColumns.RELATIVE_PATH + "=? AND " + MediaStore.MediaColumns.DISPLAY_NAME + "=? COLLATE NOCASE",
                    new String[]{target.relativeDirectory,destination.getName()}); }
            catch (Throwable e) { AppLog.d(this,"EDIT overwrite delete miss "+e); }
        }
        ContentValues values = new ContentValues();
        values.put(MediaStore.MediaColumns.DISPLAY_NAME,destination.getName());
        values.put(MediaStore.MediaColumns.MIME_TYPE,spec.mime);
        values.put(MediaStore.MediaColumns.RELATIVE_PATH,target.relativeDirectory);
        values.put(MediaStore.MediaColumns.IS_PENDING,1);
        Uri out = getContentResolver().insert(collection,values);
        if (out == null) throw new IOException("MediaStore insert failed");
        try {
            try (OutputStream os=getContentResolver().openOutputStream(out,"w")) {
                if(os==null)throw new IOException("MediaStore output unavailable");
                writeBitmap(bitmap,spec,os);
            }
            ContentValues done=new ContentValues(); done.put(MediaStore.MediaColumns.IS_PENDING,0); getContentResolver().update(out,done,null,null);
            AppLog.d(this,"EDIT backend=mediastore destination="+destination+" uri="+out);
            return out;
        } catch(Throwable e) {
            try{getContentResolver().delete(out,null,null);}catch(Throwable ignored){}
            if(e instanceof IOException)throw (IOException)e; throw new IOException(e);
        }
    }

    private Uri saveBitmapToSaf(Bitmap bitmap, File destination, Uri tree, OutputSpec spec, boolean overwrite) throws IOException {
        File parent=destination.getParentFile();
        Uri parentUri=safDocumentUriForPath(tree,parent);
        if(parentUri==null)throw new IOException("SAF destination outside grant");
        Uri existing=findSafChild(tree,parentUri,destination.getName());
        if(existing!=null && !overwrite)throw new IOException("SAF destination exists");
        Uri out=existing; boolean created=false;
        if(out==null){
            try{out=DocumentsContract.createDocument(getContentResolver(),parentUri,spec.mime,destination.getName());}
            catch(Throwable e){throw new IOException("SAF create failed",e);}
            if(out==null)throw new IOException("SAF create returned null"); created=true;
        }
        try{
            OutputStream raw;
            try{raw=getContentResolver().openOutputStream(out,overwrite?"rwt":"w");}catch(Throwable e){raw=getContentResolver().openOutputStream(out,"w");}
            if(raw==null)throw new IOException("SAF output unavailable");
            try(OutputStream os=raw){writeBitmap(bitmap,spec,os);}
            AppLog.d(this,"EDIT backend=saf destination="+destination+" tree="+tree);
            return out;
        } catch(Throwable e){
            if(created)try{DocumentsContract.deleteDocument(getContentResolver(),out);}catch(Throwable ignored){}
            if(e instanceof IOException)throw (IOException)e; throw new IOException(e);
        }
    }

    private Uri saveBitmapToSourceFolder(Bitmap bitmap, String fileName, OutputSpec spec, Uri sourceUri) throws IOException {
        String sourcePath = inferAbsolutePathFromAnyUri(sourceUri);
        if (Build.VERSION.SDK_INT >= 29 && sourcePath != null) {
            StorageTarget target = storageTargetForPath(sourcePath);
            if (target != null) {
                ContentValues values = new ContentValues();
                values.put(MediaStore.MediaColumns.DISPLAY_NAME, fileName);
                values.put(MediaStore.MediaColumns.MIME_TYPE, spec.mime);
                values.put(MediaStore.MediaColumns.RELATIVE_PATH, target.relativeDirectory);
                values.put(MediaStore.MediaColumns.IS_PENDING, 1);
                Uri collection = mediaCollectionForEditedTarget(target);
                Uri out = getContentResolver().insert(collection, values);
                if (out != null) {
                    try {
                        try (OutputStream os = getContentResolver().openOutputStream(out, "w")) {
                            if (os == null) throw new IOException("Bitmap output unavailable");
                            writeBitmap(bitmap, spec, os);
                        }
                        ContentValues done = new ContentValues();
                        done.put(MediaStore.MediaColumns.IS_PENDING, 0);
                        getContentResolver().update(out, done, null, null);
                        return out;
                    } catch (Throwable e) {
                        try { getContentResolver().delete(out, null, null); } catch (Throwable ignored) { }
                        if (e instanceof IOException) throw (IOException)e;
                        throw new IOException(e);
                    }
                }
            }
        }
        if (sourcePath != null) {
            File parent = new File(sourcePath).getParentFile();
            if (parent != null && parent.canWrite()) {
                File out = uniqueFile(parent, fileName);
                try (OutputStream os = new FileOutputStream(out)) {
                    writeBitmap(bitmap, spec, os);
                }
                return Uri.fromFile(out);
            }
        }
        throw new IOException("Source folder is not writable");
    }

    private StorageTarget storageTargetForPath(String absolutePath) {
        if (absolutePath == null) return null;
        String normalized = absolutePath.replace('\\', '/');
        String primary = "/storage/emulated/0/";
        if (normalized.startsWith(primary)) {
            String tail = normalized.substring(primary.length());
            int slash = tail.lastIndexOf('/');
            String rel = slash >= 0 ? tail.substring(0, slash + 1) : "Pictures/";
            return new StorageTarget(MediaStore.VOLUME_EXTERNAL_PRIMARY, rel);
        }
        String prefix = "/storage/";
        if (normalized.startsWith(prefix)) {
            String tail = normalized.substring(prefix.length());
            int firstSlash = tail.indexOf('/');
            if (firstSlash > 0) {
                String volumeId = tail.substring(0, firstSlash);
                String fileTail = tail.substring(firstSlash + 1);
                int slash = fileTail.lastIndexOf('/');
                String rel = slash >= 0 ? fileTail.substring(0, slash + 1) : "Pictures/";
                if (!"emulated".equalsIgnoreCase(volumeId) && !"self".equalsIgnoreCase(volumeId)) {
                    String volumeName = volumeId.toLowerCase(Locale.ROOT);
                    if (Build.VERSION.SDK_INT >= 29) {
                        try {
                            for (String available : MediaStore.getExternalVolumeNames(this)) {
                                if (available != null && available.equalsIgnoreCase(volumeId)) {
                                    volumeName = available;
                                    break;
                                }
                            }
                        } catch (Throwable ignored) { }
                    }
                    return new StorageTarget(volumeName, rel);
                }
            }
        }
        return null;
    }

    private File uniqueFile(File parent, String fileName) {
        File candidate = new File(parent, fileName);
        if (!candidate.exists()) return candidate;
        String base = baseNameOf(fileName); String ext = extensionOf(fileName);
        for (int i = 1; i < 10000; i++) {
            String numbered = ext.isEmpty() ? base + " (" + i + ")" : base + " (" + i + ")." + ext;
            File f = new File(parent, numbered);
            if (!f.exists()) return f;
        }
        return candidate;
    }

    private boolean isWritableRotationExtension(String ext) {
        return "jpg".equals(ext) || "jpeg".equals(ext) || "png".equals(ext) || "webp".equals(ext);
    }

    private boolean isWritableEditExtension(String ext) {
        return "jpg".equals(ext) || "jpeg".equals(ext) || "png".equals(ext) || "webp".equals(ext) || "gif".equals(ext);
    }

    private String editableSourceExtension(String name) throws IOException {
        String ext = extensionOf(name);
        if (ext.isEmpty()) ext = extensionFromMime(currentMime);
        if (!isWritableEditExtension(ext)) throw new IOException("Unsupported edit format: " + ext);
        return ext;
    }

    private String extensionOf(String name) {
        if (name == null) return "";
        int dot = name.lastIndexOf('.');
        return dot >= 0 && dot < name.length() - 1 ? name.substring(dot + 1).toLowerCase(Locale.ROOT) : "";
    }

    private String baseNameOf(String name) {
        if (name == null || name.isEmpty()) return "image";
        int dot = name.lastIndexOf('.');
        return dot > 0 ? name.substring(0, dot) : name;
    }

    private String sanitizeFileName(String name) {
        String clean = name == null ? "image" : name.replaceAll("[\\/:*?\"<>|]", "_").trim();
        return clean.isEmpty() ? "image" : clean;
    }

    private OutputSpec outputSpec(String extension) {
        String ext = extension == null ? "jpg" : extension.toLowerCase(Locale.ROOT);
        if ("jpeg".equals(ext)) return new OutputSpec(Bitmap.CompressFormat.JPEG, 95, "jpeg", "image/jpeg", false);
        if ("jpg".equals(ext)) return new OutputSpec(Bitmap.CompressFormat.JPEG, 95, "jpg", "image/jpeg", false);
        if ("png".equals(ext)) return new OutputSpec(Bitmap.CompressFormat.PNG, 100, "png", "image/png", false);
        if ("gif".equals(ext)) return new OutputSpec(null, 100, "gif", "image/gif", true);
        if ("webp".equals(ext)) {
            Bitmap.CompressFormat fmt = Build.VERSION.SDK_INT >= 30 ? Bitmap.CompressFormat.WEBP_LOSSLESS : Bitmap.CompressFormat.WEBP;
            return new OutputSpec(fmt, 100, "webp", "image/webp", false);
        }
        return new OutputSpec(Bitmap.CompressFormat.PNG, 100, "png", "image/png", false);
    }

    private void writeBitmap(Bitmap bitmap, OutputSpec spec, OutputStream os) throws IOException {
        if (bitmap == null || spec == null || os == null) throw new IOException("Bitmap output unavailable");
        if (spec.gif) { StaticGifEncoder.encode(bitmap, os); return; }
        if (spec.format == null || !bitmap.compress(spec.format, spec.quality, os)) throw new IOException("Bitmap compress failed");
    }

    private static class OutputSpec {
        final Bitmap.CompressFormat format; final int quality; final String extension; final String mime; final boolean gif;
        OutputSpec(Bitmap.CompressFormat format, int quality, String extension, String mime, boolean gif) {
            this.format = format; this.quality = quality; this.extension = extension; this.mime = mime; this.gif = gif;
        }
    }

    private static class StorageTarget {
        final String volumeName; final String relativeDirectory;
        StorageTarget(String volumeName, String relativeDirectory) {
            this.volumeName = volumeName; this.relativeDirectory = relativeDirectory;
        }
    }

    private void showCurrentUri(boolean fromSwipe, int direction) {
        closePdf();
        updateCurrentFormatCapabilities();
        titleView.setText(currentName == null ? resolveDisplayName(currentUri) : currentName);
        if (isPdf(currentMime, currentUri)) {
            openPdf(currentUri);
        } else {
            openImageAsync(currentUri, fromSwipe, direction);
            updatePositionLabel();
        }
    }

    private ImageDecoder.Source createImageSource(Uri uri) throws IOException {
        if (uri != null && "file".equalsIgnoreCase(uri.getScheme())) {
            String path = uri.getPath();
            if (path == null) throw new IOException("Missing file path");
            return ImageDecoder.createSource(new File(path));
        }
        return ImageDecoder.createSource(getContentResolver(), uri);
    }

    private void openImageAsync(Uri uri, boolean fromSwipe, int direction) {
        final int generation = decodeGeneration.incrementAndGet();
        final long begin = SystemClock.elapsedRealtime();
        AppLog.d(this, "IMAGE decode queued +" + elapsed() + "ms uri=" + uri);
        decodeExecutor.execute(() -> {
            try {
                ImageDecoder.Source source = createImageSource(uri);
                Drawable drawable = ImageDecoder.decodeDrawable(source, (decoder, info, src) -> {
                    // Keep ImageDecoder's default allocator/memory policy. Forcing software + LOW_RAM
                    // made adjacent full-resolution images substantially slower to become swipe-ready.
                });
                long decodeMs = SystemClock.elapsedRealtime() - begin;
                mainHandler.post(() -> {
                    if (generation != decodeGeneration.get() || isFinishing()) return;
                    imageView.setImageForViewer(drawable);
                    if (fromSwipe) {
                        float startX = direction > 0 ? imageView.getWidth() * 0.18f : -imageView.getWidth() * 0.18f;
                        imageView.setTranslationX(startX);
                        imageView.setAlpha(0.82f);
                        imageView.animate().translationX(0f).alpha(1f).setDuration(130).withEndAction(() -> pageAnimating = false).start();
                    } else pageAnimating = false;
                    if (drawable instanceof AnimatedImageDrawable) ((AnimatedImageDrawable) drawable).start();
                    AppLog.d(this, "IMAGE first paint +" + elapsed() + "ms decode=" + decodeMs + "ms class=" + drawable.getClass().getSimpleName());
                    if (!firstFrameLogged) { firstFrameLogged = true; AppLog.d(this, "PERF FIRST_IMAGE_VISIBLE=" + elapsed() + "ms"); }
                });
            } catch (Throwable e) {
                AppLog.d(this, "IMAGE decode ERROR +" + elapsed() + "ms " + e);
                mainHandler.post(() -> {
                    if (generation == decodeGeneration.get()) {
                        pageAnimating = false;
                        Toast.makeText(this, "この画像を表示できませんでした", Toast.LENGTH_LONG).show();
                    }
                });
            }
        });
    }

    private boolean hasIndexedSiblingWindow() {
        return currentIndex >= 0 && !siblings.isEmpty() && (fullListReady || progressiveListActive);
    }

    // direction is physical: +1 = page arrives from the right, -1 = from the left.
    // The siblings array itself is the single source of truth for left-to-right order.
    // Never reverse again here: doing so caused the old sort-direction double inversion.
    private int indexDeltaForPhysicalDirection(int direction) {
        return direction;
    }

    private boolean canMoveSibling(int direction) {
        if (pageAnimating) return false;
        int delta = indexDeltaForPhysicalDirection(direction);
        if (hasIndexedSiblingWindow()) {
            int next = currentIndex + delta;
            return next >= 0 && next < siblings.size();
        }
        return delta > 0 ? quickNextItem != null : quickPreviousItem != null;
    }

    private MediaItem itemForDirection(int direction) {
        int delta = indexDeltaForPhysicalDirection(direction);
        if (hasIndexedSiblingWindow()) {
            int next = currentIndex + delta;
            return (next >= 0 && next < siblings.size()) ? siblings.get(next) : null;
        }
        return delta > 0 ? quickNextItem : quickPreviousItem;
    }

    private Drawable previewForDirection(int direction) {
        return indexDeltaForPhysicalDirection(direction) > 0 ? nextPreviewDrawable : previousPreviewDrawable;
    }

    private void showPagePreview(int direction, float translationX) {
        if (!canMoveSibling(direction) || pagePreviewView == null) {
            hidePagePreview();
            return;
        }
        Drawable preview = previewForDirection(direction);
        if (preview == null) {
            pagePreviewView.setVisibility(View.GONE);
            return;
        }
        if (pagePreviewView.getDrawable() != preview) pagePreviewView.setImageDrawable(preview);
        imageView.setLayerType(View.LAYER_TYPE_HARDWARE, null);
        pagePreviewView.setLayerType(View.LAYER_TYPE_HARDWARE, null);
        pagePreviewView.setVisibility(View.VISIBLE);
        float start = direction > 0 ? imageView.getWidth() : -imageView.getWidth();
        pagePreviewView.setTranslationX(start + translationX);
        pagePreviewView.setAlpha(1f);
    }

    private void hidePagePreview() {
        if (pagePreviewView == null) return;
        pagePreviewView.animate().cancel();
        pagePreviewView.setVisibility(View.GONE);
        pagePreviewView.setTranslationX(0f);
        imageView.setLayerType(View.LAYER_TYPE_NONE, null);
        pagePreviewView.setLayerType(View.LAYER_TYPE_NONE, null);
    }

    private final PathInterpolator pageInterpolator = new PathInterpolator(0.20f, 0f, 0f, 1f);

    private void cancelPageAnimationsForTouch() {
        imageView.animate().cancel();
        if (pagePreviewView != null) pagePreviewView.animate().cancel();
        // A new finger-down owns X from this point onward. Never let an old
        // ViewPropertyAnimator continue writing translationX during ACTION_MOVE.
        imageView.setTranslationX(0f);
        hidePagePreview();
        pageAnimating = false;
    }

    private void animatePageReset() {
        float tx = imageView.getTranslationX();
        if (Math.abs(tx) < 1f) { hidePagePreview(); return; }
        int direction = tx < 0 ? 1 : -1;
        float previewTarget = direction > 0 ? imageView.getWidth() : -imageView.getWidth();
        imageView.setLayerType(View.LAYER_TYPE_HARDWARE, null);
        pagePreviewView.setLayerType(View.LAYER_TYPE_HARDWARE, null);
        imageView.animate().cancel();
        pagePreviewView.animate().cancel();
        imageView.animate().translationX(0f).setDuration(150).setInterpolator(pageInterpolator).start();
        if (pagePreviewView.getVisibility() == View.VISIBLE) {
            pagePreviewView.animate().translationX(previewTarget).setDuration(150).setInterpolator(pageInterpolator)
                    .withEndAction(this::hidePagePreview).start();
        } else {
            mainHandler.postDelayed(this::hidePagePreview, 155);
        }
    }

    private long pageDuration(float velocityX, float remainingPx) {
        float width = Math.max(1f, imageView.getWidth());
        if (Math.abs(velocityX) > 900f) {
            long byVelocity = (long)(1000f * remainingPx / Math.max(1200f, Math.abs(velocityX)));
            return Math.max(75L, Math.min(165L, byVelocity));
        }
        return (long)(105f + 60f * Math.min(1f, remainingPx / width));
    }

    private void animateToSibling(int direction, float velocityX) {
        MediaItem targetItem = itemForDirection(direction);
        if (targetItem == null || !canMoveSibling(direction)) {
            animatePageReset();
            return;
        }
        pageAnimating = true;
        final int targetIndex = hasIndexedSiblingWindow() ? currentIndex + indexDeltaForPhysicalDirection(direction) : -1;
        Drawable preview = previewForDirection(direction);
        float target = direction > 0 ? -imageView.getWidth() : imageView.getWidth();
        float remaining = Math.abs(target - imageView.getTranslationX());
        long duration = pageDuration(velocityX, remaining);

        imageView.setLayerType(View.LAYER_TYPE_HARDWARE, null);
        pagePreviewView.setLayerType(View.LAYER_TYPE_HARDWARE, null);
        imageView.animate().cancel();
        pagePreviewView.animate().cancel();

        if (preview != null) {
            if (pagePreviewView.getVisibility() != View.VISIBLE || pagePreviewView.getDrawable() != preview) {
                pagePreviewView.setImageDrawable(preview);
                pagePreviewView.setVisibility(View.VISIBLE);
                pagePreviewView.setTranslationX(direction > 0 ? imageView.getWidth() : -imageView.getWidth());
            }
            pagePreviewView.animate().translationX(0f).setDuration(duration).setInterpolator(pageInterpolator).start();
            imageView.animate().translationX(target).setDuration(duration).setInterpolator(pageInterpolator).withEndAction(() -> {
                currentUri = targetItem.uri; currentName = targetItem.name; currentMime = targetItem.mime;
                clearPendingRotationState();
                updateCurrentFormatCapabilities();
                if (targetIndex >= 0 && hasIndexedSiblingWindow()) currentIndex = targetIndex;

                // Keep the centered preview covering the hand-off for one display frame.
                // The main ImageView gets its final FIT matrix while still off-screen, so
                // users never see an old matrix / temporary wrong-size frame.
                imageView.setImageForViewerKeepingTranslation(preview);
                imageView.setTranslationX(0f);
                titleView.setText(currentName);
                updatePositionLabel();
                pagePreviewView.postOnAnimation(() -> {
                    hidePagePreview();
                    pageAnimating = false;
                });
                AppLog.d(this, "SWIPE move cached +" + elapsed() + "ms direction=" + direction + " duration=" + duration);

                // The swipe used a screen-sized preview for speed. Upgrade the now-current
                // page to the original resolution in the background without blocking touch.
                openImageAsync(currentUri, false, 0);
                if (hasIndexedSiblingWindow()) prefetchAdjacent();
                else discoverSiblingImagesAsync();
            }).start();
        } else {
            imageView.animate().translationX(target).setDuration(duration).setInterpolator(pageInterpolator).withEndAction(() -> {
                currentUri = targetItem.uri; currentName = targetItem.name; currentMime = targetItem.mime;
                clearPendingRotationState();
                updateCurrentFormatCapabilities();
                if (targetIndex >= 0 && hasIndexedSiblingWindow()) currentIndex = targetIndex;
                imageView.setTranslationX(0f);
                AppLog.d(this, "SWIPE move decode +" + elapsed() + "ms direction=" + direction);
                showCurrentUri(true, direction);
                if (hasIndexedSiblingWindow()) prefetchAdjacent();
                else discoverSiblingImagesAsync();
            }).start();
        }
    }

    private String previewKey(Uri uri) {
        return uri == null ? "" : uri.toString();
    }

    private Drawable getCachedPreview(Uri uri) {
        return previewCache.get(previewKey(uri));
    }

    private void putCachedPreview(Uri uri, Drawable drawable) {
        if (uri != null && drawable != null) previewCache.put(previewKey(uri), drawable);
    }

    /**
     * Decode only enough pixels for an on-screen swipe preview. The previous code decoded
     * the original full-resolution file here, which made the FIRST swipe wait on large photos.
     * The full-resolution drawable is loaded only after the page has actually become current.
     */
    private Drawable decodePreviewDrawable(Uri uri) throws IOException {
        ImageDecoder.Source source = createImageSource(uri);
        final int maxW = Math.max(1, getResources().getDisplayMetrics().widthPixels);
        final int maxH = Math.max(1, getResources().getDisplayMetrics().heightPixels);
        return ImageDecoder.decodeDrawable(source, (decoder, info, src) -> {
            int srcW = Math.max(1, info.getSize().getWidth());
            int srcH = Math.max(1, info.getSize().getHeight());
            float scale = Math.min((float) maxW / srcW, (float) maxH / srcH);
            if (scale < 1f) {
                int targetW = Math.max(1, Math.round(srcW * scale));
                int targetH = Math.max(1, Math.round(srcH * scale));
                decoder.setTargetSize(targetW, targetH);
            }
        });
    }

    private void prefetchQuick(MediaItem item, int direction, int generation) {
        if (item == null) return;
        Drawable cached = getCachedPreview(item.uri);
        if (cached != null) {
            if (direction > 0) nextPreviewDrawable = cached; else previousPreviewDrawable = cached;
            AppLog.d(this, "PREFETCH quick cache " + (direction > 0 ? "next" : "prev") + " +" + elapsed() + "ms");
            return;
        }
        prefetchExecutor.execute(() -> {
            long started = SystemClock.elapsedRealtime();
            try {
                Drawable d = decodePreviewDrawable(item.uri);
                putCachedPreview(item.uri, d);
                mainHandler.post(() -> {
                    if (generation != prefetchGeneration.get() || isFinishing()) return;
                    if (direction > 0) nextPreviewDrawable = d; else previousPreviewDrawable = d;
                    AppLog.d(this, "PREFETCH quick " + (direction > 0 ? "next" : "prev") + " ready +" + elapsed() + "ms took=" + (SystemClock.elapsedRealtime()-started) + "ms");
                });
            } catch (Throwable e) { AppLog.d(this, "PREFETCH quick error " + e); }
        });
    }

    private void prefetchAdjacent() {
        final int generation = prefetchGeneration.incrementAndGet();
        final int index = currentIndex;
        if (index < 0 || siblings.isEmpty()) {
            previousPreviewDrawable = null;
            nextPreviewDrawable = null;
            return;
        }
        previousPreviewDrawable = null;
        nextPreviewDrawable = null;
        final MediaItem prev = index > 0 ? siblings.get(index - 1) : null;
        final MediaItem next = index + 1 < siblings.size() ? siblings.get(index + 1) : null;

        if (prev != null) {
            Drawable cached = getCachedPreview(prev.uri);
            if (cached != null) {
                previousPreviewDrawable = cached;
            } else prefetchExecutor.execute(() -> {
                long started = SystemClock.elapsedRealtime();
                try {
                    Drawable d = decodePreviewDrawable(prev.uri);
                    putCachedPreview(prev.uri, d);
                    mainHandler.post(() -> {
                        if (generation != prefetchGeneration.get() || isFinishing()) return;
                        previousPreviewDrawable = d;
                        AppLog.d(this, "PREFETCH prev ready +" + elapsed() + "ms took=" + (SystemClock.elapsedRealtime()-started) + "ms");
                    });
                } catch (Throwable e) { AppLog.d(this, "PREFETCH prev error " + e); }
            });
        }
        if (next != null) {
            Drawable cached = getCachedPreview(next.uri);
            if (cached != null) {
                nextPreviewDrawable = cached;
            } else prefetchExecutor.execute(() -> {
                long started = SystemClock.elapsedRealtime();
                try {
                    Drawable d = decodePreviewDrawable(next.uri);
                    putCachedPreview(next.uri, d);
                    mainHandler.post(() -> {
                        if (generation != prefetchGeneration.get() || isFinishing()) return;
                        nextPreviewDrawable = d;
                        AppLog.d(this, "PREFETCH next ready +" + elapsed() + "ms took=" + (SystemClock.elapsedRealtime()-started) + "ms");
                    });
                } catch (Throwable e) { AppLog.d(this, "PREFETCH next error " + e); }
            });
        }
    }

    private void openPdf(Uri uri) {
        // PDF path remains synchronous for now; image opening is the performance priority for this build.
        try {
            AppLog.d(this, "PDF open begin uri=" + uri);
            pdfFd = getContentResolver().openFileDescriptor(uri, "r");
            if (pdfFd == null) throw new IOException("No file descriptor");
            pdfRenderer = new PdfRenderer(pdfFd);
            if (pdfRenderer.getPageCount() == 0) throw new IOException("Empty PDF");
            renderPdfPage(0);
        } catch (Throwable e) { AppLog.d(this, "PDF open ERROR " + e); Toast.makeText(this, "PDFを表示できませんでした", Toast.LENGTH_LONG).show(); }
    }

    private void renderPdfPage(int index) {
        closePdfPage(); pdfPage = pdfRenderer.openPage(index);
        int screenWidth = Math.max(1, getResources().getDisplayMetrics().widthPixels);
        float ratio = (float) pdfPage.getHeight() / (float) pdfPage.getWidth();
        int bitmapWidth = Math.min(screenWidth * 2, 2200); int bitmapHeight = Math.max(1, Math.round(bitmapWidth * ratio));
        Bitmap bitmap = Bitmap.createBitmap(bitmapWidth, bitmapHeight, Bitmap.Config.ARGB_8888); bitmap.eraseColor(Color.WHITE);
        pdfPage.render(bitmap, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY);
        imageView.setImageForViewer(new android.graphics.drawable.BitmapDrawable(getResources(), bitmap));
        pageView.setText((index + 1) + "/" + pdfRenderer.getPageCount());
    }

    private void updatePositionLabel() {
        if (progressiveListActive && !siblings.isEmpty()) {
            // left: selected-order range proven around the tapped/current image
            // middle: absolute current position once the previous chain reaches folder start
            // right: selected-order rows discovered so far, updated batch by batch
            int discovered = siblings.size();
            int centeredReady = (progressivePrevComplete || progressiveNextComplete)
                    ? discovered
                    : 1 + 2 * Math.min(progressivePrevLoaded, progressiveNextLoaded);
            String pos = progressivePrevComplete ? Integer.toString(currentIndex + 1) : "?";
            pageView.setText(centeredReady + "/" + pos + "/" + discovered);
            return;
        }
        if (currentIndex >= 0 && siblings.size() > 1) pageView.setText((currentIndex + 1) + "/" + siblings.size());
        else pageView.setText("");
    }

    private boolean hasMediaPermission() {
        if (Build.VERSION.SDK_INT >= 33) return checkSelfPermission(Manifest.permission.READ_MEDIA_IMAGES) == PackageManager.PERMISSION_GRANTED;
        return checkSelfPermission(Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED;
    }

    private void requestMediaPermission() {
        if (Build.VERSION.SDK_INT >= 33) requestPermissions(new String[]{Manifest.permission.READ_MEDIA_IMAGES}, REQ_MEDIA);
        else requestPermissions(new String[]{Manifest.permission.READ_EXTERNAL_STORAGE}, REQ_MEDIA);
    }


    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQ_MOVE_DELETE) {
            PendingMoveDelete pending = pendingMoveDelete;
            pendingMoveDelete = null;
            if (pending == null) return;
            if (resultCode != RESULT_OK) {
                AppLog.d(this, "FILE move delete consent denied source=" + pending.sourceName);
                Toast.makeText(this, "コピーは完了しましたが元ファイルを削除できませんでした", Toast.LENGTH_LONG).show();
                return;
            }
            AppLog.d(this, "FILE move delete consent granted source=" + pending.sourceName + " media=" + pending.mediaStoreUri);
            safeExecute(editExecutor, () -> {
                // Android 11+ createDeleteRequest normally performs the deletion itself.
                // Android 10 RecoverableSecurityException grants a one-shot retry instead.
                if (pending.mediaStoreUri != null && contentUriStillExists(pending.mediaStoreUri)) {
                    try {
                        int rows = getContentResolver().delete(pending.mediaStoreUri, null, null);
                        AppLog.d(this, "FILE move delete retry rows=" + rows + " media=" + pending.mediaStoreUri);
                    } catch (Throwable e) {
                        AppLog.d(this, "FILE move delete retry failed media=" + pending.mediaStoreUri + " " + e);
                    }
                }
                boolean gone = waitUntilMoveSourceGone(pending);
                mainHandler.post(() -> {
                    if (gone) {
                        AppLog.d(this, "FILE move source deletion verified source=" + pending.sourceName);
                        finishFileTransfer(true, pending.copiedUri, pending.destinationDir, pending.destination,
                                pending.sourceUri, pending.sourcePath, pending.sourceName);
                    } else {
                        AppLog.d(this, "FILE move source deletion NOT verified source=" + pending.sourceName +
                                " path=" + pending.sourcePath);
                        Toast.makeText(this, "コピーは完了しましたが元ファイルを削除できませんでした", Toast.LENGTH_LONG).show();
                    }
                });
            });
            return;
        }
        if (requestCode != REQ_SAF_TREE) return;
        File requested = pendingSafRequestedPath;
        File destinationDir = pendingSafDestinationDir;
        boolean move = pendingSafMove;
        int policy = pendingSafPolicy;
        pendingSafRequestedPath = null;
        pendingSafDestinationDir = null;
        if (resultCode != RESULT_OK || data == null || data.getData() == null) {
            AppLog.d(this, "SAF permission canceled");
            Toast.makeText(this, "外部ストレージへのアクセスを許可しなかったため中止しました", Toast.LENGTH_LONG).show();
            return;
        }
        Uri tree = data.getData();
        int takeFlags = data.getFlags() &
                (Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
        try {
            getContentResolver().takePersistableUriPermission(tree, takeFlags);
        } catch (Throwable e) {
            AppLog.d(this, "SAF takePersistableUriPermission failed tree=" + tree + " " + e);
            Toast.makeText(this, "外部ストレージの権限を保存できませんでした", Toast.LENGTH_LONG).show();
            return;
        }
        Uri covering = requested == null ? null : findPersistedSafTreeForPath(requested);
        AppLog.d(this, "SAF permission granted tree=" + tree + " requested=" + requested +
                " covers=" + (covering != null));
        if (requested != null && covering == null) {
            Toast.makeText(this, "対象フォルダを含む外部ストレージを選択してください", Toast.LENGTH_LONG).show();
            return;
        }
        if (destinationDir != null) performFileTransfer(destinationDir, move, policy);
    }

    @Override public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQ_MEDIA && grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            AppLog.d(this, "PERMISSION media granted"); discoverSiblingImagesAsync();
        } else if (requestCode == REQ_MEDIA) AppLog.d(this, "PERMISSION media denied");
    }

    private static class SeedSortKey {
        final long id;
        final String name;
        final long size;
        final long created;
        final long modified;
        SeedSortKey(long id, String name, long size, long created, long modified) {
            this.id = id; this.name = name; this.size = size; this.created = created; this.modified = modified;
        }
        SeedSortKey(long id, String name, long size, long modified) {
            this(id, name, size, modified, modified);
        }
    }

    private static class ResolvedSeed {
        final String relativePath;
        final SeedSortKey key;
        final String mime;
        final String strategy;
        ResolvedSeed(String relativePath, SeedSortKey key, String mime, String strategy) {
            this.relativePath = relativePath;
            this.key = key;
            this.mime = mime;
            this.strategy = strategy;
        }
    }

    private static class IncomingMeta {
        String name;
        String relativePath;
        String rawPath;
        long size = -1L;
        long modified = -1L;
    }

    private MediaItem queryNeighbor(String relativePath, SeedSortKey seed, boolean next, String field, boolean ascending) {
        if (seed == null) return null;
        String[] projection = new String[]{MediaStore.Images.Media._ID, MediaStore.Images.Media.DISPLAY_NAME, MediaStore.Images.Media.MIME_TYPE, MediaStore.Images.Media.SIZE, MediaStore.Images.Media.DATE_ADDED, MediaStore.Images.Media.DATE_MODIFIED};

        // "next" means forward in the currently selected slide order. Previous uses the
        // exact inverse. _ID is the stable tie-breaker for every sort mode so the quick
        // LIMIT-1 route and the later full-folder list can never disagree on neighbors.
        boolean forwardAscending = next == ascending;
        String cmp = forwardAscending ? ">" : "<";
        String order = forwardAscending ? " ASC" : " DESC";
        String selection;
        String[] args;
        String sort;

        if (SortPrefs.FIELD_NAME.equals(field)) {
            selection = MediaStore.Images.Media.RELATIVE_PATH + "=? AND ((" +
                    MediaStore.Images.Media.DISPLAY_NAME + " COLLATE NOCASE " + cmp + " ?) OR (" +
                    MediaStore.Images.Media.DISPLAY_NAME + " = ? COLLATE NOCASE AND " +
                    MediaStore.Images.Media._ID + " " + cmp + " ?))";
            args = new String[]{relativePath, seed.name, seed.name, Long.toString(seed.id)};
            sort = MediaStore.Images.Media.DISPLAY_NAME + " COLLATE NOCASE" + order + ", " +
                    MediaStore.Images.Media._ID + order;
        } else {
            String col = SortPrefs.sqlColumn(field);
            long seedValue = SortPrefs.FIELD_SIZE.equals(field) ? seed.size : (SortPrefs.FIELD_CREATED.equals(field) ? seed.created : seed.modified);
            selection = MediaStore.Images.Media.RELATIVE_PATH + "=? AND ((" + col + " " + cmp + " ?) OR (" +
                    col + "=? AND " + MediaStore.Images.Media._ID + " " + cmp + " ?))";
            args = new String[]{relativePath, Long.toString(seedValue), Long.toString(seedValue), Long.toString(seed.id)};
            sort = col + order + ", " + MediaStore.Images.Media._ID + order;
        }

        long started = SystemClock.elapsedRealtime();
        MediaItem item = queryFirstMediaItemLimited(projection, selection, args, sort);
        AppLog.d(this, "SIBLINGS neighbor " + (next ? "next" : "prev") +
                " field=" + field + " asc=" + ascending + " took=" +
                (SystemClock.elapsedRealtime() - started) + "ms ready=" + (item != null));
        return item;
    }

    private MediaItem queryFirstMediaItemLimited(String[] projection, String selection, String[] args, String sort) {
        try {
            Bundle queryArgs = new Bundle();
            queryArgs.putString(ContentResolver.QUERY_ARG_SQL_SELECTION, selection);
            queryArgs.putStringArray(ContentResolver.QUERY_ARG_SQL_SELECTION_ARGS, args);
            queryArgs.putString(ContentResolver.QUERY_ARG_SQL_SORT_ORDER, sort);
            queryArgs.putInt(ContentResolver.QUERY_ARG_LIMIT, 1);
            try (Cursor c = getContentResolver().query(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, projection, queryArgs, null)) {
                return firstMediaItemFromCursor(c);
            }
        } catch (Throwable e) {
            AppLog.d(this, "SIBLINGS neighbor bundle query error " + e);
            // Compatibility fallback: same selection/sort, but never append SQL LIMIT to
            // sortOrder. We only read the first row from the returned cursor.
            try (Cursor c = getContentResolver().query(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, projection, selection, args, sort)) {
                return firstMediaItemFromCursor(c);
            } catch (Throwable fallbackError) {
                AppLog.d(this, "SIBLINGS neighbor fallback error " + fallbackError);
            }
        }
        return null;
    }

    private MediaItem firstMediaItemFromCursor(Cursor c) {
        if (c != null && c.moveToFirst()) {
            long id = c.getLong(c.getColumnIndexOrThrow(MediaStore.Images.Media._ID));
            String name = c.getString(c.getColumnIndexOrThrow(MediaStore.Images.Media.DISPLAY_NAME));
            String mime = c.getString(c.getColumnIndexOrThrow(MediaStore.Images.Media.MIME_TYPE));
            long size = c.getLong(c.getColumnIndexOrThrow(MediaStore.Images.Media.SIZE));
            long created = c.getLong(c.getColumnIndexOrThrow(MediaStore.Images.Media.DATE_ADDED));
            long modified = c.getLong(c.getColumnIndexOrThrow(MediaStore.Images.Media.DATE_MODIFIED));
            return new MediaItem(ContentUris.withAppendedId(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, id), name, mime, size, created, modified);
        }
        return null;
    }

    private SeedSortKey lookupSeedSortKey(String relativePath, String seedName) {
        String[] projection = new String[]{MediaStore.Images.Media._ID, MediaStore.Images.Media.DISPLAY_NAME, MediaStore.Images.Media.SIZE, MediaStore.Images.Media.DATE_ADDED, MediaStore.Images.Media.DATE_MODIFIED};
        try (Cursor c = getContentResolver().query(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, projection,
                MediaStore.Images.Media.RELATIVE_PATH + "=? AND " + MediaStore.Images.Media.DISPLAY_NAME + "=? COLLATE NOCASE",
                new String[]{relativePath, seedName}, MediaStore.Images.Media._ID + " ASC")) {
            if (c != null && c.moveToFirst()) {
                return new SeedSortKey(
                        c.getLong(c.getColumnIndexOrThrow(MediaStore.Images.Media._ID)),
                        c.getString(c.getColumnIndexOrThrow(MediaStore.Images.Media.DISPLAY_NAME)),
                        c.getLong(c.getColumnIndexOrThrow(MediaStore.Images.Media.SIZE)),
                        c.getLong(c.getColumnIndexOrThrow(MediaStore.Images.Media.DATE_ADDED)),
                        c.getLong(c.getColumnIndexOrThrow(MediaStore.Images.Media.DATE_MODIFIED)));
            }
        } catch (Throwable e) {
            AppLog.d(this, "SIBLINGS seed sort lookup error " + e);
        }
        return null;
    }

    private void discoverSiblingImagesAsync() {
        if (ENABLE_CURSOR_OUT_EXPERIMENT) discoverSiblingImagesCursorOut();
        else if (ENABLE_CENTER_OUT_EXPERIMENT) discoverSiblingImagesCenterOut();
        else if (ENABLE_EXTERNAL_FAST_PATH_EXPERIMENT) discoverSiblingImagesExperimental();
        else discoverSiblingImagesLegacy();
    }

    /**
     * v0.1.19: generic external-URI resolver + two long-lived ordered cursors.
     *
     * Critical path:
     *   incoming URI -> exact MediaStore seed row -> previous cursor + next cursor
     * Each cursor is queried once, then consumed outward from the current image. There is
     * no LIMIT/paging loop and therefore no repeated 300-1000 ms provider round-trip.
     */
    private void discoverSiblingImagesCursorOut() {
        cancelSiblingQuerySignals();
        final int generation = siblingGeneration.incrementAndGet();
        prefetchGeneration.incrementAndGet();
        final Uri seedUri = currentUri;
        final String seedName = currentName;
        final String sortField = SortPrefs.field(this);
        final boolean sortAscending = SortPrefs.ascending(this);

        fullListReady = false;
        progressiveListActive = true;
        progressivePrevComplete = false;
        progressiveNextComplete = false;
        progressivePrevLoaded = 0;
        progressiveNextLoaded = 0;
        quickPreviousItem = null;
        quickNextItem = null;
        previousPreviewDrawable = null;
        nextPreviewDrawable = null;

        final CancellationSignal seedSignal = new CancellationSignal();
        seedResolveSignal = seedSignal;
        safeExecute(scanExecutor, () -> {
            try {
                AppLog.d(this, "SIBLINGS locate begin +" + elapsed() + "ms seed=" + seedName + " mode=cursor-out");

                // Preserve the v0.1.17 win: for path-style launchers, a same-folder reopen
                // can hit the completed RAM index before any MediaStore seed query.
                String cachePath = inferRelativePathFromAnyUri(seedUri);
                if (cachePath != null && !cachePath.isEmpty()) {
                    if (!cachePath.endsWith("/")) cachePath += "/";
                    ArrayList<MediaItem> instantCache = getFolderCache(cachePath, sortField, sortAscending);
                    if (instantCache != null && publishFullList(generation, seedName, instantCache, "ram-cache-preseed", 0L)) {
                        progressiveListActive = false;
                        AppLog.d(this, "CURSOR RAM cache preseed hit +" + elapsed() + "ms found=" + instantCache.size());
                        return;
                    }
                }

                // v0.1.20 fast route: if the incoming URI exposes a real shared-storage path,
                // enumerate only lightweight file metadata directly. No MediaStore seed query.
                if (ENABLE_DIRECT_FILE_ENUM_EXPERIMENT &&
                        tryDirectFilesystemIndex(generation, seedUri, seedName, cachePath, sortField, sortAscending)) {
                    progressiveListActive = false;
                    return;
                }

                // Type order is extension-group order, not a MediaStore scalar column. If a direct
                // filesystem path is unavailable, build the folder list once and sort client-side.
                if (SortPrefs.FIELD_TYPE.equals(sortField) && cachePath != null && !cachePath.isEmpty()) {
                    final String typePath = cachePath.endsWith("/") ? cachePath : cachePath + "/";
                    progressiveListActive = false;
                    safeExecute(fullScanExecutor, () -> buildFullSiblingList(
                            generation, seedName, typePath, sortField, sortAscending));
                    return;
                }

                long started = SystemClock.elapsedRealtime();
                ResolvedSeed resolved = resolveIncomingSeed(seedUri, seedName, seedSignal);
                long took = SystemClock.elapsedRealtime() - started;
                if (generation != siblingGeneration.get() || seedSignal.isCanceled()) return;
                if (resolved == null || resolved.key == null || resolved.relativePath == null) {
                    progressiveListActive = false;
                    AppLog.d(this, "CURSOR seed unresolved +" + elapsed() + "ms took=" + took + "ms");
                    return;
                }
                String path = resolved.relativePath.endsWith("/") ? resolved.relativePath : resolved.relativePath + "/";
                AppLog.d(this, "CURSOR seed ready +" + elapsed() + "ms took=" + took + "ms strategy=" +
                        resolved.strategy + " path=" + path + " id=" + resolved.key.id);

                ArrayList<MediaItem> cached = getFolderCache(path, sortField, sortAscending);
                if (cached != null && publishFullList(generation, resolved.key.name, cached, "ram-cache", 0L)) {
                    progressiveListActive = false;
                    AppLog.d(this, "CURSOR RAM cache hit +" + elapsed() + "ms found=" + cached.size());
                    return;
                }

                if (SortPrefs.FIELD_TYPE.equals(sortField)) {
                    progressiveListActive = false;
                    safeExecute(fullScanExecutor, () -> buildFullSiblingList(
                            generation, resolved.key.name, path, sortField, sortAscending));
                    return;
                }

                String centerMime = resolved.mime != null ? resolved.mime : currentMime;
                MediaItem center = new MediaItem(
                        ContentUris.withAppendedId(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, resolved.key.id),
                        resolved.key.name, centerMime, resolved.key.size, resolved.key.created, resolved.key.modified);
                mainHandler.post(() -> {
                    if (generation != siblingGeneration.get() || isFinishing()) return;
                    siblings.clear();
                    siblings.add(center);
                    currentIndex = 0;
                    progressiveListActive = true;
                    updateProgressivePositionLabel();
                });

                AtomicInteger sidesDone = new AtomicInteger(0);
                CancellationSignal prevSignal = new CancellationSignal();
                CancellationSignal nextSignal = new CancellationSignal();
                previousCursorSignal = prevSignal;
                nextCursorSignal = nextSignal;
                safeExecute(neighborExecutor, () -> streamNeighborCursor(
                        generation, path, resolved.key, false, sortField, sortAscending, sidesDone, prevSignal));
                safeExecute(neighborExecutor, () -> streamNeighborCursor(
                        generation, path, resolved.key, true, sortField, sortAscending, sidesDone, nextSignal));
            } catch (android.os.OperationCanceledException ignored) {
                AppLog.d(this, "CURSOR seed canceled +" + elapsed() + "ms");
            } catch (Throwable e) {
                if (generation == siblingGeneration.get()) {
                    progressiveListActive = false;
                    AppLog.d(this, "CURSOR seed error +" + elapsed() + "ms " + e);
                }
            }
        });
    }

    private ResolvedSeed resolveIncomingSeed(Uri uri, String fallbackName, CancellationSignal signal) {
        if (uri == null) return null;

        // Fastest possible route: the launcher already gave us a MediaStore item URI.
        ResolvedSeed direct = tryResolveDirectMediaUri(uri, signal);
        if (direct != null) return direct;

        // Path-like providers (Solid Explorer, external-storage DocumentsProvider, etc.)
        // often encode enough location information in the URI itself. This needs no IPC.
        String inferredPath = inferRelativePathFromAnyUri(uri);
        String name = fallbackName;
        // If the URI itself already exposes the shared-storage path (Solid Explorer and many
        // DocumentsProvider URIs do), avoid another provider IPC and go straight to MediaStore.
        if (inferredPath != null && !inferredPath.isEmpty() && name != null && !name.isEmpty()) {
            ResolvedSeed byPath = queryExactSeedByPath(inferredPath, name, signal, "uri-path+name");
            if (byPath != null) return byPath;
        }

        IncomingMeta meta = readIncomingMeta(uri, signal);
        if (meta != null && meta.name != null && !meta.name.isEmpty()) name = meta.name;
        if ((inferredPath == null || inferredPath.isEmpty()) && meta != null) {
            if (meta.relativePath != null && !meta.relativePath.isEmpty()) inferredPath = meta.relativePath;
            else if (meta.rawPath != null) inferredPath = relativePathFromAbsolute(meta.rawPath);
        }
        if (inferredPath != null && !inferredPath.isEmpty() && name != null && !name.isEmpty()) {
            ResolvedSeed byPath = queryExactSeedByPath(inferredPath, name, signal, "provider-path+name");
            if (byPath != null) return byPath;
        }

        // Opaque provider URI: use metadata from the single granted file to narrow MediaStore.
        if (name != null && meta != null) {
            ResolvedSeed byMeta = querySeedByMetadata(name, meta.size, meta.modified, signal);
            if (byMeta != null) return byMeta;
        }

        // Last safe fallback: a unique display name in MediaStore. If ambiguous we refuse to
        // guess a folder, because a wrong sibling chain is worse than no chain.
        if (name != null && !name.isEmpty()) return queryUniqueSeedByName(name, signal);
        return null;
    }

    private ResolvedSeed tryResolveDirectMediaUri(Uri uri, CancellationSignal signal) {
        String authority = uri.getAuthority();
        if (authority == null || !authority.toLowerCase(Locale.ROOT).contains("media")) return null;
        String[] projection = new String[]{MediaStore.Images.Media._ID, MediaStore.Images.Media.DISPLAY_NAME,
                MediaStore.Images.Media.MIME_TYPE, MediaStore.Images.Media.SIZE,
                MediaStore.Images.Media.DATE_ADDED, MediaStore.Images.Media.DATE_MODIFIED, MediaStore.Images.Media.RELATIVE_PATH};
        try (Cursor c = getContentResolver().query(uri, projection, null, null, null, signal)) {
            if (c != null && c.moveToFirst()) return resolvedSeedFromCursor(c, "direct-media-uri");
        } catch (Throwable e) {
            if (!(e instanceof android.os.OperationCanceledException))
                AppLog.d(this, "URI direct media miss " + e.getClass().getSimpleName());
        }
        return null;
    }

    private IncomingMeta readIncomingMeta(Uri uri, CancellationSignal signal) {
        if (uri == null || !"content".equalsIgnoreCase(uri.getScheme())) return null;
        IncomingMeta out = new IncomingMeta();
        try (Cursor c = getContentResolver().query(uri, null, null, null, null, signal)) {
            if (c == null || !c.moveToFirst()) return out;
            int nameCol = findColumn(c, OpenableColumns.DISPLAY_NAME, MediaStore.MediaColumns.DISPLAY_NAME,
                    "display_name", "name", "_display_name");
            int sizeCol = findColumn(c, OpenableColumns.SIZE, MediaStore.MediaColumns.SIZE, "size", "_size");
            int modifiedCol = findColumn(c, MediaStore.MediaColumns.DATE_MODIFIED,
                    "last_modified", "date_modified", "modified", "mtime");
            int relativeCol = findColumn(c, MediaStore.MediaColumns.RELATIVE_PATH, "relative_path");
            int dataCol = findColumn(c, "_data", "data", "path", "file_path");
            if (nameCol >= 0 && !c.isNull(nameCol)) out.name = c.getString(nameCol);
            if (sizeCol >= 0 && !c.isNull(sizeCol)) out.size = c.getLong(sizeCol);
            if (modifiedCol >= 0 && !c.isNull(modifiedCol)) out.modified = c.getLong(modifiedCol);
            if (relativeCol >= 0 && !c.isNull(relativeCol)) out.relativePath = c.getString(relativeCol);
            if (dataCol >= 0 && !c.isNull(dataCol)) out.rawPath = c.getString(dataCol);
            AppLog.d(this, "URI meta authority=" + uri.getAuthority() + " cols=" + Arrays.toString(c.getColumnNames()) +
                    " name=" + out.name + " size=" + out.size + " modified=" + out.modified +
                    " rel=" + out.relativePath + " raw=" + (out.rawPath != null));
        } catch (Throwable e) {
            if (!(e instanceof android.os.OperationCanceledException))
                AppLog.d(this, "URI meta unavailable authority=" + uri.getAuthority() + " " + e.getClass().getSimpleName());
        }
        return out;
    }

    private String inferRelativePathFromAnyUri(Uri uri) {
        if (uri == null) return null;
        try {
            String raw = Uri.decode(uri.getPath());
            if (raw != null) {
                String absoluteRelative = relativePathFromAbsolute(raw);
                if (absoluteRelative != null) return absoluteRelative;
                int primary = raw.indexOf("primary:");
                if (primary >= 0) {
                    String relativeFile = raw.substring(primary + "primary:".length());
                    int slash = relativeFile.lastIndexOf('/');
                    if (slash >= 0) return relativeFile.substring(0, slash + 1);
                }
            }
            if (Build.VERSION.SDK_INT >= 19 && DocumentsContract.isDocumentUri(this, uri)) {
                String docId = DocumentsContract.getDocumentId(uri);
                if (docId != null) {
                    if (docId.startsWith("primary:")) {
                        String relativeFile = docId.substring("primary:".length());
                        int slash = relativeFile.lastIndexOf('/');
                        if (slash >= 0) return relativeFile.substring(0, slash + 1);
                    }
                    if (docId.startsWith("raw:")) return relativePathFromAbsolute(docId.substring(4));
                }
            }
        } catch (Throwable e) {
            AppLog.d(this, "URI path inference miss " + e.getClass().getSimpleName());
        }
        return null;
    }

    private String relativePathFromAbsolute(String absolute) {
        if (absolute == null) return null;
        String[] markers = new String[]{"/storage/emulated/0/", "/storage/self/primary/", "/sdcard/"};
        for (String marker : markers) {
            int idx = absolute.indexOf(marker);
            if (idx < 0) continue;
            String relativeFile = absolute.substring(idx + marker.length());
            int slash = relativeFile.lastIndexOf('/');
            if (slash >= 0) return relativeFile.substring(0, slash + 1);
        }
        return null;
    }

    private ResolvedSeed queryExactSeedByPath(String relativePath, String name,
                                               CancellationSignal signal, String strategy) {
        if (!relativePath.endsWith("/")) relativePath += "/";
        String selection = MediaStore.Images.Media.RELATIVE_PATH + "=? AND " +
                MediaStore.Images.Media.DISPLAY_NAME + "=? COLLATE NOCASE";
        return querySingleResolvedSeed(selection, new String[]{relativePath, name}, signal, strategy);
    }

    private ResolvedSeed querySeedByMetadata(String name, long size, long providerModified,
                                             CancellationSignal signal) {
        String selection;
        String[] args;
        if (size >= 0) {
            selection = MediaStore.Images.Media.DISPLAY_NAME + "=? COLLATE NOCASE AND " +
                    MediaStore.Images.Media.SIZE + "=?";
            args = new String[]{name, Long.toString(size)};
        } else {
            return null;
        }
        ArrayList<ResolvedSeed> candidates = queryResolvedSeeds(selection, args, signal, 8);
        if (candidates.size() == 1) {
            ResolvedSeed r = candidates.get(0);
            return new ResolvedSeed(r.relativePath, r.key, r.mime, "name+size");
        }
        if (candidates.size() > 1 && providerModified >= 0) {
            long seconds = providerModified > 100000000000L ? providerModified / 1000L : providerModified;
            ResolvedSeed best = null;
            long bestDelta = Long.MAX_VALUE;
            for (ResolvedSeed r : candidates) {
                long delta = Math.abs(r.key.modified - seconds);
                if (delta < bestDelta) { bestDelta = delta; best = r; }
            }
            if (best != null && bestDelta <= 2L)
                return new ResolvedSeed(best.relativePath, best.key, best.mime, "name+size+modified");
        }
        if (candidates.size() > 1) AppLog.d(this, "URI metadata ambiguous name=" + name + " matches=" + candidates.size());
        return null;
    }

    private ResolvedSeed queryUniqueSeedByName(String name, CancellationSignal signal) {
        ArrayList<ResolvedSeed> candidates = queryResolvedSeeds(
                MediaStore.Images.Media.DISPLAY_NAME + "=? COLLATE NOCASE", new String[]{name}, signal, 2);
        if (candidates.size() == 1) {
            ResolvedSeed r = candidates.get(0);
            return new ResolvedSeed(r.relativePath, r.key, r.mime, "unique-name");
        }
        if (candidates.size() > 1) AppLog.d(this, "URI name ambiguous name=" + name);
        return null;
    }

    private ResolvedSeed querySingleResolvedSeed(String selection, String[] args,
                                                 CancellationSignal signal, String strategy) {
        ArrayList<ResolvedSeed> rows = queryResolvedSeeds(selection, args, signal, 1);
        if (rows.isEmpty()) return null;
        ResolvedSeed r = rows.get(0);
        return new ResolvedSeed(r.relativePath, r.key, r.mime, strategy);
    }

    private ArrayList<ResolvedSeed> queryResolvedSeeds(String selection, String[] args,
                                                       CancellationSignal signal, int limit) {
        ArrayList<ResolvedSeed> rows = new ArrayList<>();
        String[] projection = new String[]{MediaStore.Images.Media._ID, MediaStore.Images.Media.DISPLAY_NAME,
                MediaStore.Images.Media.MIME_TYPE, MediaStore.Images.Media.SIZE,
                MediaStore.Images.Media.DATE_ADDED, MediaStore.Images.Media.DATE_MODIFIED, MediaStore.Images.Media.RELATIVE_PATH};
        Bundle queryArgs = new Bundle();
        queryArgs.putString(ContentResolver.QUERY_ARG_SQL_SELECTION, selection);
        queryArgs.putStringArray(ContentResolver.QUERY_ARG_SQL_SELECTION_ARGS, args);
        queryArgs.putString(ContentResolver.QUERY_ARG_SQL_SORT_ORDER, MediaStore.Images.Media._ID + " ASC");
        queryArgs.putInt(ContentResolver.QUERY_ARG_LIMIT, Math.max(1, limit));
        try (Cursor c = getContentResolver().query(MediaStore.Images.Media.EXTERNAL_CONTENT_URI,
                projection, queryArgs, signal)) {
            while (c != null && c.moveToNext() && rows.size() < limit) {
                ResolvedSeed r = resolvedSeedFromCursor(c, "candidate");
                if (r != null) rows.add(r);
            }
        } catch (Throwable e) {
            if (!(e instanceof android.os.OperationCanceledException))
                AppLog.d(this, "URI MediaStore resolver error " + e);
        }
        return rows;
    }

    private ResolvedSeed resolvedSeedFromCursor(Cursor c, String strategy) {
        if (c == null) return null;
        int idCol = c.getColumnIndex(MediaStore.Images.Media._ID);
        int nameCol = c.getColumnIndex(MediaStore.Images.Media.DISPLAY_NAME);
        int mimeCol = c.getColumnIndex(MediaStore.Images.Media.MIME_TYPE);
        int sizeCol = c.getColumnIndex(MediaStore.Images.Media.SIZE);
        int createdCol = c.getColumnIndex(MediaStore.Images.Media.DATE_ADDED);
        int modifiedCol = c.getColumnIndex(MediaStore.Images.Media.DATE_MODIFIED);
        int pathCol = c.getColumnIndex(MediaStore.Images.Media.RELATIVE_PATH);
        if (idCol < 0 || nameCol < 0 || pathCol < 0) return null;
        long id = c.getLong(idCol);
        String name = c.getString(nameCol);
        long size = sizeCol >= 0 && !c.isNull(sizeCol) ? c.getLong(sizeCol) : 0L;
        long created = createdCol >= 0 && !c.isNull(createdCol) ? c.getLong(createdCol) : 0L;
        long modified = modifiedCol >= 0 && !c.isNull(modifiedCol) ? c.getLong(modifiedCol) : 0L;
        String mime = mimeCol >= 0 && !c.isNull(mimeCol) ? c.getString(mimeCol) : mimeFromName(name);
        String path = c.getString(pathCol);
        return new ResolvedSeed(path, new SeedSortKey(id, name, size, created, modified), mime, strategy);
    }

    private void streamNeighborCursor(int generation, String path, SeedSortKey seedKey, boolean next,
                                      String field, boolean ascending, AtomicInteger sidesDone,
                                      CancellationSignal signal) {
        long openedAt = SystemClock.elapsedRealtime();
        int total = 0;
        try (Cursor c = openNeighborCursor(path, seedKey, next, field, ascending, signal)) {
            long openMs = SystemClock.elapsedRealtime() - openedAt;
            if (generation != siblingGeneration.get() || signal.isCanceled()) return;
            AppLog.d(this, "CURSOR " + (next ? "next" : "prev") + " opened +" + elapsed() +
                    "ms took=" + openMs + "ms");
            if (c == null) {
                markCursorSideComplete(generation, next, path, field, ascending, sidesDone, 0);
                return;
            }
            ArrayList<MediaItem> chunk = new ArrayList<>(CURSOR_MERGE_CHUNK_SIZE);
            while (generation == siblingGeneration.get() && !signal.isCanceled() && c.moveToNext()) {
                MediaItem item = mediaItemFromCurrentCursorRow(c);
                if (item != null) {
                    total++;
                    if (total == 1) {
                        // Publish the actual adjacent item immediately; do not wait for a 24-row
                        // UI batch before allowing the first swipe on this side.
                        ArrayList<MediaItem> adjacent = new ArrayList<>(1);
                        adjacent.add(item);
                        mergeProgressiveBatch(generation, adjacent, next);
                    } else {
                        chunk.add(item);
                    }
                }
                if (chunk.size() >= CURSOR_MERGE_CHUNK_SIZE) {
                    mergeProgressiveBatch(generation, chunk, next);
                    chunk = new ArrayList<>(CURSOR_MERGE_CHUNK_SIZE);
                }
            }
            if (!chunk.isEmpty()) mergeProgressiveBatch(generation, chunk, next);
            if (generation == siblingGeneration.get() && !signal.isCanceled())
                markCursorSideComplete(generation, next, path, field, ascending, sidesDone, total);
        } catch (android.os.OperationCanceledException ignored) {
            AppLog.d(this, "CURSOR " + (next ? "next" : "prev") + " canceled +" + elapsed() + "ms");
        } catch (Throwable e) {
            if (generation == siblingGeneration.get()) {
                AppLog.d(this, "CURSOR " + (next ? "next" : "prev") + " error " + e);
                markCursorSideComplete(generation, next, path, field, ascending, sidesDone, total);
            }
        }
    }

    private Cursor openNeighborCursor(String relativePath, SeedSortKey anchor, boolean next,
                                      String field, boolean ascending, CancellationSignal signal) {
        String[] projection = new String[]{MediaStore.Images.Media._ID, MediaStore.Images.Media.DISPLAY_NAME,
                MediaStore.Images.Media.MIME_TYPE, MediaStore.Images.Media.SIZE,
                MediaStore.Images.Media.DATE_ADDED, MediaStore.Images.Media.DATE_MODIFIED};
        boolean outwardAscending = next == ascending;
        String cmp = outwardAscending ? ">" : "<";
        String order = outwardAscending ? " ASC" : " DESC";
        String selection;
        String[] args;
        String sort;
        if (SortPrefs.FIELD_NAME.equals(field)) {
            selection = MediaStore.Images.Media.RELATIVE_PATH + "=? AND ((" +
                    MediaStore.Images.Media.DISPLAY_NAME + " COLLATE NOCASE " + cmp + " ?) OR (" +
                    MediaStore.Images.Media.DISPLAY_NAME + " = ? COLLATE NOCASE AND " +
                    MediaStore.Images.Media._ID + " " + cmp + " ?))";
            args = new String[]{relativePath, anchor.name, anchor.name, Long.toString(anchor.id)};
            sort = MediaStore.Images.Media.DISPLAY_NAME + " COLLATE NOCASE" + order + ", " +
                    MediaStore.Images.Media._ID + order;
        } else {
            String col = SortPrefs.sqlColumn(field);
            long value = SortPrefs.FIELD_SIZE.equals(field) ? anchor.size : (SortPrefs.FIELD_CREATED.equals(field) ? anchor.created : anchor.modified);
            selection = MediaStore.Images.Media.RELATIVE_PATH + "=? AND ((" + col + " " + cmp + " ?) OR (" +
                    col + "=? AND " + MediaStore.Images.Media._ID + " " + cmp + " ?))";
            args = new String[]{relativePath, Long.toString(value), Long.toString(value), Long.toString(anchor.id)};
            sort = col + order + ", " + MediaStore.Images.Media._ID + order;
        }
        Bundle queryArgs = new Bundle();
        queryArgs.putString(ContentResolver.QUERY_ARG_SQL_SELECTION, selection);
        queryArgs.putStringArray(ContentResolver.QUERY_ARG_SQL_SELECTION_ARGS, args);
        queryArgs.putString(ContentResolver.QUERY_ARG_SQL_SORT_ORDER, sort);
        // Deliberately no QUERY_ARG_LIMIT: one ordered cursor per side replaces dozens of
        // LIMIT-24 queries. CursorWindow streams the rows as they are consumed.
        return getContentResolver().query(MediaStore.Images.Media.EXTERNAL_CONTENT_URI,
                projection, queryArgs, signal);
    }

    private MediaItem mediaItemFromCurrentCursorRow(Cursor c) {
        int idCol = c.getColumnIndex(MediaStore.Images.Media._ID);
        int nameCol = c.getColumnIndex(MediaStore.Images.Media.DISPLAY_NAME);
        int mimeCol = c.getColumnIndex(MediaStore.Images.Media.MIME_TYPE);
        int sizeCol = c.getColumnIndex(MediaStore.Images.Media.SIZE);
        int createdCol = c.getColumnIndex(MediaStore.Images.Media.DATE_ADDED);
        int modifiedCol = c.getColumnIndex(MediaStore.Images.Media.DATE_MODIFIED);
        if (idCol < 0 || nameCol < 0) return null;
        long id = c.getLong(idCol);
        String name = c.getString(nameCol);
        String mime = mimeCol >= 0 && !c.isNull(mimeCol) ? c.getString(mimeCol) : mimeFromName(name);
        long size = sizeCol >= 0 && !c.isNull(sizeCol) ? c.getLong(sizeCol) : 0L;
        long created = createdCol >= 0 && !c.isNull(createdCol) ? c.getLong(createdCol) : 0L;
        long modified = modifiedCol >= 0 && !c.isNull(modifiedCol) ? c.getLong(modifiedCol) : 0L;
        return new MediaItem(ContentUris.withAppendedId(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, id),
                name, mime, size, created, modified);
    }

    private void markCursorSideComplete(int generation, boolean next, String path, String field,
                                        boolean ascending, AtomicInteger sidesDone, int total) {
        mainHandler.post(() -> {
            if (generation != siblingGeneration.get() || isFinishing()) return;
            if (next) progressiveNextComplete = true; else progressivePrevComplete = true;
            updateProgressivePositionLabel();
            AppLog.d(this, "CURSOR side complete +" + elapsed() + "ms side=" + (next ? "next" : "prev") +
                    " rows=" + total + " prevLoaded=" + progressivePrevLoaded + " nextLoaded=" + progressiveNextLoaded);
            if (sidesDone.incrementAndGet() == 2) {
                fullListReady = true;
                progressiveListActive = false;
                putFolderCache(path, field, ascending, siblings);
                AppLog.d(this, "CURSOR full ready +" + elapsed() + "ms found=" + siblings.size() +
                        " currentIndex=" + currentIndex);
                updatePositionLabel();
                prefetchAdjacent();
            }
        });
    }

    private void cancelSiblingQuerySignals() {
        CancellationSignal a = seedResolveSignal;
        CancellationSignal b = previousCursorSignal;
        CancellationSignal c = nextCursorSignal;
        seedResolveSignal = null;
        previousCursorSignal = null;
        nextCursorSignal = null;
        try { if (a != null && !a.isCanceled()) a.cancel(); } catch (Throwable ignored) { }
        try { if (b != null && !b.isCanceled()) b.cancel(); } catch (Throwable ignored) { }
        try { if (c != null && !c.isCanceled()) c.cancel(); } catch (Throwable ignored) { }
    }

    // Exact v0.1.16-style path retained for one-flag rollback.
    private void discoverSiblingImagesLegacy() {
        final int generation = siblingGeneration.incrementAndGet();
        final int prefetchToken = prefetchGeneration.incrementAndGet();
        final Uri seedUri = currentUri;
        final String seedName = currentName;
        final String sortField = SortPrefs.field(this);
        final boolean sortAscending = SortPrefs.ascending(this);

        fullListReady = false;
        quickPreviousItem = null; quickNextItem = null;
        previousPreviewDrawable = null; nextPreviewDrawable = null;

        safeExecute(scanExecutor, () -> {
            try {
                AppLog.d(this, "SIBLINGS locate begin +" + elapsed() + "ms seed=" + seedName + " mode=legacy");
                String relativePath = resolveRelativePath(seedUri);
                if (generation != siblingGeneration.get()) return;
                if (relativePath == null || relativePath.isEmpty()) return;
                if (!relativePath.endsWith("/")) relativePath += "/";
                final String path = relativePath;
                final SeedSortKey seedKey = lookupSeedSortKey(path, seedName);
                if (generation != siblingGeneration.get()) return;
                if (seedKey == null) {
                    safeExecute(scanExecutor, () -> buildFullSiblingList(generation, seedName, path, sortField, sortAscending));
                    return;
                }
                final AtomicInteger remaining = new AtomicInteger(2);
                final AtomicReference<MediaItem> prevRef = new AtomicReference<>();
                final AtomicReference<MediaItem> nextRef = new AtomicReference<>();
                Runnable done = () -> {
                    if (remaining.decrementAndGet() == 0 && generation == siblingGeneration.get()) {
                        publishQuickPair(generation, prevRef.get(), nextRef.get(), prefetchToken, "media-legacy");
                        safeExecute(scanExecutor, () -> buildFullSiblingList(generation, seedName, path, sortField, sortAscending));
                    }
                };
                safeExecute(neighborExecutor, () -> { try { prevRef.set(queryNeighbor(path, seedKey, false, sortField, sortAscending)); } finally { done.run(); } });
                safeExecute(neighborExecutor, () -> { try { nextRef.set(queryNeighbor(path, seedKey, true, sortField, sortAscending)); } finally { done.run(); } });
            } catch (Throwable e) { AppLog.d(this, "SIBLINGS legacy error +" + elapsed() + "ms " + e); }
        });
    }

    private void discoverSiblingImagesExperimental() {
        final int generation = siblingGeneration.incrementAndGet();
        final int prefetchToken = prefetchGeneration.incrementAndGet();
        final Uri seedUri = currentUri;
        final String seedName = currentName;
        final String sortField = SortPrefs.field(this);
        final boolean sortAscending = SortPrefs.ascending(this);

        fullListReady = false;
        quickPreviousItem = null; quickNextItem = null;
        previousPreviewDrawable = null; nextPreviewDrawable = null;

        safeExecute(scanExecutor, () -> {
            try {
                AppLog.d(this, "SIBLINGS locate begin +" + elapsed() + "ms seed=" + seedName + " mode=external-race");
                String relativePath = resolveRelativePath(seedUri);
                if (generation != siblingGeneration.get()) return;
                if (relativePath == null || relativePath.isEmpty()) {
                    AppLog.d(this, "SIBLINGS no relative path +" + elapsed() + "ms");
                    return;
                }
                if (!relativePath.endsWith("/")) relativePath += "/";
                final String path = relativePath;
                AppLog.d(this, "SIBLINGS path=" + path + " +" + elapsed() + "ms race=cache/provider/full/neighbor");

                // 0) Process-memory cache. Reopening another image from the same folder/order
                // can become swipe-ready without touching MediaStore at all.
                ArrayList<MediaItem> cached = getFolderCache(path, sortField, sortAscending);
                if (cached != null && publishFullList(generation, seedName, cached, "ram-cache", 0L)) {
                    AppLog.d(this, "SIBLINGS RAM cache hit +" + elapsed() + "ms found=" + cached.size());
                    return;
                }

                // 1) Solid Explorer (or another path-style provider) parent-URI directory query.
                // It is fully isolated; failure never blocks the standard MediaStore paths.
                safeExecute(providerDirectoryExecutor, () -> tryProviderDirectoryFastPath(
                        generation, prefetchToken, seedUri, seedName, path, sortField, sortAscending));

                // 2) Full minimal MediaStore index starts immediately, instead of waiting for
                // seed lookup / neighbor queries. Logs showed this can beat LIMIT-1 on some runs.
                safeExecute(fullScanExecutor, () -> buildFullSiblingList(
                        generation, seedName, path, sortField, sortAscending));

                // 3) Existing selected-order previous/next MediaStore queries run in parallel.
                // This remains useful when the folder is huge but the indexed comparison is cheap.
                final long seedLookupStarted = SystemClock.elapsedRealtime();
                final SeedSortKey seedKey = lookupSeedSortKey(path, seedName);
                AppLog.d(this, "SIBLINGS seed lookup +" + elapsed() + "ms took=" +
                        (SystemClock.elapsedRealtime() - seedLookupStarted) + "ms ready=" + (seedKey != null));
                if (generation != siblingGeneration.get() || seedKey == null) return;

                final AtomicInteger remaining = new AtomicInteger(2);
                final AtomicReference<MediaItem> prevRef = new AtomicReference<>();
                final AtomicReference<MediaItem> nextRef = new AtomicReference<>();
                Runnable done = () -> {
                    if (remaining.decrementAndGet() == 0 && generation == siblingGeneration.get()) {
                        publishQuickPair(generation, prevRef.get(), nextRef.get(), prefetchToken, "media-neighbor");
                    }
                };
                safeExecute(neighborExecutor, () -> { try { prevRef.set(queryNeighbor(path, seedKey, false, sortField, sortAscending)); } finally { done.run(); } });
                safeExecute(neighborExecutor, () -> { try { nextRef.set(queryNeighbor(path, seedKey, true, sortField, sortAscending)); } finally { done.run(); } });
            } catch (Throwable e) { AppLog.d(this, "SIBLINGS experimental error +" + elapsed() + "ms " + e); }
        });
    }

    /**
     * v0.1.18: no full-folder scan is on the critical path. Resolve the tapped MediaStore
     * row once, then grow two keyset-paginated chains outward in the selected slide order:
     * -1/+1, then farther previous/next items. Each batch becomes swipeable immediately.
     */
    private void discoverSiblingImagesCenterOut() {
        final int generation = siblingGeneration.incrementAndGet();
        prefetchGeneration.incrementAndGet();
        final Uri seedUri = currentUri;
        final String seedName = currentName;
        final String sortField = SortPrefs.field(this);
        final boolean sortAscending = SortPrefs.ascending(this);

        fullListReady = false;
        progressiveListActive = true;
        progressivePrevComplete = false;
        progressiveNextComplete = false;
        progressivePrevLoaded = 0;
        progressiveNextLoaded = 0;
        quickPreviousItem = null; quickNextItem = null;
        previousPreviewDrawable = null; nextPreviewDrawable = null;

        safeExecute(scanExecutor, () -> {
            try {
                AppLog.d(this, "SIBLINGS locate begin +" + elapsed() + "ms seed=" + seedName + " mode=center-out");
                String relativePath = resolveRelativePath(seedUri);
                if (generation != siblingGeneration.get()) return;
                if (relativePath == null || relativePath.isEmpty()) {
                    AppLog.d(this, "CENTER no relative path +" + elapsed() + "ms");
                    return;
                }
                if (!relativePath.endsWith("/")) relativePath += "/";
                final String path = relativePath;

                ArrayList<MediaItem> cached = getFolderCache(path, sortField, sortAscending);
                if (cached != null && publishFullList(generation, seedName, cached, "ram-cache", 0L)) {
                    progressiveListActive = false;
                    AppLog.d(this, "CENTER RAM cache hit +" + elapsed() + "ms found=" + cached.size());
                    return;
                }

                long seedStarted = SystemClock.elapsedRealtime();
                SeedSortKey seedKey = lookupSeedSortKeyFast(path, seedName);
                AppLog.d(this, "CENTER seed ready +" + elapsed() + "ms took=" +
                        (SystemClock.elapsedRealtime() - seedStarted) + "ms ready=" + (seedKey != null));
                if (generation != siblingGeneration.get() || seedKey == null) {
                    progressiveListActive = false;
                    return;
                }

                MediaItem center = new MediaItem(
                        ContentUris.withAppendedId(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, seedKey.id),
                        seedKey.name, currentMime, seedKey.size, seedKey.created, seedKey.modified);
                mainHandler.post(() -> {
                    if (generation != siblingGeneration.get() || isFinishing()) return;
                    siblings.clear();
                    siblings.add(center);
                    currentIndex = 0;
                    progressiveListActive = true;
                    updateProgressivePositionLabel();
                });

                AtomicInteger sidesDone = new AtomicInteger(0);
                safeExecute(neighborExecutor, () -> expandCenterOutSide(
                        generation, path, seedKey, false, sortField, sortAscending, sidesDone));
                safeExecute(neighborExecutor, () -> expandCenterOutSide(
                        generation, path, seedKey, true, sortField, sortAscending, sidesDone));
            } catch (Throwable e) {
                progressiveListActive = false;
                AppLog.d(this, "CENTER error +" + elapsed() + "ms " + e);
            }
        });
    }

    private SeedSortKey lookupSeedSortKeyFast(String relativePath, String seedName) {
        String[] projection = new String[]{MediaStore.Images.Media._ID, MediaStore.Images.Media.DISPLAY_NAME,
                MediaStore.Images.Media.SIZE, MediaStore.Images.Media.DATE_ADDED, MediaStore.Images.Media.DATE_MODIFIED};
        String selection = MediaStore.Images.Media.RELATIVE_PATH + "=? AND " +
                MediaStore.Images.Media.DISPLAY_NAME + "=? COLLATE NOCASE";
        String[] args = new String[]{relativePath, seedName};
        try {
            Bundle queryArgs = new Bundle();
            queryArgs.putString(ContentResolver.QUERY_ARG_SQL_SELECTION, selection);
            queryArgs.putStringArray(ContentResolver.QUERY_ARG_SQL_SELECTION_ARGS, args);
            queryArgs.putString(ContentResolver.QUERY_ARG_SQL_SORT_ORDER, MediaStore.Images.Media._ID + " ASC");
            queryArgs.putInt(ContentResolver.QUERY_ARG_LIMIT, 1);
            try (Cursor c = getContentResolver().query(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, projection, queryArgs, null)) {
                if (c != null && c.moveToFirst()) {
                    return new SeedSortKey(
                            c.getLong(c.getColumnIndexOrThrow(MediaStore.Images.Media._ID)),
                            c.getString(c.getColumnIndexOrThrow(MediaStore.Images.Media.DISPLAY_NAME)),
                            c.getLong(c.getColumnIndexOrThrow(MediaStore.Images.Media.SIZE)),
                            c.getLong(c.getColumnIndexOrThrow(MediaStore.Images.Media.DATE_ADDED)),
                            c.getLong(c.getColumnIndexOrThrow(MediaStore.Images.Media.DATE_MODIFIED)));
                }
            }
        } catch (Throwable e) {
            AppLog.d(this, "CENTER seed bundle error " + e);
        }
        return lookupSeedSortKey(relativePath, seedName);
    }

    private void expandCenterOutSide(int generation, String path, SeedSortKey seedKey, boolean next,
                                     String field, boolean ascending, AtomicInteger sidesDone) {
        SeedSortKey anchor = seedKey;
        int batchNo = 0;
        try {
            while (generation == siblingGeneration.get() && !Thread.currentThread().isInterrupted()) {
                long started = SystemClock.elapsedRealtime();
                ArrayList<MediaItem> batch = queryNeighborBatch(path, anchor, next, field, ascending, CENTER_OUT_BATCH_SIZE);
                long took = SystemClock.elapsedRealtime() - started;
                batchNo++;
                AppLog.d(this, "CENTER " + (next ? "next" : "prev") + " batch=" + batchNo +
                        " took=" + took + "ms found=" + batch.size());
                if (batch.isEmpty()) {
                    markCenterOutSideComplete(generation, next, path, field, ascending, sidesDone);
                    return;
                }
                mergeProgressiveBatch(generation, batch, next);
                MediaItem farthest = batch.get(batch.size() - 1);
                anchor = seedKeyFromMediaItem(farthest);
                if (anchor == null || batch.size() < CENTER_OUT_BATCH_SIZE) {
                    markCenterOutSideComplete(generation, next, path, field, ascending, sidesDone);
                    return;
                }
                // Let image decoding and UI work breathe between metadata batches.
                try { Thread.sleep(8L); } catch (InterruptedException e) { Thread.currentThread().interrupt(); return; }
            }
        } catch (Throwable e) {
            AppLog.d(this, "CENTER " + (next ? "next" : "prev") + " error " + e);
            markCenterOutSideComplete(generation, next, path, field, ascending, sidesDone);
        }
    }

    private SeedSortKey seedKeyFromMediaItem(MediaItem item) {
        if (item == null || item.uri == null) return null;
        try {
            long id = ContentUris.parseId(item.uri);
            return new SeedSortKey(id, item.name, item.size, item.created, item.modified);
        } catch (Throwable e) {
            AppLog.d(this, "CENTER anchor id error " + e);
            return null;
        }
    }

    private ArrayList<MediaItem> queryNeighborBatch(String relativePath, SeedSortKey anchor, boolean next,
                                                     String field, boolean ascending, int limit) {
        ArrayList<MediaItem> out = new ArrayList<>();
        if (anchor == null) return out;
        String[] projection = new String[]{MediaStore.Images.Media._ID, MediaStore.Images.Media.DISPLAY_NAME,
                MediaStore.Images.Media.MIME_TYPE, MediaStore.Images.Media.SIZE, MediaStore.Images.Media.DATE_ADDED, MediaStore.Images.Media.DATE_MODIFIED};
        boolean forwardAscending = next == ascending;
        String cmp = forwardAscending ? ">" : "<";
        String order = forwardAscending ? " ASC" : " DESC";
        String selection;
        String[] args;
        String sort;
        if (SortPrefs.FIELD_NAME.equals(field)) {
            selection = MediaStore.Images.Media.RELATIVE_PATH + "=? AND ((" +
                    MediaStore.Images.Media.DISPLAY_NAME + " COLLATE NOCASE " + cmp + " ?) OR (" +
                    MediaStore.Images.Media.DISPLAY_NAME + " = ? COLLATE NOCASE AND " +
                    MediaStore.Images.Media._ID + " " + cmp + " ?))";
            args = new String[]{relativePath, anchor.name, anchor.name, Long.toString(anchor.id)};
            sort = MediaStore.Images.Media.DISPLAY_NAME + " COLLATE NOCASE" + order + ", " +
                    MediaStore.Images.Media._ID + order;
        } else {
            String col = SortPrefs.sqlColumn(field);
            long value = SortPrefs.FIELD_SIZE.equals(field) ? anchor.size : (SortPrefs.FIELD_CREATED.equals(field) ? anchor.created : anchor.modified);
            selection = MediaStore.Images.Media.RELATIVE_PATH + "=? AND ((" + col + " " + cmp + " ?) OR (" +
                    col + "=? AND " + MediaStore.Images.Media._ID + " " + cmp + " ?))";
            args = new String[]{relativePath, Long.toString(value), Long.toString(value), Long.toString(anchor.id)};
            sort = col + order + ", " + MediaStore.Images.Media._ID + order;
        }
        try {
            Bundle queryArgs = new Bundle();
            queryArgs.putString(ContentResolver.QUERY_ARG_SQL_SELECTION, selection);
            queryArgs.putStringArray(ContentResolver.QUERY_ARG_SQL_SELECTION_ARGS, args);
            queryArgs.putString(ContentResolver.QUERY_ARG_SQL_SORT_ORDER, sort);
            queryArgs.putInt(ContentResolver.QUERY_ARG_LIMIT, limit);
            try (Cursor c = getContentResolver().query(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, projection, queryArgs, null)) {
                appendMediaItemsFromCursor(c, out, limit);
            }
        } catch (Throwable bundleError) {
            AppLog.d(this, "CENTER batch bundle error " + bundleError);
            try (Cursor c = getContentResolver().query(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, projection, selection, args, sort)) {
                appendMediaItemsFromCursor(c, out, limit);
            } catch (Throwable fallbackError) {
                AppLog.d(this, "CENTER batch fallback error " + fallbackError);
            }
        }
        return out;
    }

    private void appendMediaItemsFromCursor(Cursor c, ArrayList<MediaItem> out, int limit) {
        if (c == null) return;
        int idCol = c.getColumnIndexOrThrow(MediaStore.Images.Media._ID);
        int nameCol = c.getColumnIndexOrThrow(MediaStore.Images.Media.DISPLAY_NAME);
        int mimeCol = c.getColumnIndexOrThrow(MediaStore.Images.Media.MIME_TYPE);
        int sizeCol = c.getColumnIndexOrThrow(MediaStore.Images.Media.SIZE);
        int createdCol = c.getColumnIndexOrThrow(MediaStore.Images.Media.DATE_ADDED);
        int modifiedCol = c.getColumnIndexOrThrow(MediaStore.Images.Media.DATE_MODIFIED);
        while (out.size() < limit && c.moveToNext()) {
            long id = c.getLong(idCol);
            out.add(new MediaItem(ContentUris.withAppendedId(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, id),
                    c.getString(nameCol), c.getString(mimeCol), c.getLong(sizeCol), c.getLong(createdCol), c.getLong(modifiedCol)));
        }
    }

    private void mergeProgressiveBatch(int generation, ArrayList<MediaItem> batch, boolean next) {
        if (batch == null || batch.isEmpty()) return;
        final ArrayList<MediaItem> copy = new ArrayList<>(batch);
        mainHandler.post(() -> {
            if (generation != siblingGeneration.get() || isFinishing() || !progressiveListActive) return;
            boolean wasAtExpandingEdge = next ? currentIndex == siblings.size() - 1 : currentIndex == 0;
            if (next) {
                siblings.addAll(copy);
                progressiveNextLoaded += copy.size();
            } else {
                ArrayList<MediaItem> ordered = new ArrayList<>(copy);
                Collections.reverse(ordered);
                siblings.addAll(0, ordered);
                currentIndex += ordered.size();
                progressivePrevLoaded += ordered.size();
            }
            AppLog.d(this, "CENTER merge +" + elapsed() + "ms side=" + (next ? "next" : "prev") +
                    " loaded=" + siblings.size() + " currentWindowIndex=" + currentIndex);
            updateProgressivePositionLabel();
            // Do not restart preview decoding for every far-away metadata batch. Only when
            // this batch actually created a new adjacent page at the user's current edge.
            if (wasAtExpandingEdge) prefetchAdjacent();
        });
    }

    private void markCenterOutSideComplete(int generation, boolean next, String path, String field,
                                           boolean ascending, AtomicInteger sidesDone) {
        mainHandler.post(() -> {
            if (generation != siblingGeneration.get() || isFinishing()) return;
            if (next) progressiveNextComplete = true; else progressivePrevComplete = true;
            updateProgressivePositionLabel();
            AppLog.d(this, "CENTER side complete +" + elapsed() + "ms side=" + (next ? "next" : "prev") +
                    " prevLoaded=" + progressivePrevLoaded + " nextLoaded=" + progressiveNextLoaded);
            if (sidesDone.incrementAndGet() == 2) {
                fullListReady = true;
                progressiveListActive = false;
                putFolderCache(path, field, ascending, siblings);
                AppLog.d(this, "CENTER full ready +" + elapsed() + "ms found=" + siblings.size() +
                        " currentIndex=" + currentIndex);
                updatePositionLabel();
                prefetchAdjacent();
            }
        });
    }

    private void updateProgressivePositionLabel() {
        updatePositionLabel();
    }

    private void publishQuickPair(int generation, MediaItem prev, MediaItem next, int prefetchToken, String source) {
        mainHandler.post(() -> {
            if (generation != siblingGeneration.get() || isFinishing() || fullListReady) return;
            quickPreviousItem = prev;
            quickNextItem = next;
            AppLog.d(this, "SIBLINGS quick pair +" + elapsed() + "ms source=" + source +
                    " prev=" + (prev != null) + " next=" + (next != null));
            if (prev != null) prefetchQuick(prev, -1, prefetchToken);
            if (next != null) prefetchQuick(next, 1, prefetchToken);
        });
    }

    private boolean publishFullList(int generation, String seedName, List<MediaItem> found, String source, long scanMs) {
        if (generation != siblingGeneration.get() || found == null || found.isEmpty()) return false;
        int idx = -1;
        for (int i = 0; i < found.size(); i++) {
            if (sameName(found.get(i).name, seedName)) { idx = i; break; }
        }
        if (idx < 0) return false;
        final int finalIndex = idx;
        final ArrayList<MediaItem> copy = new ArrayList<>(found);
        mainHandler.post(() -> {
            if (generation != siblingGeneration.get() || isFinishing()) return;
            siblings.clear(); siblings.addAll(copy); currentIndex = finalIndex;
            fullListReady = true;
            quickPreviousItem = null; quickNextItem = null;
            AppLog.d(this, "SIBLINGS full ready +" + elapsed() + "ms source=" + source +
                    " scan=" + scanMs + "ms found=" + siblings.size() + " currentIndex=" + currentIndex);
            updatePositionLabel();
            prefetchAdjacent();
        });
        return true;
    }

    // Cache identity is the folder only. Sort field/direction never invalidates a warm folder index.
    private String folderCacheKey(String path) {
        return path == null ? "" : path;
    }

    private boolean cacheSupportsSort(FolderCacheEntry entry, String field) {
        if (entry == null) return false;
        if (SortPrefs.FIELD_NAME.equals(field) || SortPrefs.FIELD_TYPE.equals(field)) return true;
        final boolean needSize = SortPrefs.FIELD_SIZE.equals(field);
        final boolean needCreated = SortPrefs.FIELD_CREATED.equals(field);
        final boolean needModified = SortPrefs.FIELD_MODIFIED.equals(field);
        for (MediaItem item : entry.items) {
            if (item == null) continue;
            if (needSize && item.size < 0L) return false;
            if (needCreated && item.created < 0L) return false;
            if (needModified && item.modified < 0L) return false;
        }
        return true;
    }

    private ArrayList<MediaItem> getFolderCache(String path, String field, boolean asc) {
        String key = folderCacheKey(path);
        synchronized (FOLDER_CACHE_LOCK) {
            FolderCacheEntry e = FOLDER_INDEX_CACHE.get(key);
            if (e == null) return null;
            if (SystemClock.elapsedRealtime() - e.createdAt > FOLDER_CACHE_TTL_MS) {
                FOLDER_INDEX_CACHE.remove(key);
                return null;
            }
            // A name-only scan is intentionally incomplete for size/modified sorting.
            // If that metadata is missing, force one direct rescan that enriches this same cache.
            if (!cacheSupportsSort(e, field)) return null;
            ArrayList<MediaItem> out = new ArrayList<>(e.items);
            sortProviderItems(out, field, asc);
            return out;
        }
    }

    private void putFolderCache(String path, String field, boolean asc, List<MediaItem> items) {
        if (path == null || items == null || items.isEmpty()) return;
        String key = folderCacheKey(path);
        synchronized (FOLDER_CACHE_LOCK) {
            FolderCacheEntry previous = FOLDER_INDEX_CACHE.get(key);
            HashMap<String, MediaItem> oldByName = new HashMap<>();
            if (previous != null) {
                for (MediaItem old : previous.items) {
                    if (old != null && old.name != null) oldByName.put(old.name, old);
                }
            }

            ArrayList<MediaItem> merged = new ArrayList<>(items.size());
            for (MediaItem item : items) {
                if (item == null || item.name == null) continue;
                MediaItem old = oldByName.get(item.name);
                long size = item.size >= 0L ? item.size : (old == null ? -1L : old.size);
                long created = item.created >= 0L ? item.created : (old == null ? -1L : old.created);
                long modified = item.modified >= 0L ? item.modified : (old == null ? -1L : old.modified);
                Uri uri = item.uri != null ? item.uri : (old == null ? null : old.uri);
                String mime = item.mime != null ? item.mime : (old == null ? null : old.mime);
                merged.add(new MediaItem(uri, item.name, mime, size, created, modified));
            }
            FOLDER_INDEX_CACHE.put(key, new FolderCacheEntry(SystemClock.elapsedRealtime(), merged));
        }
    }

    private boolean tryDirectFilesystemIndex(int generation, Uri seedUri, String seedName,
                                             String relativePath, String sortField, boolean sortAscending) {
        long started = SystemClock.elapsedRealtime();
        try {
            String absoluteSeed = inferAbsolutePathFromAnyUri(seedUri);
            if (absoluteSeed == null || absoluteSeed.isEmpty()) {
                AppLog.d(this, "FILE fast skip +" + elapsed() + "ms reason=no-absolute-path");
                return false;
            }
            File seedFile = new File(absoluteSeed);
            File parent = seedFile.getParentFile();
            if (parent == null || !parent.isDirectory() || !parent.canRead()) {
                AppLog.d(this, "FILE fast skip +" + elapsed() + "ms reason=unreadable-parent path=" +
                        (parent == null ? "null" : parent.getAbsolutePath()));
                return false;
            }
            // File.list() returns names without doing a per-entry stat. This matters for large folders:
            // name sort must not call isFile(), length(), or lastModified() for every item.
            String[] names = parent.list((dir, name) -> isSupportedImageName(name));
            if (names == null) {
                AppLog.d(this, "FILE fast skip +" + elapsed() + "ms reason=list-null");
                return false;
            }
            final boolean needSize = SortPrefs.FIELD_SIZE.equals(sortField);
            final boolean needCreated = SortPrefs.FIELD_CREATED.equals(sortField);
            final boolean needModified = SortPrefs.FIELD_MODIFIED.equals(sortField);
            ArrayList<MediaItem> found = new ArrayList<>(names.length);
            for (String name : names) {
                if (generation != siblingGeneration.get()) return true;
                if (name == null || name.isEmpty()) continue;
                File f = new File(parent, name);
                long size = needSize ? Math.max(0L, f.length()) : -1L;
                long created = needCreated ? fileCreationTimeMillis(f) : -1L;
                long modified = needModified ? Math.max(0L, f.lastModified()) : -1L;
                found.add(new MediaItem(Uri.fromFile(f), name, mimeFromName(name), size, created, modified));
            }
            if (found.isEmpty()) {
                AppLog.d(this, "FILE fast skip +" + elapsed() + "ms reason=no-images");
                return false;
            }
            sortProviderItems(found, sortField, sortAscending);
            // Name/type order is fully determined from File.list() alone. Start decoding the exact
            // two neighbors before any later folder bookkeeping, so the tapped image becomes
            // swipe-ready from the center outward. Size/date order must wait for all required stats.
            if (SortPrefs.FIELD_NAME.equals(sortField) || SortPrefs.FIELD_TYPE.equals(sortField)) {
                int seedIndex = -1;
                for (int i = 0; i < found.size(); i++) {
                    if (sameName(found.get(i).name, seedName)) { seedIndex = i; break; }
                }
                if (seedIndex >= 0) {
                    MediaItem prev = seedIndex > 0 ? found.get(seedIndex - 1) : null;
                    MediaItem next = seedIndex + 1 < found.size() ? found.get(seedIndex + 1) : null;
                    publishQuickPair(generation, prev, next, prefetchGeneration.get(), "filesystem-order-neighbors");
                    AppLog.d(this, "PREFETCH order neighbors queued +" + elapsed() + "ms field=" + sortField);
                }
            }
            String cachePath = relativePath;
            if (cachePath == null || cachePath.isEmpty()) cachePath = relativePathFromAbsolute(absoluteSeed);
            if (cachePath == null || cachePath.isEmpty()) cachePath = parent.getAbsolutePath() + "/";
            if (!cachePath.endsWith("/")) cachePath += "/";
            putFolderCache(cachePath, sortField, sortAscending, found);
            long took = SystemClock.elapsedRealtime() - started;
            boolean published = publishFullList(generation, seedName, found, "filesystem-direct", took);
            AppLog.d(this, "FILE fast ready +" + elapsed() + "ms took=" + took + "ms found=" +
                    found.size() + " published=" + published + " metadata=" +
                    (needSize ? "size-only" : (needCreated ? "created-only" : (needModified ? "modified-only" : (SortPrefs.FIELD_TYPE.equals(sortField) ? "type-name-only" : "name-only")))) +
                    " parent=" + parent.getAbsolutePath());
            return published;
        } catch (SecurityException e) {
            AppLog.d(this, "FILE fast denied +" + elapsed() + "ms " + e.getClass().getSimpleName());
            return false;
        } catch (Throwable e) {
            AppLog.d(this, "FILE fast error +" + elapsed() + "ms " + e);
            return false;
        }
    }

    private long fileCreationTimeMillis(File file) {
        if (file == null) return -1L;
        try {
            BasicFileAttributes attrs = Files.readAttributes(file.toPath(), BasicFileAttributes.class);
            long value = attrs.creationTime().toMillis();
            if (value > 0L) return value;
        } catch (Throwable ignored) { }
        // Some Android/storage providers do not expose birth time. In that case the best
        // deterministic fallback is mtime, while keeping it distinct when birth time exists.
        try {
            long modified = file.lastModified();
            return modified > 0L ? modified : -1L;
        } catch (Throwable ignored) { return -1L; }
    }

    private String inferAbsolutePathFromAnyUri(Uri uri) {
        if (uri == null) return null;
        try {
            if ("file".equalsIgnoreCase(uri.getScheme())) return uri.getPath();
            String raw = Uri.decode(uri.getPath());
            if (raw != null) {
                // Solid Explorer and other path-style providers may expose removable storage
                // directly as /storage/XXXX-XXXX/... . Preserve that absolute path too.
                if (raw.startsWith("/storage/") && !raw.endsWith("/")) return raw;
                String[] markers = new String[]{"/storage/emulated/0/", "/storage/self/primary/", "/sdcard/"};
                for (String marker : markers) {
                    int idx = raw.indexOf(marker);
                    if (idx >= 0) {
                        String tail = raw.substring(idx + marker.length());
                        return new File(android.os.Environment.getExternalStorageDirectory(), tail).getAbsolutePath();
                    }
                }
                int primary = raw.indexOf("primary:");
                if (primary >= 0) {
                    String tail = raw.substring(primary + "primary:".length());
                    return new File(android.os.Environment.getExternalStorageDirectory(), tail).getAbsolutePath();
                }
            }
            if (Build.VERSION.SDK_INT >= 19 && DocumentsContract.isDocumentUri(this, uri)) {
                String docId = DocumentsContract.getDocumentId(uri);
                if (docId != null) {
                    if (docId.startsWith("primary:")) {
                        return new File(android.os.Environment.getExternalStorageDirectory(),
                                docId.substring("primary:".length())).getAbsolutePath();
                    }
                    if (docId.startsWith("raw:")) return docId.substring(4);
                    int colon = docId.indexOf(':');
                    if (colon > 0) {
                        String volume = docId.substring(0, colon);
                        String relative = docId.substring(colon + 1);
                        if (!volume.isEmpty() && !"primary".equalsIgnoreCase(volume)) {
                            return relative.isEmpty() ? new File("/storage/" + volume).getAbsolutePath()
                                    : new File("/storage/" + volume, relative).getAbsolutePath();
                        }
                    }
                }
            }
        } catch (Throwable e) {
            AppLog.d(this, "FILE absolute path inference miss " + e.getClass().getSimpleName());
        }
        return null;
    }

    private void tryProviderDirectoryFastPath(int generation, int prefetchToken, Uri seedUri,
                                              String seedName, String relativePath,
                                              String sortField, boolean sortAscending) {
        if (generation != siblingGeneration.get() || seedUri == null) return;
        String authority = seedUri.getAuthority();
        if (authority == null || !authority.equals("pl.solidexplorer2.files")) {
            AppLog.d(this, "PROVIDER fast skip authority=" + authority);
            return;
        }
        Uri parent = parentProviderUri(seedUri);
        if (parent == null) return;
        long started = SystemClock.elapsedRealtime();
        AppLog.d(this, "PROVIDER parent query begin +" + elapsed() + "ms uri=" + parent);
        try (Cursor c = getContentResolver().query(parent, null, null, null, null)) {
            if (c == null) {
                AppLog.d(this, "PROVIDER parent query null +" + elapsed() + "ms");
                return;
            }
            AppLog.d(this, "PROVIDER parent columns=" + Arrays.toString(c.getColumnNames()));
            int nameCol = findColumn(c, OpenableColumns.DISPLAY_NAME, "display_name", "name", "_display_name");
            int mimeCol = findColumn(c, "mime_type", "mimetype", "type");
            int sizeCol = findColumn(c, OpenableColumns.SIZE, "size", "_size");
            int createdCol = findColumn(c, "date_added", "created", "creation_time", "birthtime");
            int modifiedCol = findColumn(c, "last_modified", "date_modified", "modified", "mtime");
            if (nameCol < 0) {
                AppLog.d(this, "PROVIDER parent unusable: no display-name column");
                return;
            }
            if ((SortPrefs.FIELD_SIZE.equals(sortField) && sizeCol < 0) ||
                    (SortPrefs.FIELD_CREATED.equals(sortField) && createdCol < 0) ||
                    (SortPrefs.FIELD_MODIFIED.equals(sortField) && modifiedCol < 0)) {
                AppLog.d(this, "PROVIDER parent unusable for sort=" + sortField +
                        " sizeCol=" + sizeCol + " createdCol=" + createdCol + " modifiedCol=" + modifiedCol);
                return;
            }
            ArrayList<MediaItem> found = new ArrayList<>();
            int rows = 0;
            while (c.moveToNext() && rows < 5000) {
                rows++;
                String name = c.isNull(nameCol) ? null : c.getString(nameCol);
                if (name == null || !looksLikeImage(name)) continue;
                String mime = (mimeCol >= 0 && !c.isNull(mimeCol)) ? c.getString(mimeCol) : mimeFromName(name);
                long size = (sizeCol >= 0 && !c.isNull(sizeCol)) ? c.getLong(sizeCol) : -1L;
                long created = (createdCol >= 0 && !c.isNull(createdCol)) ? c.getLong(createdCol) : -1L;
                long modified = (modifiedCol >= 0 && !c.isNull(modifiedCol)) ? c.getLong(modifiedCol) : -1L;
                Uri child = sameName(name, seedName) ? seedUri : parent.buildUpon().appendPath(name).build();
                found.add(new MediaItem(child, name, mime, size, created, modified));
            }
            sortProviderItems(found, sortField, sortAscending);
            long took = SystemClock.elapsedRealtime() - started;
            boolean accepted = publishFullList(generation, seedName, found, "provider-parent", took);
            AppLog.d(this, "PROVIDER parent query end +" + elapsed() + "ms took=" + took +
                    "ms rows=" + rows + " images=" + found.size() + " accepted=" + accepted);
            if (accepted) {
                // Provider list is intentionally not kept in the cross-activity cache; a URI
                // grant may be tied to this incoming Intent. MediaStore full-scan will populate
                // the safe process cache when/if it finishes.
            }
        } catch (Throwable e) {
            AppLog.d(this, "PROVIDER parent query error +" + elapsed() + "ms " + e);
        }
    }

    private Uri parentProviderUri(Uri seedUri) {
        String encoded = seedUri.getEncodedPath();
        if (encoded == null) return null;
        int slash = encoded.lastIndexOf('/');
        if (slash <= 0) return null;
        return seedUri.buildUpon().encodedPath(encoded.substring(0, slash + 1)).clearQuery().fragment(null).build();
    }

    private int findColumn(Cursor c, String... candidates) {
        String[] cols = c.getColumnNames();
        for (String candidate : candidates) {
            if (candidate == null) continue;
            for (int i = 0; i < cols.length; i++) if (candidate.equalsIgnoreCase(cols[i])) return i;
        }
        return -1;
    }

    private boolean looksLikeImage(String name) {
        if (name == null) return false;
        String n = name.toLowerCase(Locale.ROOT);
        return n.endsWith(".jpg") || n.endsWith(".jpeg") || n.endsWith(".png") ||
                n.endsWith(".gif") || n.endsWith(".bmp") || n.endsWith(".webp") ||
                n.endsWith(".heic") || n.endsWith(".heif") || n.endsWith(".avif");
    }

    private boolean isSupportedImageName(String name) {
        if (name == null) return false;
        String n = name.toLowerCase(Locale.ROOT);
        return looksLikeImage(name) || n.endsWith(".pdf");
    }

    private String mimeFromName(String name) {
        String n = name.toLowerCase(Locale.ROOT);
        if (n.endsWith(".png")) return "image/png";
        if (n.endsWith(".gif")) return "image/gif";
        if (n.endsWith(".bmp")) return "image/bmp";
        if (n.endsWith(".webp")) return "image/webp";
        if (n.endsWith(".heic") || n.endsWith(".heif")) return "image/heic";
        if (n.endsWith(".avif")) return "image/avif";
        if (n.endsWith(".pdf")) return "application/pdf";
        return "image/jpeg";
    }

    private String fileTypeKey(String name) {
        if (name == null) return "";
        String n = name.toLowerCase(Locale.ROOT);
        int dot = n.lastIndexOf('.');
        if (dot < 0 || dot >= n.length() - 1) return "";
        String ext = n.substring(dot + 1);
        // Treat equivalent container extensions as one file kind.
        if ("jpeg".equals(ext)) return "jpg";
        if ("heif".equals(ext)) return "heic";
        return ext;
    }

    private void sortProviderItems(List<MediaItem> list, String field, boolean asc) {
        Comparator<MediaItem> byName = (a, b) -> String.CASE_INSENSITIVE_ORDER.compare(
                a.name == null ? "" : a.name, b.name == null ? "" : b.name);
        Comparator<MediaItem> cmp;
        if (SortPrefs.FIELD_SIZE.equals(field)) {
            cmp = (a, b) -> { int x = Long.compare(a.size, b.size); return x != 0 ? x : byName.compare(a, b); };
        } else if (SortPrefs.FIELD_TYPE.equals(field)) {
            cmp = (a, b) -> {
                int x = fileTypeKey(a == null ? null : a.name).compareToIgnoreCase(fileTypeKey(b == null ? null : b.name));
                return x != 0 ? x : byName.compare(a, b);
            };
        } else if (SortPrefs.FIELD_CREATED.equals(field)) {
            cmp = (a, b) -> { int x = Long.compare(a.created, b.created); return x != 0 ? x : byName.compare(a, b); };
        } else if (SortPrefs.FIELD_MODIFIED.equals(field)) {
            cmp = (a, b) -> { int x = Long.compare(a.modified, b.modified); return x != 0 ? x : byName.compare(a, b); };
        } else cmp = byName;
        if (!asc) cmp = cmp.reversed();
        Collections.sort(list, cmp);
    }

    private boolean safeExecute(ExecutorService executor, Runnable task) {
        if (executor == null || task == null || executor.isShutdown() || executor.isTerminated()) return false;
        try { executor.execute(task); return true; }
        catch (java.util.concurrent.RejectedExecutionException e) {
            AppLog.d(this, "EXECUTOR rejected +" + elapsed() + "ms " + e.getClass().getSimpleName());
            return false;
        }
    }

    private void logLaunchIntentDetails() {
        try {
            Intent i = getIntent();
            ClipData clip = i.getClipData();
            Bundle extras = i.getExtras();
            AppLog.d(this, "INTENT flags=0x" + Integer.toHexString(i.getFlags()) +
                    " referrer=" + getReferrer() +
                    " clipCount=" + (clip == null ? 0 : clip.getItemCount()) +
                    " extras=" + (extras == null ? "[]" : extras.keySet().toString()));
            if (clip != null) {
                for (int n = 0; n < Math.min(clip.getItemCount(), 8); n++) {
                    ClipData.Item item = clip.getItemAt(n);
                    AppLog.d(this, "INTENT clip[" + n + "] uri=" + item.getUri());
                }
            }
        } catch (Throwable e) { AppLog.d(this, "INTENT detail error " + e); }
    }

    private void buildFullSiblingList(int generation, String seedName, String relativePath, String sortField, boolean sortAscending) {
        long started = SystemClock.elapsedRealtime();
        try {
            String[] projection = new String[]{MediaStore.Images.Media._ID, MediaStore.Images.Media.DISPLAY_NAME, MediaStore.Images.Media.MIME_TYPE, MediaStore.Images.Media.SIZE, MediaStore.Images.Media.DATE_ADDED, MediaStore.Images.Media.DATE_MODIFIED};
            String selection = MediaStore.Images.Media.RELATIVE_PATH + "=?";
            String direction = sortAscending ? " ASC" : " DESC";
            String col = SortPrefs.sqlColumn(sortField);
            String sort = SortPrefs.FIELD_NAME.equals(sortField)
                    ? MediaStore.Images.Media.DISPLAY_NAME + " COLLATE NOCASE" + direction + ", " + MediaStore.Images.Media._ID + direction
                    : col + direction + ", " + MediaStore.Images.Media._ID + direction;
            ArrayList<MediaItem> found = new ArrayList<>();
            try (Cursor c = getContentResolver().query(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, projection, selection, new String[]{relativePath}, sort)) {
                if (c != null) {
                    int idCol = c.getColumnIndexOrThrow(MediaStore.Images.Media._ID);
                    int nameCol = c.getColumnIndexOrThrow(MediaStore.Images.Media.DISPLAY_NAME);
                    int mimeCol = c.getColumnIndexOrThrow(MediaStore.Images.Media.MIME_TYPE);
                    int sizeCol = c.getColumnIndexOrThrow(MediaStore.Images.Media.SIZE);
                    int createdCol = c.getColumnIndexOrThrow(MediaStore.Images.Media.DATE_ADDED);
                    int modifiedCol = c.getColumnIndexOrThrow(MediaStore.Images.Media.DATE_MODIFIED);
                    while (c.moveToNext()) {
                        if (generation != siblingGeneration.get()) return;
                        long id = c.getLong(idCol); String name = c.getString(nameCol); String mime = c.getString(mimeCol);
                        long size = c.getLong(sizeCol); long created = c.getLong(createdCol); long modified = c.getLong(modifiedCol);
                        found.add(new MediaItem(ContentUris.withAppendedId(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, id), name, mime, size, created, modified));
                    }
                }
            }
            sortProviderItems(found, sortField, sortAscending);
            long scanMs = SystemClock.elapsedRealtime() - started;
            putFolderCache(relativePath, sortField, sortAscending, found);
            publishFullList(generation, seedName, found, "mediastore-full", scanMs);
        } catch (Throwable e) { AppLog.d(this, "SIBLINGS full error +" + elapsed() + "ms " + e); }
    }

    private String resolveRelativePath(Uri uri) {
        // Some file managers (including Solid Explorer) expose a provider URI whose path contains
        // the actual shared-storage path, but do not implement RELATIVE_PATH on that provider.
        try {
            String rawPath = uri.getPath();
            if (rawPath != null) {
                String marker = "/storage/emulated/0/";
                int idx = rawPath.indexOf(marker);
                if (idx >= 0) {
                    String relativeFile = rawPath.substring(idx + marker.length());
                    int slash = relativeFile.lastIndexOf('/');
                    if (slash >= 0) {
                        String inferred = relativeFile.substring(0, slash + 1);
                        AppLog.d(this, "SIBLINGS inferred path from provider=" + inferred);
                        return inferred;
                    }
                }
            }
        } catch (Throwable e) { AppLog.d(this, "SIBLINGS provider path parse error " + e); }

        try (Cursor c = getContentResolver().query(uri, new String[]{MediaStore.MediaColumns.RELATIVE_PATH}, null, null, null)) {
            if (c != null && c.moveToFirst()) {
                int col = c.getColumnIndex(MediaStore.MediaColumns.RELATIVE_PATH);
                if (col >= 0) {
                    String v = c.getString(col);
                    if (v != null && !v.isEmpty()) return v;
                }
            }
        } catch (Throwable e) { AppLog.d(this, "SIBLINGS seed RELATIVE_PATH unavailable " + e.getClass().getSimpleName()); }

        String name = resolveDisplayName(uri); if (name == null) return null;
        try (Cursor c = getContentResolver().query(MediaStore.Images.Media.EXTERNAL_CONTENT_URI,
                new String[]{MediaStore.Images.Media.RELATIVE_PATH, MediaStore.Images.Media.DISPLAY_NAME},
                MediaStore.Images.Media.DISPLAY_NAME + "=?", new String[]{name}, MediaStore.Images.Media.DATE_MODIFIED + " DESC")) {
            if (c != null && c.moveToFirst()) {
                int col = c.getColumnIndex(MediaStore.Images.Media.RELATIVE_PATH);
                if (col >= 0) return c.getString(col);
            }
        } catch (Throwable e) { AppLog.d(this, "SIBLINGS MediaStore name lookup error " + e); }
        return null;
    }

    private boolean sameName(String a, String b) { return a != null && b != null && a.equalsIgnoreCase(b); }
    private boolean isPdf(String mime, Uri uri) { return "application/pdf".equalsIgnoreCase(mime) || (uri != null && uri.toString().toLowerCase().endsWith(".pdf")); }

    private String resolveDisplayName(Uri uri) {
        String name = null;
        if ("content".equals(uri.getScheme())) {
            try (Cursor cursor = getContentResolver().query(uri, new String[]{OpenableColumns.DISPLAY_NAME}, null, null, null)) {
                if (cursor != null && cursor.moveToFirst()) { int index = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME); if (index >= 0) name = cursor.getString(index); }
            } catch (Exception ignored) { }
        }
        if (name == null || name.isEmpty()) name = uri.getLastPathSegment();
        return name == null ? "Chirami" : name;
    }

    private void closePdfPage() { if (pdfPage != null) { pdfPage.close(); pdfPage = null; } }
    private void closePdf() {
        closePdfPage(); if (pdfRenderer != null) { pdfRenderer.close(); pdfRenderer = null; }
        if (pdfFd != null) { try { pdfFd.close(); } catch (IOException ignored) { } pdfFd = null; }
    }

    @Override protected void onDestroy() {
        AppLog.d(this, "VIEWER onDestroy");
        stopSlideshowInternal(false);
        siblingGeneration.incrementAndGet();
        cancelSiblingQuerySignals();
        dismissRotationPopup();
        closePdf();
        decodeGeneration.incrementAndGet();
        decodeExecutor.shutdownNow(); editExecutor.shutdownNow(); fileManagerExecutor.shutdownNow(); scanExecutor.shutdownNow(); neighborExecutor.shutdownNow();
        providerDirectoryExecutor.shutdownNow(); fullScanExecutor.shutdownNow(); prefetchExecutor.shutdownNow();
        super.onDestroy();
    }

    /** White, label-free bottom toolbar icons drawn in code so the visual weight stays consistent. */
    private static class BottomActionIconView extends View {
        static final int SHARE = 0;
        static final int DELETE = 1;

        private final int kind;
        private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final RectF rect = new RectF();

        BottomActionIconView(Activity context, int kind) {
            super(context);
            this.kind = kind;
            setClickable(true);
            setFocusable(true);
        }

        @Override protected void onDraw(Canvas canvas) {
            super.onDraw(canvas);
            final float d = getResources().getDisplayMetrics().density;
            final float cx = getWidth() * 0.5f;
            final float cy = getHeight() * 0.5f;
            final float visualScale = 0.85f; // smaller glyph only; keep the full 72dp tap cell
            canvas.save();
            canvas.scale(visualScale, visualScale, cx, cy);
            paint.setColor(Color.WHITE);
            paint.setStyle(Paint.Style.STROKE);
            paint.setStrokeWidth(2.35f * d);
            paint.setStrokeCap(Paint.Cap.ROUND);
            paint.setStrokeJoin(Paint.Join.ROUND);

            if (kind == SHARE) {
                float r = 3.25f * d;
                float lx = cx - 8.5f * d;
                float ly = cy;
                float rx = cx + 7.5f * d;
                float ty = cy - 8.0f * d;
                float by = cy + 8.0f * d;
                canvas.drawLine(lx + r * 0.65f, ly - r * 0.35f, rx - r * 0.75f, ty + r * 0.45f, paint);
                canvas.drawLine(lx + r * 0.65f, ly + r * 0.35f, rx - r * 0.75f, by - r * 0.45f, paint);
                canvas.drawCircle(lx, ly, r, paint);
                canvas.drawCircle(rx, ty, r, paint);
                canvas.drawCircle(rx, by, r, paint);
                canvas.restore();
                return;
            }

            // Trash can: simple rounded outline, lid and handle, matching the share icon's weight.
            rect.set(cx - 8.0f * d, cy - 4.5f * d, cx + 8.0f * d, cy + 10.5f * d);
            canvas.drawRoundRect(rect, 2.2f * d, 2.2f * d, paint);
            canvas.drawLine(cx - 10.0f * d, cy - 8.0f * d, cx + 10.0f * d, cy - 8.0f * d, paint);
            rect.set(cx - 3.6f * d, cy - 11.0f * d, cx + 3.6f * d, cy - 8.0f * d);
            canvas.drawRoundRect(rect, 1.4f * d, 1.4f * d, paint);
            canvas.restore();
        }
    }

    /**
     * Font-independent toolbar glyphs. The rotate and info icons intentionally share the same
     * outer diameter so their circles line up exactly; back/more also use the same vertical center.
     */
    private static class ToolbarIconView extends View {
        static final int BACK = 0;
        static final int ROTATE = 1;
        static final int INFO = 2;
        static final int MORE = 3;
        static final int CHECK = 4;
        static final int CHECK_LARGE = 5;

        private final int kind;
        private final float requestedDiameterPx;
        private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final RectF arc = new RectF();

        ToolbarIconView(Activity context, int kind, int requestedDiameterPx) {
            super(context);
            this.kind = kind;
            this.requestedDiameterPx = requestedDiameterPx;
            setClickable(true);
            setFocusable(true);
        }

        @Override protected void onDraw(Canvas canvas) {
            super.onDraw(canvas);
            final float cx = getWidth() * 0.5f;
            // v0.1.38 moves only the rotate glyph another 1 physical px downward from v0.1.37,
            // leaving it 1 px above the shared toolbar baseline; the touch target is unchanged.
            final float cy = getHeight() * 0.5f - (kind == ROTATE ? 1.0f : 0.0f);
            final float density = getResources().getDisplayMetrics().density;
            // Keep touch targets/layout unchanged. Back/info remain at 0.49 of the original visual
            // size, overflow at 0.70, and rotate is 95% of its v0.1.36 size (0.49 * 0.95).
            final float visualScale = (kind == MORE) ? 0.70f : (kind == ROTATE ? 0.4655f : (kind == CHECK_LARGE ? 0.95f : 0.49f));
            final int iconSave = canvas.save();
            canvas.scale(visualScale, visualScale, cx, cy);
            paint.setColor(isEnabled() ? Color.WHITE : Color.rgb(90, 85, 85));
            paint.setStrokeCap(Paint.Cap.ROUND);
            paint.setStrokeJoin(Paint.Join.ROUND);

            if (kind == BACK) {
                paint.setStyle(Paint.Style.STROKE);
                paint.setStrokeWidth(2.7f * density);
                float halfH = 13f * density;
                float halfW = 8f * density;
                canvas.drawLine(cx + halfW * 0.55f, cy - halfH, cx - halfW, cy, paint);
                canvas.drawLine(cx - halfW, cy, cx + halfW * 0.55f, cy + halfH, paint);
                canvas.restoreToCount(iconSave);
                return;
            }

            if (kind == CHECK || kind == CHECK_LARGE) {
                // Two straight segments only: intentionally sharper than a font checkmark.
                paint.setStyle(Paint.Style.STROKE);
                paint.setStrokeWidth((kind == CHECK_LARGE ? 1.15f : 2.4f) * density);
                paint.setStrokeCap(Paint.Cap.SQUARE);
                paint.setStrokeJoin(Paint.Join.MITER);
                android.graphics.Path checkPath = new android.graphics.Path();
                checkPath.moveTo(cx - 8.0f * density, cy + 0.5f * density);
                checkPath.lineTo(cx - 2.0f * density, cy + 7.0f * density);
                checkPath.lineTo(cx + 10.0f * density, cy - 8.0f * density);
                canvas.drawPath(checkPath, paint);
                canvas.restoreToCount(iconSave);
                return;
            }

            if (kind == MORE) {
                paint.setStyle(Paint.Style.FILL);
                float r = 2.15f * density;
                canvas.drawCircle(cx, cy - 9f * density, r, paint);
                canvas.drawCircle(cx, cy, r, paint);
                canvas.drawCircle(cx, cy + 9f * density, r, paint);
                canvas.restoreToCount(iconSave);
                return;
            }

            // ROTATE and INFO use the exact same diameter and center.
            float diameter = Math.min(requestedDiameterPx, Math.min(getWidth(), getHeight()) - 4f * density);
            float radius = diameter * 0.5f;
            float stroke = 2.1f * density;
            paint.setStyle(Paint.Style.STROKE);
            paint.setStrokeWidth(stroke);

            if (kind == INFO) {
                canvas.drawCircle(cx, cy, radius - stroke * 0.5f, paint);
                paint.setStyle(Paint.Style.FILL);
                canvas.drawCircle(cx, cy - 7.2f * density, 1.7f * density, paint);
                paint.setStrokeWidth(2.2f * density);
                paint.setStrokeCap(Paint.Cap.ROUND);
                canvas.drawRoundRect(cx - 1.1f * density, cy - 1.5f * density,
                        cx + 1.1f * density, cy + 8.4f * density, 1.1f * density, 1.1f * density, paint);
                canvas.restoreToCount(iconSave);
                return;
            }

            float inset = stroke * 0.5f;
            arc.set(cx - radius + inset, cy - radius + inset, cx + radius - inset, cy + radius - inset);
            // Leave a deliberate gap at the top-right for the arrow head.
            canvas.drawArc(arc, 42f, 292f, false, paint);
            paint.setStyle(Paint.Style.FILL);
            android.graphics.Path arrow = new android.graphics.Path();
            float ax = cx + radius * 0.74f;
            float ay = cy - radius * 0.56f;
            arrow.moveTo(ax + 5.0f * density, ay - 4.2f * density);
            arrow.lineTo(ax + 4.0f * density, ay + 5.5f * density);
            arrow.lineTo(ax - 5.4f * density, ay + 2.7f * density);
            arrow.close();
            canvas.drawPath(arrow, paint);
            canvas.restoreToCount(iconSave);
        }
    }


    /** Dedicated crop surface: renders the current image, dimmed outside the crop rectangle. */
    private class RotationSliderView extends View {
        private final Paint trackPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint tickPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint knobPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint textPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private float degrees = 0f;
        private int stickySnap = Integer.MIN_VALUE;
        private static final float SNAP_ENTER_DEG = 7f;
        private static final float SNAP_RELEASE_DEG = 14f;

        RotationSliderView() {
            super(ViewerActivity.this);
            setClickable(true);
            trackPaint.setColor(Color.rgb(90, 85, 85));
            trackPaint.setStrokeWidth(dp(2));
            tickPaint.setColor(Color.rgb(190, 190, 198));
            tickPaint.setStrokeWidth(dp(1));
            knobPaint.setColor(Color.rgb(220, 225, 235));
            textPaint.setColor(Color.rgb(210, 210, 218));
            textPaint.setTextSize(dp(11));
            textPaint.setTextAlign(Paint.Align.CENTER);
        }

        void setDegrees(float value, boolean notify) {
            degrees = Math.max(-180f, Math.min(180f, value));
            if (notify && cropOverlayView != null) cropOverlayView.setFineRotation(degrees);
            invalidate();
        }

        private float trackLeft() { return dp(8); }
        private float trackRight() { return Math.max(trackLeft() + 1f, getWidth() - dp(8)); }
        private float valueForX(float x) {
            float t = (Math.max(trackLeft(), Math.min(trackRight(), x)) - trackLeft()) / Math.max(1f, trackRight() - trackLeft());
            return -180f + t * 360f;
        }
        private float xForValue(float value) {
            float t = (value + 180f) / 360f;
            return trackLeft() + t * (trackRight() - trackLeft());
        }

        private float applySnap(float raw) {
            if (stickySnap != Integer.MIN_VALUE) {
                if (Math.abs(raw - stickySnap) <= SNAP_RELEASE_DEG) return stickySnap;
                stickySnap = Integer.MIN_VALUE;
            }
            int nearest = Math.round(raw / 45f) * 45;
            nearest = Math.max(-180, Math.min(180, nearest));
            if (Math.abs(raw - nearest) <= SNAP_ENTER_DEG) {
                stickySnap = nearest;
                return nearest;
            }
            return raw;
        }

        @Override protected void onDraw(Canvas canvas) {
            super.onDraw(canvas);
            float y = getHeight() - dp(20);
            float left = trackLeft();
            float right = trackRight();
            canvas.drawLine(left, y, right, y, trackPaint);
            for (int mark = -180; mark <= 180; mark += 45) {
                float x = xForValue(mark);
                float h = mark % 90 == 0 ? dp(8) : dp(5);
                canvas.drawLine(x, y - h, x, y + h, tickPaint);
            }
            canvas.drawCircle(xForValue(degrees), y, dp(7), knobPaint);
            float labelY = dp(16);
            // Keep the end labels inside the view so glyphs are never clipped at either edge.
            float edgeLabelInset = dp(24);
            canvas.drawText("-180°", left + edgeLabelInset, labelY, textPaint);
            canvas.drawText("0°", xForValue(0f), labelY, textPaint);
            canvas.drawText("+180°", right - edgeLabelInset, labelY, textPaint);
            String current = String.format(Locale.ROOT, "%+.0f°", degrees);
            if (Math.abs(degrees) < 0.5f) current = "0°";
            textPaint.setTextAlign(Paint.Align.RIGHT);
            canvas.drawText(current, right, dp(36), textPaint);
            textPaint.setTextAlign(Paint.Align.CENTER);
        }

        @Override public boolean onTouchEvent(MotionEvent event) {
            int action = event.getActionMasked();
            if (action == MotionEvent.ACTION_DOWN) {
                getParent().requestDisallowInterceptTouchEvent(true);
                stickySnap = Integer.MIN_VALUE;
            }
            if (action == MotionEvent.ACTION_DOWN || action == MotionEvent.ACTION_MOVE) {
                float raw = valueForX(event.getX());
                float snapped = applySnap(raw);
                setDegrees(snapped, true);
                return true;
            }
            if (action == MotionEvent.ACTION_UP || action == MotionEvent.ACTION_CANCEL) {
                getParent().requestDisallowInterceptTouchEvent(false);
                AppLog.d(ViewerActivity.this, "CROP rotate slider=" + degrees);
                return true;
            }
            return true;
        }
    }

    private class WallpaperEditorView extends View {
        private final Drawable drawable;
        private final int baseRotationDegrees;
        private final Matrix matrix = new Matrix();
        private final RectF imageBounds = new RectF();
        private final RectF guideRect = new RectF();
        private final Paint dimPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint linePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private float offsetX = 0f;
        private float offsetY = 0f;
        private float lastX;
        private float lastY;

        WallpaperEditorView(Drawable drawable, int baseRotationDegrees) {
            super(ViewerActivity.this);
            this.drawable = drawable;
            this.baseRotationDegrees = ((baseRotationDegrees % 360) + 360) % 360;
            setBackgroundColor(Color.BLACK);
            setClickable(true);
            dimPaint.setColor(Color.argb(150, 0, 0, 0));
            linePaint.setColor(Color.WHITE);
            linePaint.setStyle(Paint.Style.STROKE);
            linePaint.setStrokeWidth(dp(1.6f));
        }

        @Override protected void onSizeChanged(int w, int h, int oldw, int oldh) {
            super.onSizeChanged(w, h, oldw, oldh);
            resetForModeChange();
        }

        void resetForModeChange() {
            offsetX = 0f;
            offsetY = 0f;
            updateGeometry();
            invalidate();
        }

        private void updateGeometry() {
            if (drawable == null || getWidth() <= 0 || getHeight() <= 0) return;
            float aspect = Math.max(0.05f, wallpaperTargetAspect());
            float maxW = Math.max(1f, getWidth() - dp(30));
            float maxH = Math.max(1f, getHeight() - dp(24));
            float gw = Math.min(maxW, maxH * aspect);
            float gh = gw / aspect;
            if (gh > maxH) { gh = maxH; gw = gh * aspect; }
            guideRect.set(getWidth() * 0.5f - gw * 0.5f, getHeight() * 0.5f - gh * 0.5f,
                    getWidth() * 0.5f + gw * 0.5f, getHeight() * 0.5f + gh * 0.5f);
            buildImageMatrix();

            float adjustX = 0f;
            float adjustY = 0f;
            if (imageBounds.left > guideRect.left) adjustX = guideRect.left - imageBounds.left;
            else if (imageBounds.right < guideRect.right) adjustX = guideRect.right - imageBounds.right;
            if (imageBounds.top > guideRect.top) adjustY = guideRect.top - imageBounds.top;
            else if (imageBounds.bottom < guideRect.bottom) adjustY = guideRect.bottom - imageBounds.bottom;
            if (Math.abs(adjustX) > 0.01f || Math.abs(adjustY) > 0.01f) {
                offsetX += adjustX;
                offsetY += adjustY;
                buildImageMatrix();
            }
        }

        private void buildImageMatrix() {
            int iw = Math.max(1, drawable.getIntrinsicWidth());
            int ih = Math.max(1, drawable.getIntrinsicHeight());
            float totalRotation = baseRotationDegrees + wallpaperRotationDegrees;
            matrix.reset();
            matrix.setRotate(totalRotation, iw * 0.5f, ih * 0.5f);
            RectF rotated = new RectF(0f, 0f, iw, ih);
            matrix.mapRect(rotated);
            float scale = Math.max(guideRect.width() / Math.max(1f, rotated.width()),
                    guideRect.height() / Math.max(1f, rotated.height()));
            scale *= 1.002f;
            matrix.postScale(scale, scale, rotated.centerX(), rotated.centerY());
            rotated.set(0f, 0f, iw, ih);
            matrix.mapRect(rotated);
            matrix.postTranslate(guideRect.centerX() + offsetX - rotated.centerX(),
                    guideRect.centerY() + offsetY - rotated.centerY());
            imageBounds.set(0f, 0f, iw, ih);
            matrix.mapRect(imageBounds);
        }

        RectF getNormalizedCrop() {
            updateGeometry();
            if (imageBounds.width() <= 1f || imageBounds.height() <= 1f || guideRect.isEmpty()) return null;
            RectF n = new RectF(
                    (guideRect.left - imageBounds.left) / imageBounds.width(),
                    (guideRect.top - imageBounds.top) / imageBounds.height(),
                    (guideRect.right - imageBounds.left) / imageBounds.width(),
                    (guideRect.bottom - imageBounds.top) / imageBounds.height());
            n.left = Math.max(0f, Math.min(1f, n.left));
            n.top = Math.max(0f, Math.min(1f, n.top));
            n.right = Math.max(n.left, Math.min(1f, n.right));
            n.bottom = Math.max(n.top, Math.min(1f, n.bottom));
            return n;
        }

        @Override protected void onDraw(Canvas canvas) {
            super.onDraw(canvas);
            if (drawable == null) return;
            updateGeometry();
            int save = canvas.save();
            canvas.concat(matrix);
            android.graphics.Rect old = new android.graphics.Rect(drawable.getBounds());
            drawable.setBounds(0, 0, Math.max(1, drawable.getIntrinsicWidth()), Math.max(1, drawable.getIntrinsicHeight()));
            drawable.draw(canvas);
            drawable.setBounds(old);
            canvas.restoreToCount(save);

            canvas.drawRect(0, 0, getWidth(), guideRect.top, dimPaint);
            canvas.drawRect(0, guideRect.bottom, getWidth(), getHeight(), dimPaint);
            canvas.drawRect(0, guideRect.top, guideRect.left, guideRect.bottom, dimPaint);
            canvas.drawRect(guideRect.right, guideRect.top, getWidth(), guideRect.bottom, dimPaint);
            canvas.drawRect(guideRect, linePaint);
            linePaint.setAlpha(170);
            float x1 = guideRect.left + guideRect.width() / 3f;
            float x2 = guideRect.left + guideRect.width() * 2f / 3f;
            float y1 = guideRect.top + guideRect.height() / 3f;
            float y2 = guideRect.top + guideRect.height() * 2f / 3f;
            canvas.drawLine(x1, guideRect.top, x1, guideRect.bottom, linePaint);
            canvas.drawLine(x2, guideRect.top, x2, guideRect.bottom, linePaint);
            canvas.drawLine(guideRect.left, y1, guideRect.right, y1, linePaint);
            canvas.drawLine(guideRect.left, y2, guideRect.right, y2, linePaint);
            linePaint.setAlpha(255);
            float corner = dp(18);
            canvas.drawLine(guideRect.left, guideRect.top, guideRect.left + corner, guideRect.top, linePaint);
            canvas.drawLine(guideRect.left, guideRect.top, guideRect.left, guideRect.top + corner, linePaint);
            canvas.drawLine(guideRect.right, guideRect.top, guideRect.right - corner, guideRect.top, linePaint);
            canvas.drawLine(guideRect.right, guideRect.top, guideRect.right, guideRect.top + corner, linePaint);
            canvas.drawLine(guideRect.left, guideRect.bottom, guideRect.left + corner, guideRect.bottom, linePaint);
            canvas.drawLine(guideRect.left, guideRect.bottom, guideRect.left, guideRect.bottom - corner, linePaint);
            canvas.drawLine(guideRect.right, guideRect.bottom, guideRect.right - corner, guideRect.bottom, linePaint);
            canvas.drawLine(guideRect.right, guideRect.bottom, guideRect.right, guideRect.bottom - corner, linePaint);
        }

        @Override public boolean onTouchEvent(MotionEvent event) {
            int action = event.getActionMasked();
            if (action == MotionEvent.ACTION_DOWN) {
                lastX = event.getX(); lastY = event.getY(); return true;
            }
            if (action == MotionEvent.ACTION_MOVE) {
                offsetX += event.getX() - lastX;
                offsetY += event.getY() - lastY;
                lastX = event.getX(); lastY = event.getY();
                updateGeometry(); invalidate(); return true;
            }
            return true;
        }
    }

    private class OverwriteToggleView extends View {
        private boolean checked = false;
        private Runnable listener;
        private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        OverwriteToggleView() { super(ViewerActivity.this); setClickable(true); setFocusable(true); setContentDescription("上書き許可"); setOnClickListener(v -> setChecked(!checked)); }
        boolean isChecked(){ return checked; }
        void setOnCheckedChanged(Runnable r){ listener=r; }
        void setChecked(boolean value){ if(checked==value)return; checked=value; invalidate(); if(listener!=null)listener.run(); }
        @Override protected void onDraw(Canvas c){
            super.onDraw(c); float h=getHeight(), w=getWidth(); float cy=h/2f; float radius=Math.min(h*0.34f,dp(9));
            p.setColor(checked?Color.rgb(119,85,0):Color.rgb(69,64,64));
            c.drawRoundRect(dp(2),cy-radius,w-dp(2),cy+radius,radius,radius,p);
            float knob=Math.min(h*0.42f,dp(10)); float cx=checked?(w-dp(3)-knob):(dp(3)+knob);
            p.setColor(Color.rgb(169,169,153)); c.drawCircle(cx,cy,knob,p);
        }
    }

    private class WallpaperRatioIconView extends View {
        private final Paint line = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint handle = new Paint(Paint.ANTI_ALIAS_FLAG);
        private int mode = 0;

        WallpaperRatioIconView(android.content.Context context) {
            super(context);
            setClickable(true);
            setFocusable(true);
            line.setColor(Color.WHITE);
            line.setStyle(Paint.Style.STROKE);
            line.setStrokeWidth(dp(1.7f));
            line.setStrokeCap(Paint.Cap.SQUARE);
            handle.setColor(Color.argb(175, 165, 165, 165));
            handle.setStyle(Paint.Style.FILL);
        }

        void setMode(int mode) {
            this.mode = Math.max(0, Math.min(2, mode));
            invalidate();
        }

        @Override protected void onDraw(Canvas canvas) {
            super.onDraw(canvas);
            float cx = getWidth() * 0.5f;
            float cy = getHeight() * 0.5f;
            float w = mode == 0 ? dp(21) : (mode == 1 ? dp(31) : dp(26));
            float h = mode == 0 ? dp(31) : (mode == 1 ? dp(21) : dp(26));
            RectF r = new RectF(cx - w * 0.5f, cy - h * 0.5f, cx + w * 0.5f, cy + h * 0.5f);
            canvas.drawRect(r, line);
            float x1 = r.left + r.width() / 3f;
            float x2 = r.left + r.width() * 2f / 3f;
            float y1 = r.top + r.height() / 3f;
            float y2 = r.top + r.height() * 2f / 3f;
            line.setAlpha(180);
            canvas.drawLine(x1, r.top, x1, r.bottom, line);
            canvas.drawLine(x2, r.top, x2, r.bottom, line);
            canvas.drawLine(r.left, y1, r.right, y1, line);
            canvas.drawLine(r.left, y2, r.right, y2, line);
            line.setAlpha(255);
            float hr = dp(4.3f);
            canvas.drawCircle(r.left, r.top, hr, handle);
            canvas.drawCircle(r.right, r.top, hr, handle);
            canvas.drawCircle(r.left, r.bottom, hr, handle);
            canvas.drawCircle(r.right, r.bottom, hr, handle);
        }
    }

    private class SlideshowStopView extends View {
        private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
        SlideshowStopView(android.content.Context context) { super(context); setClickable(true); setFocusable(true); }
        @Override protected void onDraw(Canvas canvas) {
            super.onDraw(canvas);
            float cx = getWidth() * 0.5f;
            float cy = getHeight() * 0.5f;
            float radius = Math.min(getWidth(), getHeight()) * 0.47f;
            paint.setStyle(Paint.Style.FILL);
            paint.setColor(Color.argb(155, 55, 55, 55));
            canvas.drawCircle(cx, cy, radius, paint);
            paint.setColor(Color.WHITE);
            float barW = Math.max(dp(7), getWidth() * 0.085f);
            float barH = getHeight() * 0.38f;
            float gap = getWidth() * 0.075f;
            canvas.drawRoundRect(cx - gap - barW, cy - barH * 0.5f, cx - gap, cy + barH * 0.5f,
                    barW * 0.20f, barW * 0.20f, paint);
            canvas.drawRoundRect(cx + gap, cy - barH * 0.5f, cx + gap + barW, cy + barH * 0.5f,
                    barW * 0.20f, barW * 0.20f, paint);
        }
    }

    private class CropOverlayView extends View {
        private static final int DRAG_NONE = 0;
        private static final int DRAG_MOVE = 1;
        private static final int DRAG_TL = 2;
        private static final int DRAG_TR = 3;
        private static final int DRAG_BR = 4;
        private static final int DRAG_BL = 5;

        private final Drawable drawable;
        private final int rotationDegrees;
        private final Matrix drawMatrix = new Matrix();
        private final RectF imageBounds = new RectF();
        private final RectF cropRect = new RectF();
        private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint dimPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint linePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint handlePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private int dragMode = DRAG_NONE;
        private float lastX;
        private float lastY;

        CropOverlayView(Drawable drawable, int rotationDegrees) {
            super(ViewerActivity.this);
            this.drawable = drawable;
            this.rotationDegrees = ((rotationDegrees % 360) + 360) % 360;
            setBackgroundColor(Color.BLACK);
            setClickable(true);
            dimPaint.setColor(Color.argb(155, 0, 0, 0));
            linePaint.setColor(Color.WHITE);
            linePaint.setStyle(Paint.Style.STROKE);
            linePaint.setStrokeWidth(dp(1.6f));
            handlePaint.setColor(Color.argb(210, 165, 165, 165));
            handlePaint.setStyle(Paint.Style.FILL);
        }

        @Override protected void onSizeChanged(int w, int h, int oldw, int oldh) {
            super.onSizeChanged(w, h, oldw, oldh);
            updateImageGeometry();
            resetForSelection();
        }

        private void updateImageGeometry() {
            if (drawable == null || getWidth() <= 0 || getHeight() <= 0) return;
            int iw = Math.max(1, drawable.getIntrinsicWidth());
            int ih = Math.max(1, drawable.getIntrinsicHeight());
            float totalRotation = rotationDegrees + cropFineRotationDegrees;
            drawMatrix.reset();
            drawMatrix.setRotate(totalRotation, iw / 2f, ih / 2f);
            RectF rotated = new RectF(0f, 0f, iw, ih);
            drawMatrix.mapRect(rotated);
            float availableW = Math.max(1f, getWidth() - dp(30));
            float availableH = Math.max(1f, getHeight() - dp(24));
            float scale = Math.min(availableW / Math.max(1f, rotated.width()),
                    availableH / Math.max(1f, rotated.height()));
            if (!Float.isFinite(scale) || scale <= 0f) scale = 1f;

            // In every crop mode except "全体", rotating must never resize or move the crop box.
            // Keep the screen-space cropRect untouched and enlarge only the image enough for all
            // four crop corners to stay inside the actual rotated image (not merely its AABB).
            if (cropRatioMode != CROP_RATIO_FULL && !cropRect.isEmpty()) {
                float coverScale = scaleNeededToCoverCrop(iw, ih, totalRotation);
                if (Float.isFinite(coverScale) && coverScale > scale) scale = coverScale;
            }

            drawMatrix.postScale(scale, scale, rotated.centerX(), rotated.centerY());
            rotated.set(0f, 0f, iw, ih);
            drawMatrix.mapRect(rotated);
            drawMatrix.postTranslate(getWidth() / 2f - rotated.centerX(), getHeight() / 2f - rotated.centerY());
            imageBounds.set(0f, 0f, iw, ih);
            drawMatrix.mapRect(imageBounds);
        }

        private float scaleNeededToCoverCrop(int iw, int ih, float totalRotationDegrees) {
            if (cropRect.isEmpty() || iw <= 0 || ih <= 0) return 0f;
            float cx = getWidth() * 0.5f;
            float cy = getHeight() * 0.5f;
            double radians = Math.toRadians(totalRotationDegrees);
            float cos = (float) Math.cos(radians);
            float sin = (float) Math.sin(radians);
            float halfW = Math.max(0.5f, iw * 0.5f);
            float halfH = Math.max(0.5f, ih * 0.5f);
            float required = 0f;
            float[] corners = new float[]{
                    cropRect.left, cropRect.top,
                    cropRect.right, cropRect.top,
                    cropRect.right, cropRect.bottom,
                    cropRect.left, cropRect.bottom
            };
            for (int i = 0; i < corners.length; i += 2) {
                float dx = corners[i] - cx;
                float dy = corners[i + 1] - cy;
                // Inverse-rotate the crop corner into the image's local axes. The uniform scale
                // needed to contain that point is the larger requirement of the two source axes.
                float localX = cos * dx + sin * dy;
                float localY = -sin * dx + cos * dy;
                required = Math.max(required, Math.abs(localX) / halfW);
                required = Math.max(required, Math.abs(localY) / halfH);
            }
            // Tiny safety margin prevents antialiasing from exposing a one-pixel black seam.
            return required * 1.002f;
        }

        void resetForSelection() {
            updateImageGeometry();
            if (imageBounds.width() <= 1f || imageBounds.height() <= 1f) return;
            if (cropRatioMode == CROP_RATIO_FULL) {
                cropRect.set(imageBounds);
                invalidate();
                AppLog.d(ViewerActivity.this, "CROP reset mode=full");
                return;
            }
            if (cropRatioMode == CROP_RATIO_FREE && !cropRect.isEmpty()) {
                fitExistingCropIntoImageBounds();
                invalidate();
                AppLog.d(ViewerActivity.this, "CROP reset mode=free preserve");
                return;
            }
            float aspect = Math.max(0.05f, currentCropAspect());
            float maxW = imageBounds.width();
            float maxH = imageBounds.height();
            float w = Math.min(maxW, maxH * aspect);
            float h = w / aspect;
            if (h > maxH) {
                h = maxH;
                w = h * aspect;
            }
            float cx = imageBounds.centerX();
            float cy = imageBounds.centerY();
            cropRect.set(cx - w / 2f, cy - h / 2f, cx + w / 2f, cy + h / 2f);
            invalidate();
            AppLog.d(ViewerActivity.this, "CROP reset mode=" + cropRatioMode +
                    " portrait=" + cropPortrait + " aspect=" + aspect);
        }

        void setNormalizedCrop(RectF normalizedCrop) {
            updateImageGeometry();
            if (normalizedCrop == null || imageBounds.width() <= 1f || imageBounds.height() <= 1f) {
                resetForSelection();
                return;
            }
            RectF n = new RectF(normalizedCrop);
            n.left = Math.max(0f, Math.min(1f, n.left));
            n.top = Math.max(0f, Math.min(1f, n.top));
            n.right = Math.max(n.left, Math.min(1f, n.right));
            n.bottom = Math.max(n.top, Math.min(1f, n.bottom));
            cropRect.set(
                    imageBounds.left + n.left * imageBounds.width(),
                    imageBounds.top + n.top * imageBounds.height(),
                    imageBounds.left + n.right * imageBounds.width(),
                    imageBounds.top + n.bottom * imageBounds.height());
            clampCropToImage();
            invalidate();
        }

        float getCurrentAspect() {
            return cropRect.height() <= 1f ? 1f : cropRect.width() / cropRect.height();
        }

        void setFineRotation(float degrees) {
            cropFineRotationDegrees = Math.max(-180f, Math.min(180f, degrees));
            updateImageGeometry();
            if (cropRatioMode == CROP_RATIO_FULL) {
                cropRect.set(imageBounds);
            }
            // Non-full modes deliberately leave cropRect byte-for-byte untouched here.
            // updateImageGeometry() grows only the image when the rotated content needs more room.
            invalidate();
        }

        private void fitExistingCropIntoImageBounds() {
            if (imageBounds.width() <= 1f || imageBounds.height() <= 1f) return;
            if (cropRect.isEmpty()) {
                cropRect.set(imageBounds);
                return;
            }
            float scale = Math.min(1f, Math.min(
                    imageBounds.width() / Math.max(1f, cropRect.width()),
                    imageBounds.height() / Math.max(1f, cropRect.height())));
            if (scale < 1f) {
                float cx = cropRect.centerX();
                float cy = cropRect.centerY();
                float halfW = cropRect.width() * scale * 0.5f;
                float halfH = cropRect.height() * scale * 0.5f;
                cropRect.set(cx - halfW, cy - halfH, cx + halfW, cy + halfH);
            }
            float dx = 0f;
            float dy = 0f;
            if (cropRect.left < imageBounds.left) dx = imageBounds.left - cropRect.left;
            else if (cropRect.right > imageBounds.right) dx = imageBounds.right - cropRect.right;
            if (cropRect.top < imageBounds.top) dy = imageBounds.top - cropRect.top;
            else if (cropRect.bottom > imageBounds.bottom) dy = imageBounds.bottom - cropRect.bottom;
            cropRect.offset(dx, dy);
            clampCropToImage();
        }

        RectF getNormalizedCrop() {
            if (imageBounds.width() <= 1f || imageBounds.height() <= 1f || cropRect.width() <= 1f || cropRect.height() <= 1f) return null;
            RectF n = new RectF(
                    (cropRect.left - imageBounds.left) / imageBounds.width(),
                    (cropRect.top - imageBounds.top) / imageBounds.height(),
                    (cropRect.right - imageBounds.left) / imageBounds.width(),
                    (cropRect.bottom - imageBounds.top) / imageBounds.height());
            n.left = Math.max(0f, Math.min(1f, n.left));
            n.top = Math.max(0f, Math.min(1f, n.top));
            n.right = Math.max(n.left, Math.min(1f, n.right));
            n.bottom = Math.max(n.top, Math.min(1f, n.bottom));
            return n;
        }

        @Override protected void onDraw(Canvas canvas) {
            super.onDraw(canvas);
            if (drawable == null) return;
            updateImageGeometry();
            if (cropRect.isEmpty()) resetForSelection();

            int save = canvas.save();
            canvas.concat(drawMatrix);
            android.graphics.Rect oldBounds = new android.graphics.Rect(drawable.getBounds());
            drawable.setBounds(0, 0, Math.max(1, drawable.getIntrinsicWidth()), Math.max(1, drawable.getIntrinsicHeight()));
            drawable.draw(canvas);
            drawable.setBounds(oldBounds);
            canvas.restoreToCount(save);

            canvas.drawRect(imageBounds.left, imageBounds.top, imageBounds.right, cropRect.top, dimPaint);
            canvas.drawRect(imageBounds.left, cropRect.bottom, imageBounds.right, imageBounds.bottom, dimPaint);
            canvas.drawRect(imageBounds.left, cropRect.top, cropRect.left, cropRect.bottom, dimPaint);
            canvas.drawRect(cropRect.right, cropRect.top, imageBounds.right, cropRect.bottom, dimPaint);

            canvas.drawRect(cropRect, linePaint);
            float x1 = cropRect.left + cropRect.width() / 3f;
            float x2 = cropRect.left + cropRect.width() * 2f / 3f;
            float y1 = cropRect.top + cropRect.height() / 3f;
            float y2 = cropRect.top + cropRect.height() * 2f / 3f;
            linePaint.setAlpha(180);
            canvas.drawLine(x1, cropRect.top, x1, cropRect.bottom, linePaint);
            canvas.drawLine(x2, cropRect.top, x2, cropRect.bottom, linePaint);
            canvas.drawLine(cropRect.left, y1, cropRect.right, y1, linePaint);
            canvas.drawLine(cropRect.left, y2, cropRect.right, y2, linePaint);
            linePaint.setAlpha(255);

            float r = dp(13);
            canvas.drawCircle(cropRect.left, cropRect.top, r, handlePaint);
            canvas.drawCircle(cropRect.right, cropRect.top, r, handlePaint);
            canvas.drawCircle(cropRect.right, cropRect.bottom, r, handlePaint);
            canvas.drawCircle(cropRect.left, cropRect.bottom, r, handlePaint);
        }

        @Override public boolean onTouchEvent(MotionEvent event) {
            if (imageBounds.isEmpty() || cropRect.isEmpty()) return true;
            if (cropRatioMode == CROP_RATIO_FULL) return true;
            float x = event.getX();
            float y = event.getY();
            int action = event.getActionMasked();
            if (action == MotionEvent.ACTION_DOWN) {
                dragMode = hitTest(x, y);
                lastX = x;
                lastY = y;
                return true;
            }
            if (action == MotionEvent.ACTION_MOVE) {
                if (dragMode == DRAG_MOVE) {
                    moveCrop(x - lastX, y - lastY);
                } else if (dragMode >= DRAG_TL) {
                    resizeCrop(dragMode, x, y);
                }
                lastX = x;
                lastY = y;
                invalidate();
                return true;
            }
            if (action == MotionEvent.ACTION_UP || action == MotionEvent.ACTION_CANCEL) {
                if (dragMode != DRAG_NONE) {
                    AppLog.d(ViewerActivity.this, "CROP rect=" + getNormalizedCrop());
                }
                dragMode = DRAG_NONE;
                return true;
            }
            return true;
        }

        private int hitTest(float x, float y) {
            float hit = dp(30);
            if (distanceTo(x, y, cropRect.left, cropRect.top) <= hit) return DRAG_TL;
            if (distanceTo(x, y, cropRect.right, cropRect.top) <= hit) return DRAG_TR;
            if (distanceTo(x, y, cropRect.right, cropRect.bottom) <= hit) return DRAG_BR;
            if (distanceTo(x, y, cropRect.left, cropRect.bottom) <= hit) return DRAG_BL;
            return cropRect.contains(x, y) ? DRAG_MOVE : DRAG_NONE;
        }

        private float distanceTo(float x1, float y1, float x2, float y2) {
            float dx = x1 - x2;
            float dy = y1 - y2;
            return (float)Math.sqrt(dx * dx + dy * dy);
        }

        private void moveCrop(float dx, float dy) {
            float targetLeft = cropRect.left + dx;
            float targetTop = cropRect.top + dy;
            if (targetLeft < imageBounds.left) dx += imageBounds.left - targetLeft;
            if (cropRect.right + dx > imageBounds.right) dx -= cropRect.right + dx - imageBounds.right;
            if (targetTop < imageBounds.top) dy += imageBounds.top - targetTop;
            if (cropRect.bottom + dy > imageBounds.bottom) dy -= cropRect.bottom + dy - imageBounds.bottom;
            cropRect.offset(dx, dy);
        }

        private void resizeCrop(int corner, float x, float y) {
            x = Math.max(imageBounds.left, Math.min(imageBounds.right, x));
            y = Math.max(imageBounds.top, Math.min(imageBounds.bottom, y));
            float min = dp(56);
            if (!cropAspectLocked()) {
                if (corner == DRAG_TL) {
                    cropRect.left = Math.min(x, cropRect.right - min);
                    cropRect.top = Math.min(y, cropRect.bottom - min);
                } else if (corner == DRAG_TR) {
                    cropRect.right = Math.max(x, cropRect.left + min);
                    cropRect.top = Math.min(y, cropRect.bottom - min);
                } else if (corner == DRAG_BR) {
                    cropRect.right = Math.max(x, cropRect.left + min);
                    cropRect.bottom = Math.max(y, cropRect.top + min);
                } else if (corner == DRAG_BL) {
                    cropRect.left = Math.min(x, cropRect.right - min);
                    cropRect.bottom = Math.max(y, cropRect.top + min);
                }
                clampCropToImage();
                return;
            }

            float aspect = Math.max(0.05f, currentCropAspect());
            float ax;
            float ay;
            float sx;
            float sy;
            if (corner == DRAG_TL) { ax = cropRect.right; ay = cropRect.bottom; sx = -1f; sy = -1f; }
            else if (corner == DRAG_TR) { ax = cropRect.left; ay = cropRect.bottom; sx = 1f; sy = -1f; }
            else if (corner == DRAG_BR) { ax = cropRect.left; ay = cropRect.top; sx = 1f; sy = 1f; }
            else { ax = cropRect.right; ay = cropRect.top; sx = -1f; sy = 1f; }

            float wantedW = Math.max(min, Math.abs(x - ax));
            float wantedH = Math.max(min, Math.abs(y - ay));
            float w = Math.max(wantedW, wantedH * aspect);
            float h = w / aspect;
            float maxW = sx > 0f ? imageBounds.right - ax : ax - imageBounds.left;
            float maxH = sy > 0f ? imageBounds.bottom - ay : ay - imageBounds.top;
            float factor = Math.min(1f, Math.min(maxW / Math.max(1f, w), maxH / Math.max(1f, h)));
            w *= factor;
            h *= factor;
            if (w < min || h < min) return;
            float bx = ax + sx * w;
            float by = ay + sy * h;
            cropRect.set(Math.min(ax, bx), Math.min(ay, by), Math.max(ax, bx), Math.max(ay, by));
            clampCropToImage();
        }

        private void clampCropToImage() {
            cropRect.left = Math.max(imageBounds.left, cropRect.left);
            cropRect.top = Math.max(imageBounds.top, cropRect.top);
            cropRect.right = Math.min(imageBounds.right, cropRect.right);
            cropRect.bottom = Math.min(imageBounds.bottom, cropRect.bottom);
        }
    }

    /** Lightweight zoom/pan/page view. No external image-view dependency: keeps Chirami small and startup cheap. */
    private class ZoomImageView extends ImageView {
        interface PageListener { boolean canPage(int direction); void onPageDrag(int direction, float translationX); void onPageReset(); void onPage(int direction, float velocityX); void onSingleTap(); }
        private PageListener pageListener;
        private final Matrix matrix = new Matrix();
        private final float[] values = new float[9];
        private final ScaleGestureDetector scaleDetector;
        private static final float MIN_USER_SCALE = 0.001f;
        private float fitScale = 1f;
        private float userScale = 1f;
        private int viewerRotationDegrees = 0;
        private float lastX, lastY, downX, downY;
        private long lastTapUp = 0;
        private float lastTapX, lastTapY;
        private boolean secondTap = false;
        private boolean doubleTapZoomDrag = false;
        private float doubleTapStartY, doubleTapStartScale;
        private boolean paging = false;
        private boolean moved = false;
        private VelocityTracker velocityTracker;
        private final int touchSlop = ViewConfiguration.get(ViewerActivity.this).getScaledTouchSlop();
        private Runnable pendingSingleTap;

        ZoomImageView() {
            super(ViewerActivity.this);
            setScaleType(ScaleType.MATRIX);
            setClickable(true);
            scaleDetector = new ScaleGestureDetector(ViewerActivity.this, new ScaleGestureDetector.SimpleOnScaleGestureListener() {
                @Override public boolean onScaleBegin(ScaleGestureDetector detector) { paging = false; cancelSingleTap(); if (zoomAnimator != null) zoomAnimator.cancel(); return true; }
                @Override public boolean onScale(ScaleGestureDetector detector) {
                    float factor = detector.getScaleFactor();
                    setUserScale(userScale * factor, detector.getFocusX(), detector.getFocusY());
                    return true;
                }
            });
        }

        void setPageListener(PageListener listener) { pageListener = listener; }

        void setImageForViewer(Drawable drawable) {
            setTranslationX(0f); setAlpha(1f);
            setImageForViewerKeepingTranslation(drawable);
        }

        void setImageForViewerKeepingTranslation(Drawable drawable) {
            viewerRotationDegrees = pendingRotationDegrees;
            super.setImageDrawable(drawable);
            // Compute the final FIT matrix synchronously whenever the view is measured.
            // This prevents a temporary frame rendered with the previous image's matrix.
            if (getWidth() > 0 && getHeight() > 0) resetToFit();
            else post(this::resetToFit);
        }

        private void resetToFit() { resetToFit(1f); }

        private void resetToFit(float zoomMultiplier) {
            Drawable d = getDrawable(); if (d == null || getWidth() <= 0 || getHeight() <= 0) return;
            int iw = Math.max(1, d.getIntrinsicWidth()); int ih = Math.max(1, d.getIntrinsicHeight());
            fitScale = fitScaleForViewerRotation(viewerRotationDegrees);
            if (!Float.isFinite(fitScale) || fitScale <= 0f) fitScale = 1f;

            matrix.reset();
            matrix.setRotate(viewerRotationDegrees, iw / 2f, ih / 2f);
            RectF bounds = new RectF(0, 0, iw, ih);
            matrix.mapRect(bounds);
            matrix.postScale(fitScale, fitScale, bounds.centerX(), bounds.centerY());
            bounds.set(0, 0, iw, ih);
            matrix.mapRect(bounds);
            matrix.postTranslate(getWidth() / 2f - bounds.centerX(), getHeight() / 2f - bounds.centerY());

            float zoom = Math.max(MIN_USER_SCALE, zoomMultiplier);
            userScale = fitScale;
            if (Math.abs(zoom - 1f) > 0.0001f) {
                matrix.postScale(zoom, zoom, getWidth() / 2f, getHeight() / 2f);
                userScale = fitScale * zoom;
                constrain();
            }
            setImageMatrix(matrix);
            notifyImageBoundsChanged();
        }

        float fitScaleForViewerRotation(int degrees) {
            Drawable d = getDrawable();
            if (d == null || getWidth() <= 0 || getHeight() <= 0) return fitScale;
            int iw = Math.max(1, d.getIntrinsicWidth());
            int ih = Math.max(1, d.getIntrinsicHeight());
            int normalized = ((degrees % 360) + 360) % 360;
            float rw = (normalized % 180 == 0) ? iw : ih;
            float rh = (normalized % 180 == 0) ? ih : iw;
            float result = Math.min(getWidth() / rw, getHeight() / rh);
            return (!Float.isFinite(result) || result <= 0f) ? 1f : result;
        }

        float getViewerFitScale() { return fitScale; }

        float getViewerZoomMultiplier() {
            if (!Float.isFinite(fitScale) || fitScale <= 0f) return 1f;
            float value = userScale / fitScale;
            return (!Float.isFinite(value) || value <= 0f) ? 1f : Math.max(MIN_USER_SCALE, value);
        }

        void commitViewerRotation(int degrees, float zoomMultiplier) {
            viewerRotationDegrees = ((degrees % 360) + 360) % 360;
            resetToFit(zoomMultiplier);
        }

        void notifyImageBoundsChanged() {
            Drawable d = getDrawable(); if (d == null) return;
            RectF r = new RectF(0, 0, Math.max(1,d.getIntrinsicWidth()), Math.max(1,d.getIntrinsicHeight()));
            matrix.mapRect(r);
            ViewerActivity.this.updateChromeShadeBounds(r);
        }

        private void setUserScale(float target, float focusX, float focusY) {
            float max = Math.max(8f, fitScale * 12f);
            target = Math.max(MIN_USER_SCALE, Math.min(max, target));
            float safeCurrent = Math.max(MIN_USER_SCALE, userScale);
            float factor = target / safeCurrent;
            matrix.postScale(factor, factor, focusX, focusY);
            userScale = target;
            constrain(); setImageMatrix(matrix);
        }

        // At-or-below FIT keeps one-finger horizontal swipes available for paging.
        private boolean isAtFit() { return userScale <= fitScale * 1.015f; }

        private boolean isExactlyFit() {
            return Math.abs(userScale - fitScale) < Math.max(0.002f, fitScale * 0.015f);
        }

        private ValueAnimator zoomAnimator;

        private void toggleOriginal(float x, float y) {
            final float start = userScale;
            final boolean fromFit = isExactlyFit();
            // Double tap is a strict 1:1 <-> FIT toggle. From any free pinch scale, return to FIT.
            final float target = fromFit ? 1f : fitScale;
            if (Math.abs(target - start) < 0.001f) return;
            if (zoomAnimator != null) zoomAnimator.cancel();
            zoomAnimator = ValueAnimator.ofFloat(start, target);
            zoomAnimator.setDuration(210L);
            zoomAnimator.setInterpolator(new DecelerateInterpolator(1.8f));
            zoomAnimator.addUpdateListener(a -> setUserScale((float)a.getAnimatedValue(), x, y));
            zoomAnimator.addListener(new android.animation.AnimatorListenerAdapter() {
                @Override public void onAnimationEnd(android.animation.Animator animation) {
                    if (!fromFit) resetToFit();
                    zoomAnimator = null;
                }
                @Override public void onAnimationCancel(android.animation.Animator animation) { zoomAnimator = null; }
            });
            zoomAnimator.start();
            AppLog.d(ViewerActivity.this, "ZOOM doubleTap animate " + start + " -> " + target +
                    " fit=" + fitScale + " mode=" + (fromFit ? "ORIGINAL_1X" : "FIT"));
        }

        private void pan(float dx, float dy) { matrix.postTranslate(dx, dy); constrain(); setImageMatrix(matrix); }

        private void constrain() {
            Drawable d = getDrawable(); if (d == null) return;
            RectF r = new RectF(0, 0, Math.max(1,d.getIntrinsicWidth()), Math.max(1,d.getIntrinsicHeight())); matrix.mapRect(r);
            float dx = 0, dy = 0;
            if (r.width() <= getWidth()) dx = getWidth()/2f - r.centerX(); else if (r.left > 0) dx = -r.left; else if (r.right < getWidth()) dx = getWidth() - r.right;
            if (r.height() <= getHeight()) dy = getHeight()/2f - r.centerY(); else if (r.top > 0) dy = -r.top; else if (r.bottom < getHeight()) dy = getHeight() - r.bottom;
            matrix.postTranslate(dx, dy);
            notifyImageBoundsChanged();
        }

        @Override public boolean onTouchEvent(MotionEvent e) {
            if (pageAnimating) return true;
            scaleDetector.onTouchEvent(e);
            int action = e.getActionMasked();
            if (action == MotionEvent.ACTION_DOWN) {
                ViewerActivity.this.cancelPageAnimationsForTouch();
                if (velocityTracker != null) velocityTracker.recycle(); velocityTracker = VelocityTracker.obtain(); velocityTracker.addMovement(e);
                downX = lastX = e.getX(); downY = lastY = e.getY(); moved = false; paging = false;
                long now = SystemClock.uptimeMillis();
                secondTap = (now - lastTapUp <= DOUBLE_TAP_MS && distance(e.getX(), e.getY(), lastTapX, lastTapY) < dp(48));
                if (secondTap) { cancelSingleTap(); doubleTapZoomDrag = false; doubleTapStartY = e.getY(); doubleTapStartScale = userScale; }
                return true;
            }
            if (velocityTracker != null) velocityTracker.addMovement(e);
            if (action == MotionEvent.ACTION_MOVE) {
                float x=e.getX(), y=e.getY(); float dx=x-lastX, dy=y-lastY;
                if (Math.abs(x-downX)>touchSlop || Math.abs(y-downY)>touchSlop) moved=true;
                if (secondTap && !scaleDetector.isInProgress()) {
                    float totalY = y-doubleTapStartY;
                    if (Math.abs(totalY) > touchSlop) {
                        doubleTapZoomDrag = true;
                        // Up = zoom in, down = zoom out. Exponential response feels natural over the whole screen.
                        float factor = (float)Math.exp(-totalY / Math.max(220f, getHeight()*0.42f));
                        setUserScale(doubleTapStartScale * factor, downX, downY);
                    }
                } else if (scaleDetector.isInProgress()) {
                    // handled by ScaleGestureDetector
                } else if (!isAtFit()) {
                    pan(dx, dy);
                } else {
                    float totalX=x-downX, totalY=y-downY;
                    if (!paging && Math.abs(totalX)>touchSlop && Math.abs(totalX)>Math.abs(totalY)*1.15f) paging=true;
                    if (paging) {
                        int direction = totalX < 0 ? 1 : -1;
                        float resistance = (pageListener != null && pageListener.canPage(direction)) ? 1f : 0.23f;
                        float translation = totalX * resistance;
                        setTranslationX(translation);
                        if (pageListener != null) pageListener.onPageDrag(direction, translation);
                    }
                }
                lastX=x; lastY=y; return true;
            }
            if (action == MotionEvent.ACTION_UP || action == MotionEvent.ACTION_CANCEL) {
                float vx=0f; if (velocityTracker != null) { velocityTracker.computeCurrentVelocity(1000); vx=velocityTracker.getXVelocity(); velocityTracker.recycle(); velocityTracker=null; }
                if (secondTap) {
                    if (!doubleTapZoomDrag && action==MotionEvent.ACTION_UP) toggleOriginal(e.getX(), e.getY());
                    AppLog.d(ViewerActivity.this, doubleTapZoomDrag ? "ZOOM doubleTapHold end scale="+userScale : "ZOOM doubleTap toggle scale="+userScale);
                    secondTap=false; doubleTapZoomDrag=false; setTranslationX(0f); return true;
                }
                if (paging) {
                    float tx=getTranslationX(); int direction = tx<0 ? 1 : -1;
                    boolean commit = Math.abs(tx) > getWidth()*0.12f || Math.abs(vx)>550f;
                    if (commit && pageListener != null && pageListener.canPage(direction)) pageListener.onPage(direction, vx);
                    else {
                        if (pageListener != null) pageListener.onPageReset();
                        else animate().translationX(0f).setDuration(150).start();
                    }
                    paging=false; return true;
                }
                if (!moved && action==MotionEvent.ACTION_UP && !scaleDetector.isInProgress()) {
                    lastTapUp=SystemClock.uptimeMillis(); lastTapX=e.getX(); lastTapY=e.getY();
                    scheduleSingleTap();
                }
                return true;
            }
            return true;
        }

        private void scheduleSingleTap() {
            cancelSingleTap();
            pendingSingleTap = () -> { pendingSingleTap=null; if (pageListener!=null) pageListener.onSingleTap(); };
            mainHandler.postDelayed(pendingSingleTap, DOUBLE_TAP_MS + 20);
        }
        private void cancelSingleTap() { if (pendingSingleTap != null) { mainHandler.removeCallbacks(pendingSingleTap); pendingSingleTap=null; } }
        private float distance(float x1,float y1,float x2,float y2) { float dx=x1-x2, dy=y1-y2; return (float)Math.sqrt(dx*dx+dy*dy); }
    }
}
