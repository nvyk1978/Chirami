package com.chirami.viewer;

import android.Manifest;
import android.app.Activity;
import android.content.ContentUris;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.ImageDecoder;
import android.graphics.Matrix;
import android.graphics.RectF;
import android.graphics.drawable.AnimatedImageDrawable;
import android.graphics.drawable.Drawable;
import android.graphics.pdf.PdfRenderer;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.ParcelFileDescriptor;
import android.os.SystemClock;
import android.provider.MediaStore;
import android.provider.OpenableColumns;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.ScaleGestureDetector;
import android.view.VelocityTracker;
import android.view.View;
import android.view.ViewConfiguration;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicInteger;

public class ViewerActivity extends Activity {
    private static final int REQ_MEDIA = 1001;
    private static final long DOUBLE_TAP_MS = 300;

    private LinearLayout topBar;
    private LinearLayout bottomBar;
    private ZoomImageView imageView;
    private TextView titleView;
    private TextView pageView;

    private ParcelFileDescriptor pdfFd;
    private PdfRenderer pdfRenderer;
    private PdfRenderer.Page pdfPage;

    private final List<MediaItem> siblings = new ArrayList<>();
    private int currentIndex = -1;
    private Uri currentUri;
    private String currentMime;
    private String currentName;

    private final ExecutorService decodeExecutor = Executors.newSingleThreadExecutor();
    private final ExecutorService scanExecutor = Executors.newSingleThreadExecutor();
    private final Handler mainHandler = new Handler(Looper.getMainLooper());
    private final AtomicInteger decodeGeneration = new AtomicInteger();
    private long launchStartedMs;
    private boolean firstFrameLogged = false;
    private boolean pageAnimating = false;

    private static class MediaItem {
        final Uri uri;
        final String name;
        final String mime;
        MediaItem(Uri uri, String name, String mime) {
            this.uri = uri; this.name = name; this.mime = mime;
        }
    }

    private int dp(float value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        launchStartedMs = SystemClock.elapsedRealtime();
        super.onCreate(savedInstanceState);
        AppLog.d(this, "VIEWER onCreate action=" + getIntent().getAction() + " type=" + getIntent().getType() + " data=" + getIntent().getData());
        getWindow().setStatusBarColor(Color.BLACK);
        getWindow().setNavigationBarColor(Color.BLACK);
        buildUi();

        Uri uri = getIntent().getData();
        if (uri == null) {
            AppLog.d(this, "VIEWER no URI");
            Toast.makeText(this, "ファイルを開けませんでした", Toast.LENGTH_SHORT).show();
            finish();
            return;
        }

        currentUri = uri;
        currentName = resolveDisplayName(uri);
        currentMime = getIntent().getType();
        if (currentMime == null) currentMime = getContentResolver().getType(uri);
        AppLog.d(this, "VIEWER open +" + elapsed() + "ms name=" + currentName + " mime=" + currentMime + " uri=" + currentUri);

        // Most important rule in Chirami: render the tapped file first. Folder scanning is never allowed to delay it.
        showCurrentUri(false, 0);

        if (!isPdf(currentMime, uri)) {
            if (hasMediaPermission()) discoverSiblingImagesAsync();
            else requestMediaPermission();
        }
    }

    private long elapsed() { return SystemClock.elapsedRealtime() - launchStartedMs; }

    private void buildUi() {
        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(Color.BLACK);

        imageView = new ZoomImageView();
        imageView.setBackgroundColor(Color.BLACK);
        imageView.setPageListener(new ZoomImageView.PageListener() {
            @Override public boolean canPage(int direction) { return canMoveSibling(direction); }
            @Override public void onPage(int direction, float velocityX) { animateToSibling(direction, velocityX); }
            @Override public void onSingleTap() { toggleChrome(); }
        });
        root.addView(imageView, new FrameLayout.LayoutParams(-1, -1));

        topBar = new LinearLayout(this);
        topBar.setOrientation(LinearLayout.HORIZONTAL);
        topBar.setGravity(Gravity.CENTER_VERTICAL);
        topBar.setPadding(dp(8), 0, dp(8), 0);
        topBar.setBackgroundColor(Color.argb(118, 0, 0, 0));

        TextView back = new TextView(this);
        back.setText("‹"); back.setTextColor(Color.WHITE); back.setTextSize(42); back.setGravity(Gravity.CENTER);
        back.setOnClickListener(v -> finish());
        topBar.addView(back, new LinearLayout.LayoutParams(dp(48), dp(60)));

        titleView = new TextView(this);
        titleView.setTextColor(Color.WHITE); titleView.setTextSize(19); titleView.setSingleLine(true);
        titleView.setEllipsize(android.text.TextUtils.TruncateAt.END); titleView.setGravity(Gravity.CENTER_VERTICAL);
        topBar.addView(titleView, new LinearLayout.LayoutParams(0, dp(60), 1f));

        pageView = new TextView(this);
        pageView.setTextColor(Color.WHITE); pageView.setTextSize(12); pageView.setGravity(Gravity.CENTER);
        topBar.addView(pageView, new LinearLayout.LayoutParams(dp(62), dp(60)));

        TextView info = new TextView(this);
        info.setText("ⓘ"); info.setTextColor(Color.WHITE); info.setTextSize(27); info.setGravity(Gravity.CENTER);
        info.setOnClickListener(v -> Toast.makeText(this, currentName == null ? "" : currentName, Toast.LENGTH_SHORT).show());
        topBar.addView(info, new LinearLayout.LayoutParams(dp(46), dp(60)));

        TextView more = new TextView(this);
        more.setText("⋮"); more.setTextColor(Color.WHITE); more.setTextSize(30); more.setGravity(Gravity.CENTER);
        more.setOnClickListener(v -> Toast.makeText(this, "リネーム・回転・リサイズ・トリミングは順次追加します", Toast.LENGTH_SHORT).show());
        topBar.addView(more, new LinearLayout.LayoutParams(dp(42), dp(60)));
        root.addView(topBar, new FrameLayout.LayoutParams(-1, dp(60), Gravity.TOP));

        bottomBar = new LinearLayout(this);
        bottomBar.setOrientation(LinearLayout.HORIZONTAL); bottomBar.setGravity(Gravity.CENTER);
        bottomBar.setPadding(dp(38), 0, dp(38), 0); bottomBar.setBackgroundColor(Color.argb(118, 0, 0, 0));

        TextView edit = makeBottomAction("✎", "編集");
        edit.setOnClickListener(v -> Toast.makeText(this, "注釈・編集は次の段階で追加します", Toast.LENGTH_SHORT).show());
        bottomBar.addView(edit, new LinearLayout.LayoutParams(0, dp(72), 1f));

        TextView share = makeBottomAction("↗", "共有");
        share.setOnClickListener(v -> shareCurrent());
        bottomBar.addView(share, new LinearLayout.LayoutParams(0, dp(72), 1f));

        TextView delete = makeBottomAction("⌫", "削除");
        delete.setOnClickListener(v -> Toast.makeText(this, "削除は確認ダイアログ付きで追加します", Toast.LENGTH_SHORT).show());
        bottomBar.addView(delete, new LinearLayout.LayoutParams(0, dp(72), 1f));
        root.addView(bottomBar, new FrameLayout.LayoutParams(-1, dp(72), Gravity.BOTTOM));

        setContentView(root);
        AppLog.d(this, "VIEWER UI ready +" + elapsed() + "ms");
    }

    private TextView makeBottomAction(String icon, String label) {
        TextView view = new TextView(this);
        view.setText(icon + "\n" + label); view.setTextColor(Color.WHITE); view.setTextSize(13);
        view.setGravity(Gravity.CENTER); view.setLines(2); return view;
    }

    private void toggleChrome() {
        boolean showing = topBar.getVisibility() == View.VISIBLE;
        topBar.setVisibility(showing ? View.GONE : View.VISIBLE);
        bottomBar.setVisibility(showing ? View.GONE : View.VISIBLE);
        if (showing) {
            getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_FULLSCREEN | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION);
        } else {
            getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_VISIBLE);
        }
    }

    private void shareCurrent() {
        if (currentUri == null) return;
        try {
            android.content.Intent share = new android.content.Intent(android.content.Intent.ACTION_SEND);
            share.setType(currentMime == null ? "image/*" : currentMime);
            share.putExtra(android.content.Intent.EXTRA_STREAM, currentUri);
            share.addFlags(android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION);
            startActivity(android.content.Intent.createChooser(share, "共有"));
        } catch (Throwable e) { Toast.makeText(this, "共有できませんでした", Toast.LENGTH_SHORT).show(); }
    }

    private void showCurrentUri(boolean fromSwipe, int direction) {
        closePdf();
        titleView.setText(currentName == null ? resolveDisplayName(currentUri) : currentName);
        if (isPdf(currentMime, currentUri)) {
            openPdf(currentUri);
        } else {
            openImageAsync(currentUri, fromSwipe, direction);
            updatePositionLabel();
        }
    }

    private void openImageAsync(Uri uri, boolean fromSwipe, int direction) {
        final int generation = decodeGeneration.incrementAndGet();
        final long begin = SystemClock.elapsedRealtime();
        AppLog.d(this, "IMAGE decode queued +" + elapsed() + "ms uri=" + uri);
        decodeExecutor.execute(() -> {
            try {
                ImageDecoder.Source source = ImageDecoder.createSource(getContentResolver(), uri);
                Drawable drawable = ImageDecoder.decodeDrawable(source, (decoder, info, src) -> {
                    decoder.setAllocator(ImageDecoder.ALLOCATOR_SOFTWARE);
                    decoder.setMemorySizePolicy(ImageDecoder.MEMORY_POLICY_LOW_RAM);
                });
                long decodeMs = SystemClock.elapsedRealtime() - begin;
                mainHandler.post(() -> {
                    if (generation != decodeGeneration.get() || isFinishing()) return;
                    imageView.setImageForViewer(drawable);
                    if (fromSwipe) {
                        float startX = direction > 0 ? imageView.getWidth() * 0.18f : -imageView.getWidth() * 0.18f;
                        imageView.setTranslationX(startX);
                        imageView.setAlpha(0.82f);
                        imageView.animate().translationX(0f).alpha(1f).setDuration(130).withEndAction(() -> pageAnimating = false).start();
                    } else pageAnimating = false;
                    if (drawable instanceof AnimatedImageDrawable) ((AnimatedImageDrawable) drawable).start();
                    AppLog.d(this, "IMAGE first paint +" + elapsed() + "ms decode=" + decodeMs + "ms class=" + drawable.getClass().getSimpleName());
                    if (!firstFrameLogged) { firstFrameLogged = true; AppLog.d(this, "PERF FIRST_IMAGE_VISIBLE=" + elapsed() + "ms"); }
                });
            } catch (Throwable e) {
                AppLog.d(this, "IMAGE decode ERROR +" + elapsed() + "ms " + e);
                mainHandler.post(() -> {
                    if (generation == decodeGeneration.get()) {
                        pageAnimating = false;
                        Toast.makeText(this, "この画像を表示できませんでした", Toast.LENGTH_LONG).show();
                    }
                });
            }
        });
    }

    private boolean canMoveSibling(int direction) {
        if (pageAnimating || siblings.size() <= 1 || currentIndex < 0) return false;
        int next = currentIndex + direction;
        return next >= 0 && next < siblings.size();
    }

    private void animateToSibling(int direction, float velocityX) {
        if (!canMoveSibling(direction)) {
            imageView.animate().translationX(0f).setDuration(100).start();
            return;
        }
        pageAnimating = true;
        float target = direction > 0 ? -imageView.getWidth() : imageView.getWidth();
        long duration = Math.abs(velocityX) > 1500 ? 90 : 135;
        imageView.animate().translationX(target).alpha(0.80f).setDuration(duration).withEndAction(() -> {
            imageView.setTranslationX(0f); imageView.setAlpha(1f);
            currentIndex += direction;
            MediaItem item = siblings.get(currentIndex);
            currentUri = item.uri; currentName = item.name; currentMime = item.mime;
            AppLog.d(this, "SWIPE move +" + elapsed() + "ms index=" + currentIndex + "/" + siblings.size());
            showCurrentUri(true, direction);
        }).start();
    }

    private void openPdf(Uri uri) {
        // PDF path remains synchronous for now; image opening is the performance priority for this build.
        try {
            AppLog.d(this, "PDF open begin uri=" + uri);
            pdfFd = getContentResolver().openFileDescriptor(uri, "r");
            if (pdfFd == null) throw new IOException("No file descriptor");
            pdfRenderer = new PdfRenderer(pdfFd);
            if (pdfRenderer.getPageCount() == 0) throw new IOException("Empty PDF");
            renderPdfPage(0);
        } catch (Throwable e) { AppLog.d(this, "PDF open ERROR " + e); Toast.makeText(this, "PDFを表示できませんでした", Toast.LENGTH_LONG).show(); }
    }

    private void renderPdfPage(int index) {
        closePdfPage(); pdfPage = pdfRenderer.openPage(index);
        int screenWidth = Math.max(1, getResources().getDisplayMetrics().widthPixels);
        float ratio = (float) pdfPage.getHeight() / (float) pdfPage.getWidth();
        int bitmapWidth = Math.min(screenWidth * 2, 2200); int bitmapHeight = Math.max(1, Math.round(bitmapWidth * ratio));
        Bitmap bitmap = Bitmap.createBitmap(bitmapWidth, bitmapHeight, Bitmap.Config.ARGB_8888); bitmap.eraseColor(Color.WHITE);
        pdfPage.render(bitmap, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY);
        imageView.setImageForViewer(new android.graphics.drawable.BitmapDrawable(getResources(), bitmap));
        pageView.setText((index + 1) + " / " + pdfRenderer.getPageCount());
    }

    private void updatePositionLabel() {
        if (currentIndex >= 0 && siblings.size() > 1) pageView.setText((currentIndex + 1) + " / " + siblings.size());
        else pageView.setText("");
    }

    private boolean hasMediaPermission() {
        if (Build.VERSION.SDK_INT >= 33) return checkSelfPermission(Manifest.permission.READ_MEDIA_IMAGES) == PackageManager.PERMISSION_GRANTED;
        return checkSelfPermission(Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED;
    }

    private void requestMediaPermission() {
        if (Build.VERSION.SDK_INT >= 33) requestPermissions(new String[]{Manifest.permission.READ_MEDIA_IMAGES}, REQ_MEDIA);
        else requestPermissions(new String[]{Manifest.permission.READ_EXTERNAL_STORAGE}, REQ_MEDIA);
    }

    @Override public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQ_MEDIA && grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            AppLog.d(this, "PERMISSION media granted"); discoverSiblingImagesAsync();
        } else if (requestCode == REQ_MEDIA) AppLog.d(this, "PERMISSION media denied");
    }

    private void discoverSiblingImagesAsync() {
        final Uri seedUri = currentUri;
        final String seedName = currentName;
        scanExecutor.execute(() -> {
            try {
                long started = SystemClock.elapsedRealtime();
                String relativePath = resolveRelativePath(seedUri);
                if (relativePath == null) return;
                String[] projection = new String[]{MediaStore.Images.Media._ID, MediaStore.Images.Media.DISPLAY_NAME, MediaStore.Images.Media.MIME_TYPE};
                String selection = MediaStore.Images.Media.RELATIVE_PATH + "=?";
                String sort = MediaStore.Images.Media.DISPLAY_NAME + " COLLATE NOCASE ASC";
                ArrayList<MediaItem> found = new ArrayList<>();
                try (Cursor c = getContentResolver().query(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, projection, selection, new String[]{relativePath}, sort)) {
                    if (c != null) {
                        int idCol = c.getColumnIndexOrThrow(MediaStore.Images.Media._ID);
                        int nameCol = c.getColumnIndexOrThrow(MediaStore.Images.Media.DISPLAY_NAME);
                        int mimeCol = c.getColumnIndexOrThrow(MediaStore.Images.Media.MIME_TYPE);
                        while (c.moveToNext()) {
                            long id = c.getLong(idCol); String name = c.getString(nameCol); String mime = c.getString(mimeCol);
                            found.add(new MediaItem(ContentUris.withAppendedId(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, id), name, mime));
                        }
                    }
                }
                mainHandler.post(() -> {
                    siblings.clear(); siblings.addAll(found); currentIndex = -1;
                    for (int i = 0; i < siblings.size(); i++) if (sameName(siblings.get(i).name, seedName)) { currentIndex = i; break; }
                    AppLog.d(this, "SIBLINGS ready +" + elapsed() + "ms scan=" + (SystemClock.elapsedRealtime()-started) + "ms found=" + siblings.size() + " currentIndex=" + currentIndex);
                    updatePositionLabel();
                });
            } catch (Throwable e) { AppLog.d(this, "SIBLINGS error " + e); }
        });
    }

    private String resolveRelativePath(Uri uri) {
        try (Cursor c = getContentResolver().query(uri, new String[]{MediaStore.MediaColumns.RELATIVE_PATH}, null, null, null)) {
            if (c != null && c.moveToFirst()) { int col = c.getColumnIndex(MediaStore.MediaColumns.RELATIVE_PATH); if (col >= 0) { String v = c.getString(col); if (v != null && !v.isEmpty()) return v; } }
        } catch (Throwable ignored) { }
        String name = resolveDisplayName(uri); if (name == null) return null;
        try (Cursor c = getContentResolver().query(MediaStore.Images.Media.EXTERNAL_CONTENT_URI,
                new String[]{MediaStore.Images.Media.RELATIVE_PATH, MediaStore.Images.Media.DISPLAY_NAME},
                MediaStore.Images.Media.DISPLAY_NAME + "=?", new String[]{name}, MediaStore.Images.Media.DATE_MODIFIED + " DESC")) {
            if (c != null && c.moveToFirst()) { int col = c.getColumnIndex(MediaStore.Images.Media.RELATIVE_PATH); if (col >= 0) return c.getString(col); }
        } catch (Throwable ignored) { }
        return null;
    }

    private boolean sameName(String a, String b) { return a != null && b != null && a.equalsIgnoreCase(b); }
    private boolean isPdf(String mime, Uri uri) { return "application/pdf".equalsIgnoreCase(mime) || (uri != null && uri.toString().toLowerCase().endsWith(".pdf")); }

    private String resolveDisplayName(Uri uri) {
        String name = null;
        if ("content".equals(uri.getScheme())) {
            try (Cursor cursor = getContentResolver().query(uri, new String[]{OpenableColumns.DISPLAY_NAME}, null, null, null)) {
                if (cursor != null && cursor.moveToFirst()) { int index = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME); if (index >= 0) name = cursor.getString(index); }
            } catch (Exception ignored) { }
        }
        if (name == null || name.isEmpty()) name = uri.getLastPathSegment();
        return name == null ? "Chirami" : name;
    }

    private void closePdfPage() { if (pdfPage != null) { pdfPage.close(); pdfPage = null; } }
    private void closePdf() {
        closePdfPage(); if (pdfRenderer != null) { pdfRenderer.close(); pdfRenderer = null; }
        if (pdfFd != null) { try { pdfFd.close(); } catch (IOException ignored) { } pdfFd = null; }
    }

    @Override protected void onDestroy() {
        AppLog.d(this, "VIEWER onDestroy"); closePdf(); decodeGeneration.incrementAndGet(); decodeExecutor.shutdownNow(); scanExecutor.shutdownNow(); super.onDestroy();
    }

    /** Lightweight zoom/pan/page view. No external image-view dependency: keeps Chirami small and startup cheap. */
    private class ZoomImageView extends ImageView {
        interface PageListener { boolean canPage(int direction); void onPage(int direction, float velocityX); void onSingleTap(); }
        private PageListener pageListener;
        private final Matrix matrix = new Matrix();
        private final float[] values = new float[9];
        private final ScaleGestureDetector scaleDetector;
        private float fitScale = 1f;
        private float userScale = 1f;
        private float lastX, lastY, downX, downY;
        private long lastTapUp = 0;
        private float lastTapX, lastTapY;
        private boolean secondTap = false;
        private boolean doubleTapZoomDrag = false;
        private float doubleTapStartY, doubleTapStartScale;
        private boolean paging = false;
        private boolean moved = false;
        private VelocityTracker velocityTracker;
        private final int touchSlop = ViewConfiguration.get(ViewerActivity.this).getScaledTouchSlop();
        private Runnable pendingSingleTap;

        ZoomImageView() {
            super(ViewerActivity.this);
            setScaleType(ScaleType.MATRIX);
            setClickable(true);
            scaleDetector = new ScaleGestureDetector(ViewerActivity.this, new ScaleGestureDetector.SimpleOnScaleGestureListener() {
                @Override public boolean onScaleBegin(ScaleGestureDetector detector) { paging = false; cancelSingleTap(); return true; }
                @Override public boolean onScale(ScaleGestureDetector detector) {
                    float factor = detector.getScaleFactor();
                    setUserScale(userScale * factor, detector.getFocusX(), detector.getFocusY());
                    return true;
                }
            });
        }

        void setPageListener(PageListener listener) { pageListener = listener; }

        void setImageForViewer(Drawable drawable) {
            setTranslationX(0f); setAlpha(1f); super.setImageDrawable(drawable); post(this::resetToFit);
        }

        private void resetToFit() {
            Drawable d = getDrawable(); if (d == null || getWidth() <= 0 || getHeight() <= 0) return;
            int iw = Math.max(1, d.getIntrinsicWidth()); int ih = Math.max(1, d.getIntrinsicHeight());
            fitScale = Math.min((float)getWidth()/iw, (float)getHeight()/ih);
            if (!Float.isFinite(fitScale) || fitScale <= 0f) fitScale = 1f;
            userScale = fitScale;
            matrix.reset();
            matrix.postScale(fitScale, fitScale);
            matrix.postTranslate((getWidth()-iw*fitScale)/2f, (getHeight()-ih*fitScale)/2f);
            setImageMatrix(matrix);
        }

        private void setUserScale(float target, float focusX, float focusY) {
            float max = Math.max(8f, fitScale * 12f);
            target = Math.max(fitScale, Math.min(max, target));
            float factor = target / userScale;
            matrix.postScale(factor, factor, focusX, focusY);
            userScale = target;
            constrain(); setImageMatrix(matrix);
        }

        private boolean isAtFit() { return userScale <= fitScale * 1.015f; }

        private void toggleOriginal(float x, float y) {
            float target = Math.abs(userScale - fitScale) < 0.02f ? Math.max(1f, fitScale) : fitScale;
            setUserScale(target, x, y);
            if (target == fitScale) resetToFit();
            AppLog.d(ViewerActivity.this, "ZOOM doubleTap scale=" + userScale + " fit=" + fitScale);
        }

        private void pan(float dx, float dy) { matrix.postTranslate(dx, dy); constrain(); setImageMatrix(matrix); }

        private void constrain() {
            Drawable d = getDrawable(); if (d == null) return;
            RectF r = new RectF(0, 0, Math.max(1,d.getIntrinsicWidth()), Math.max(1,d.getIntrinsicHeight())); matrix.mapRect(r);
            float dx = 0, dy = 0;
            if (r.width() <= getWidth()) dx = getWidth()/2f - r.centerX(); else if (r.left > 0) dx = -r.left; else if (r.right < getWidth()) dx = getWidth() - r.right;
            if (r.height() <= getHeight()) dy = getHeight()/2f - r.centerY(); else if (r.top > 0) dy = -r.top; else if (r.bottom < getHeight()) dy = getHeight() - r.bottom;
            matrix.postTranslate(dx, dy);
        }

        @Override public boolean onTouchEvent(MotionEvent e) {
            if (pageAnimating) return true;
            scaleDetector.onTouchEvent(e);
            int action = e.getActionMasked();
            if (action == MotionEvent.ACTION_DOWN) {
                if (velocityTracker != null) velocityTracker.recycle(); velocityTracker = VelocityTracker.obtain(); velocityTracker.addMovement(e);
                downX = lastX = e.getX(); downY = lastY = e.getY(); moved = false; paging = false;
                long now = SystemClock.uptimeMillis();
                secondTap = (now - lastTapUp <= DOUBLE_TAP_MS && distance(e.getX(), e.getY(), lastTapX, lastTapY) < dp(48));
                if (secondTap) { cancelSingleTap(); doubleTapZoomDrag = false; doubleTapStartY = e.getY(); doubleTapStartScale = userScale; }
                return true;
            }
            if (velocityTracker != null) velocityTracker.addMovement(e);
            if (action == MotionEvent.ACTION_MOVE) {
                float x=e.getX(), y=e.getY(); float dx=x-lastX, dy=y-lastY;
                if (Math.abs(x-downX)>touchSlop || Math.abs(y-downY)>touchSlop) moved=true;
                if (secondTap && !scaleDetector.isInProgress()) {
                    float totalY = y-doubleTapStartY;
                    if (Math.abs(totalY) > touchSlop) {
                        doubleTapZoomDrag = true;
                        // Up = zoom in, down = zoom out. Exponential response feels natural over the whole screen.
                        float factor = (float)Math.exp(-totalY / Math.max(220f, getHeight()*0.42f));
                        setUserScale(doubleTapStartScale * factor, downX, downY);
                    }
                } else if (scaleDetector.isInProgress()) {
                    // handled by ScaleGestureDetector
                } else if (!isAtFit()) {
                    pan(dx, dy);
                } else {
                    float totalX=x-downX, totalY=y-downY;
                    if (!paging && Math.abs(totalX)>touchSlop && Math.abs(totalX)>Math.abs(totalY)*1.15f) paging=true;
                    if (paging) {
                        int direction = totalX < 0 ? 1 : -1;
                        float resistance = (pageListener != null && pageListener.canPage(direction)) ? 1f : 0.23f;
                        setTranslationX(totalX * resistance);
                    }
                }
                lastX=x; lastY=y; return true;
            }
            if (action == MotionEvent.ACTION_UP || action == MotionEvent.ACTION_CANCEL) {
                float vx=0f; if (velocityTracker != null) { velocityTracker.computeCurrentVelocity(1000); vx=velocityTracker.getXVelocity(); velocityTracker.recycle(); velocityTracker=null; }
                if (secondTap) {
                    if (!doubleTapZoomDrag && action==MotionEvent.ACTION_UP) toggleOriginal(e.getX(), e.getY());
                    AppLog.d(ViewerActivity.this, doubleTapZoomDrag ? "ZOOM doubleTapHold end scale="+userScale : "ZOOM doubleTap toggle scale="+userScale);
                    secondTap=false; doubleTapZoomDrag=false; setTranslationX(0f); return true;
                }
                if (paging) {
                    float tx=getTranslationX(); int direction = tx<0 ? 1 : -1;
                    boolean commit = Math.abs(tx) > getWidth()*0.20f || Math.abs(vx)>800f;
                    if (commit && pageListener != null && pageListener.canPage(direction)) pageListener.onPage(direction, vx);
                    else animate().translationX(0f).setDuration(110).start();
                    paging=false; return true;
                }
                if (!moved && action==MotionEvent.ACTION_UP && !scaleDetector.isInProgress()) {
                    lastTapUp=SystemClock.uptimeMillis(); lastTapX=e.getX(); lastTapY=e.getY();
                    scheduleSingleTap();
                }
                return true;
            }
            return true;
        }

        private void scheduleSingleTap() {
            cancelSingleTap();
            pendingSingleTap = () -> { pendingSingleTap=null; if (pageListener!=null) pageListener.onSingleTap(); };
            mainHandler.postDelayed(pendingSingleTap, DOUBLE_TAP_MS + 20);
        }
        private void cancelSingleTap() { if (pendingSingleTap != null) { mainHandler.removeCallbacks(pendingSingleTap); pendingSingleTap=null; } }
        private float distance(float x1,float y1,float x2,float y2) { float dx=x1-x2, dy=y1-y2; return (float)Math.sqrt(dx*dx+dy*dy); }
    }
}
