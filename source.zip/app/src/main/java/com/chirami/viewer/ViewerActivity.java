package com.chirami.viewer;

import android.app.Activity;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.ImageDecoder;
import android.graphics.drawable.AnimatedImageDrawable;
import android.graphics.drawable.Drawable;
import android.graphics.pdf.PdfRenderer;
import android.net.Uri;
import android.os.Bundle;
import android.os.ParcelFileDescriptor;
import android.provider.OpenableColumns;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.io.IOException;

public class ViewerActivity extends Activity {
    private LinearLayout topBar;
    private ImageView imageView;
    private TextView titleView;
    private TextView pageView;
    private ParcelFileDescriptor pdfFd;
    private PdfRenderer pdfRenderer;
    private PdfRenderer.Page pdfPage;

    private int dp(float value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(Color.BLACK);
        getWindow().setNavigationBarColor(Color.BLACK);
        buildUi();

        Uri uri = getIntent().getData();
        if (uri == null) {
            Toast.makeText(this, "ファイルを開けませんでした", Toast.LENGTH_SHORT).show();
            finish();
            return;
        }

        getIntent().addFlags(android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION);
        titleView.setText(resolveDisplayName(uri));

        String mime = getIntent().getType();
        if (mime == null) {
            mime = getContentResolver().getType(uri);
        }

        if ("application/pdf".equalsIgnoreCase(mime) || uri.toString().toLowerCase().endsWith(".pdf")) {
            openPdf(uri);
        } else {
            openImage(uri);
        }
    }

    private void buildUi() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Color.BLACK);

        topBar = new LinearLayout(this);
        topBar.setOrientation(LinearLayout.HORIZONTAL);
        topBar.setGravity(Gravity.CENTER_VERTICAL);
        topBar.setPadding(dp(8), 0, dp(12), 0);
        topBar.setBackgroundColor(Color.rgb(42, 34, 34));

        TextView back = new TextView(this);
        back.setText("‹");
        back.setTextColor(Color.WHITE);
        back.setTextSize(42);
        back.setGravity(Gravity.CENTER);
        back.setOnClickListener(v -> finish());
        topBar.addView(back, new LinearLayout.LayoutParams(dp(48), dp(56)));

        titleView = new TextView(this);
        titleView.setTextColor(Color.WHITE);
        titleView.setTextSize(15);
        titleView.setSingleLine(true);
        titleView.setEllipsize(android.text.TextUtils.TruncateAt.MIDDLE);
        LinearLayout.LayoutParams titleParams = new LinearLayout.LayoutParams(0, dp(56), 1f);
        titleView.setGravity(Gravity.CENTER_VERTICAL);
        topBar.addView(titleView, titleParams);

        pageView = new TextView(this);
        pageView.setTextColor(Color.LTGRAY);
        pageView.setTextSize(13);
        pageView.setGravity(Gravity.CENTER_VERTICAL | Gravity.END);
        topBar.addView(pageView, new LinearLayout.LayoutParams(dp(68), dp(56)));

        root.addView(topBar, new LinearLayout.LayoutParams(-1, dp(56)));

        FrameLayout stage = new FrameLayout(this);
        stage.setBackgroundColor(Color.BLACK);

        imageView = new ImageView(this);
        imageView.setBackgroundColor(Color.BLACK);
        imageView.setScaleType(ImageView.ScaleType.FIT_CENTER);
        imageView.setOnClickListener(v -> toggleChrome());
        stage.addView(imageView, new FrameLayout.LayoutParams(-1, -1));

        root.addView(stage, new LinearLayout.LayoutParams(-1, 0, 1f));
        setContentView(root);
    }

    private void toggleChrome() {
        if (topBar.getVisibility() == View.VISIBLE) {
            topBar.setVisibility(View.GONE);
            getWindow().getDecorView().setSystemUiVisibility(
                    View.SYSTEM_UI_FLAG_FULLSCREEN |
                    View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY |
                    View.SYSTEM_UI_FLAG_HIDE_NAVIGATION);
        } else {
            topBar.setVisibility(View.VISIBLE);
            getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_VISIBLE);
        }
    }

    private void openImage(Uri uri) {
        try {
            ImageDecoder.Source source = ImageDecoder.createSource(getContentResolver(), uri);
            Drawable drawable = ImageDecoder.decodeDrawable(source);
            imageView.setImageDrawable(drawable);
            pageView.setText("");
            if (drawable instanceof AnimatedImageDrawable) {
                ((AnimatedImageDrawable) drawable).start();
            }
        } catch (Throwable e) {
            Toast.makeText(this, "この画像を表示できませんでした", Toast.LENGTH_LONG).show();
        }
    }

    private void openPdf(Uri uri) {
        try {
            pdfFd = getContentResolver().openFileDescriptor(uri, "r");
            if (pdfFd == null) throw new IOException("No file descriptor");
            pdfRenderer = new PdfRenderer(pdfFd);
            if (pdfRenderer.getPageCount() == 0) throw new IOException("Empty PDF");
            renderPdfPage(0);
        } catch (Throwable e) {
            Toast.makeText(this, "PDFを表示できませんでした", Toast.LENGTH_LONG).show();
        }
    }

    private void renderPdfPage(int index) {
        closePdfPage();
        pdfPage = pdfRenderer.openPage(index);
        int screenWidth = Math.max(1, getResources().getDisplayMetrics().widthPixels);
        float ratio = (float) pdfPage.getHeight() / (float) pdfPage.getWidth();
        int bitmapWidth = Math.min(screenWidth * 2, 2200);
        int bitmapHeight = Math.max(1, Math.round(bitmapWidth * ratio));
        Bitmap bitmap = Bitmap.createBitmap(bitmapWidth, bitmapHeight, Bitmap.Config.ARGB_8888);
        bitmap.eraseColor(Color.WHITE);
        pdfPage.render(bitmap, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY);
        imageView.setImageBitmap(bitmap);
        pageView.setText((index + 1) + " / " + pdfRenderer.getPageCount());
    }

    private String resolveDisplayName(Uri uri) {
        String name = null;
        if ("content".equals(uri.getScheme())) {
            try (android.database.Cursor cursor = getContentResolver().query(uri,
                    new String[]{OpenableColumns.DISPLAY_NAME}, null, null, null)) {
                if (cursor != null && cursor.moveToFirst()) {
                    int index = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME);
                    if (index >= 0) name = cursor.getString(index);
                }
            } catch (Exception ignored) { }
        }
        if (name == null || name.isEmpty()) {
            name = uri.getLastPathSegment();
        }
        return name == null ? "Chirami" : name;
    }

    private void closePdfPage() {
        if (pdfPage != null) {
            pdfPage.close();
            pdfPage = null;
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        closePdfPage();
        if (pdfRenderer != null) {
            pdfRenderer.close();
            pdfRenderer = null;
        }
        if (pdfFd != null) {
            try { pdfFd.close(); } catch (IOException ignored) { }
            pdfFd = null;
        }
    }
}
