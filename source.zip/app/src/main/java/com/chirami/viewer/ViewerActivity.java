package com.chirami.viewer;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.ContentUris;
import android.content.ContentResolver;
import android.content.ClipData;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.res.ColorStateList;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Color;
import android.graphics.ImageDecoder;
import android.graphics.Matrix;
import android.animation.ValueAnimator;
import android.graphics.RectF;
import android.graphics.drawable.AnimatedImageDrawable;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.graphics.pdf.PdfRenderer;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.CancellationSignal;
import android.os.Handler;
import android.os.Looper;
import android.os.ParcelFileDescriptor;
import android.os.SystemClock;
import android.provider.MediaStore;
import android.provider.DocumentsContract;
import android.provider.OpenableColumns;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.animation.PathInterpolator;
import android.view.animation.DecelerateInterpolator;
import android.view.ScaleGestureDetector;
import android.view.VelocityTracker;
import android.view.View;
import android.view.ViewConfiguration;
import android.util.LruCache;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import java.io.IOException;
import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicReference;

public class ViewerActivity extends Activity {
    private static final int REQ_MEDIA = 1001;
    private static final long DOUBLE_TAP_MS = 300;

    // v0.1.20 experiment: use a direct shared-storage directory index whenever the incoming
    // URI exposes a real path. MediaStore seed resolution remains the generic fallback.
    private static final boolean ENABLE_DIRECT_FILE_ENUM_EXPERIMENT = true;
    private static final boolean ENABLE_CURSOR_OUT_EXPERIMENT = true;
    private static final boolean ENABLE_CENTER_OUT_EXPERIMENT = true;
    private static final boolean ENABLE_EXTERNAL_FAST_PATH_EXPERIMENT = true;
    // This is only a UI merge chunk now; it is NOT a MediaStore query LIMIT.
    private static final int CURSOR_MERGE_CHUNK_SIZE = 24;
    private static final int CENTER_OUT_BATCH_SIZE = 24;
    private static final long FOLDER_CACHE_TTL_MS = 2 * 60 * 1000L;

    private LinearLayout topBar;
    private LinearLayout bottomBar;
    private ChromeShadeOverlay shadeOverlay;
    private ZoomImageView imageView;
    private ImageView pagePreviewView;
    private TextView titleView;
    private TextView pageView;

    private ParcelFileDescriptor pdfFd;
    private PdfRenderer pdfRenderer;
    private PdfRenderer.Page pdfPage;

    private final List<MediaItem> siblings = new ArrayList<>();
    private int currentIndex = -1;
    private Uri currentUri;
    private String currentMime;
    private String currentName;

    private final ExecutorService decodeExecutor = Executors.newSingleThreadExecutor();
    private final ExecutorService scanExecutor = Executors.newSingleThreadExecutor();
    private final ExecutorService neighborExecutor = Executors.newFixedThreadPool(2);
    private final ExecutorService providerDirectoryExecutor = Executors.newSingleThreadExecutor();
    private final ExecutorService fullScanExecutor = Executors.newSingleThreadExecutor();
    private final ExecutorService prefetchExecutor = Executors.newFixedThreadPool(2);
    private final Handler mainHandler = new Handler(Looper.getMainLooper());
    private final AtomicInteger decodeGeneration = new AtomicInteger();
    private final AtomicInteger prefetchGeneration = new AtomicInteger();
    private final AtomicInteger siblingGeneration = new AtomicInteger();
    // CancellationSignals matter because interrupting an Executor thread does not reliably
    // abort a slow ContentResolver query. A new viewer/search cancels the provider work itself.
    private volatile CancellationSignal seedResolveSignal;
    private volatile CancellationSignal previousCursorSignal;
    private volatile CancellationSignal nextCursorSignal;
    // Small screen-sized preview cache. This avoids re-decoding the same adjacent image
    // when the user swipes back and forth. Full-resolution images are not retained here.
    private final LruCache<String, Drawable> previewCache = new LruCache<>(6);
    private long launchStartedMs;
    private boolean firstFrameLogged = false;
    private boolean pageAnimating = false;
    private volatile Drawable previousPreviewDrawable;
    private volatile Drawable nextPreviewDrawable;
    private volatile MediaItem quickPreviousItem;
    private volatile MediaItem quickNextItem;
    private volatile boolean fullListReady = false;
    private volatile boolean progressiveListActive = false;
    private volatile boolean progressivePrevComplete = false;
    private volatile boolean progressiveNextComplete = false;
    private volatile int progressivePrevLoaded = 0;
    private volatile int progressiveNextLoaded = 0;
    private int topShadeExtentPx;
    private int bottomShadeExtentPx;

    private static class MediaItem {
        final Uri uri;
        final String name;
        final String mime;
        final long size;
        final long modified;
        MediaItem(Uri uri, String name, String mime, long size, long modified) {
            this.uri = uri; this.name = name; this.mime = mime; this.size = size; this.modified = modified;
        }
    }

    private static class FolderCacheEntry {
        final long createdAt;
        final ArrayList<MediaItem> items;
        FolderCacheEntry(long createdAt, List<MediaItem> items) {
            this.createdAt = createdAt;
            this.items = new ArrayList<>(items);
        }
    }

    // Process-only cache: no library/database is created. It disappears when Android kills
    // Chirami's process. Cache stores order-independent folder metadata; each request sorts
    // a copy in RAM, so changing slide sort never throws away a warm folder index.
    private static final Object FOLDER_CACHE_LOCK = new Object();
    private static final LruCache<String, FolderCacheEntry> FOLDER_INDEX_CACHE = new LruCache<>(4);

    private int dp(float value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        launchStartedMs = SystemClock.elapsedRealtime();
        super.onCreate(savedInstanceState);
        AppLog.d(this, "VIEWER onCreate action=" + getIntent().getAction() + " type=" + getIntent().getType() + " data=" + getIntent().getData());
        logLaunchIntentDetails();
        getWindow().setStatusBarColor(Color.BLACK);
        getWindow().setNavigationBarColor(Color.BLACK);
        buildUi();

        Uri uri = getIntent().getData();
        if (uri == null) {
            AppLog.d(this, "VIEWER no URI");
            Toast.makeText(this, "ファイルを開けませんでした", Toast.LENGTH_SHORT).show();
            finish();
            return;
        }

        currentUri = uri;
        currentName = resolveDisplayName(uri);
        currentMime = getIntent().getType();
        if (currentMime == null) currentMime = getContentResolver().getType(uri);
        AppLog.d(this, "VIEWER open +" + elapsed() + "ms name=" + currentName + " mime=" + currentMime + " uri=" + currentUri);

        // Most important rule in Chirami: render the tapped file first. Folder scanning is never allowed to delay it.
        showCurrentUri(false, 0);

        if (!isPdf(currentMime, uri)) {
            if (hasMediaPermission()) discoverSiblingImagesAsync();
            else requestMediaPermission();
        }
    }

    private long elapsed() { return SystemClock.elapsedRealtime() - launchStartedMs; }

    private void buildUi() {
        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(Color.BLACK);

        pagePreviewView = new ImageView(this);
        pagePreviewView.setBackgroundColor(Color.BLACK);
        pagePreviewView.setScaleType(ImageView.ScaleType.FIT_CENTER);
        pagePreviewView.setVisibility(View.GONE);
        root.addView(pagePreviewView, new FrameLayout.LayoutParams(-1, -1));

        imageView = new ZoomImageView();
        imageView.setBackgroundColor(Color.BLACK);
        imageView.setPageListener(new ZoomImageView.PageListener() {
            @Override public boolean canPage(int direction) { return canMoveSibling(direction); }
            @Override public void onPageDrag(int direction, float translationX) { showPagePreview(direction, translationX); }
            @Override public void onPageReset() { animatePageReset(); }
            @Override public void onPage(int direction, float velocityX) { animateToSibling(direction, velocityX); }
            @Override public void onSingleTap() { toggleChrome(); }
        });
        root.addView(imageView, new FrameLayout.LayoutParams(-1, -1));

        // Chrome is intentionally fully transparent: no top/bottom alpha-gray overlay.
        final int chromeInset = dp(50);
        shadeOverlay = null;

        topBar = new LinearLayout(this);
        topBar.setOrientation(LinearLayout.HORIZONTAL);
        topBar.setGravity(Gravity.CENTER_VERTICAL);
        topBar.setPadding(dp(8), 0, dp(8), 0);
        topBar.setBackgroundColor(Color.TRANSPARENT);

        TextView back = new TextView(this);
        back.setText("‹"); back.setTextColor(Color.WHITE); back.setTextSize(42); back.setGravity(Gravity.CENTER);
        back.setOnClickListener(v -> returnToCaller());
        topBar.addView(back, new LinearLayout.LayoutParams(dp(48), dp(60)));

        titleView = new TextView(this);
        titleView.setTextColor(Color.WHITE); titleView.setTextSize(19); titleView.setSingleLine(true);
        titleView.setEllipsize(android.text.TextUtils.TruncateAt.END); titleView.setGravity(Gravity.CENTER_VERTICAL);
        topBar.addView(titleView, new LinearLayout.LayoutParams(0, dp(60), 1f));

        pageView = new TextView(this);
        pageView.setTextColor(Color.WHITE); pageView.setTextSize(12); pageView.setGravity(Gravity.CENTER);
        topBar.addView(pageView, new LinearLayout.LayoutParams(dp(62), dp(60)));

        TextView info = new TextView(this);
        info.setText("ⓘ"); info.setTextColor(Color.WHITE); info.setTextSize(27); info.setGravity(Gravity.CENTER);
        info.setOnClickListener(v -> Toast.makeText(this, currentName == null ? "" : currentName, Toast.LENGTH_SHORT).show());
        topBar.addView(info, new LinearLayout.LayoutParams(dp(46), dp(60)));

        TextView more = new TextView(this);
        more.setText("⋮"); more.setTextColor(Color.WHITE); more.setTextSize(30); more.setGravity(Gravity.CENTER);
        more.setOnClickListener(v -> showViewerMenu());
        topBar.addView(more, new LinearLayout.LayoutParams(dp(42), dp(60)));
        FrameLayout.LayoutParams topParams = new FrameLayout.LayoutParams(-1, dp(60), Gravity.TOP);
        topParams.topMargin = chromeInset;
        root.addView(topBar, topParams);


        bottomBar = new LinearLayout(this);
        bottomBar.setOrientation(LinearLayout.HORIZONTAL); bottomBar.setGravity(Gravity.CENTER);
        bottomBar.setPadding(dp(38), 0, dp(38), 0); bottomBar.setBackgroundColor(Color.TRANSPARENT);

        TextView edit = makeBottomAction("✎", "編集");
        edit.setOnClickListener(v -> Toast.makeText(this, "注釈・編集は次の段階で追加します", Toast.LENGTH_SHORT).show());
        bottomBar.addView(edit, new LinearLayout.LayoutParams(0, dp(72), 1f));

        TextView share = makeBottomAction("↗", "共有");
        share.setOnClickListener(v -> shareCurrent());
        bottomBar.addView(share, new LinearLayout.LayoutParams(0, dp(72), 1f));

        TextView delete = makeBottomAction("⌫", "削除");
        delete.setOnClickListener(v -> Toast.makeText(this, "削除は確認ダイアログ付きで追加します", Toast.LENGTH_SHORT).show());
        bottomBar.addView(delete, new LinearLayout.LayoutParams(0, dp(72), 1f));
        FrameLayout.LayoutParams bottomParams = new FrameLayout.LayoutParams(-1, dp(72), Gravity.BOTTOM);
        bottomParams.bottomMargin = chromeInset;
        root.addView(bottomBar, bottomParams);

        setContentView(root);
        AppLog.d(this, "VIEWER UI ready +" + elapsed() + "ms");
    }

    private void returnToCaller() {
        AppLog.d(this, "VIEWER returnToCaller taskRoot=" + isTaskRoot());
        try {
            // ViewerActivity has an empty taskAffinity, so finishing its affinity never
            // walks back into Chirami's launcher/settings task. It reveals the app that
            // launched ACTION_VIEW (file manager, browser, etc.).
            if (isTaskRoot()) finishAndRemoveTask();
            else finishAffinity();
        } catch (Throwable ignored) {
            finish();
        }
    }

    @Override
    public void onBackPressed() {
        returnToCaller();
    }

    private void showViewerMenu() {
        final int panel = Color.rgb(58, 51, 51); // #3A3333
        final String[] items = new String[]{"スライド順", "リネーム（準備中）", "回転（準備中）", "リサイズ（準備中）", "トリミング（準備中）"};
        AlertDialog dialog = new AlertDialog.Builder(this)
                .setItems(items, (d, which) -> {
                    if (which == 0) showSortDialog();
                    else Toast.makeText(this, "この機能は順次追加します", Toast.LENGTH_SHORT).show();
                }).create();
        dialog.setOnShowListener(ignored -> {
            if (dialog.getWindow() != null) {
                dialog.getWindow().setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(panel));
            }
            android.widget.ListView list = dialog.getListView();
            if (list != null) {
                list.setBackgroundColor(panel);
                for (int i = 0; i < list.getChildCount(); i++) {
                    View child = list.getChildAt(i);
                    if (child instanceof TextView) ((TextView) child).setTextColor(Color.WHITE);
                }
            }
        });
        dialog.show();
    }

    private void showSortDialog() {
        final String initialField = SortPrefs.field(this);
        final boolean initialAsc = SortPrefs.ascending(this);
        final int panel = Color.rgb(58, 51, 51);       // #3A3333
        final int selected = Color.rgb(68, 85, 119);  // #445577
        final int unselected = Color.rgb(90, 85, 85); // #5A5555
        ColorStateList tint = new ColorStateList(
                new int[][]{new int[]{android.R.attr.state_checked}, new int[]{}},
                new int[]{selected, unselected});

        LinearLayout content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(dp(22), dp(6), dp(22), dp(8));
        content.setBackgroundColor(panel);

        RadioGroup fieldGroup = new RadioGroup(this);
        fieldGroup.setOrientation(RadioGroup.VERTICAL);
        RadioButton byName = makeDialogRadio("名前", false, tint);
        RadioButton bySize = makeDialogRadio("サイズ", false, tint);
        RadioButton byModified = makeDialogRadio("最終更新日", false, tint);
        fieldGroup.addView(byName, new RadioGroup.LayoutParams(-1, dp(50)));
        fieldGroup.addView(bySize, new RadioGroup.LayoutParams(-1, dp(50)));
        fieldGroup.addView(byModified, new RadioGroup.LayoutParams(-1, dp(50)));
        if (SortPrefs.FIELD_SIZE.equals(initialField)) fieldGroup.check(bySize.getId());
        else if (SortPrefs.FIELD_MODIFIED.equals(initialField)) fieldGroup.check(byModified.getId());
        else fieldGroup.check(byName.getId());
        content.addView(fieldGroup);

        View divider = new View(this);
        divider.setBackgroundColor(Color.rgb(90, 85, 85));
        LinearLayout.LayoutParams dividerParams = new LinearLayout.LayoutParams(-1, dp(1));
        dividerParams.topMargin = dp(8);
        dividerParams.bottomMargin = dp(8);
        content.addView(divider, dividerParams);

        RadioGroup orderGroup = new RadioGroup(this);
        orderGroup.setOrientation(RadioGroup.HORIZONTAL);
        RadioButton ascending = makeDialogRadio("昇順", false, tint);
        RadioButton descending = makeDialogRadio("降順", false, tint);
        orderGroup.addView(ascending, new RadioGroup.LayoutParams(0, dp(52), 1f));
        orderGroup.addView(descending, new RadioGroup.LayoutParams(0, dp(52), 1f));
        orderGroup.check((initialAsc ? ascending : descending).getId());
        content.addView(orderGroup);

        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle("スライド順")
                .setView(content)
                .setNegativeButton("キャンセル", null)
                .setPositiveButton("OK", null)
                .create();

        dialog.setOnShowListener(ignored -> {
            if (dialog.getWindow() != null) {
                dialog.getWindow().setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(panel));
            }
            int titleId = getResources().getIdentifier("alertTitle", "id", "android");
            TextView title = dialog.findViewById(titleId);
            if (title != null) title.setTextColor(Color.WHITE);
            dialog.getButton(AlertDialog.BUTTON_NEGATIVE).setTextColor(Color.WHITE);
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setTextColor(Color.WHITE);
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v -> {
                String selectedField = bySize.isChecked() ? SortPrefs.FIELD_SIZE
                        : (byModified.isChecked() ? SortPrefs.FIELD_MODIFIED : SortPrefs.FIELD_NAME);
                boolean selectedAsc = ascending.isChecked();
                SortPrefs.save(this, selectedField, selectedAsc);
                AppLog.d(this, "SORT changed field=" + selectedField + " asc=" + selectedAsc);
                dialog.dismiss();
                discoverSiblingImagesAsync();
                Toast.makeText(this, SortPrefs.fieldLabel(selectedField) + "・" + (selectedAsc ? "昇順" : "降順"), Toast.LENGTH_SHORT).show();
            });
        });
        dialog.show();
    }

    private RadioButton makeDialogRadio(String label, boolean checked, ColorStateList tint) {
        RadioButton button = new RadioButton(this);
        button.setId(View.generateViewId());
        button.setText(label);
        button.setTextColor(Color.WHITE);
        button.setTextSize(17);
        button.setChecked(checked);
        button.setButtonTintList(tint);
        button.setGravity(Gravity.CENTER_VERTICAL);
        button.setPadding(0, dp(2), 0, dp(2));
        return button;
    }

    private TextView makeBottomAction(String icon, String label) {
        TextView view = new TextView(this);
        view.setText(icon + "\n" + label); view.setTextColor(Color.WHITE); view.setTextSize(13);
        view.setGravity(Gravity.CENTER); view.setLines(2); return view;
    }

    private void toggleChrome() {
        boolean showing = topBar.getVisibility() == View.VISIBLE;
        topBar.setVisibility(showing ? View.GONE : View.VISIBLE);
        bottomBar.setVisibility(showing ? View.GONE : View.VISIBLE);
        if (shadeOverlay != null) {
            shadeOverlay.setChromeVisible(!showing);
        }
        if (!showing && imageView != null) imageView.notifyImageBoundsChanged();
        if (showing) {
            getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_FULLSCREEN | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION);
        } else {
            getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_VISIBLE);
        }
    }

    private void updateChromeShadeBounds(RectF imageBounds) {
        if (shadeOverlay != null) shadeOverlay.setImageBounds(imageBounds);
    }

    private class ChromeShadeOverlay extends View {
        ChromeShadeOverlay() {
            super(ViewerActivity.this);
            setClickable(false);
            setFocusable(false);
        }
        void setChromeVisible(boolean visible) { }
        void setImageBounds(RectF imageBounds) { }
        @Override protected void onDraw(Canvas canvas) { super.onDraw(canvas); }
    }

    private void shareCurrent() {
        if (currentUri == null) return;
        try {
            Uri shareUri = currentUri;
            if ("file".equalsIgnoreCase(currentUri.getScheme())) {
                File f = new File(currentUri.getPath());
                shareUri = androidx.core.content.FileProvider.getUriForFile(
                        this, getPackageName() + ".fileprovider", f);
            }
            android.content.Intent share = new android.content.Intent(android.content.Intent.ACTION_SEND);
            share.setType(currentMime == null ? "image/*" : currentMime);
            share.putExtra(android.content.Intent.EXTRA_STREAM, shareUri);
            share.addFlags(android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION);
            startActivity(android.content.Intent.createChooser(share, "共有"));
        } catch (Throwable e) {
            AppLog.d(this, "SHARE error " + e);
            Toast.makeText(this, "共有できませんでした", Toast.LENGTH_SHORT).show();
        }
    }

    private void showCurrentUri(boolean fromSwipe, int direction) {
        closePdf();
        titleView.setText(currentName == null ? resolveDisplayName(currentUri) : currentName);
        if (isPdf(currentMime, currentUri)) {
            openPdf(currentUri);
        } else {
            openImageAsync(currentUri, fromSwipe, direction);
            updatePositionLabel();
        }
    }

    private ImageDecoder.Source createImageSource(Uri uri) throws IOException {
        if (uri != null && "file".equalsIgnoreCase(uri.getScheme())) {
            String path = uri.getPath();
            if (path == null) throw new IOException("Missing file path");
            return ImageDecoder.createSource(new File(path));
        }
        return ImageDecoder.createSource(getContentResolver(), uri);
    }

    private void openImageAsync(Uri uri, boolean fromSwipe, int direction) {
        final int generation = decodeGeneration.incrementAndGet();
        final long begin = SystemClock.elapsedRealtime();
        AppLog.d(this, "IMAGE decode queued +" + elapsed() + "ms uri=" + uri);
        decodeExecutor.execute(() -> {
            try {
                ImageDecoder.Source source = createImageSource(uri);
                Drawable drawable = ImageDecoder.decodeDrawable(source, (decoder, info, src) -> {
                    // Keep ImageDecoder's default allocator/memory policy. Forcing software + LOW_RAM
                    // made adjacent full-resolution images substantially slower to become swipe-ready.
                });
                long decodeMs = SystemClock.elapsedRealtime() - begin;
                mainHandler.post(() -> {
                    if (generation != decodeGeneration.get() || isFinishing()) return;
                    imageView.setImageForViewer(drawable);
                    if (fromSwipe) {
                        float startX = direction > 0 ? imageView.getWidth() * 0.18f : -imageView.getWidth() * 0.18f;
                        imageView.setTranslationX(startX);
                        imageView.setAlpha(0.82f);
                        imageView.animate().translationX(0f).alpha(1f).setDuration(130).withEndAction(() -> pageAnimating = false).start();
                    } else pageAnimating = false;
                    if (drawable instanceof AnimatedImageDrawable) ((AnimatedImageDrawable) drawable).start();
                    AppLog.d(this, "IMAGE first paint +" + elapsed() + "ms decode=" + decodeMs + "ms class=" + drawable.getClass().getSimpleName());
                    if (!firstFrameLogged) { firstFrameLogged = true; AppLog.d(this, "PERF FIRST_IMAGE_VISIBLE=" + elapsed() + "ms"); }
                });
            } catch (Throwable e) {
                AppLog.d(this, "IMAGE decode ERROR +" + elapsed() + "ms " + e);
                mainHandler.post(() -> {
                    if (generation == decodeGeneration.get()) {
                        pageAnimating = false;
                        Toast.makeText(this, "この画像を表示できませんでした", Toast.LENGTH_LONG).show();
                    }
                });
            }
        });
    }

    private boolean hasIndexedSiblingWindow() {
        return currentIndex >= 0 && !siblings.isEmpty() && (fullListReady || progressiveListActive);
    }

    // direction is physical: +1 = page arrives from the right, -1 = from the left.
    // Ascending advances from the right; descending advances from the left.
    private int indexDeltaForPhysicalDirection(int direction) {
        return SortPrefs.ascending(this) ? direction : -direction;
    }

    private boolean canMoveSibling(int direction) {
        if (pageAnimating) return false;
        int delta = indexDeltaForPhysicalDirection(direction);
        if (hasIndexedSiblingWindow()) {
            int next = currentIndex + delta;
            return next >= 0 && next < siblings.size();
        }
        return delta > 0 ? quickNextItem != null : quickPreviousItem != null;
    }

    private MediaItem itemForDirection(int direction) {
        int delta = indexDeltaForPhysicalDirection(direction);
        if (hasIndexedSiblingWindow()) {
            int next = currentIndex + delta;
            return (next >= 0 && next < siblings.size()) ? siblings.get(next) : null;
        }
        return delta > 0 ? quickNextItem : quickPreviousItem;
    }

    private Drawable previewForDirection(int direction) {
        return indexDeltaForPhysicalDirection(direction) > 0 ? nextPreviewDrawable : previousPreviewDrawable;
    }

    private void showPagePreview(int direction, float translationX) {
        if (!canMoveSibling(direction) || pagePreviewView == null) {
            hidePagePreview();
            return;
        }
        Drawable preview = previewForDirection(direction);
        if (preview == null) {
            pagePreviewView.setVisibility(View.GONE);
            return;
        }
        if (pagePreviewView.getDrawable() != preview) pagePreviewView.setImageDrawable(preview);
        imageView.setLayerType(View.LAYER_TYPE_HARDWARE, null);
        pagePreviewView.setLayerType(View.LAYER_TYPE_HARDWARE, null);
        pagePreviewView.setVisibility(View.VISIBLE);
        float start = direction > 0 ? imageView.getWidth() : -imageView.getWidth();
        pagePreviewView.setTranslationX(start + translationX);
        pagePreviewView.setAlpha(1f);
    }

    private void hidePagePreview() {
        if (pagePreviewView == null) return;
        pagePreviewView.animate().cancel();
        pagePreviewView.setVisibility(View.GONE);
        pagePreviewView.setTranslationX(0f);
        imageView.setLayerType(View.LAYER_TYPE_NONE, null);
        pagePreviewView.setLayerType(View.LAYER_TYPE_NONE, null);
    }

    private final PathInterpolator pageInterpolator = new PathInterpolator(0.20f, 0f, 0f, 1f);

    private void cancelPageAnimationsForTouch() {
        imageView.animate().cancel();
        if (pagePreviewView != null) pagePreviewView.animate().cancel();
        // A new finger-down owns X from this point onward. Never let an old
        // ViewPropertyAnimator continue writing translationX during ACTION_MOVE.
        imageView.setTranslationX(0f);
        hidePagePreview();
        pageAnimating = false;
    }

    private void animatePageReset() {
        float tx = imageView.getTranslationX();
        if (Math.abs(tx) < 1f) { hidePagePreview(); return; }
        int direction = tx < 0 ? 1 : -1;
        float previewTarget = direction > 0 ? imageView.getWidth() : -imageView.getWidth();
        imageView.setLayerType(View.LAYER_TYPE_HARDWARE, null);
        pagePreviewView.setLayerType(View.LAYER_TYPE_HARDWARE, null);
        imageView.animate().cancel();
        pagePreviewView.animate().cancel();
        imageView.animate().translationX(0f).setDuration(150).setInterpolator(pageInterpolator).start();
        if (pagePreviewView.getVisibility() == View.VISIBLE) {
            pagePreviewView.animate().translationX(previewTarget).setDuration(150).setInterpolator(pageInterpolator)
                    .withEndAction(this::hidePagePreview).start();
        } else {
            mainHandler.postDelayed(this::hidePagePreview, 155);
        }
    }

    private long pageDuration(float velocityX, float remainingPx) {
        float width = Math.max(1f, imageView.getWidth());
        if (Math.abs(velocityX) > 900f) {
            long byVelocity = (long)(1000f * remainingPx / Math.max(1200f, Math.abs(velocityX)));
            return Math.max(75L, Math.min(165L, byVelocity));
        }
        return (long)(105f + 60f * Math.min(1f, remainingPx / width));
    }

    private void animateToSibling(int direction, float velocityX) {
        MediaItem targetItem = itemForDirection(direction);
        if (targetItem == null || !canMoveSibling(direction)) {
            animatePageReset();
            return;
        }
        pageAnimating = true;
        final int targetIndex = hasIndexedSiblingWindow() ? currentIndex + indexDeltaForPhysicalDirection(direction) : -1;
        Drawable preview = previewForDirection(direction);
        float target = direction > 0 ? -imageView.getWidth() : imageView.getWidth();
        float remaining = Math.abs(target - imageView.getTranslationX());
        long duration = pageDuration(velocityX, remaining);

        imageView.setLayerType(View.LAYER_TYPE_HARDWARE, null);
        pagePreviewView.setLayerType(View.LAYER_TYPE_HARDWARE, null);
        imageView.animate().cancel();
        pagePreviewView.animate().cancel();

        if (preview != null) {
            if (pagePreviewView.getVisibility() != View.VISIBLE || pagePreviewView.getDrawable() != preview) {
                pagePreviewView.setImageDrawable(preview);
                pagePreviewView.setVisibility(View.VISIBLE);
                pagePreviewView.setTranslationX(direction > 0 ? imageView.getWidth() : -imageView.getWidth());
            }
            pagePreviewView.animate().translationX(0f).setDuration(duration).setInterpolator(pageInterpolator).start();
            imageView.animate().translationX(target).setDuration(duration).setInterpolator(pageInterpolator).withEndAction(() -> {
                currentUri = targetItem.uri; currentName = targetItem.name; currentMime = targetItem.mime;
                if (targetIndex >= 0 && hasIndexedSiblingWindow()) currentIndex = targetIndex;

                // Keep the centered preview covering the hand-off for one display frame.
                // The main ImageView gets its final FIT matrix while still off-screen, so
                // users never see an old matrix / temporary wrong-size frame.
                imageView.setImageForViewerKeepingTranslation(preview);
                imageView.setTranslationX(0f);
                titleView.setText(currentName);
                updatePositionLabel();
                pagePreviewView.postOnAnimation(() -> {
                    hidePagePreview();
                    pageAnimating = false;
                });
                AppLog.d(this, "SWIPE move cached +" + elapsed() + "ms direction=" + direction + " duration=" + duration);

                // The swipe used a screen-sized preview for speed. Upgrade the now-current
                // page to the original resolution in the background without blocking touch.
                openImageAsync(currentUri, false, 0);
                if (hasIndexedSiblingWindow()) prefetchAdjacent();
                else discoverSiblingImagesAsync();
            }).start();
        } else {
            imageView.animate().translationX(target).setDuration(duration).setInterpolator(pageInterpolator).withEndAction(() -> {
                currentUri = targetItem.uri; currentName = targetItem.name; currentMime = targetItem.mime;
                if (targetIndex >= 0 && hasIndexedSiblingWindow()) currentIndex = targetIndex;
                imageView.setTranslationX(0f);
                AppLog.d(this, "SWIPE move decode +" + elapsed() + "ms direction=" + direction);
                showCurrentUri(true, direction);
                if (hasIndexedSiblingWindow()) prefetchAdjacent();
                else discoverSiblingImagesAsync();
            }).start();
        }
    }

    private String previewKey(Uri uri) {
        return uri == null ? "" : uri.toString();
    }

    private Drawable getCachedPreview(Uri uri) {
        return previewCache.get(previewKey(uri));
    }

    private void putCachedPreview(Uri uri, Drawable drawable) {
        if (uri != null && drawable != null) previewCache.put(previewKey(uri), drawable);
    }

    /**
     * Decode only enough pixels for an on-screen swipe preview. The previous code decoded
     * the original full-resolution file here, which made the FIRST swipe wait on large photos.
     * The full-resolution drawable is loaded only after the page has actually become current.
     */
    private Drawable decodePreviewDrawable(Uri uri) throws IOException {
        ImageDecoder.Source source = createImageSource(uri);
        final int maxW = Math.max(1, getResources().getDisplayMetrics().widthPixels);
        final int maxH = Math.max(1, getResources().getDisplayMetrics().heightPixels);
        return ImageDecoder.decodeDrawable(source, (decoder, info, src) -> {
            int srcW = Math.max(1, info.getSize().getWidth());
            int srcH = Math.max(1, info.getSize().getHeight());
            float scale = Math.min((float) maxW / srcW, (float) maxH / srcH);
            if (scale < 1f) {
                int targetW = Math.max(1, Math.round(srcW * scale));
                int targetH = Math.max(1, Math.round(srcH * scale));
                decoder.setTargetSize(targetW, targetH);
            }
        });
    }

    private void prefetchQuick(MediaItem item, int direction, int generation) {
        if (item == null) return;
        Drawable cached = getCachedPreview(item.uri);
        if (cached != null) {
            if (direction > 0) nextPreviewDrawable = cached; else previousPreviewDrawable = cached;
            AppLog.d(this, "PREFETCH quick cache " + (direction > 0 ? "next" : "prev") + " +" + elapsed() + "ms");
            return;
        }
        prefetchExecutor.execute(() -> {
            long started = SystemClock.elapsedRealtime();
            try {
                Drawable d = decodePreviewDrawable(item.uri);
                putCachedPreview(item.uri, d);
                mainHandler.post(() -> {
                    if (generation != prefetchGeneration.get() || isFinishing()) return;
                    if (direction > 0) nextPreviewDrawable = d; else previousPreviewDrawable = d;
                    AppLog.d(this, "PREFETCH quick " + (direction > 0 ? "next" : "prev") + " ready +" + elapsed() + "ms took=" + (SystemClock.elapsedRealtime()-started) + "ms");
                });
            } catch (Throwable e) { AppLog.d(this, "PREFETCH quick error " + e); }
        });
    }

    private void prefetchAdjacent() {
        final int generation = prefetchGeneration.incrementAndGet();
        final int index = currentIndex;
        if (index < 0 || siblings.isEmpty()) {
            previousPreviewDrawable = null;
            nextPreviewDrawable = null;
            return;
        }
        previousPreviewDrawable = null;
        nextPreviewDrawable = null;
        final MediaItem prev = index > 0 ? siblings.get(index - 1) : null;
        final MediaItem next = index + 1 < siblings.size() ? siblings.get(index + 1) : null;

        if (prev != null) {
            Drawable cached = getCachedPreview(prev.uri);
            if (cached != null) {
                previousPreviewDrawable = cached;
            } else prefetchExecutor.execute(() -> {
                long started = SystemClock.elapsedRealtime();
                try {
                    Drawable d = decodePreviewDrawable(prev.uri);
                    putCachedPreview(prev.uri, d);
                    mainHandler.post(() -> {
                        if (generation != prefetchGeneration.get() || isFinishing()) return;
                        previousPreviewDrawable = d;
                        AppLog.d(this, "PREFETCH prev ready +" + elapsed() + "ms took=" + (SystemClock.elapsedRealtime()-started) + "ms");
                    });
                } catch (Throwable e) { AppLog.d(this, "PREFETCH prev error " + e); }
            });
        }
        if (next != null) {
            Drawable cached = getCachedPreview(next.uri);
            if (cached != null) {
                nextPreviewDrawable = cached;
            } else prefetchExecutor.execute(() -> {
                long started = SystemClock.elapsedRealtime();
                try {
                    Drawable d = decodePreviewDrawable(next.uri);
                    putCachedPreview(next.uri, d);
                    mainHandler.post(() -> {
                        if (generation != prefetchGeneration.get() || isFinishing()) return;
                        nextPreviewDrawable = d;
                        AppLog.d(this, "PREFETCH next ready +" + elapsed() + "ms took=" + (SystemClock.elapsedRealtime()-started) + "ms");
                    });
                } catch (Throwable e) { AppLog.d(this, "PREFETCH next error " + e); }
            });
        }
    }

    private void openPdf(Uri uri) {
        // PDF path remains synchronous for now; image opening is the performance priority for this build.
        try {
            AppLog.d(this, "PDF open begin uri=" + uri);
            pdfFd = getContentResolver().openFileDescriptor(uri, "r");
            if (pdfFd == null) throw new IOException("No file descriptor");
            pdfRenderer = new PdfRenderer(pdfFd);
            if (pdfRenderer.getPageCount() == 0) throw new IOException("Empty PDF");
            renderPdfPage(0);
        } catch (Throwable e) { AppLog.d(this, "PDF open ERROR " + e); Toast.makeText(this, "PDFを表示できませんでした", Toast.LENGTH_LONG).show(); }
    }

    private void renderPdfPage(int index) {
        closePdfPage(); pdfPage = pdfRenderer.openPage(index);
        int screenWidth = Math.max(1, getResources().getDisplayMetrics().widthPixels);
        float ratio = (float) pdfPage.getHeight() / (float) pdfPage.getWidth();
        int bitmapWidth = Math.min(screenWidth * 2, 2200); int bitmapHeight = Math.max(1, Math.round(bitmapWidth * ratio));
        Bitmap bitmap = Bitmap.createBitmap(bitmapWidth, bitmapHeight, Bitmap.Config.ARGB_8888); bitmap.eraseColor(Color.WHITE);
        pdfPage.render(bitmap, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY);
        imageView.setImageForViewer(new android.graphics.drawable.BitmapDrawable(getResources(), bitmap));
        pageView.setText((index + 1) + " / " + pdfRenderer.getPageCount());
    }

    private void updatePositionLabel() {
        if (progressiveListActive && !siblings.isEmpty()) {
            // left: selected-order range proven around the tapped/current image
            // middle: absolute current position once the previous chain reaches folder start
            // right: selected-order rows discovered so far, updated batch by batch
            int discovered = siblings.size();
            int centeredReady = (progressivePrevComplete || progressiveNextComplete)
                    ? discovered
                    : 1 + 2 * Math.min(progressivePrevLoaded, progressiveNextLoaded);
            String pos = progressivePrevComplete ? Integer.toString(currentIndex + 1) : "?";
            pageView.setText(centeredReady + " / " + pos + " / " + discovered);
            return;
        }
        if (currentIndex >= 0 && siblings.size() > 1) pageView.setText((currentIndex + 1) + " / " + siblings.size());
        else pageView.setText("");
    }

    private boolean hasMediaPermission() {
        if (Build.VERSION.SDK_INT >= 33) return checkSelfPermission(Manifest.permission.READ_MEDIA_IMAGES) == PackageManager.PERMISSION_GRANTED;
        return checkSelfPermission(Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED;
    }

    private void requestMediaPermission() {
        if (Build.VERSION.SDK_INT >= 33) requestPermissions(new String[]{Manifest.permission.READ_MEDIA_IMAGES}, REQ_MEDIA);
        else requestPermissions(new String[]{Manifest.permission.READ_EXTERNAL_STORAGE}, REQ_MEDIA);
    }

    @Override public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQ_MEDIA && grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            AppLog.d(this, "PERMISSION media granted"); discoverSiblingImagesAsync();
        } else if (requestCode == REQ_MEDIA) AppLog.d(this, "PERMISSION media denied");
    }

    private static class SeedSortKey {
        final long id;
        final String name;
        final long size;
        final long modified;
        SeedSortKey(long id, String name, long size, long modified) {
            this.id = id; this.name = name; this.size = size; this.modified = modified;
        }
    }

    private static class ResolvedSeed {
        final String relativePath;
        final SeedSortKey key;
        final String mime;
        final String strategy;
        ResolvedSeed(String relativePath, SeedSortKey key, String mime, String strategy) {
            this.relativePath = relativePath;
            this.key = key;
            this.mime = mime;
            this.strategy = strategy;
        }
    }

    private static class IncomingMeta {
        String name;
        String relativePath;
        String rawPath;
        long size = -1L;
        long modified = -1L;
    }

    private MediaItem queryNeighbor(String relativePath, SeedSortKey seed, boolean next, String field, boolean ascending) {
        if (seed == null) return null;
        String[] projection = new String[]{MediaStore.Images.Media._ID, MediaStore.Images.Media.DISPLAY_NAME, MediaStore.Images.Media.MIME_TYPE, MediaStore.Images.Media.SIZE, MediaStore.Images.Media.DATE_MODIFIED};

        // "next" means forward in the currently selected slide order. Previous uses the
        // exact inverse. _ID is the stable tie-breaker for every sort mode so the quick
        // LIMIT-1 route and the later full-folder list can never disagree on neighbors.
        boolean forwardAscending = next == ascending;
        String cmp = forwardAscending ? ">" : "<";
        String order = forwardAscending ? " ASC" : " DESC";
        String selection;
        String[] args;
        String sort;

        if (SortPrefs.FIELD_NAME.equals(field)) {
            selection = MediaStore.Images.Media.RELATIVE_PATH + "=? AND ((" +
                    MediaStore.Images.Media.DISPLAY_NAME + " COLLATE NOCASE " + cmp + " ?) OR (" +
                    MediaStore.Images.Media.DISPLAY_NAME + " = ? COLLATE NOCASE AND " +
                    MediaStore.Images.Media._ID + " " + cmp + " ?))";
            args = new String[]{relativePath, seed.name, seed.name, Long.toString(seed.id)};
            sort = MediaStore.Images.Media.DISPLAY_NAME + " COLLATE NOCASE" + order + ", " +
                    MediaStore.Images.Media._ID + order;
        } else {
            String col = SortPrefs.sqlColumn(field);
            long seedValue = SortPrefs.FIELD_SIZE.equals(field) ? seed.size : seed.modified;
            selection = MediaStore.Images.Media.RELATIVE_PATH + "=? AND ((" + col + " " + cmp + " ?) OR (" +
                    col + "=? AND " + MediaStore.Images.Media._ID + " " + cmp + " ?))";
            args = new String[]{relativePath, Long.toString(seedValue), Long.toString(seedValue), Long.toString(seed.id)};
            sort = col + order + ", " + MediaStore.Images.Media._ID + order;
        }

        long started = SystemClock.elapsedRealtime();
        MediaItem item = queryFirstMediaItemLimited(projection, selection, args, sort);
        AppLog.d(this, "SIBLINGS neighbor " + (next ? "next" : "prev") +
                " field=" + field + " asc=" + ascending + " took=" +
                (SystemClock.elapsedRealtime() - started) + "ms ready=" + (item != null));
        return item;
    }

    private MediaItem queryFirstMediaItemLimited(String[] projection, String selection, String[] args, String sort) {
        try {
            Bundle queryArgs = new Bundle();
            queryArgs.putString(ContentResolver.QUERY_ARG_SQL_SELECTION, selection);
            queryArgs.putStringArray(ContentResolver.QUERY_ARG_SQL_SELECTION_ARGS, args);
            queryArgs.putString(ContentResolver.QUERY_ARG_SQL_SORT_ORDER, sort);
            queryArgs.putInt(ContentResolver.QUERY_ARG_LIMIT, 1);
            try (Cursor c = getContentResolver().query(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, projection, queryArgs, null)) {
                return firstMediaItemFromCursor(c);
            }
        } catch (Throwable e) {
            AppLog.d(this, "SIBLINGS neighbor bundle query error " + e);
            // Compatibility fallback: same selection/sort, but never append SQL LIMIT to
            // sortOrder. We only read the first row from the returned cursor.
            try (Cursor c = getContentResolver().query(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, projection, selection, args, sort)) {
                return firstMediaItemFromCursor(c);
            } catch (Throwable fallbackError) {
                AppLog.d(this, "SIBLINGS neighbor fallback error " + fallbackError);
            }
        }
        return null;
    }

    private MediaItem firstMediaItemFromCursor(Cursor c) {
        if (c != null && c.moveToFirst()) {
            long id = c.getLong(c.getColumnIndexOrThrow(MediaStore.Images.Media._ID));
            String name = c.getString(c.getColumnIndexOrThrow(MediaStore.Images.Media.DISPLAY_NAME));
            String mime = c.getString(c.getColumnIndexOrThrow(MediaStore.Images.Media.MIME_TYPE));
            long size = c.getLong(c.getColumnIndexOrThrow(MediaStore.Images.Media.SIZE));
            long modified = c.getLong(c.getColumnIndexOrThrow(MediaStore.Images.Media.DATE_MODIFIED));
            return new MediaItem(ContentUris.withAppendedId(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, id), name, mime, size, modified);
        }
        return null;
    }

    private SeedSortKey lookupSeedSortKey(String relativePath, String seedName) {
        String[] projection = new String[]{MediaStore.Images.Media._ID, MediaStore.Images.Media.DISPLAY_NAME, MediaStore.Images.Media.SIZE, MediaStore.Images.Media.DATE_MODIFIED};
        try (Cursor c = getContentResolver().query(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, projection,
                MediaStore.Images.Media.RELATIVE_PATH + "=? AND " + MediaStore.Images.Media.DISPLAY_NAME + "=? COLLATE NOCASE",
                new String[]{relativePath, seedName}, MediaStore.Images.Media._ID + " ASC")) {
            if (c != null && c.moveToFirst()) {
                return new SeedSortKey(
                        c.getLong(c.getColumnIndexOrThrow(MediaStore.Images.Media._ID)),
                        c.getString(c.getColumnIndexOrThrow(MediaStore.Images.Media.DISPLAY_NAME)),
                        c.getLong(c.getColumnIndexOrThrow(MediaStore.Images.Media.SIZE)),
                        c.getLong(c.getColumnIndexOrThrow(MediaStore.Images.Media.DATE_MODIFIED)));
            }
        } catch (Throwable e) {
            AppLog.d(this, "SIBLINGS seed sort lookup error " + e);
        }
        return null;
    }

    private void discoverSiblingImagesAsync() {
        if (ENABLE_CURSOR_OUT_EXPERIMENT) discoverSiblingImagesCursorOut();
        else if (ENABLE_CENTER_OUT_EXPERIMENT) discoverSiblingImagesCenterOut();
        else if (ENABLE_EXTERNAL_FAST_PATH_EXPERIMENT) discoverSiblingImagesExperimental();
        else discoverSiblingImagesLegacy();
    }

    /**
     * v0.1.19: generic external-URI resolver + two long-lived ordered cursors.
     *
     * Critical path:
     *   incoming URI -> exact MediaStore seed row -> previous cursor + next cursor
     * Each cursor is queried once, then consumed outward from the current image. There is
     * no LIMIT/paging loop and therefore no repeated 300-1000 ms provider round-trip.
     */
    private void discoverSiblingImagesCursorOut() {
        cancelSiblingQuerySignals();
        final int generation = siblingGeneration.incrementAndGet();
        prefetchGeneration.incrementAndGet();
        final Uri seedUri = currentUri;
        final String seedName = currentName;
        final String sortField = SortPrefs.field(this);
        final boolean sortAscending = SortPrefs.ascending(this);

        fullListReady = false;
        progressiveListActive = true;
        progressivePrevComplete = false;
        progressiveNextComplete = false;
        progressivePrevLoaded = 0;
        progressiveNextLoaded = 0;
        quickPreviousItem = null;
        quickNextItem = null;
        previousPreviewDrawable = null;
        nextPreviewDrawable = null;

        final CancellationSignal seedSignal = new CancellationSignal();
        seedResolveSignal = seedSignal;
        safeExecute(scanExecutor, () -> {
            try {
                AppLog.d(this, "SIBLINGS locate begin +" + elapsed() + "ms seed=" + seedName + " mode=cursor-out");

                // Preserve the v0.1.17 win: for path-style launchers, a same-folder reopen
                // can hit the completed RAM index before any MediaStore seed query.
                String cachePath = inferRelativePathFromAnyUri(seedUri);
                if (cachePath != null && !cachePath.isEmpty()) {
                    if (!cachePath.endsWith("/")) cachePath += "/";
                    ArrayList<MediaItem> instantCache = getFolderCache(cachePath, sortField, sortAscending);
                    if (instantCache != null && publishFullList(generation, seedName, instantCache, "ram-cache-preseed", 0L)) {
                        progressiveListActive = false;
                        AppLog.d(this, "CURSOR RAM cache preseed hit +" + elapsed() + "ms found=" + instantCache.size());
                        return;
                    }
                }

                // v0.1.20 fast route: if the incoming URI exposes a real shared-storage path,
                // enumerate only lightweight file metadata directly. No MediaStore seed query.
                if (ENABLE_DIRECT_FILE_ENUM_EXPERIMENT &&
                        tryDirectFilesystemIndex(generation, seedUri, seedName, cachePath, sortField, sortAscending)) {
                    progressiveListActive = false;
                    return;
                }

                long started = SystemClock.elapsedRealtime();
                ResolvedSeed resolved = resolveIncomingSeed(seedUri, seedName, seedSignal);
                long took = SystemClock.elapsedRealtime() - started;
                if (generation != siblingGeneration.get() || seedSignal.isCanceled()) return;
                if (resolved == null || resolved.key == null || resolved.relativePath == null) {
                    progressiveListActive = false;
                    AppLog.d(this, "CURSOR seed unresolved +" + elapsed() + "ms took=" + took + "ms");
                    return;
                }
                String path = resolved.relativePath.endsWith("/") ? resolved.relativePath : resolved.relativePath + "/";
                AppLog.d(this, "CURSOR seed ready +" + elapsed() + "ms took=" + took + "ms strategy=" +
                        resolved.strategy + " path=" + path + " id=" + resolved.key.id);

                ArrayList<MediaItem> cached = getFolderCache(path, sortField, sortAscending);
                if (cached != null && publishFullList(generation, resolved.key.name, cached, "ram-cache", 0L)) {
                    progressiveListActive = false;
                    AppLog.d(this, "CURSOR RAM cache hit +" + elapsed() + "ms found=" + cached.size());
                    return;
                }

                String centerMime = resolved.mime != null ? resolved.mime : currentMime;
                MediaItem center = new MediaItem(
                        ContentUris.withAppendedId(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, resolved.key.id),
                        resolved.key.name, centerMime, resolved.key.size, resolved.key.modified);
                mainHandler.post(() -> {
                    if (generation != siblingGeneration.get() || isFinishing()) return;
                    siblings.clear();
                    siblings.add(center);
                    currentIndex = 0;
                    progressiveListActive = true;
                    updateProgressivePositionLabel();
                });

                AtomicInteger sidesDone = new AtomicInteger(0);
                CancellationSignal prevSignal = new CancellationSignal();
                CancellationSignal nextSignal = new CancellationSignal();
                previousCursorSignal = prevSignal;
                nextCursorSignal = nextSignal;
                safeExecute(neighborExecutor, () -> streamNeighborCursor(
                        generation, path, resolved.key, false, sortField, sortAscending, sidesDone, prevSignal));
                safeExecute(neighborExecutor, () -> streamNeighborCursor(
                        generation, path, resolved.key, true, sortField, sortAscending, sidesDone, nextSignal));
            } catch (android.os.OperationCanceledException ignored) {
                AppLog.d(this, "CURSOR seed canceled +" + elapsed() + "ms");
            } catch (Throwable e) {
                if (generation == siblingGeneration.get()) {
                    progressiveListActive = false;
                    AppLog.d(this, "CURSOR seed error +" + elapsed() + "ms " + e);
                }
            }
        });
    }

    private ResolvedSeed resolveIncomingSeed(Uri uri, String fallbackName, CancellationSignal signal) {
        if (uri == null) return null;

        // Fastest possible route: the launcher already gave us a MediaStore item URI.
        ResolvedSeed direct = tryResolveDirectMediaUri(uri, signal);
        if (direct != null) return direct;

        // Path-like providers (Solid Explorer, external-storage DocumentsProvider, etc.)
        // often encode enough location information in the URI itself. This needs no IPC.
        String inferredPath = inferRelativePathFromAnyUri(uri);
        String name = fallbackName;
        // If the URI itself already exposes the shared-storage path (Solid Explorer and many
        // DocumentsProvider URIs do), avoid another provider IPC and go straight to MediaStore.
        if (inferredPath != null && !inferredPath.isEmpty() && name != null && !name.isEmpty()) {
            ResolvedSeed byPath = queryExactSeedByPath(inferredPath, name, signal, "uri-path+name");
            if (byPath != null) return byPath;
        }

        IncomingMeta meta = readIncomingMeta(uri, signal);
        if (meta != null && meta.name != null && !meta.name.isEmpty()) name = meta.name;
        if ((inferredPath == null || inferredPath.isEmpty()) && meta != null) {
            if (meta.relativePath != null && !meta.relativePath.isEmpty()) inferredPath = meta.relativePath;
            else if (meta.rawPath != null) inferredPath = relativePathFromAbsolute(meta.rawPath);
        }
        if (inferredPath != null && !inferredPath.isEmpty() && name != null && !name.isEmpty()) {
            ResolvedSeed byPath = queryExactSeedByPath(inferredPath, name, signal, "provider-path+name");
            if (byPath != null) return byPath;
        }

        // Opaque provider URI: use metadata from the single granted file to narrow MediaStore.
        if (name != null && meta != null) {
            ResolvedSeed byMeta = querySeedByMetadata(name, meta.size, meta.modified, signal);
            if (byMeta != null) return byMeta;
        }

        // Last safe fallback: a unique display name in MediaStore. If ambiguous we refuse to
        // guess a folder, because a wrong sibling chain is worse than no chain.
        if (name != null && !name.isEmpty()) return queryUniqueSeedByName(name, signal);
        return null;
    }

    private ResolvedSeed tryResolveDirectMediaUri(Uri uri, CancellationSignal signal) {
        String authority = uri.getAuthority();
        if (authority == null || !authority.toLowerCase(Locale.ROOT).contains("media")) return null;
        String[] projection = new String[]{MediaStore.Images.Media._ID, MediaStore.Images.Media.DISPLAY_NAME,
                MediaStore.Images.Media.MIME_TYPE, MediaStore.Images.Media.SIZE,
                MediaStore.Images.Media.DATE_MODIFIED, MediaStore.Images.Media.RELATIVE_PATH};
        try (Cursor c = getContentResolver().query(uri, projection, null, null, null, signal)) {
            if (c != null && c.moveToFirst()) return resolvedSeedFromCursor(c, "direct-media-uri");
        } catch (Throwable e) {
            if (!(e instanceof android.os.OperationCanceledException))
                AppLog.d(this, "URI direct media miss " + e.getClass().getSimpleName());
        }
        return null;
    }

    private IncomingMeta readIncomingMeta(Uri uri, CancellationSignal signal) {
        if (uri == null || !"content".equalsIgnoreCase(uri.getScheme())) return null;
        IncomingMeta out = new IncomingMeta();
        try (Cursor c = getContentResolver().query(uri, null, null, null, null, signal)) {
            if (c == null || !c.moveToFirst()) return out;
            int nameCol = findColumn(c, OpenableColumns.DISPLAY_NAME, MediaStore.MediaColumns.DISPLAY_NAME,
                    "display_name", "name", "_display_name");
            int sizeCol = findColumn(c, OpenableColumns.SIZE, MediaStore.MediaColumns.SIZE, "size", "_size");
            int modifiedCol = findColumn(c, MediaStore.MediaColumns.DATE_MODIFIED,
                    "last_modified", "date_modified", "modified", "mtime");
            int relativeCol = findColumn(c, MediaStore.MediaColumns.RELATIVE_PATH, "relative_path");
            int dataCol = findColumn(c, "_data", "data", "path", "file_path");
            if (nameCol >= 0 && !c.isNull(nameCol)) out.name = c.getString(nameCol);
            if (sizeCol >= 0 && !c.isNull(sizeCol)) out.size = c.getLong(sizeCol);
            if (modifiedCol >= 0 && !c.isNull(modifiedCol)) out.modified = c.getLong(modifiedCol);
            if (relativeCol >= 0 && !c.isNull(relativeCol)) out.relativePath = c.getString(relativeCol);
            if (dataCol >= 0 && !c.isNull(dataCol)) out.rawPath = c.getString(dataCol);
            AppLog.d(this, "URI meta authority=" + uri.getAuthority() + " cols=" + Arrays.toString(c.getColumnNames()) +
                    " name=" + out.name + " size=" + out.size + " modified=" + out.modified +
                    " rel=" + out.relativePath + " raw=" + (out.rawPath != null));
        } catch (Throwable e) {
            if (!(e instanceof android.os.OperationCanceledException))
                AppLog.d(this, "URI meta unavailable authority=" + uri.getAuthority() + " " + e.getClass().getSimpleName());
        }
        return out;
    }

    private String inferRelativePathFromAnyUri(Uri uri) {
        if (uri == null) return null;
        try {
            String raw = Uri.decode(uri.getPath());
            if (raw != null) {
                String absoluteRelative = relativePathFromAbsolute(raw);
                if (absoluteRelative != null) return absoluteRelative;
                int primary = raw.indexOf("primary:");
                if (primary >= 0) {
                    String relativeFile = raw.substring(primary + "primary:".length());
                    int slash = relativeFile.lastIndexOf('/');
                    if (slash >= 0) return relativeFile.substring(0, slash + 1);
                }
            }
            if (Build.VERSION.SDK_INT >= 19 && DocumentsContract.isDocumentUri(this, uri)) {
                String docId = DocumentsContract.getDocumentId(uri);
                if (docId != null) {
                    if (docId.startsWith("primary:")) {
                        String relativeFile = docId.substring("primary:".length());
                        int slash = relativeFile.lastIndexOf('/');
                        if (slash >= 0) return relativeFile.substring(0, slash + 1);
                    }
                    if (docId.startsWith("raw:")) return relativePathFromAbsolute(docId.substring(4));
                }
            }
        } catch (Throwable e) {
            AppLog.d(this, "URI path inference miss " + e.getClass().getSimpleName());
        }
        return null;
    }

    private String relativePathFromAbsolute(String absolute) {
        if (absolute == null) return null;
        String[] markers = new String[]{"/storage/emulated/0/", "/storage/self/primary/", "/sdcard/"};
        for (String marker : markers) {
            int idx = absolute.indexOf(marker);
            if (idx < 0) continue;
            String relativeFile = absolute.substring(idx + marker.length());
            int slash = relativeFile.lastIndexOf('/');
            if (slash >= 0) return relativeFile.substring(0, slash + 1);
        }
        return null;
    }

    private ResolvedSeed queryExactSeedByPath(String relativePath, String name,
                                               CancellationSignal signal, String strategy) {
        if (!relativePath.endsWith("/")) relativePath += "/";
        String selection = MediaStore.Images.Media.RELATIVE_PATH + "=? AND " +
                MediaStore.Images.Media.DISPLAY_NAME + "=? COLLATE NOCASE";
        return querySingleResolvedSeed(selection, new String[]{relativePath, name}, signal, strategy);
    }

    private ResolvedSeed querySeedByMetadata(String name, long size, long providerModified,
                                             CancellationSignal signal) {
        String selection;
        String[] args;
        if (size >= 0) {
            selection = MediaStore.Images.Media.DISPLAY_NAME + "=? COLLATE NOCASE AND " +
                    MediaStore.Images.Media.SIZE + "=?";
            args = new String[]{name, Long.toString(size)};
        } else {
            return null;
        }
        ArrayList<ResolvedSeed> candidates = queryResolvedSeeds(selection, args, signal, 8);
        if (candidates.size() == 1) {
            ResolvedSeed r = candidates.get(0);
            return new ResolvedSeed(r.relativePath, r.key, r.mime, "name+size");
        }
        if (candidates.size() > 1 && providerModified >= 0) {
            long seconds = providerModified > 100000000000L ? providerModified / 1000L : providerModified;
            ResolvedSeed best = null;
            long bestDelta = Long.MAX_VALUE;
            for (ResolvedSeed r : candidates) {
                long delta = Math.abs(r.key.modified - seconds);
                if (delta < bestDelta) { bestDelta = delta; best = r; }
            }
            if (best != null && bestDelta <= 2L)
                return new ResolvedSeed(best.relativePath, best.key, best.mime, "name+size+modified");
        }
        if (candidates.size() > 1) AppLog.d(this, "URI metadata ambiguous name=" + name + " matches=" + candidates.size());
        return null;
    }

    private ResolvedSeed queryUniqueSeedByName(String name, CancellationSignal signal) {
        ArrayList<ResolvedSeed> candidates = queryResolvedSeeds(
                MediaStore.Images.Media.DISPLAY_NAME + "=? COLLATE NOCASE", new String[]{name}, signal, 2);
        if (candidates.size() == 1) {
            ResolvedSeed r = candidates.get(0);
            return new ResolvedSeed(r.relativePath, r.key, r.mime, "unique-name");
        }
        if (candidates.size() > 1) AppLog.d(this, "URI name ambiguous name=" + name);
        return null;
    }

    private ResolvedSeed querySingleResolvedSeed(String selection, String[] args,
                                                 CancellationSignal signal, String strategy) {
        ArrayList<ResolvedSeed> rows = queryResolvedSeeds(selection, args, signal, 1);
        if (rows.isEmpty()) return null;
        ResolvedSeed r = rows.get(0);
        return new ResolvedSeed(r.relativePath, r.key, r.mime, strategy);
    }

    private ArrayList<ResolvedSeed> queryResolvedSeeds(String selection, String[] args,
                                                       CancellationSignal signal, int limit) {
        ArrayList<ResolvedSeed> rows = new ArrayList<>();
        String[] projection = new String[]{MediaStore.Images.Media._ID, MediaStore.Images.Media.DISPLAY_NAME,
                MediaStore.Images.Media.MIME_TYPE, MediaStore.Images.Media.SIZE,
                MediaStore.Images.Media.DATE_MODIFIED, MediaStore.Images.Media.RELATIVE_PATH};
        Bundle queryArgs = new Bundle();
        queryArgs.putString(ContentResolver.QUERY_ARG_SQL_SELECTION, selection);
        queryArgs.putStringArray(ContentResolver.QUERY_ARG_SQL_SELECTION_ARGS, args);
        queryArgs.putString(ContentResolver.QUERY_ARG_SQL_SORT_ORDER, MediaStore.Images.Media._ID + " ASC");
        queryArgs.putInt(ContentResolver.QUERY_ARG_LIMIT, Math.max(1, limit));
        try (Cursor c = getContentResolver().query(MediaStore.Images.Media.EXTERNAL_CONTENT_URI,
                projection, queryArgs, signal)) {
            while (c != null && c.moveToNext() && rows.size() < limit) {
                ResolvedSeed r = resolvedSeedFromCursor(c, "candidate");
                if (r != null) rows.add(r);
            }
        } catch (Throwable e) {
            if (!(e instanceof android.os.OperationCanceledException))
                AppLog.d(this, "URI MediaStore resolver error " + e);
        }
        return rows;
    }

    private ResolvedSeed resolvedSeedFromCursor(Cursor c, String strategy) {
        if (c == null) return null;
        int idCol = c.getColumnIndex(MediaStore.Images.Media._ID);
        int nameCol = c.getColumnIndex(MediaStore.Images.Media.DISPLAY_NAME);
        int mimeCol = c.getColumnIndex(MediaStore.Images.Media.MIME_TYPE);
        int sizeCol = c.getColumnIndex(MediaStore.Images.Media.SIZE);
        int modifiedCol = c.getColumnIndex(MediaStore.Images.Media.DATE_MODIFIED);
        int pathCol = c.getColumnIndex(MediaStore.Images.Media.RELATIVE_PATH);
        if (idCol < 0 || nameCol < 0 || pathCol < 0) return null;
        long id = c.getLong(idCol);
        String name = c.getString(nameCol);
        long size = sizeCol >= 0 && !c.isNull(sizeCol) ? c.getLong(sizeCol) : 0L;
        long modified = modifiedCol >= 0 && !c.isNull(modifiedCol) ? c.getLong(modifiedCol) : 0L;
        String mime = mimeCol >= 0 && !c.isNull(mimeCol) ? c.getString(mimeCol) : mimeFromName(name);
        String path = c.getString(pathCol);
        return new ResolvedSeed(path, new SeedSortKey(id, name, size, modified), mime, strategy);
    }

    private void streamNeighborCursor(int generation, String path, SeedSortKey seedKey, boolean next,
                                      String field, boolean ascending, AtomicInteger sidesDone,
                                      CancellationSignal signal) {
        long openedAt = SystemClock.elapsedRealtime();
        int total = 0;
        try (Cursor c = openNeighborCursor(path, seedKey, next, field, ascending, signal)) {
            long openMs = SystemClock.elapsedRealtime() - openedAt;
            if (generation != siblingGeneration.get() || signal.isCanceled()) return;
            AppLog.d(this, "CURSOR " + (next ? "next" : "prev") + " opened +" + elapsed() +
                    "ms took=" + openMs + "ms");
            if (c == null) {
                markCursorSideComplete(generation, next, path, field, ascending, sidesDone, 0);
                return;
            }
            ArrayList<MediaItem> chunk = new ArrayList<>(CURSOR_MERGE_CHUNK_SIZE);
            while (generation == siblingGeneration.get() && !signal.isCanceled() && c.moveToNext()) {
                MediaItem item = mediaItemFromCurrentCursorRow(c);
                if (item != null) {
                    total++;
                    if (total == 1) {
                        // Publish the actual adjacent item immediately; do not wait for a 24-row
                        // UI batch before allowing the first swipe on this side.
                        ArrayList<MediaItem> adjacent = new ArrayList<>(1);
                        adjacent.add(item);
                        mergeProgressiveBatch(generation, adjacent, next);
                    } else {
                        chunk.add(item);
                    }
                }
                if (chunk.size() >= CURSOR_MERGE_CHUNK_SIZE) {
                    mergeProgressiveBatch(generation, chunk, next);
                    chunk = new ArrayList<>(CURSOR_MERGE_CHUNK_SIZE);
                }
            }
            if (!chunk.isEmpty()) mergeProgressiveBatch(generation, chunk, next);
            if (generation == siblingGeneration.get() && !signal.isCanceled())
                markCursorSideComplete(generation, next, path, field, ascending, sidesDone, total);
        } catch (android.os.OperationCanceledException ignored) {
            AppLog.d(this, "CURSOR " + (next ? "next" : "prev") + " canceled +" + elapsed() + "ms");
        } catch (Throwable e) {
            if (generation == siblingGeneration.get()) {
                AppLog.d(this, "CURSOR " + (next ? "next" : "prev") + " error " + e);
                markCursorSideComplete(generation, next, path, field, ascending, sidesDone, total);
            }
        }
    }

    private Cursor openNeighborCursor(String relativePath, SeedSortKey anchor, boolean next,
                                      String field, boolean ascending, CancellationSignal signal) {
        String[] projection = new String[]{MediaStore.Images.Media._ID, MediaStore.Images.Media.DISPLAY_NAME,
                MediaStore.Images.Media.MIME_TYPE, MediaStore.Images.Media.SIZE,
                MediaStore.Images.Media.DATE_MODIFIED};
        boolean outwardAscending = next == ascending;
        String cmp = outwardAscending ? ">" : "<";
        String order = outwardAscending ? " ASC" : " DESC";
        String selection;
        String[] args;
        String sort;
        if (SortPrefs.FIELD_NAME.equals(field)) {
            selection = MediaStore.Images.Media.RELATIVE_PATH + "=? AND ((" +
                    MediaStore.Images.Media.DISPLAY_NAME + " COLLATE NOCASE " + cmp + " ?) OR (" +
                    MediaStore.Images.Media.DISPLAY_NAME + " = ? COLLATE NOCASE AND " +
                    MediaStore.Images.Media._ID + " " + cmp + " ?))";
            args = new String[]{relativePath, anchor.name, anchor.name, Long.toString(anchor.id)};
            sort = MediaStore.Images.Media.DISPLAY_NAME + " COLLATE NOCASE" + order + ", " +
                    MediaStore.Images.Media._ID + order;
        } else {
            String col = SortPrefs.sqlColumn(field);
            long value = SortPrefs.FIELD_SIZE.equals(field) ? anchor.size : anchor.modified;
            selection = MediaStore.Images.Media.RELATIVE_PATH + "=? AND ((" + col + " " + cmp + " ?) OR (" +
                    col + "=? AND " + MediaStore.Images.Media._ID + " " + cmp + " ?))";
            args = new String[]{relativePath, Long.toString(value), Long.toString(value), Long.toString(anchor.id)};
            sort = col + order + ", " + MediaStore.Images.Media._ID + order;
        }
        Bundle queryArgs = new Bundle();
        queryArgs.putString(ContentResolver.QUERY_ARG_SQL_SELECTION, selection);
        queryArgs.putStringArray(ContentResolver.QUERY_ARG_SQL_SELECTION_ARGS, args);
        queryArgs.putString(ContentResolver.QUERY_ARG_SQL_SORT_ORDER, sort);
        // Deliberately no QUERY_ARG_LIMIT: one ordered cursor per side replaces dozens of
        // LIMIT-24 queries. CursorWindow streams the rows as they are consumed.
        return getContentResolver().query(MediaStore.Images.Media.EXTERNAL_CONTENT_URI,
                projection, queryArgs, signal);
    }

    private MediaItem mediaItemFromCurrentCursorRow(Cursor c) {
        int idCol = c.getColumnIndex(MediaStore.Images.Media._ID);
        int nameCol = c.getColumnIndex(MediaStore.Images.Media.DISPLAY_NAME);
        int mimeCol = c.getColumnIndex(MediaStore.Images.Media.MIME_TYPE);
        int sizeCol = c.getColumnIndex(MediaStore.Images.Media.SIZE);
        int modifiedCol = c.getColumnIndex(MediaStore.Images.Media.DATE_MODIFIED);
        if (idCol < 0 || nameCol < 0) return null;
        long id = c.getLong(idCol);
        String name = c.getString(nameCol);
        String mime = mimeCol >= 0 && !c.isNull(mimeCol) ? c.getString(mimeCol) : mimeFromName(name);
        long size = sizeCol >= 0 && !c.isNull(sizeCol) ? c.getLong(sizeCol) : 0L;
        long modified = modifiedCol >= 0 && !c.isNull(modifiedCol) ? c.getLong(modifiedCol) : 0L;
        return new MediaItem(ContentUris.withAppendedId(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, id),
                name, mime, size, modified);
    }

    private void markCursorSideComplete(int generation, boolean next, String path, String field,
                                        boolean ascending, AtomicInteger sidesDone, int total) {
        mainHandler.post(() -> {
            if (generation != siblingGeneration.get() || isFinishing()) return;
            if (next) progressiveNextComplete = true; else progressivePrevComplete = true;
            updateProgressivePositionLabel();
            AppLog.d(this, "CURSOR side complete +" + elapsed() + "ms side=" + (next ? "next" : "prev") +
                    " rows=" + total + " prevLoaded=" + progressivePrevLoaded + " nextLoaded=" + progressiveNextLoaded);
            if (sidesDone.incrementAndGet() == 2) {
                fullListReady = true;
                progressiveListActive = false;
                putFolderCache(path, field, ascending, siblings);
                AppLog.d(this, "CURSOR full ready +" + elapsed() + "ms found=" + siblings.size() +
                        " currentIndex=" + currentIndex);
                updatePositionLabel();
                prefetchAdjacent();
            }
        });
    }

    private void cancelSiblingQuerySignals() {
        CancellationSignal a = seedResolveSignal;
        CancellationSignal b = previousCursorSignal;
        CancellationSignal c = nextCursorSignal;
        seedResolveSignal = null;
        previousCursorSignal = null;
        nextCursorSignal = null;
        try { if (a != null && !a.isCanceled()) a.cancel(); } catch (Throwable ignored) { }
        try { if (b != null && !b.isCanceled()) b.cancel(); } catch (Throwable ignored) { }
        try { if (c != null && !c.isCanceled()) c.cancel(); } catch (Throwable ignored) { }
    }

    // Exact v0.1.16-style path retained for one-flag rollback.
    private void discoverSiblingImagesLegacy() {
        final int generation = siblingGeneration.incrementAndGet();
        final int prefetchToken = prefetchGeneration.incrementAndGet();
        final Uri seedUri = currentUri;
        final String seedName = currentName;
        final String sortField = SortPrefs.field(this);
        final boolean sortAscending = SortPrefs.ascending(this);

        fullListReady = false;
        quickPreviousItem = null; quickNextItem = null;
        previousPreviewDrawable = null; nextPreviewDrawable = null;

        safeExecute(scanExecutor, () -> {
            try {
                AppLog.d(this, "SIBLINGS locate begin +" + elapsed() + "ms seed=" + seedName + " mode=legacy");
                String relativePath = resolveRelativePath(seedUri);
                if (generation != siblingGeneration.get()) return;
                if (relativePath == null || relativePath.isEmpty()) return;
                if (!relativePath.endsWith("/")) relativePath += "/";
                final String path = relativePath;
                final SeedSortKey seedKey = lookupSeedSortKey(path, seedName);
                if (generation != siblingGeneration.get()) return;
                if (seedKey == null) {
                    safeExecute(scanExecutor, () -> buildFullSiblingList(generation, seedName, path, sortField, sortAscending));
                    return;
                }
                final AtomicInteger remaining = new AtomicInteger(2);
                final AtomicReference<MediaItem> prevRef = new AtomicReference<>();
                final AtomicReference<MediaItem> nextRef = new AtomicReference<>();
                Runnable done = () -> {
                    if (remaining.decrementAndGet() == 0 && generation == siblingGeneration.get()) {
                        publishQuickPair(generation, prevRef.get(), nextRef.get(), prefetchToken, "media-legacy");
                        safeExecute(scanExecutor, () -> buildFullSiblingList(generation, seedName, path, sortField, sortAscending));
                    }
                };
                safeExecute(neighborExecutor, () -> { try { prevRef.set(queryNeighbor(path, seedKey, false, sortField, sortAscending)); } finally { done.run(); } });
                safeExecute(neighborExecutor, () -> { try { nextRef.set(queryNeighbor(path, seedKey, true, sortField, sortAscending)); } finally { done.run(); } });
            } catch (Throwable e) { AppLog.d(this, "SIBLINGS legacy error +" + elapsed() + "ms " + e); }
        });
    }

    private void discoverSiblingImagesExperimental() {
        final int generation = siblingGeneration.incrementAndGet();
        final int prefetchToken = prefetchGeneration.incrementAndGet();
        final Uri seedUri = currentUri;
        final String seedName = currentName;
        final String sortField = SortPrefs.field(this);
        final boolean sortAscending = SortPrefs.ascending(this);

        fullListReady = false;
        quickPreviousItem = null; quickNextItem = null;
        previousPreviewDrawable = null; nextPreviewDrawable = null;

        safeExecute(scanExecutor, () -> {
            try {
                AppLog.d(this, "SIBLINGS locate begin +" + elapsed() + "ms seed=" + seedName + " mode=external-race");
                String relativePath = resolveRelativePath(seedUri);
                if (generation != siblingGeneration.get()) return;
                if (relativePath == null || relativePath.isEmpty()) {
                    AppLog.d(this, "SIBLINGS no relative path +" + elapsed() + "ms");
                    return;
                }
                if (!relativePath.endsWith("/")) relativePath += "/";
                final String path = relativePath;
                AppLog.d(this, "SIBLINGS path=" + path + " +" + elapsed() + "ms race=cache/provider/full/neighbor");

                // 0) Process-memory cache. Reopening another image from the same folder/order
                // can become swipe-ready without touching MediaStore at all.
                ArrayList<MediaItem> cached = getFolderCache(path, sortField, sortAscending);
                if (cached != null && publishFullList(generation, seedName, cached, "ram-cache", 0L)) {
                    AppLog.d(this, "SIBLINGS RAM cache hit +" + elapsed() + "ms found=" + cached.size());
                    return;
                }

                // 1) Solid Explorer (or another path-style provider) parent-URI directory query.
                // It is fully isolated; failure never blocks the standard MediaStore paths.
                safeExecute(providerDirectoryExecutor, () -> tryProviderDirectoryFastPath(
                        generation, prefetchToken, seedUri, seedName, path, sortField, sortAscending));

                // 2) Full minimal MediaStore index starts immediately, instead of waiting for
                // seed lookup / neighbor queries. Logs showed this can beat LIMIT-1 on some runs.
                safeExecute(fullScanExecutor, () -> buildFullSiblingList(
                        generation, seedName, path, sortField, sortAscending));

                // 3) Existing selected-order previous/next MediaStore queries run in parallel.
                // This remains useful when the folder is huge but the indexed comparison is cheap.
                final long seedLookupStarted = SystemClock.elapsedRealtime();
                final SeedSortKey seedKey = lookupSeedSortKey(path, seedName);
                AppLog.d(this, "SIBLINGS seed lookup +" + elapsed() + "ms took=" +
                        (SystemClock.elapsedRealtime() - seedLookupStarted) + "ms ready=" + (seedKey != null));
                if (generation != siblingGeneration.get() || seedKey == null) return;

                final AtomicInteger remaining = new AtomicInteger(2);
                final AtomicReference<MediaItem> prevRef = new AtomicReference<>();
                final AtomicReference<MediaItem> nextRef = new AtomicReference<>();
                Runnable done = () -> {
                    if (remaining.decrementAndGet() == 0 && generation == siblingGeneration.get()) {
                        publishQuickPair(generation, prevRef.get(), nextRef.get(), prefetchToken, "media-neighbor");
                    }
                };
                safeExecute(neighborExecutor, () -> { try { prevRef.set(queryNeighbor(path, seedKey, false, sortField, sortAscending)); } finally { done.run(); } });
                safeExecute(neighborExecutor, () -> { try { nextRef.set(queryNeighbor(path, seedKey, true, sortField, sortAscending)); } finally { done.run(); } });
            } catch (Throwable e) { AppLog.d(this, "SIBLINGS experimental error +" + elapsed() + "ms " + e); }
        });
    }

    /**
     * v0.1.18: no full-folder scan is on the critical path. Resolve the tapped MediaStore
     * row once, then grow two keyset-paginated chains outward in the selected slide order:
     * -1/+1, then farther previous/next items. Each batch becomes swipeable immediately.
     */
    private void discoverSiblingImagesCenterOut() {
        final int generation = siblingGeneration.incrementAndGet();
        prefetchGeneration.incrementAndGet();
        final Uri seedUri = currentUri;
        final String seedName = currentName;
        final String sortField = SortPrefs.field(this);
        final boolean sortAscending = SortPrefs.ascending(this);

        fullListReady = false;
        progressiveListActive = true;
        progressivePrevComplete = false;
        progressiveNextComplete = false;
        progressivePrevLoaded = 0;
        progressiveNextLoaded = 0;
        quickPreviousItem = null; quickNextItem = null;
        previousPreviewDrawable = null; nextPreviewDrawable = null;

        safeExecute(scanExecutor, () -> {
            try {
                AppLog.d(this, "SIBLINGS locate begin +" + elapsed() + "ms seed=" + seedName + " mode=center-out");
                String relativePath = resolveRelativePath(seedUri);
                if (generation != siblingGeneration.get()) return;
                if (relativePath == null || relativePath.isEmpty()) {
                    AppLog.d(this, "CENTER no relative path +" + elapsed() + "ms");
                    return;
                }
                if (!relativePath.endsWith("/")) relativePath += "/";
                final String path = relativePath;

                ArrayList<MediaItem> cached = getFolderCache(path, sortField, sortAscending);
                if (cached != null && publishFullList(generation, seedName, cached, "ram-cache", 0L)) {
                    progressiveListActive = false;
                    AppLog.d(this, "CENTER RAM cache hit +" + elapsed() + "ms found=" + cached.size());
                    return;
                }

                long seedStarted = SystemClock.elapsedRealtime();
                SeedSortKey seedKey = lookupSeedSortKeyFast(path, seedName);
                AppLog.d(this, "CENTER seed ready +" + elapsed() + "ms took=" +
                        (SystemClock.elapsedRealtime() - seedStarted) + "ms ready=" + (seedKey != null));
                if (generation != siblingGeneration.get() || seedKey == null) {
                    progressiveListActive = false;
                    return;
                }

                MediaItem center = new MediaItem(
                        ContentUris.withAppendedId(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, seedKey.id),
                        seedKey.name, currentMime, seedKey.size, seedKey.modified);
                mainHandler.post(() -> {
                    if (generation != siblingGeneration.get() || isFinishing()) return;
                    siblings.clear();
                    siblings.add(center);
                    currentIndex = 0;
                    progressiveListActive = true;
                    updateProgressivePositionLabel();
                });

                AtomicInteger sidesDone = new AtomicInteger(0);
                safeExecute(neighborExecutor, () -> expandCenterOutSide(
                        generation, path, seedKey, false, sortField, sortAscending, sidesDone));
                safeExecute(neighborExecutor, () -> expandCenterOutSide(
                        generation, path, seedKey, true, sortField, sortAscending, sidesDone));
            } catch (Throwable e) {
                progressiveListActive = false;
                AppLog.d(this, "CENTER error +" + elapsed() + "ms " + e);
            }
        });
    }

    private SeedSortKey lookupSeedSortKeyFast(String relativePath, String seedName) {
        String[] projection = new String[]{MediaStore.Images.Media._ID, MediaStore.Images.Media.DISPLAY_NAME,
                MediaStore.Images.Media.SIZE, MediaStore.Images.Media.DATE_MODIFIED};
        String selection = MediaStore.Images.Media.RELATIVE_PATH + "=? AND " +
                MediaStore.Images.Media.DISPLAY_NAME + "=? COLLATE NOCASE";
        String[] args = new String[]{relativePath, seedName};
        try {
            Bundle queryArgs = new Bundle();
            queryArgs.putString(ContentResolver.QUERY_ARG_SQL_SELECTION, selection);
            queryArgs.putStringArray(ContentResolver.QUERY_ARG_SQL_SELECTION_ARGS, args);
            queryArgs.putString(ContentResolver.QUERY_ARG_SQL_SORT_ORDER, MediaStore.Images.Media._ID + " ASC");
            queryArgs.putInt(ContentResolver.QUERY_ARG_LIMIT, 1);
            try (Cursor c = getContentResolver().query(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, projection, queryArgs, null)) {
                if (c != null && c.moveToFirst()) {
                    return new SeedSortKey(
                            c.getLong(c.getColumnIndexOrThrow(MediaStore.Images.Media._ID)),
                            c.getString(c.getColumnIndexOrThrow(MediaStore.Images.Media.DISPLAY_NAME)),
                            c.getLong(c.getColumnIndexOrThrow(MediaStore.Images.Media.SIZE)),
                            c.getLong(c.getColumnIndexOrThrow(MediaStore.Images.Media.DATE_MODIFIED)));
                }
            }
        } catch (Throwable e) {
            AppLog.d(this, "CENTER seed bundle error " + e);
        }
        return lookupSeedSortKey(relativePath, seedName);
    }

    private void expandCenterOutSide(int generation, String path, SeedSortKey seedKey, boolean next,
                                     String field, boolean ascending, AtomicInteger sidesDone) {
        SeedSortKey anchor = seedKey;
        int batchNo = 0;
        try {
            while (generation == siblingGeneration.get() && !Thread.currentThread().isInterrupted()) {
                long started = SystemClock.elapsedRealtime();
                ArrayList<MediaItem> batch = queryNeighborBatch(path, anchor, next, field, ascending, CENTER_OUT_BATCH_SIZE);
                long took = SystemClock.elapsedRealtime() - started;
                batchNo++;
                AppLog.d(this, "CENTER " + (next ? "next" : "prev") + " batch=" + batchNo +
                        " took=" + took + "ms found=" + batch.size());
                if (batch.isEmpty()) {
                    markCenterOutSideComplete(generation, next, path, field, ascending, sidesDone);
                    return;
                }
                mergeProgressiveBatch(generation, batch, next);
                MediaItem farthest = batch.get(batch.size() - 1);
                anchor = seedKeyFromMediaItem(farthest);
                if (anchor == null || batch.size() < CENTER_OUT_BATCH_SIZE) {
                    markCenterOutSideComplete(generation, next, path, field, ascending, sidesDone);
                    return;
                }
                // Let image decoding and UI work breathe between metadata batches.
                try { Thread.sleep(8L); } catch (InterruptedException e) { Thread.currentThread().interrupt(); return; }
            }
        } catch (Throwable e) {
            AppLog.d(this, "CENTER " + (next ? "next" : "prev") + " error " + e);
            markCenterOutSideComplete(generation, next, path, field, ascending, sidesDone);
        }
    }

    private SeedSortKey seedKeyFromMediaItem(MediaItem item) {
        if (item == null || item.uri == null) return null;
        try {
            long id = ContentUris.parseId(item.uri);
            return new SeedSortKey(id, item.name, item.size, item.modified);
        } catch (Throwable e) {
            AppLog.d(this, "CENTER anchor id error " + e);
            return null;
        }
    }

    private ArrayList<MediaItem> queryNeighborBatch(String relativePath, SeedSortKey anchor, boolean next,
                                                     String field, boolean ascending, int limit) {
        ArrayList<MediaItem> out = new ArrayList<>();
        if (anchor == null) return out;
        String[] projection = new String[]{MediaStore.Images.Media._ID, MediaStore.Images.Media.DISPLAY_NAME,
                MediaStore.Images.Media.MIME_TYPE, MediaStore.Images.Media.SIZE, MediaStore.Images.Media.DATE_MODIFIED};
        boolean forwardAscending = next == ascending;
        String cmp = forwardAscending ? ">" : "<";
        String order = forwardAscending ? " ASC" : " DESC";
        String selection;
        String[] args;
        String sort;
        if (SortPrefs.FIELD_NAME.equals(field)) {
            selection = MediaStore.Images.Media.RELATIVE_PATH + "=? AND ((" +
                    MediaStore.Images.Media.DISPLAY_NAME + " COLLATE NOCASE " + cmp + " ?) OR (" +
                    MediaStore.Images.Media.DISPLAY_NAME + " = ? COLLATE NOCASE AND " +
                    MediaStore.Images.Media._ID + " " + cmp + " ?))";
            args = new String[]{relativePath, anchor.name, anchor.name, Long.toString(anchor.id)};
            sort = MediaStore.Images.Media.DISPLAY_NAME + " COLLATE NOCASE" + order + ", " +
                    MediaStore.Images.Media._ID + order;
        } else {
            String col = SortPrefs.sqlColumn(field);
            long value = SortPrefs.FIELD_SIZE.equals(field) ? anchor.size : anchor.modified;
            selection = MediaStore.Images.Media.RELATIVE_PATH + "=? AND ((" + col + " " + cmp + " ?) OR (" +
                    col + "=? AND " + MediaStore.Images.Media._ID + " " + cmp + " ?))";
            args = new String[]{relativePath, Long.toString(value), Long.toString(value), Long.toString(anchor.id)};
            sort = col + order + ", " + MediaStore.Images.Media._ID + order;
        }
        try {
            Bundle queryArgs = new Bundle();
            queryArgs.putString(ContentResolver.QUERY_ARG_SQL_SELECTION, selection);
            queryArgs.putStringArray(ContentResolver.QUERY_ARG_SQL_SELECTION_ARGS, args);
            queryArgs.putString(ContentResolver.QUERY_ARG_SQL_SORT_ORDER, sort);
            queryArgs.putInt(ContentResolver.QUERY_ARG_LIMIT, limit);
            try (Cursor c = getContentResolver().query(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, projection, queryArgs, null)) {
                appendMediaItemsFromCursor(c, out, limit);
            }
        } catch (Throwable bundleError) {
            AppLog.d(this, "CENTER batch bundle error " + bundleError);
            try (Cursor c = getContentResolver().query(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, projection, selection, args, sort)) {
                appendMediaItemsFromCursor(c, out, limit);
            } catch (Throwable fallbackError) {
                AppLog.d(this, "CENTER batch fallback error " + fallbackError);
            }
        }
        return out;
    }

    private void appendMediaItemsFromCursor(Cursor c, ArrayList<MediaItem> out, int limit) {
        if (c == null) return;
        int idCol = c.getColumnIndexOrThrow(MediaStore.Images.Media._ID);
        int nameCol = c.getColumnIndexOrThrow(MediaStore.Images.Media.DISPLAY_NAME);
        int mimeCol = c.getColumnIndexOrThrow(MediaStore.Images.Media.MIME_TYPE);
        int sizeCol = c.getColumnIndexOrThrow(MediaStore.Images.Media.SIZE);
        int modifiedCol = c.getColumnIndexOrThrow(MediaStore.Images.Media.DATE_MODIFIED);
        while (out.size() < limit && c.moveToNext()) {
            long id = c.getLong(idCol);
            out.add(new MediaItem(ContentUris.withAppendedId(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, id),
                    c.getString(nameCol), c.getString(mimeCol), c.getLong(sizeCol), c.getLong(modifiedCol)));
        }
    }

    private void mergeProgressiveBatch(int generation, ArrayList<MediaItem> batch, boolean next) {
        if (batch == null || batch.isEmpty()) return;
        final ArrayList<MediaItem> copy = new ArrayList<>(batch);
        mainHandler.post(() -> {
            if (generation != siblingGeneration.get() || isFinishing() || !progressiveListActive) return;
            boolean wasAtExpandingEdge = next ? currentIndex == siblings.size() - 1 : currentIndex == 0;
            if (next) {
                siblings.addAll(copy);
                progressiveNextLoaded += copy.size();
            } else {
                ArrayList<MediaItem> ordered = new ArrayList<>(copy);
                Collections.reverse(ordered);
                siblings.addAll(0, ordered);
                currentIndex += ordered.size();
                progressivePrevLoaded += ordered.size();
            }
            AppLog.d(this, "CENTER merge +" + elapsed() + "ms side=" + (next ? "next" : "prev") +
                    " loaded=" + siblings.size() + " currentWindowIndex=" + currentIndex);
            updateProgressivePositionLabel();
            // Do not restart preview decoding for every far-away metadata batch. Only when
            // this batch actually created a new adjacent page at the user's current edge.
            if (wasAtExpandingEdge) prefetchAdjacent();
        });
    }

    private void markCenterOutSideComplete(int generation, boolean next, String path, String field,
                                           boolean ascending, AtomicInteger sidesDone) {
        mainHandler.post(() -> {
            if (generation != siblingGeneration.get() || isFinishing()) return;
            if (next) progressiveNextComplete = true; else progressivePrevComplete = true;
            updateProgressivePositionLabel();
            AppLog.d(this, "CENTER side complete +" + elapsed() + "ms side=" + (next ? "next" : "prev") +
                    " prevLoaded=" + progressivePrevLoaded + " nextLoaded=" + progressiveNextLoaded);
            if (sidesDone.incrementAndGet() == 2) {
                fullListReady = true;
                progressiveListActive = false;
                putFolderCache(path, field, ascending, siblings);
                AppLog.d(this, "CENTER full ready +" + elapsed() + "ms found=" + siblings.size() +
                        " currentIndex=" + currentIndex);
                updatePositionLabel();
                prefetchAdjacent();
            }
        });
    }

    private void updateProgressivePositionLabel() {
        updatePositionLabel();
    }

    private void publishQuickPair(int generation, MediaItem prev, MediaItem next, int prefetchToken, String source) {
        mainHandler.post(() -> {
            if (generation != siblingGeneration.get() || isFinishing() || fullListReady) return;
            quickPreviousItem = prev;
            quickNextItem = next;
            AppLog.d(this, "SIBLINGS quick pair +" + elapsed() + "ms source=" + source +
                    " prev=" + (prev != null) + " next=" + (next != null));
            if (prev != null) prefetchQuick(prev, -1, prefetchToken);
            if (next != null) prefetchQuick(next, 1, prefetchToken);
        });
    }

    private boolean publishFullList(int generation, String seedName, List<MediaItem> found, String source, long scanMs) {
        if (generation != siblingGeneration.get() || found == null || found.isEmpty()) return false;
        int idx = -1;
        for (int i = 0; i < found.size(); i++) {
            if (sameName(found.get(i).name, seedName)) { idx = i; break; }
        }
        if (idx < 0) return false;
        final int finalIndex = idx;
        final ArrayList<MediaItem> copy = new ArrayList<>(found);
        mainHandler.post(() -> {
            if (generation != siblingGeneration.get() || isFinishing()) return;
            siblings.clear(); siblings.addAll(copy); currentIndex = finalIndex;
            fullListReady = true;
            quickPreviousItem = null; quickNextItem = null;
            AppLog.d(this, "SIBLINGS full ready +" + elapsed() + "ms source=" + source +
                    " scan=" + scanMs + "ms found=" + siblings.size() + " currentIndex=" + currentIndex);
            updatePositionLabel();
            prefetchAdjacent();
        });
        return true;
    }

    // Cache identity is the folder only. Sort field/direction never invalidates a warm folder index.
    private String folderCacheKey(String path) {
        return path == null ? "" : path;
    }

    private boolean cacheSupportsSort(FolderCacheEntry entry, String field) {
        if (entry == null) return false;
        if (SortPrefs.FIELD_NAME.equals(field)) return true;
        final boolean needSize = SortPrefs.FIELD_SIZE.equals(field);
        final boolean needModified = SortPrefs.FIELD_MODIFIED.equals(field);
        for (MediaItem item : entry.items) {
            if (item == null) continue;
            if (needSize && item.size < 0L) return false;
            if (needModified && item.modified < 0L) return false;
        }
        return true;
    }

    private ArrayList<MediaItem> getFolderCache(String path, String field, boolean asc) {
        String key = folderCacheKey(path);
        synchronized (FOLDER_CACHE_LOCK) {
            FolderCacheEntry e = FOLDER_INDEX_CACHE.get(key);
            if (e == null) return null;
            if (SystemClock.elapsedRealtime() - e.createdAt > FOLDER_CACHE_TTL_MS) {
                FOLDER_INDEX_CACHE.remove(key);
                return null;
            }
            // A name-only scan is intentionally incomplete for size/modified sorting.
            // If that metadata is missing, force one direct rescan that enriches this same cache.
            if (!cacheSupportsSort(e, field)) return null;
            ArrayList<MediaItem> out = new ArrayList<>(e.items);
            sortProviderItems(out, field, asc);
            return out;
        }
    }

    private void putFolderCache(String path, String field, boolean asc, List<MediaItem> items) {
        if (path == null || items == null || items.isEmpty()) return;
        String key = folderCacheKey(path);
        synchronized (FOLDER_CACHE_LOCK) {
            FolderCacheEntry previous = FOLDER_INDEX_CACHE.get(key);
            HashMap<String, MediaItem> oldByName = new HashMap<>();
            if (previous != null) {
                for (MediaItem old : previous.items) {
                    if (old != null && old.name != null) oldByName.put(old.name, old);
                }
            }

            ArrayList<MediaItem> merged = new ArrayList<>(items.size());
            for (MediaItem item : items) {
                if (item == null || item.name == null) continue;
                MediaItem old = oldByName.get(item.name);
                long size = item.size >= 0L ? item.size : (old == null ? -1L : old.size);
                long modified = item.modified >= 0L ? item.modified : (old == null ? -1L : old.modified);
                Uri uri = item.uri != null ? item.uri : (old == null ? null : old.uri);
                String mime = item.mime != null ? item.mime : (old == null ? null : old.mime);
                merged.add(new MediaItem(uri, item.name, mime, size, modified));
            }
            FOLDER_INDEX_CACHE.put(key, new FolderCacheEntry(SystemClock.elapsedRealtime(), merged));
        }
    }

    private boolean tryDirectFilesystemIndex(int generation, Uri seedUri, String seedName,
                                             String relativePath, String sortField, boolean sortAscending) {
        long started = SystemClock.elapsedRealtime();
        try {
            String absoluteSeed = inferAbsolutePathFromAnyUri(seedUri);
            if (absoluteSeed == null || absoluteSeed.isEmpty()) {
                AppLog.d(this, "FILE fast skip +" + elapsed() + "ms reason=no-absolute-path");
                return false;
            }
            File seedFile = new File(absoluteSeed);
            File parent = seedFile.getParentFile();
            if (parent == null || !parent.isDirectory() || !parent.canRead()) {
                AppLog.d(this, "FILE fast skip +" + elapsed() + "ms reason=unreadable-parent path=" +
                        (parent == null ? "null" : parent.getAbsolutePath()));
                return false;
            }
            // File.list() returns names without doing a per-entry stat. This matters for large folders:
            // name sort must not call isFile(), length(), or lastModified() for every item.
            String[] names = parent.list((dir, name) -> isSupportedImageName(name));
            if (names == null) {
                AppLog.d(this, "FILE fast skip +" + elapsed() + "ms reason=list-null");
                return false;
            }
            final boolean needSize = SortPrefs.FIELD_SIZE.equals(sortField);
            final boolean needModified = SortPrefs.FIELD_MODIFIED.equals(sortField);
            ArrayList<MediaItem> found = new ArrayList<>(names.length);
            for (String name : names) {
                if (generation != siblingGeneration.get()) return true;
                if (name == null || name.isEmpty()) continue;
                File f = new File(parent, name);
                long size = needSize ? Math.max(0L, f.length()) : -1L;
                long modified = needModified ? Math.max(0L, f.lastModified()) : -1L;
                found.add(new MediaItem(Uri.fromFile(f), name, mimeFromName(name), size, modified));
            }
            if (found.isEmpty()) {
                AppLog.d(this, "FILE fast skip +" + elapsed() + "ms reason=no-images");
                return false;
            }
            sortProviderItems(found, sortField, sortAscending);
            String cachePath = relativePath;
            if (cachePath == null || cachePath.isEmpty()) cachePath = relativePathFromAbsolute(absoluteSeed);
            if (cachePath == null || cachePath.isEmpty()) cachePath = parent.getAbsolutePath() + "/";
            if (!cachePath.endsWith("/")) cachePath += "/";
            putFolderCache(cachePath, sortField, sortAscending, found);
            long took = SystemClock.elapsedRealtime() - started;
            boolean published = publishFullList(generation, seedName, found, "filesystem-direct", took);
            AppLog.d(this, "FILE fast ready +" + elapsed() + "ms took=" + took + "ms found=" +
                    found.size() + " published=" + published + " metadata=" +
                    (needSize ? "size-only" : (needModified ? "modified-only" : "name-only")) +
                    " parent=" + parent.getAbsolutePath());
            return published;
        } catch (SecurityException e) {
            AppLog.d(this, "FILE fast denied +" + elapsed() + "ms " + e.getClass().getSimpleName());
            return false;
        } catch (Throwable e) {
            AppLog.d(this, "FILE fast error +" + elapsed() + "ms " + e);
            return false;
        }
    }

    private String inferAbsolutePathFromAnyUri(Uri uri) {
        if (uri == null) return null;
        try {
            if ("file".equalsIgnoreCase(uri.getScheme())) return uri.getPath();
            String raw = Uri.decode(uri.getPath());
            if (raw != null) {
                String[] markers = new String[]{"/storage/emulated/0/", "/storage/self/primary/", "/sdcard/"};
                for (String marker : markers) {
                    int idx = raw.indexOf(marker);
                    if (idx >= 0) {
                        String tail = raw.substring(idx + marker.length());
                        return new File(android.os.Environment.getExternalStorageDirectory(), tail).getAbsolutePath();
                    }
                }
                int primary = raw.indexOf("primary:");
                if (primary >= 0) {
                    String tail = raw.substring(primary + "primary:".length());
                    return new File(android.os.Environment.getExternalStorageDirectory(), tail).getAbsolutePath();
                }
            }
            if (Build.VERSION.SDK_INT >= 19 && DocumentsContract.isDocumentUri(this, uri)) {
                String docId = DocumentsContract.getDocumentId(uri);
                if (docId != null) {
                    if (docId.startsWith("primary:")) {
                        return new File(android.os.Environment.getExternalStorageDirectory(),
                                docId.substring("primary:".length())).getAbsolutePath();
                    }
                    if (docId.startsWith("raw:")) return docId.substring(4);
                }
            }
        } catch (Throwable e) {
            AppLog.d(this, "FILE absolute path inference miss " + e.getClass().getSimpleName());
        }
        return null;
    }

    private void tryProviderDirectoryFastPath(int generation, int prefetchToken, Uri seedUri,
                                              String seedName, String relativePath,
                                              String sortField, boolean sortAscending) {
        if (generation != siblingGeneration.get() || seedUri == null) return;
        String authority = seedUri.getAuthority();
        if (authority == null || !authority.equals("pl.solidexplorer2.files")) {
            AppLog.d(this, "PROVIDER fast skip authority=" + authority);
            return;
        }
        Uri parent = parentProviderUri(seedUri);
        if (parent == null) return;
        long started = SystemClock.elapsedRealtime();
        AppLog.d(this, "PROVIDER parent query begin +" + elapsed() + "ms uri=" + parent);
        try (Cursor c = getContentResolver().query(parent, null, null, null, null)) {
            if (c == null) {
                AppLog.d(this, "PROVIDER parent query null +" + elapsed() + "ms");
                return;
            }
            AppLog.d(this, "PROVIDER parent columns=" + Arrays.toString(c.getColumnNames()));
            int nameCol = findColumn(c, OpenableColumns.DISPLAY_NAME, "display_name", "name", "_display_name");
            int mimeCol = findColumn(c, "mime_type", "mimetype", "type");
            int sizeCol = findColumn(c, OpenableColumns.SIZE, "size", "_size");
            int modifiedCol = findColumn(c, "last_modified", "date_modified", "modified", "mtime");
            if (nameCol < 0) {
                AppLog.d(this, "PROVIDER parent unusable: no display-name column");
                return;
            }
            if ((SortPrefs.FIELD_SIZE.equals(sortField) && sizeCol < 0) ||
                    (SortPrefs.FIELD_MODIFIED.equals(sortField) && modifiedCol < 0)) {
                AppLog.d(this, "PROVIDER parent unusable for sort=" + sortField +
                        " sizeCol=" + sizeCol + " modifiedCol=" + modifiedCol);
                return;
            }
            ArrayList<MediaItem> found = new ArrayList<>();
            int rows = 0;
            while (c.moveToNext() && rows < 5000) {
                rows++;
                String name = c.isNull(nameCol) ? null : c.getString(nameCol);
                if (name == null || !looksLikeImage(name)) continue;
                String mime = (mimeCol >= 0 && !c.isNull(mimeCol)) ? c.getString(mimeCol) : mimeFromName(name);
                long size = (sizeCol >= 0 && !c.isNull(sizeCol)) ? c.getLong(sizeCol) : 0L;
                long modified = (modifiedCol >= 0 && !c.isNull(modifiedCol)) ? c.getLong(modifiedCol) : 0L;
                Uri child = sameName(name, seedName) ? seedUri : parent.buildUpon().appendPath(name).build();
                found.add(new MediaItem(child, name, mime, size, modified));
            }
            sortProviderItems(found, sortField, sortAscending);
            long took = SystemClock.elapsedRealtime() - started;
            boolean accepted = publishFullList(generation, seedName, found, "provider-parent", took);
            AppLog.d(this, "PROVIDER parent query end +" + elapsed() + "ms took=" + took +
                    "ms rows=" + rows + " images=" + found.size() + " accepted=" + accepted);
            if (accepted) {
                // Provider list is intentionally not kept in the cross-activity cache; a URI
                // grant may be tied to this incoming Intent. MediaStore full-scan will populate
                // the safe process cache when/if it finishes.
            }
        } catch (Throwable e) {
            AppLog.d(this, "PROVIDER parent query error +" + elapsed() + "ms " + e);
        }
    }

    private Uri parentProviderUri(Uri seedUri) {
        String encoded = seedUri.getEncodedPath();
        if (encoded == null) return null;
        int slash = encoded.lastIndexOf('/');
        if (slash <= 0) return null;
        return seedUri.buildUpon().encodedPath(encoded.substring(0, slash + 1)).clearQuery().fragment(null).build();
    }

    private int findColumn(Cursor c, String... candidates) {
        String[] cols = c.getColumnNames();
        for (String candidate : candidates) {
            if (candidate == null) continue;
            for (int i = 0; i < cols.length; i++) if (candidate.equalsIgnoreCase(cols[i])) return i;
        }
        return -1;
    }

    private boolean looksLikeImage(String name) {
        if (name == null) return false;
        String n = name.toLowerCase(Locale.ROOT);
        return n.endsWith(".jpg") || n.endsWith(".jpeg") || n.endsWith(".png") ||
                n.endsWith(".gif") || n.endsWith(".bmp") || n.endsWith(".webp") ||
                n.endsWith(".heic") || n.endsWith(".heif") || n.endsWith(".avif");
    }

    private boolean isSupportedImageName(String name) {
        if (name == null) return false;
        String n = name.toLowerCase(Locale.ROOT);
        return looksLikeImage(name) || n.endsWith(".pdf");
    }

    private String mimeFromName(String name) {
        String n = name.toLowerCase(Locale.ROOT);
        if (n.endsWith(".png")) return "image/png";
        if (n.endsWith(".gif")) return "image/gif";
        if (n.endsWith(".bmp")) return "image/bmp";
        if (n.endsWith(".webp")) return "image/webp";
        if (n.endsWith(".heic") || n.endsWith(".heif")) return "image/heic";
        if (n.endsWith(".avif")) return "image/avif";
        return "image/jpeg";
    }

    private void sortProviderItems(List<MediaItem> list, String field, boolean asc) {
        Comparator<MediaItem> byName = (a, b) -> String.CASE_INSENSITIVE_ORDER.compare(
                a.name == null ? "" : a.name, b.name == null ? "" : b.name);
        Comparator<MediaItem> cmp;
        if (SortPrefs.FIELD_SIZE.equals(field)) {
            cmp = (a, b) -> { int x = Long.compare(a.size, b.size); return x != 0 ? x : byName.compare(a, b); };
        } else if (SortPrefs.FIELD_MODIFIED.equals(field)) {
            cmp = (a, b) -> { int x = Long.compare(a.modified, b.modified); return x != 0 ? x : byName.compare(a, b); };
        } else cmp = byName;
        if (!asc) cmp = cmp.reversed();
        Collections.sort(list, cmp);
    }

    private boolean safeExecute(ExecutorService executor, Runnable task) {
        if (executor == null || task == null || executor.isShutdown() || executor.isTerminated()) return false;
        try { executor.execute(task); return true; }
        catch (java.util.concurrent.RejectedExecutionException e) {
            AppLog.d(this, "EXECUTOR rejected +" + elapsed() + "ms " + e.getClass().getSimpleName());
            return false;
        }
    }

    private void logLaunchIntentDetails() {
        try {
            Intent i = getIntent();
            ClipData clip = i.getClipData();
            Bundle extras = i.getExtras();
            AppLog.d(this, "INTENT flags=0x" + Integer.toHexString(i.getFlags()) +
                    " referrer=" + getReferrer() +
                    " clipCount=" + (clip == null ? 0 : clip.getItemCount()) +
                    " extras=" + (extras == null ? "[]" : extras.keySet().toString()));
            if (clip != null) {
                for (int n = 0; n < Math.min(clip.getItemCount(), 8); n++) {
                    ClipData.Item item = clip.getItemAt(n);
                    AppLog.d(this, "INTENT clip[" + n + "] uri=" + item.getUri());
                }
            }
        } catch (Throwable e) { AppLog.d(this, "INTENT detail error " + e); }
    }

    private void buildFullSiblingList(int generation, String seedName, String relativePath, String sortField, boolean sortAscending) {
        long started = SystemClock.elapsedRealtime();
        try {
            String[] projection = new String[]{MediaStore.Images.Media._ID, MediaStore.Images.Media.DISPLAY_NAME, MediaStore.Images.Media.MIME_TYPE, MediaStore.Images.Media.SIZE, MediaStore.Images.Media.DATE_MODIFIED};
            String selection = MediaStore.Images.Media.RELATIVE_PATH + "=?";
            String direction = sortAscending ? " ASC" : " DESC";
            String col = SortPrefs.sqlColumn(sortField);
            String sort = SortPrefs.FIELD_NAME.equals(sortField)
                    ? MediaStore.Images.Media.DISPLAY_NAME + " COLLATE NOCASE" + direction + ", " + MediaStore.Images.Media._ID + direction
                    : col + direction + ", " + MediaStore.Images.Media._ID + direction;
            ArrayList<MediaItem> found = new ArrayList<>();
            try (Cursor c = getContentResolver().query(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, projection, selection, new String[]{relativePath}, sort)) {
                if (c != null) {
                    int idCol = c.getColumnIndexOrThrow(MediaStore.Images.Media._ID);
                    int nameCol = c.getColumnIndexOrThrow(MediaStore.Images.Media.DISPLAY_NAME);
                    int mimeCol = c.getColumnIndexOrThrow(MediaStore.Images.Media.MIME_TYPE);
                    int sizeCol = c.getColumnIndexOrThrow(MediaStore.Images.Media.SIZE);
                    int modifiedCol = c.getColumnIndexOrThrow(MediaStore.Images.Media.DATE_MODIFIED);
                    while (c.moveToNext()) {
                        if (generation != siblingGeneration.get()) return;
                        long id = c.getLong(idCol); String name = c.getString(nameCol); String mime = c.getString(mimeCol);
                        long size = c.getLong(sizeCol); long modified = c.getLong(modifiedCol);
                        found.add(new MediaItem(ContentUris.withAppendedId(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, id), name, mime, size, modified));
                    }
                }
            }
            long scanMs = SystemClock.elapsedRealtime() - started;
            putFolderCache(relativePath, sortField, sortAscending, found);
            publishFullList(generation, seedName, found, "mediastore-full", scanMs);
        } catch (Throwable e) { AppLog.d(this, "SIBLINGS full error +" + elapsed() + "ms " + e); }
    }

    private String resolveRelativePath(Uri uri) {
        // Some file managers (including Solid Explorer) expose a provider URI whose path contains
        // the actual shared-storage path, but do not implement RELATIVE_PATH on that provider.
        try {
            String rawPath = uri.getPath();
            if (rawPath != null) {
                String marker = "/storage/emulated/0/";
                int idx = rawPath.indexOf(marker);
                if (idx >= 0) {
                    String relativeFile = rawPath.substring(idx + marker.length());
                    int slash = relativeFile.lastIndexOf('/');
                    if (slash >= 0) {
                        String inferred = relativeFile.substring(0, slash + 1);
                        AppLog.d(this, "SIBLINGS inferred path from provider=" + inferred);
                        return inferred;
                    }
                }
            }
        } catch (Throwable e) { AppLog.d(this, "SIBLINGS provider path parse error " + e); }

        try (Cursor c = getContentResolver().query(uri, new String[]{MediaStore.MediaColumns.RELATIVE_PATH}, null, null, null)) {
            if (c != null && c.moveToFirst()) {
                int col = c.getColumnIndex(MediaStore.MediaColumns.RELATIVE_PATH);
                if (col >= 0) {
                    String v = c.getString(col);
                    if (v != null && !v.isEmpty()) return v;
                }
            }
        } catch (Throwable e) { AppLog.d(this, "SIBLINGS seed RELATIVE_PATH unavailable " + e.getClass().getSimpleName()); }

        String name = resolveDisplayName(uri); if (name == null) return null;
        try (Cursor c = getContentResolver().query(MediaStore.Images.Media.EXTERNAL_CONTENT_URI,
                new String[]{MediaStore.Images.Media.RELATIVE_PATH, MediaStore.Images.Media.DISPLAY_NAME},
                MediaStore.Images.Media.DISPLAY_NAME + "=?", new String[]{name}, MediaStore.Images.Media.DATE_MODIFIED + " DESC")) {
            if (c != null && c.moveToFirst()) {
                int col = c.getColumnIndex(MediaStore.Images.Media.RELATIVE_PATH);
                if (col >= 0) return c.getString(col);
            }
        } catch (Throwable e) { AppLog.d(this, "SIBLINGS MediaStore name lookup error " + e); }
        return null;
    }

    private boolean sameName(String a, String b) { return a != null && b != null && a.equalsIgnoreCase(b); }
    private boolean isPdf(String mime, Uri uri) { return "application/pdf".equalsIgnoreCase(mime) || (uri != null && uri.toString().toLowerCase().endsWith(".pdf")); }

    private String resolveDisplayName(Uri uri) {
        String name = null;
        if ("content".equals(uri.getScheme())) {
            try (Cursor cursor = getContentResolver().query(uri, new String[]{OpenableColumns.DISPLAY_NAME}, null, null, null)) {
                if (cursor != null && cursor.moveToFirst()) { int index = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME); if (index >= 0) name = cursor.getString(index); }
            } catch (Exception ignored) { }
        }
        if (name == null || name.isEmpty()) name = uri.getLastPathSegment();
        return name == null ? "Chirami" : name;
    }

    private void closePdfPage() { if (pdfPage != null) { pdfPage.close(); pdfPage = null; } }
    private void closePdf() {
        closePdfPage(); if (pdfRenderer != null) { pdfRenderer.close(); pdfRenderer = null; }
        if (pdfFd != null) { try { pdfFd.close(); } catch (IOException ignored) { } pdfFd = null; }
    }

    @Override protected void onDestroy() {
        AppLog.d(this, "VIEWER onDestroy");
        siblingGeneration.incrementAndGet();
        cancelSiblingQuerySignals();
        closePdf();
        decodeGeneration.incrementAndGet();
        decodeExecutor.shutdownNow(); scanExecutor.shutdownNow(); neighborExecutor.shutdownNow();
        providerDirectoryExecutor.shutdownNow(); fullScanExecutor.shutdownNow(); prefetchExecutor.shutdownNow();
        super.onDestroy();
    }

    /** Lightweight zoom/pan/page view. No external image-view dependency: keeps Chirami small and startup cheap. */
    private class ZoomImageView extends ImageView {
        interface PageListener { boolean canPage(int direction); void onPageDrag(int direction, float translationX); void onPageReset(); void onPage(int direction, float velocityX); void onSingleTap(); }
        private PageListener pageListener;
        private final Matrix matrix = new Matrix();
        private final float[] values = new float[9];
        private final ScaleGestureDetector scaleDetector;
        private float fitScale = 1f;
        private float userScale = 1f;
        private float lastX, lastY, downX, downY;
        private long lastTapUp = 0;
        private float lastTapX, lastTapY;
        private boolean secondTap = false;
        private boolean doubleTapZoomDrag = false;
        private float doubleTapStartY, doubleTapStartScale;
        private boolean paging = false;
        private boolean moved = false;
        private VelocityTracker velocityTracker;
        private final int touchSlop = ViewConfiguration.get(ViewerActivity.this).getScaledTouchSlop();
        private Runnable pendingSingleTap;

        ZoomImageView() {
            super(ViewerActivity.this);
            setScaleType(ScaleType.MATRIX);
            setClickable(true);
            scaleDetector = new ScaleGestureDetector(ViewerActivity.this, new ScaleGestureDetector.SimpleOnScaleGestureListener() {
                @Override public boolean onScaleBegin(ScaleGestureDetector detector) { paging = false; cancelSingleTap(); if (zoomAnimator != null) zoomAnimator.cancel(); return true; }
                @Override public boolean onScale(ScaleGestureDetector detector) {
                    float factor = detector.getScaleFactor();
                    setUserScale(userScale * factor, detector.getFocusX(), detector.getFocusY());
                    return true;
                }
            });
        }

        void setPageListener(PageListener listener) { pageListener = listener; }

        void setImageForViewer(Drawable drawable) {
            setTranslationX(0f); setAlpha(1f);
            setImageForViewerKeepingTranslation(drawable);
        }

        void setImageForViewerKeepingTranslation(Drawable drawable) {
            super.setImageDrawable(drawable);
            // Compute the final FIT matrix synchronously whenever the view is measured.
            // This prevents a temporary frame rendered with the previous image's matrix.
            if (getWidth() > 0 && getHeight() > 0) resetToFit();
            else post(this::resetToFit);
        }

        private void resetToFit() {
            Drawable d = getDrawable(); if (d == null || getWidth() <= 0 || getHeight() <= 0) return;
            int iw = Math.max(1, d.getIntrinsicWidth()); int ih = Math.max(1, d.getIntrinsicHeight());
            fitScale = Math.min((float)getWidth()/iw, (float)getHeight()/ih);
            if (!Float.isFinite(fitScale) || fitScale <= 0f) fitScale = 1f;
            userScale = fitScale;
            matrix.reset();
            matrix.postScale(fitScale, fitScale);
            matrix.postTranslate((getWidth()-iw*fitScale)/2f, (getHeight()-ih*fitScale)/2f);
            setImageMatrix(matrix);
            notifyImageBoundsChanged();
        }

        void notifyImageBoundsChanged() {
            Drawable d = getDrawable(); if (d == null) return;
            RectF r = new RectF(0, 0, Math.max(1,d.getIntrinsicWidth()), Math.max(1,d.getIntrinsicHeight()));
            matrix.mapRect(r);
            ViewerActivity.this.updateChromeShadeBounds(r);
        }

        private void setUserScale(float target, float focusX, float focusY) {
            float max = Math.max(8f, fitScale * 12f);
            target = Math.max(fitScale, Math.min(max, target));
            float factor = target / userScale;
            matrix.postScale(factor, factor, focusX, focusY);
            userScale = target;
            constrain(); setImageMatrix(matrix);
        }

        private boolean isAtFit() { return userScale <= fitScale * 1.015f; }

        private ValueAnimator zoomAnimator;

        private void toggleOriginal(float x, float y) {
            final float start = userScale;
            final boolean zoomingIn = Math.abs(userScale - fitScale) < Math.max(0.02f, fitScale * 0.02f);
            final float target = zoomingIn ? Math.max(1f, fitScale) : fitScale;
            if (Math.abs(target - start) < 0.001f) return;
            if (zoomAnimator != null) zoomAnimator.cancel();
            zoomAnimator = ValueAnimator.ofFloat(start, target);
            zoomAnimator.setDuration(210L);
            zoomAnimator.setInterpolator(new DecelerateInterpolator(1.8f));
            zoomAnimator.addUpdateListener(a -> setUserScale((float)a.getAnimatedValue(), x, y));
            zoomAnimator.addListener(new android.animation.AnimatorListenerAdapter() {
                @Override public void onAnimationEnd(android.animation.Animator animation) {
                    if (!zoomingIn) resetToFit();
                    zoomAnimator = null;
                }
                @Override public void onAnimationCancel(android.animation.Animator animation) { zoomAnimator = null; }
            });
            zoomAnimator.start();
            AppLog.d(ViewerActivity.this, "ZOOM doubleTap animate " + start + " -> " + target + " fit=" + fitScale);
        }

        private void pan(float dx, float dy) { matrix.postTranslate(dx, dy); constrain(); setImageMatrix(matrix); }

        private void constrain() {
            Drawable d = getDrawable(); if (d == null) return;
            RectF r = new RectF(0, 0, Math.max(1,d.getIntrinsicWidth()), Math.max(1,d.getIntrinsicHeight())); matrix.mapRect(r);
            float dx = 0, dy = 0;
            if (r.width() <= getWidth()) dx = getWidth()/2f - r.centerX(); else if (r.left > 0) dx = -r.left; else if (r.right < getWidth()) dx = getWidth() - r.right;
            if (r.height() <= getHeight()) dy = getHeight()/2f - r.centerY(); else if (r.top > 0) dy = -r.top; else if (r.bottom < getHeight()) dy = getHeight() - r.bottom;
            matrix.postTranslate(dx, dy);
            notifyImageBoundsChanged();
        }

        @Override public boolean onTouchEvent(MotionEvent e) {
            if (pageAnimating) return true;
            scaleDetector.onTouchEvent(e);
            int action = e.getActionMasked();
            if (action == MotionEvent.ACTION_DOWN) {
                ViewerActivity.this.cancelPageAnimationsForTouch();
                if (velocityTracker != null) velocityTracker.recycle(); velocityTracker = VelocityTracker.obtain(); velocityTracker.addMovement(e);
                downX = lastX = e.getX(); downY = lastY = e.getY(); moved = false; paging = false;
                long now = SystemClock.uptimeMillis();
                secondTap = (now - lastTapUp <= DOUBLE_TAP_MS && distance(e.getX(), e.getY(), lastTapX, lastTapY) < dp(48));
                if (secondTap) { cancelSingleTap(); doubleTapZoomDrag = false; doubleTapStartY = e.getY(); doubleTapStartScale = userScale; }
                return true;
            }
            if (velocityTracker != null) velocityTracker.addMovement(e);
            if (action == MotionEvent.ACTION_MOVE) {
                float x=e.getX(), y=e.getY(); float dx=x-lastX, dy=y-lastY;
                if (Math.abs(x-downX)>touchSlop || Math.abs(y-downY)>touchSlop) moved=true;
                if (secondTap && !scaleDetector.isInProgress()) {
                    float totalY = y-doubleTapStartY;
                    if (Math.abs(totalY) > touchSlop) {
                        doubleTapZoomDrag = true;
                        // Up = zoom in, down = zoom out. Exponential response feels natural over the whole screen.
                        float factor = (float)Math.exp(-totalY / Math.max(220f, getHeight()*0.42f));
                        setUserScale(doubleTapStartScale * factor, downX, downY);
                    }
                } else if (scaleDetector.isInProgress()) {
                    // handled by ScaleGestureDetector
                } else if (!isAtFit()) {
                    pan(dx, dy);
                } else {
                    float totalX=x-downX, totalY=y-downY;
                    if (!paging && Math.abs(totalX)>touchSlop && Math.abs(totalX)>Math.abs(totalY)*1.15f) paging=true;
                    if (paging) {
                        int direction = totalX < 0 ? 1 : -1;
                        float resistance = (pageListener != null && pageListener.canPage(direction)) ? 1f : 0.23f;
                        float translation = totalX * resistance;
                        setTranslationX(translation);
                        if (pageListener != null) pageListener.onPageDrag(direction, translation);
                    }
                }
                lastX=x; lastY=y; return true;
            }
            if (action == MotionEvent.ACTION_UP || action == MotionEvent.ACTION_CANCEL) {
                float vx=0f; if (velocityTracker != null) { velocityTracker.computeCurrentVelocity(1000); vx=velocityTracker.getXVelocity(); velocityTracker.recycle(); velocityTracker=null; }
                if (secondTap) {
                    if (!doubleTapZoomDrag && action==MotionEvent.ACTION_UP) toggleOriginal(e.getX(), e.getY());
                    AppLog.d(ViewerActivity.this, doubleTapZoomDrag ? "ZOOM doubleTapHold end scale="+userScale : "ZOOM doubleTap toggle scale="+userScale);
                    secondTap=false; doubleTapZoomDrag=false; setTranslationX(0f); return true;
                }
                if (paging) {
                    float tx=getTranslationX(); int direction = tx<0 ? 1 : -1;
                    boolean commit = Math.abs(tx) > getWidth()*0.12f || Math.abs(vx)>550f;
                    if (commit && pageListener != null && pageListener.canPage(direction)) pageListener.onPage(direction, vx);
                    else {
                        if (pageListener != null) pageListener.onPageReset();
                        else animate().translationX(0f).setDuration(150).start();
                    }
                    paging=false; return true;
                }
                if (!moved && action==MotionEvent.ACTION_UP && !scaleDetector.isInProgress()) {
                    lastTapUp=SystemClock.uptimeMillis(); lastTapX=e.getX(); lastTapY=e.getY();
                    scheduleSingleTap();
                }
                return true;
            }
            return true;
        }

        private void scheduleSingleTap() {
            cancelSingleTap();
            pendingSingleTap = () -> { pendingSingleTap=null; if (pageListener!=null) pageListener.onSingleTap(); };
            mainHandler.postDelayed(pendingSingleTap, DOUBLE_TAP_MS + 20);
        }
        private void cancelSingleTap() { if (pendingSingleTap != null) { mainHandler.removeCallbacks(pendingSingleTap); pendingSingleTap=null; } }
        private float distance(float x1,float y1,float x2,float y2) { float dx=x1-x2, dy=y1-y2; return (float)Math.sqrt(dx*dx+dy*dy); }
    }
}
