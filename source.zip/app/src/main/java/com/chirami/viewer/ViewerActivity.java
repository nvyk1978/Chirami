package com.chirami.viewer;

import android.Manifest;
import android.app.Activity;
import android.content.ContentUris;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.ImageDecoder;
import android.graphics.drawable.AnimatedImageDrawable;
import android.graphics.drawable.Drawable;
import android.graphics.pdf.PdfRenderer;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.ParcelFileDescriptor;
import android.provider.MediaStore;
import android.provider.OpenableColumns;
import android.view.GestureDetector;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class ViewerActivity extends Activity {
    private static final int REQ_MEDIA = 1001;

    private LinearLayout topBar;
    private LinearLayout bottomBar;
    private ImageView imageView;
    private TextView titleView;
    private TextView pageView;
    private GestureDetector gestureDetector;

    private ParcelFileDescriptor pdfFd;
    private PdfRenderer pdfRenderer;
    private PdfRenderer.Page pdfPage;

    private final List<MediaItem> siblings = new ArrayList<>();
    private int currentIndex = -1;
    private Uri currentUri;
    private String currentMime;
    private String currentName;

    private static class MediaItem {
        final Uri uri;
        final String name;
        final String mime;

        MediaItem(Uri uri, String name, String mime) {
            this.uri = uri;
            this.name = name;
            this.mime = mime;
        }
    }

    private int dp(float value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(Color.BLACK);
        getWindow().setNavigationBarColor(Color.BLACK);
        buildUi();

        Uri uri = getIntent().getData();
        if (uri == null) {
            Toast.makeText(this, "ファイルを開けませんでした", Toast.LENGTH_SHORT).show();
            finish();
            return;
        }

        getIntent().addFlags(android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION);
        currentUri = uri;
        currentName = resolveDisplayName(uri);
        currentMime = getIntent().getType();
        if (currentMime == null) currentMime = getContentResolver().getType(uri);
        showCurrentUri();

        if (!isPdf(currentMime, uri)) {
            if (hasMediaPermission()) {
                discoverSiblingImages();
            } else {
                requestMediaPermission();
            }
        }
    }

    private void buildUi() {
        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(Color.BLACK);

        imageView = new ImageView(this);
        imageView.setBackgroundColor(Color.BLACK);
        imageView.setScaleType(ImageView.ScaleType.FIT_CENTER);
        root.addView(imageView, new FrameLayout.LayoutParams(-1, -1));

        // Top chrome: floats over the image instead of taking layout space.
        topBar = new LinearLayout(this);
        topBar.setOrientation(LinearLayout.HORIZONTAL);
        topBar.setGravity(Gravity.CENTER_VERTICAL);
        topBar.setPadding(dp(8), 0, dp(10), 0);
        topBar.setBackgroundColor(Color.argb(150, 0, 0, 0));

        TextView back = new TextView(this);
        back.setText("‹");
        back.setTextColor(Color.WHITE);
        back.setTextSize(42);
        back.setGravity(Gravity.CENTER);
        back.setOnClickListener(v -> finish());
        topBar.addView(back, new LinearLayout.LayoutParams(dp(48), dp(58)));

        titleView = new TextView(this);
        titleView.setTextColor(Color.WHITE);
        titleView.setTextSize(16);
        titleView.setSingleLine(true);
        titleView.setEllipsize(android.text.TextUtils.TruncateAt.MIDDLE);
        titleView.setGravity(Gravity.CENTER_VERTICAL);
        topBar.addView(titleView, new LinearLayout.LayoutParams(0, dp(58), 1f));

        pageView = new TextView(this);
        pageView.setTextColor(Color.WHITE);
        pageView.setTextSize(13);
        pageView.setGravity(Gravity.CENTER_VERTICAL | Gravity.END);
        topBar.addView(pageView, new LinearLayout.LayoutParams(dp(76), dp(58)));

        TextView more = new TextView(this);
        more.setText("⋮");
        more.setTextColor(Color.WHITE);
        more.setTextSize(30);
        more.setGravity(Gravity.CENTER);
        more.setOnClickListener(v -> Toast.makeText(this, "メニューは順次追加します", Toast.LENGTH_SHORT).show());
        topBar.addView(more, new LinearLayout.LayoutParams(dp(44), dp(58)));

        FrameLayout.LayoutParams topParams = new FrameLayout.LayoutParams(-1, dp(58), Gravity.TOP);
        root.addView(topBar, topParams);

        // Bottom chrome: minimal controls, also transparent and overlaid.
        bottomBar = new LinearLayout(this);
        bottomBar.setOrientation(LinearLayout.HORIZONTAL);
        bottomBar.setGravity(Gravity.CENTER);
        bottomBar.setPadding(dp(16), 0, dp(16), 0);
        bottomBar.setBackgroundColor(Color.argb(150, 0, 0, 0));

        TextView edit = makeBottomAction("✎", "編集");
        edit.setOnClickListener(v -> Toast.makeText(this, "編集機能は次の段階で追加します", Toast.LENGTH_SHORT).show());
        bottomBar.addView(edit, new LinearLayout.LayoutParams(0, dp(66), 1f));

        TextView share = makeBottomAction("↗", "共有");
        share.setOnClickListener(v -> shareCurrent());
        bottomBar.addView(share, new LinearLayout.LayoutParams(0, dp(66), 1f));

        FrameLayout.LayoutParams bottomParams = new FrameLayout.LayoutParams(-1, dp(66), Gravity.BOTTOM);
        root.addView(bottomBar, bottomParams);

        gestureDetector = new GestureDetector(this, new GestureDetector.SimpleOnGestureListener() {
            @Override
            public boolean onDown(MotionEvent e) {
                return true;
            }

            @Override
            public boolean onSingleTapConfirmed(MotionEvent e) {
                toggleChrome();
                return true;
            }

            @Override
            public boolean onFling(MotionEvent e1, MotionEvent e2, float velocityX, float velocityY) {
                if (e1 == null || e2 == null) return false;
                float dx = e2.getX() - e1.getX();
                float dy = e2.getY() - e1.getY();
                if (Math.abs(dx) < dp(70) || Math.abs(dx) <= Math.abs(dy) * 1.15f) return false;
                if (dx < 0) return moveSibling(1);
                return moveSibling(-1);
            }
        });
        imageView.setOnTouchListener((v, event) -> gestureDetector.onTouchEvent(event));

        setContentView(root);
    }

    private TextView makeBottomAction(String icon, String label) {
        TextView view = new TextView(this);
        view.setText(icon + "\n" + label);
        view.setTextColor(Color.WHITE);
        view.setTextSize(13);
        view.setGravity(Gravity.CENTER);
        view.setLines(2);
        return view;
    }

    private void shareCurrent() {
        if (currentUri == null) return;
        try {
            android.content.Intent share = new android.content.Intent(android.content.Intent.ACTION_SEND);
            share.setType(currentMime == null ? "image/*" : currentMime);
            share.putExtra(android.content.Intent.EXTRA_STREAM, currentUri);
            share.addFlags(android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION);
            startActivity(android.content.Intent.createChooser(share, "共有"));
        } catch (Throwable e) {
            Toast.makeText(this, "共有できませんでした", Toast.LENGTH_SHORT).show();
        }
    }

    private void toggleChrome() {
        boolean showing = topBar.getVisibility() == View.VISIBLE;
        topBar.setVisibility(showing ? View.GONE : View.VISIBLE);
        bottomBar.setVisibility(showing ? View.GONE : View.VISIBLE);
        if (showing) {
            getWindow().getDecorView().setSystemUiVisibility(
                    View.SYSTEM_UI_FLAG_FULLSCREEN |
                    View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY |
                    View.SYSTEM_UI_FLAG_HIDE_NAVIGATION);
        } else {
            getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_VISIBLE);
        }
    }

    private void showCurrentUri() {
        closePdf();
        titleView.setText(currentName == null ? resolveDisplayName(currentUri) : currentName);
        if (isPdf(currentMime, currentUri)) {
            openPdf(currentUri);
        } else {
            openImage(currentUri);
            updatePositionLabel();
        }
    }

    private void openImage(Uri uri) {
        try {
            ImageDecoder.Source source = ImageDecoder.createSource(getContentResolver(), uri);
            Drawable drawable = ImageDecoder.decodeDrawable(source);
            imageView.setImageDrawable(drawable);
            if (drawable instanceof AnimatedImageDrawable) {
                ((AnimatedImageDrawable) drawable).start();
            }
        } catch (Throwable e) {
            Toast.makeText(this, "この画像を表示できませんでした", Toast.LENGTH_LONG).show();
        }
    }

    private void openPdf(Uri uri) {
        try {
            pdfFd = getContentResolver().openFileDescriptor(uri, "r");
            if (pdfFd == null) throw new IOException("No file descriptor");
            pdfRenderer = new PdfRenderer(pdfFd);
            if (pdfRenderer.getPageCount() == 0) throw new IOException("Empty PDF");
            renderPdfPage(0);
        } catch (Throwable e) {
            Toast.makeText(this, "PDFを表示できませんでした", Toast.LENGTH_LONG).show();
        }
    }

    private void renderPdfPage(int index) {
        closePdfPage();
        pdfPage = pdfRenderer.openPage(index);
        int screenWidth = Math.max(1, getResources().getDisplayMetrics().widthPixels);
        float ratio = (float) pdfPage.getHeight() / (float) pdfPage.getWidth();
        int bitmapWidth = Math.min(screenWidth * 2, 2200);
        int bitmapHeight = Math.max(1, Math.round(bitmapWidth * ratio));
        Bitmap bitmap = Bitmap.createBitmap(bitmapWidth, bitmapHeight, Bitmap.Config.ARGB_8888);
        bitmap.eraseColor(Color.WHITE);
        pdfPage.render(bitmap, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY);
        imageView.setImageBitmap(bitmap);
        pageView.setText((index + 1) + " / " + pdfRenderer.getPageCount());
    }

    private boolean moveSibling(int delta) {
        if (siblings.size() <= 1 || currentIndex < 0) return false;
        int next = currentIndex + delta;
        if (next < 0 || next >= siblings.size()) return false;
        currentIndex = next;
        MediaItem item = siblings.get(currentIndex);
        currentUri = item.uri;
        currentName = item.name;
        currentMime = item.mime;
        showCurrentUri();
        return true;
    }

    private void updatePositionLabel() {
        if (currentIndex >= 0 && siblings.size() > 1) {
            pageView.setText((currentIndex + 1) + " / " + siblings.size());
        } else {
            pageView.setText("");
        }
    }

    private boolean hasMediaPermission() {
        if (Build.VERSION.SDK_INT >= 33) {
            return checkSelfPermission(Manifest.permission.READ_MEDIA_IMAGES) == PackageManager.PERMISSION_GRANTED;
        }
        return checkSelfPermission(Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED;
    }

    private void requestMediaPermission() {
        if (Build.VERSION.SDK_INT >= 33) {
            requestPermissions(new String[]{Manifest.permission.READ_MEDIA_IMAGES}, REQ_MEDIA);
        } else {
            requestPermissions(new String[]{Manifest.permission.READ_EXTERNAL_STORAGE}, REQ_MEDIA);
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQ_MEDIA && grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            discoverSiblingImages();
        }
    }

    private void discoverSiblingImages() {
        try {
            String relativePath = resolveRelativePath(currentUri);
            if (relativePath == null) return;

            String[] projection = new String[]{
                    MediaStore.Images.Media._ID,
                    MediaStore.Images.Media.DISPLAY_NAME,
                    MediaStore.Images.Media.MIME_TYPE
            };
            String selection = MediaStore.Images.Media.RELATIVE_PATH + "=?";
            String[] args = new String[]{relativePath};
            String sort = MediaStore.Images.Media.DISPLAY_NAME + " COLLATE NOCASE ASC";

            siblings.clear();
            try (Cursor c = getContentResolver().query(
                    MediaStore.Images.Media.EXTERNAL_CONTENT_URI,
                    projection, selection, args, sort)) {
                if (c != null) {
                    int idCol = c.getColumnIndexOrThrow(MediaStore.Images.Media._ID);
                    int nameCol = c.getColumnIndexOrThrow(MediaStore.Images.Media.DISPLAY_NAME);
                    int mimeCol = c.getColumnIndexOrThrow(MediaStore.Images.Media.MIME_TYPE);
                    while (c.moveToNext()) {
                        long id = c.getLong(idCol);
                        String name = c.getString(nameCol);
                        String mime = c.getString(mimeCol);
                        Uri uri = ContentUris.withAppendedId(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, id);
                        siblings.add(new MediaItem(uri, name, mime));
                    }
                }
            }

            currentIndex = -1;
            for (int i = 0; i < siblings.size(); i++) {
                MediaItem item = siblings.get(i);
                if (sameName(item.name, currentName)) {
                    currentIndex = i;
                    currentUri = item.uri;
                    currentMime = item.mime;
                    break;
                }
            }
            updatePositionLabel();
        } catch (Throwable ignored) {
            siblings.clear();
            currentIndex = -1;
            updatePositionLabel();
        }
    }

    private String resolveRelativePath(Uri uri) {
        String[] projection = new String[]{MediaStore.MediaColumns.RELATIVE_PATH};
        try (Cursor c = getContentResolver().query(uri, projection, null, null, null)) {
            if (c != null && c.moveToFirst()) {
                int col = c.getColumnIndex(MediaStore.MediaColumns.RELATIVE_PATH);
                if (col >= 0) {
                    String value = c.getString(col);
                    if (value != null && !value.isEmpty()) return value;
                }
            }
        } catch (Throwable ignored) { }

        String name = resolveDisplayName(uri);
        if (name == null) return null;
        String[] mediaProjection = new String[]{MediaStore.Images.Media.RELATIVE_PATH, MediaStore.Images.Media.DISPLAY_NAME};
        try (Cursor c = getContentResolver().query(
                MediaStore.Images.Media.EXTERNAL_CONTENT_URI,
                mediaProjection,
                MediaStore.Images.Media.DISPLAY_NAME + "=?",
                new String[]{name},
                MediaStore.Images.Media.DATE_MODIFIED + " DESC")) {
            if (c != null && c.moveToFirst()) {
                int relCol = c.getColumnIndex(MediaStore.Images.Media.RELATIVE_PATH);
                if (relCol >= 0) return c.getString(relCol);
            }
        } catch (Throwable ignored) { }
        return null;
    }

    private boolean sameName(String a, String b) {
        return a != null && b != null && a.equalsIgnoreCase(b);
    }

    private boolean isPdf(String mime, Uri uri) {
        return "application/pdf".equalsIgnoreCase(mime) ||
                (uri != null && uri.toString().toLowerCase().endsWith(".pdf"));
    }

    private String resolveDisplayName(Uri uri) {
        String name = null;
        if ("content".equals(uri.getScheme())) {
            try (Cursor cursor = getContentResolver().query(uri,
                    new String[]{OpenableColumns.DISPLAY_NAME}, null, null, null)) {
                if (cursor != null && cursor.moveToFirst()) {
                    int index = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME);
                    if (index >= 0) name = cursor.getString(index);
                }
            } catch (Exception ignored) { }
        }
        if (name == null || name.isEmpty()) name = uri.getLastPathSegment();
        return name == null ? "Chirami" : name;
    }

    private void closePdfPage() {
        if (pdfPage != null) {
            pdfPage.close();
            pdfPage = null;
        }
    }

    private void closePdf() {
        closePdfPage();
        if (pdfRenderer != null) {
            pdfRenderer.close();
            pdfRenderer = null;
        }
        if (pdfFd != null) {
            try { pdfFd.close(); } catch (IOException ignored) { }
            pdfFd = null;
        }
    }

    @Override
    protected void onDestroy() {
        closePdf();
        super.onDestroy();
    }
}
