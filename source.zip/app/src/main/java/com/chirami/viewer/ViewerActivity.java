package com.chirami.viewer;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.ContentUris;
import android.content.ContentValues;
import android.content.ContentResolver;
import android.content.ClipData;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.res.ColorStateList;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Color;
import android.graphics.ImageDecoder;
import android.graphics.Matrix;
import android.animation.ValueAnimator;
import android.graphics.RectF;
import android.graphics.drawable.AnimatedImageDrawable;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.graphics.pdf.PdfRenderer;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.CancellationSignal;
import android.os.Handler;
import android.os.Looper;
import android.os.ParcelFileDescriptor;
import android.os.SystemClock;
import android.os.Environment;
import android.os.storage.StorageManager;
import android.os.storage.StorageVolume;
import android.provider.MediaStore;
import android.provider.DocumentsContract;
import android.provider.OpenableColumns;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.animation.PathInterpolator;
import android.view.animation.DecelerateInterpolator;
import android.view.ScaleGestureDetector;
import android.view.VelocityTracker;
import android.view.View;
import android.view.ViewConfiguration;
import android.util.LruCache;
import android.widget.FrameLayout;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.EditText;
import android.widget.CheckBox;
import android.widget.ScrollView;
import android.widget.PopupWindow;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import java.io.IOException;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileInputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Locale;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicReference;
import java.nio.file.Files;
import java.nio.file.attribute.BasicFileAttributes;

public class ViewerActivity extends Activity {
    private static final int REQ_MEDIA = 1001;
    private static final long DOUBLE_TAP_MS = 300;

    // v0.1.20 experiment: use a direct shared-storage directory index whenever the incoming
    // URI exposes a real path. MediaStore seed resolution remains the generic fallback.
    private static final boolean ENABLE_DIRECT_FILE_ENUM_EXPERIMENT = true;
    private static final boolean ENABLE_CURSOR_OUT_EXPERIMENT = true;
    private static final boolean ENABLE_CENTER_OUT_EXPERIMENT = true;
    private static final boolean ENABLE_EXTERNAL_FAST_PATH_EXPERIMENT = true;
    // This is only a UI merge chunk now; it is NOT a MediaStore query LIMIT.
    private static final int CURSOR_MERGE_CHUNK_SIZE = 24;
    private static final int CENTER_OUT_BATCH_SIZE = 24;
    private static final long FOLDER_CACHE_TTL_MS = 2 * 60 * 1000L;

    private LinearLayout topBar;
    private LinearLayout bottomBar;
    private ChromeShadeOverlay shadeOverlay;
    private ZoomImageView imageView;
    private ImageView pagePreviewView;
    private TextView titleView;
    private TextView pageView;
    private View rotateButton;
    private TextView saveRotationButton;
    private volatile int pendingRotationDegrees = 0;
    private volatile Bitmap pendingRotationBitmap;
    private final AtomicInteger rotationGeneration = new AtomicInteger();
    private boolean rotationAnimating = false;
    // Session-only confirmations. These are never persisted across ViewerActivity sessions.
    private boolean skipDeleteConfirmationThisSession = false;
    private static final int CONFLICT_ASK = 0;
    private static final int CONFLICT_OVERWRITE = 1;
    private static final int CONFLICT_RENAME = 2;
    private int conflictPolicyThisSession = CONFLICT_ASK;

    private ParcelFileDescriptor pdfFd;
    private PdfRenderer pdfRenderer;
    private PdfRenderer.Page pdfPage;

    private final List<MediaItem> siblings = new ArrayList<>();
    private int currentIndex = -1;
    private Uri currentUri;
    private String currentMime;
    private String currentName;

    private final ExecutorService decodeExecutor = Executors.newSingleThreadExecutor();
    // Editing/encoding is isolated so a rotation save/share never blocks the next image decode.
    private final ExecutorService editExecutor = Executors.newSingleThreadExecutor();
    // Folder enumeration must never block the UI thread.
    private final ExecutorService fileManagerExecutor = Executors.newSingleThreadExecutor();
    private final AtomicInteger fileManagerGeneration = new AtomicInteger();
    private final ExecutorService scanExecutor = Executors.newSingleThreadExecutor();
    private final ExecutorService neighborExecutor = Executors.newFixedThreadPool(2);
    private final ExecutorService providerDirectoryExecutor = Executors.newSingleThreadExecutor();
    private final ExecutorService fullScanExecutor = Executors.newSingleThreadExecutor();
    private final ExecutorService prefetchExecutor = Executors.newFixedThreadPool(2);
    private final Handler mainHandler = new Handler(Looper.getMainLooper());
    private final AtomicInteger decodeGeneration = new AtomicInteger();
    private final AtomicInteger prefetchGeneration = new AtomicInteger();
    private final AtomicInteger siblingGeneration = new AtomicInteger();
    // CancellationSignals matter because interrupting an Executor thread does not reliably
    // abort a slow ContentResolver query. A new viewer/search cancels the provider work itself.
    private volatile CancellationSignal seedResolveSignal;
    private volatile CancellationSignal previousCursorSignal;
    private volatile CancellationSignal nextCursorSignal;
    // Small screen-sized preview cache. This avoids re-decoding the same adjacent image
    // when the user swipes back and forth. Full-resolution images are not retained here.
    private final LruCache<String, Drawable> previewCache = new LruCache<>(6);
    private long launchStartedMs;
    private boolean firstFrameLogged = false;
    private boolean pageAnimating = false;
    private volatile Drawable previousPreviewDrawable;
    private volatile Drawable nextPreviewDrawable;
    private volatile MediaItem quickPreviousItem;
    private volatile MediaItem quickNextItem;
    private volatile boolean fullListReady = false;
    private volatile boolean progressiveListActive = false;
    private volatile boolean progressivePrevComplete = false;
    private volatile boolean progressiveNextComplete = false;
    private volatile int progressivePrevLoaded = 0;
    private volatile int progressiveNextLoaded = 0;
    private int topShadeExtentPx;
    private int bottomShadeExtentPx;

    private static class MediaItem {
        final Uri uri;
        final String name;
        final String mime;
        final long size;
        final long created;
        final long modified;
        MediaItem(Uri uri, String name, String mime, long size, long created, long modified) {
            this.uri = uri; this.name = name; this.mime = mime; this.size = size; this.created = created; this.modified = modified;
        }
        MediaItem(Uri uri, String name, String mime, long size, long modified) {
            this(uri, name, mime, size, modified, modified);
        }
    }

    private static class FolderCacheEntry {
        final long createdAt;
        final ArrayList<MediaItem> items;
        FolderCacheEntry(long createdAt, List<MediaItem> items) {
            this.createdAt = createdAt;
            this.items = new ArrayList<>(items);
        }
    }

    // Process-only cache: no library/database is created. It disappears when Android kills
    // Chirami's process. Cache stores order-independent folder metadata; each request sorts
    // a copy in RAM, so changing slide sort never throws away a warm folder index.
    private static final Object FOLDER_CACHE_LOCK = new Object();
    private static final LruCache<String, FolderCacheEntry> FOLDER_INDEX_CACHE = new LruCache<>(4);
    private static final Object DIRECTORY_CACHE_LOCK = new Object();
    private static final long DIRECTORY_CACHE_TTL_MS = 30 * 1000L;
    private static final LruCache<String, DirectoryCacheEntry> DIRECTORY_CACHE = new LruCache<>(32);

    private static class DirectoryCacheEntry {
        final long createdAt;
        final ArrayList<String> folderNames;
        DirectoryCacheEntry(long createdAt, List<String> folderNames) {
            this.createdAt = createdAt;
            this.folderNames = new ArrayList<>(folderNames);
        }
    }

    private int dp(float value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        launchStartedMs = SystemClock.elapsedRealtime();
        super.onCreate(savedInstanceState);
        AppLog.d(this, "VIEWER onCreate action=" + getIntent().getAction() + " type=" + getIntent().getType() + " data=" + getIntent().getData());
        logLaunchIntentDetails();
        getWindow().setStatusBarColor(Color.BLACK);
        getWindow().setNavigationBarColor(Color.BLACK);
        buildUi();

        Uri uri = getIntent().getData();
        if (uri == null) {
            AppLog.d(this, "VIEWER no URI");
            Toast.makeText(this, "ファイルを開けませんでした", Toast.LENGTH_SHORT).show();
            finish();
            return;
        }

        currentUri = uri;
        currentName = resolveDisplayName(uri);
        currentMime = getIntent().getType();
        if (currentMime == null) currentMime = getContentResolver().getType(uri);
        AppLog.d(this, "VIEWER open +" + elapsed() + "ms name=" + currentName + " mime=" + currentMime + " uri=" + currentUri);

        // Most important rule in Chirami: render the tapped file first. Folder scanning is never allowed to delay it.
        showCurrentUri(false, 0);

        if (!isPdf(currentMime, uri)) {
            if (hasMediaPermission()) discoverSiblingImagesAsync();
            else requestMediaPermission();
        }
    }

    private long elapsed() { return SystemClock.elapsedRealtime() - launchStartedMs; }

    private void buildUi() {
        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(Color.BLACK);

        pagePreviewView = new ImageView(this);
        pagePreviewView.setBackgroundColor(Color.BLACK);
        pagePreviewView.setScaleType(ImageView.ScaleType.FIT_CENTER);
        pagePreviewView.setVisibility(View.GONE);
        root.addView(pagePreviewView, new FrameLayout.LayoutParams(-1, -1));

        imageView = new ZoomImageView();
        imageView.setBackgroundColor(Color.BLACK);
        imageView.setPageListener(new ZoomImageView.PageListener() {
            @Override public boolean canPage(int direction) { return canMoveSibling(direction); }
            @Override public void onPageDrag(int direction, float translationX) { showPagePreview(direction, translationX); }
            @Override public void onPageReset() { animatePageReset(); }
            @Override public void onPage(int direction, float velocityX) { animateToSibling(direction, velocityX); }
            @Override public void onSingleTap() { toggleChrome(); }
        });
        root.addView(imageView, new FrameLayout.LayoutParams(-1, -1));

        // Chrome is intentionally fully transparent: no top/bottom alpha-gray overlay.
        final int chromeInset = dp(50);
        shadeOverlay = null;

        topBar = new LinearLayout(this);
        topBar.setOrientation(LinearLayout.HORIZONTAL);
        topBar.setGravity(Gravity.CENTER_VERTICAL);
        topBar.setPadding(dp(4), 0, dp(4), 0);
        topBar.setBackgroundColor(Color.TRANSPARENT);

        final int topControlHeight = dp(58);
        final int roundIconDiameter = dp(38);

        // Draw the chrome icons ourselves instead of relying on font glyph baselines.
        // This keeps every control on the exact same visual center line on different fonts/devices.
        View back = new ToolbarIconView(this, ToolbarIconView.BACK, roundIconDiameter);
        back.setOnClickListener(v -> returnToCaller());
        topBar.addView(back, new LinearLayout.LayoutParams(dp(44), topControlHeight));

        titleView = new TextView(this);
        titleView.setTextColor(Color.WHITE); titleView.setTextSize(17); titleView.setSingleLine(true);
        titleView.setIncludeFontPadding(false);
        titleView.setEllipsize(android.text.TextUtils.TruncateAt.END); titleView.setGravity(Gravity.CENTER_VERTICAL);
        topBar.addView(titleView, new LinearLayout.LayoutParams(0, topControlHeight, 1f));

        pageView = new TextView(this);
        pageView.setTextColor(Color.rgb(210, 210, 210));
        pageView.setTextSize(12);
        pageView.setSingleLine(true);
        pageView.setIncludeFontPadding(false);
        pageView.setGravity(Gravity.CENTER);
        pageView.setPadding(dp(5), 0, dp(5), 0);
        pageView.setVisibility(View.VISIBLE);
        topBar.addView(pageView, new LinearLayout.LayoutParams(-2, topControlHeight));

        saveRotationButton = new TextView(this);
        saveRotationButton.setText("✓"); saveRotationButton.setTextColor(Color.WHITE); saveRotationButton.setTextSize(24); saveRotationButton.setGravity(Gravity.CENTER);
        saveRotationButton.setIncludeFontPadding(false);
        saveRotationButton.setVisibility(View.GONE);
        saveRotationButton.setOnClickListener(v -> showSaveRotatedDialog());
        topBar.addView(saveRotationButton, new LinearLayout.LayoutParams(dp(38), topControlHeight));

        rotateButton = new ToolbarIconView(this, ToolbarIconView.ROTATE, roundIconDiameter);
        rotateButton.setOnClickListener(this::showRotatePopup);
        topBar.addView(rotateButton, new LinearLayout.LayoutParams(dp(46), topControlHeight));

        View info = new ToolbarIconView(this, ToolbarIconView.INFO, roundIconDiameter);
        info.setOnClickListener(v -> showPropertiesDialog());
        topBar.addView(info, new LinearLayout.LayoutParams(dp(46), topControlHeight));

        View more = new ToolbarIconView(this, ToolbarIconView.MORE, roundIconDiameter);
        more.setOnClickListener(v -> showViewerMenu());
        topBar.addView(more, new LinearLayout.LayoutParams(dp(44), topControlHeight));
        FrameLayout.LayoutParams topParams = new FrameLayout.LayoutParams(-1, topControlHeight, Gravity.TOP);
        topParams.topMargin = chromeInset;
        root.addView(topBar, topParams);


        bottomBar = new LinearLayout(this);
        bottomBar.setOrientation(LinearLayout.HORIZONTAL); bottomBar.setGravity(Gravity.CENTER);
        bottomBar.setPadding(dp(38), 0, dp(38), 0); bottomBar.setBackgroundColor(Color.TRANSPARENT);

        View share = makeBottomIconAction(BottomActionIconView.SHARE, "共有", v -> shareCurrent());
        bottomBar.addView(share, new LinearLayout.LayoutParams(0, dp(72), 1f));

        View delete = makeBottomIconAction(BottomActionIconView.DELETE, "削除", v -> requestDeleteCurrent());
        bottomBar.addView(delete, new LinearLayout.LayoutParams(0, dp(72), 1f));
        FrameLayout.LayoutParams bottomParams = new FrameLayout.LayoutParams(-1, dp(72), Gravity.BOTTOM);
        bottomParams.bottomMargin = chromeInset;
        root.addView(bottomBar, bottomParams);

        setContentView(root);
        AppLog.d(this, "VIEWER UI ready +" + elapsed() + "ms");
    }

    private void returnToCaller() {
        AppLog.d(this, "VIEWER returnToCaller taskRoot=" + isTaskRoot());
        try {
            // ViewerActivity has an empty taskAffinity, so finishing its affinity never
            // walks back into Chirami's launcher/settings task. It reveals the app that
            // launched ACTION_VIEW (file manager, browser, etc.).
            if (isTaskRoot()) finishAndRemoveTask();
            else finishAffinity();
        } catch (Throwable ignored) {
            finish();
        }
    }

    @Override
    public void onBackPressed() {
        returnToCaller();
    }

    private void showViewerMenu() {
        final int panel = Color.rgb(58, 51, 51); // #3A3333
        LinearLayout content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(dp(6), dp(6), dp(6), dp(6));
        content.setBackground(makeRoundedPanel(panel));

        TextView sort = makeViewerMenuRow("スライド順");
        TextView copy = makeViewerMenuRow("コピー");
        TextView move = makeViewerMenuRow("移動");
        content.addView(sort, new LinearLayout.LayoutParams(dp(220), dp(52)));
        content.addView(copy, new LinearLayout.LayoutParams(dp(220), dp(52)));
        content.addView(move, new LinearLayout.LayoutParams(dp(220), dp(52)));

        AlertDialog dialog = new AlertDialog.Builder(this).setView(content).create();
        dialog.setCanceledOnTouchOutside(true);
        prepareDialogBeforeShow(dialog, panel);
        sort.setOnClickListener(v -> { dialog.dismiss(); showSortDialog(); });
        copy.setOnClickListener(v -> { dialog.dismiss(); showDestinationManager(false); });
        move.setOnClickListener(v -> { dialog.dismiss(); showDestinationManager(true); });
        AppLog.d(this, "DIALOG viewer-menu show-prepared");
        dialog.show();
    }

    private TextView makeViewerMenuRow(String text) {
        TextView row = new TextView(this);
        row.setText(text);
        row.setTextColor(Color.WHITE);
        row.setTextSize(17);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(dp(18), 0, dp(18), 0);
        return row;
    }

    private void showSortDialog() {
        final String initialField = SortPrefs.field(this);
        final boolean initialAsc = SortPrefs.ascending(this);
        final int panel = Color.rgb(58, 51, 51);       // #3A3333
        final int selected = Color.rgb(68, 85, 119);  // #445577
        final int unselected = Color.rgb(90, 85, 85); // #5A5555
        ColorStateList tint = new ColorStateList(
                new int[][]{new int[]{android.R.attr.state_checked}, new int[]{}},
                new int[]{selected, unselected});

        LinearLayout content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(dp(22), dp(6), dp(22), dp(8));
        content.setBackgroundColor(panel);

        RadioGroup fieldGroup = new RadioGroup(this);
        fieldGroup.setOrientation(RadioGroup.VERTICAL);
        RadioButton byName = makeDialogRadio("名前", false, tint);
        RadioButton bySize = makeDialogRadio("サイズ", false, tint);
        RadioButton byType = makeDialogRadio("種類", false, tint);
        RadioButton byCreated = makeDialogRadio("作成日", false, tint);
        RadioButton byModified = makeDialogRadio("最終更新日", false, tint);
        fieldGroup.addView(byName, new RadioGroup.LayoutParams(-1, dp(50)));
        fieldGroup.addView(bySize, new RadioGroup.LayoutParams(-1, dp(50)));
        fieldGroup.addView(byType, new RadioGroup.LayoutParams(-1, dp(50)));
        fieldGroup.addView(byCreated, new RadioGroup.LayoutParams(-1, dp(50)));
        fieldGroup.addView(byModified, new RadioGroup.LayoutParams(-1, dp(50)));
        if (SortPrefs.FIELD_SIZE.equals(initialField)) fieldGroup.check(bySize.getId());
        else if (SortPrefs.FIELD_TYPE.equals(initialField)) fieldGroup.check(byType.getId());
        else if (SortPrefs.FIELD_CREATED.equals(initialField)) fieldGroup.check(byCreated.getId());
        else if (SortPrefs.FIELD_MODIFIED.equals(initialField)) fieldGroup.check(byModified.getId());
        else fieldGroup.check(byName.getId());
        content.addView(fieldGroup);

        View divider = new View(this);
        divider.setBackgroundColor(Color.rgb(90, 85, 85));
        LinearLayout.LayoutParams dividerParams = new LinearLayout.LayoutParams(-1, dp(1));
        dividerParams.topMargin = dp(8);
        dividerParams.bottomMargin = dp(8);
        content.addView(divider, dividerParams);

        RadioGroup orderGroup = new RadioGroup(this);
        orderGroup.setOrientation(RadioGroup.HORIZONTAL);
        RadioButton ascending = makeDialogRadio("左から", false, tint);
        RadioButton descending = makeDialogRadio("右から", false, tint);
        orderGroup.addView(ascending, new RadioGroup.LayoutParams(0, dp(52), 1f));
        orderGroup.addView(descending, new RadioGroup.LayoutParams(0, dp(52), 1f));
        orderGroup.check((initialAsc ? ascending : descending).getId());
        content.addView(orderGroup);

        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle("スライド順")
                .setView(content)
                .setNegativeButton("キャンセル", null)
                .setPositiveButton("OK", null)
                .create();
        prepareDialogBeforeShow(dialog, panel);

        dialog.setOnShowListener(ignored -> {
            int titleId = getResources().getIdentifier("alertTitle", "id", "android");
            TextView title = dialog.findViewById(titleId);
            if (title != null) title.setTextColor(Color.WHITE);
            styleDialogButton(dialog, AlertDialog.BUTTON_NEGATIVE, Color.WHITE, panel);
            styleDialogButton(dialog, AlertDialog.BUTTON_POSITIVE, Color.WHITE, panel);
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v -> {
                String selectedField = bySize.isChecked() ? SortPrefs.FIELD_SIZE
                        : (byType.isChecked() ? SortPrefs.FIELD_TYPE
                        : (byCreated.isChecked() ? SortPrefs.FIELD_CREATED
                        : (byModified.isChecked() ? SortPrefs.FIELD_MODIFIED : SortPrefs.FIELD_NAME)));
                boolean selectedAsc = ascending.isChecked();
                SortPrefs.save(this, selectedField, selectedAsc);
                AppLog.d(this, "SORT changed field=" + selectedField + " asc=" + selectedAsc);
                dialog.dismiss();
                if (!applySortImmediately(selectedField, selectedAsc)) discoverSiblingImagesAsync();
                Toast.makeText(this, SortPrefs.fieldLabel(selectedField) + "・" + (selectedAsc ? "左から" : "右から"), Toast.LENGTH_SHORT).show();
            });
        });
        dialog.show();
    }

    private RadioButton makeDialogRadio(String label, boolean checked, ColorStateList tint) {
        RadioButton button = new RadioButton(this);
        button.setId(View.generateViewId());
        button.setText(label);
        button.setTextColor(Color.WHITE);
        button.setTextSize(17);
        button.setChecked(checked);
        button.setButtonTintList(tint);
        button.setGravity(Gravity.CENTER_VERTICAL);
        button.setPadding(0, dp(2), 0, dp(2));
        return button;
    }

    private boolean applySortImmediately(String field, boolean ascending) {
        if (!fullListReady || siblings.isEmpty() || currentName == null) return false;
        if (!itemsSupportSort(siblings, field)) {
            AppLog.d(this, "SORT immediate miss field=" + field + " reason=metadata");
            return false;
        }
        ArrayList<MediaItem> sorted = new ArrayList<>(siblings);
        sortProviderItems(sorted, field, ascending);
        int idx = -1;
        for (int i = 0; i < sorted.size(); i++) {
            if (sameName(sorted.get(i).name, currentName)) { idx = i; break; }
        }
        if (idx < 0) {
            AppLog.d(this, "SORT immediate miss field=" + field + " reason=current-not-found");
            return false;
        }
        siblingGeneration.incrementAndGet();
        cancelSiblingQuerySignals();
        siblings.clear();
        siblings.addAll(sorted);
        currentIndex = idx;
        fullListReady = true;
        progressiveListActive = false;
        quickPreviousItem = null;
        quickNextItem = null;
        updatePositionLabel();
        prefetchAdjacent();
        AppLog.d(this, "SORT applied immediate field=" + field + " asc=" + ascending +
                " found=" + siblings.size() + " currentIndex=" + currentIndex);
        return true;
    }

    private boolean itemsSupportSort(List<MediaItem> items, String field) {
        if (items == null || items.isEmpty() || SortPrefs.FIELD_NAME.equals(field) || SortPrefs.FIELD_TYPE.equals(field)) return items != null && !items.isEmpty();
        for (MediaItem item : items) {
            if (item == null) continue;
            if (SortPrefs.FIELD_SIZE.equals(field) && item.size < 0L) return false;
            if (SortPrefs.FIELD_CREATED.equals(field) && item.created < 0L) return false;
            if (SortPrefs.FIELD_MODIFIED.equals(field) && item.modified < 0L) return false;
        }
        return true;
    }

    private TextView makeBottomAction(String icon, String label) {
        TextView view = new TextView(this);
        view.setText(icon + "\n" + label); view.setTextColor(Color.WHITE); view.setTextSize(13);
        view.setGravity(Gravity.CENTER); view.setLines(2); return view;
    }

    private View makeBottomIconAction(int kind, String contentDescription, View.OnClickListener listener) {
        BottomActionIconView icon = new BottomActionIconView(this, kind);
        icon.setContentDescription(contentDescription);
        icon.setOnClickListener(listener);
        return icon;
    }

    private GradientDrawable makeRoundedPanel(int color) {
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(color);
        bg.setCornerRadius(dp(10));
        return bg;
    }

    private void prepareDialogBeforeShow(AlertDialog dialog, int panelColor) {
        if (dialog == null || dialog.getWindow() == null) return;
        android.view.Window window = dialog.getWindow();
        window.setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(Color.TRANSPARENT));
        window.setWindowAnimations(R.style.Animation_Chirami_Dialog);
        View decor = window.getDecorView();
        decor.setBackground(makeRoundedPanel(panelColor));
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) decor.setClipToOutline(true);
    }

    private void styleDialogButton(AlertDialog dialog, int which, int textColor, int panelColor) {
        if (dialog == null) return;
        Button button = dialog.getButton(which);
        if (button == null) return;
        button.setTextColor(textColor);
        button.setAllCaps(false);
        int fill = panelColor == Color.rgb(42, 34, 34) ? Color.rgb(58, 51, 51) : Color.rgb(42, 34, 34);
        GradientDrawable bg = makeRoundedPanel(fill);
        button.setBackground(bg);
    }

    /** Destination-manager actions stay text-only; the dialog itself remains rounded. */
    private void styleManagerTextAction(AlertDialog dialog, int which, int textColor) {
        if (dialog == null) return;
        Button button = dialog.getButton(which);
        if (button == null) return;
        button.setTextColor(textColor);
        button.setTextSize(14);
        button.setAllCaps(false);
        button.setBackground(new android.graphics.drawable.ColorDrawable(Color.TRANSPARENT));
    }

    private void toggleChrome() {
        boolean showing = topBar.getVisibility() == View.VISIBLE;
        topBar.setVisibility(showing ? View.GONE : View.VISIBLE);
        bottomBar.setVisibility(showing ? View.GONE : View.VISIBLE);
        if (shadeOverlay != null) {
            shadeOverlay.setChromeVisible(!showing);
        }
        if (!showing && imageView != null) imageView.notifyImageBoundsChanged();
        if (showing) {
            getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_FULLSCREEN | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION);
        } else {
            getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_VISIBLE);
        }
    }

    private void updateChromeShadeBounds(RectF imageBounds) {
        if (shadeOverlay != null) shadeOverlay.setImageBounds(imageBounds);
    }

    private class ChromeShadeOverlay extends View {
        ChromeShadeOverlay() {
            super(ViewerActivity.this);
            setClickable(false);
            setFocusable(false);
        }
        void setChromeVisible(boolean visible) { }
        void setImageBounds(RectF imageBounds) { }
        @Override protected void onDraw(Canvas canvas) { super.onDraw(canvas); }
    }

    private void requestDeleteCurrent() {
        if (currentUri == null) return;
        if (skipDeleteConfirmationThisSession) {
            deleteCurrentNow();
            return;
        }
        final int panel = Color.rgb(58, 51, 51);
        CheckBox skip = new CheckBox(this);
        skip.setText("このセッションでは再度確認しない");
        skip.setTextColor(Color.WHITE);
        skip.setPadding(dp(18), dp(4), dp(18), dp(4));
        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle("削除")
                .setMessage("この画像を削除しますか？")
                .setView(skip)
                .setNegativeButton("キャンセル", null)
                .setPositiveButton("削除", null)
                .create();
        prepareDialogBeforeShow(dialog, panel);
        dialog.setOnShowListener(v -> {
            int titleId = getResources().getIdentifier("alertTitle", "id", "android");
            TextView title = dialog.findViewById(titleId);
            if (title != null) title.setTextColor(Color.WHITE);
            int messageId = getResources().getIdentifier("message", "id", "android");
            TextView message = dialog.findViewById(messageId);
            if (message != null) message.setTextColor(Color.WHITE);
            styleDialogButton(dialog, AlertDialog.BUTTON_NEGATIVE, Color.WHITE, panel);
            styleDialogButton(dialog, AlertDialog.BUTTON_POSITIVE, Color.rgb(220, 95, 75), panel);
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v2 -> {
                skipDeleteConfirmationThisSession = skip.isChecked();
                dialog.dismiss();
                deleteCurrentNow();
            });
        });
        dialog.show();
    }

    private void deleteCurrentNow() {
        final Uri targetUri = currentUri;
        final String targetName = currentName;
        final String targetPath = inferAbsolutePathFromAnyUri(targetUri);
        final int oldIndex = currentIndex;
        if (targetUri == null) return;
        Toast.makeText(this, "削除しています", Toast.LENGTH_SHORT).show();
        safeExecute(editExecutor, () -> {
            boolean deleted = false;
            try {
                if ("content".equalsIgnoreCase(targetUri.getScheme())) {
                    try { deleted = getContentResolver().delete(targetUri, null, null) > 0; }
                    catch (Throwable ignored) { }
                }
                if (!deleted && targetPath != null) {
                    File f = new File(targetPath);
                    deleted = !f.exists() || f.delete();
                }
            } catch (Throwable e) {
                AppLog.d(this, "DELETE error " + e);
            }
            final boolean ok = deleted;
            mainHandler.post(() -> {
                if (!ok) {
                    Toast.makeText(this, "削除できませんでした", Toast.LENGTH_LONG).show();
                    return;
                }
                AppLog.d(this, "DELETE success name=" + targetName + " uri=" + targetUri);
                clearPendingRotationState();
                synchronized (FOLDER_CACHE_LOCK) { FOLDER_INDEX_CACHE.evictAll(); }
                int removeIndex = -1;
                for (int i = 0; i < siblings.size(); i++) {
                    MediaItem item = siblings.get(i);
                    if (item == null) continue;
                    if ((item.uri != null && item.uri.equals(targetUri)) ||
                            (targetName != null && targetName.equalsIgnoreCase(item.name))) {
                        removeIndex = i;
                        break;
                    }
                }
                if (removeIndex >= 0) siblings.remove(removeIndex);
                if (siblings.isEmpty()) {
                    Toast.makeText(this, "削除しました", Toast.LENGTH_SHORT).show();
                    returnToCaller();
                    return;
                }
                int nextIndex = oldIndex >= 0 ? Math.min(oldIndex, siblings.size() - 1) : 0;
                if (removeIndex >= 0) nextIndex = Math.min(removeIndex, siblings.size() - 1);
                currentIndex = Math.max(0, nextIndex);
                MediaItem next = siblings.get(currentIndex);
                currentUri = next.uri;
                currentName = next.name;
                currentMime = next.mime;
                showCurrentUri(false, 0);
                prefetchAdjacent();
                Toast.makeText(this, "削除しました", Toast.LENGTH_SHORT).show();
            });
        });
    }

    private static class BrowserStorageTarget {
        final String label;
        final File root;
        BrowserStorageTarget(String label, File root) { this.label = label; this.root = root; }
    }

    private void showDestinationManager(boolean move) {
        if (currentUri == null) return;
        String sourcePath = inferAbsolutePathFromAnyUri(currentUri);
        if (sourcePath == null) {
            Toast.makeText(this, "このファイルではコピー先を参照できません", Toast.LENGTH_LONG).show();
            return;
        }
        File sourceFile = new File(sourcePath);
        File start = sourceFile.getParentFile();
        if (start == null) {
            Toast.makeText(this, "現在のフォルダを開けません", Toast.LENGTH_SHORT).show();
            return;
        }

        final File[] currentDir = new File[]{start};
        final File[] rootLimit = new File[]{storageRootFor(start)};
        final int panel = Color.rgb(42, 34, 34);      // #2A2222
        final int rowPanel = Color.rgb(58, 51, 51);   // #3A3333
        final int accent = Color.rgb(68, 85, 119);    // #445577
        final ArrayList<BrowserStorageTarget> storageTargets = discoverBrowserStorageTargets(start);
        AppLog.d(this, "MANAGER open mode=" + (move ? "move" : "copy") + " start=" + start.getAbsolutePath() +
                " storages=" + storageTargets.size());

        LinearLayout content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(dp(14), dp(2), dp(14), dp(8));
        content.setBackgroundColor(panel);

        TextView storageSelector = new TextView(this);
        storageSelector.setTextColor(Color.WHITE);
        storageSelector.setTextSize(16);
        storageSelector.setGravity(Gravity.CENTER_VERTICAL);
        storageSelector.setPadding(dp(12), 0, dp(12), 0);
        GradientDrawable selectorBg = new GradientDrawable();
        selectorBg.setColor(rowPanel); selectorBg.setCornerRadius(dp(10));
        storageSelector.setBackground(selectorBg);
        content.addView(storageSelector, new LinearLayout.LayoutParams(-1, dp(42)));

        TextView pathView = new TextView(this);
        pathView.setTextColor(Color.rgb(185, 180, 180));
        pathView.setTextSize(12);
        pathView.setSingleLine(true);
        pathView.setEllipsize(android.text.TextUtils.TruncateAt.START);
        pathView.setPadding(dp(4), dp(7), dp(4), dp(7));
        content.addView(pathView, new LinearLayout.LayoutParams(-1, dp(36)));

        LinearLayout nav = new LinearLayout(this);
        nav.setOrientation(LinearLayout.HORIZONTAL);
        nav.setGravity(Gravity.CENTER_VERTICAL);
        TextView parentButton = makeManagerButton("‹  戻る");
        TextView newFolderButton = makeManagerButton("＋  新規フォルダ");
        nav.addView(parentButton, new LinearLayout.LayoutParams(0, dp(44), 1f));
        nav.addView(newFolderButton, new LinearLayout.LayoutParams(0, dp(44), 1f));
        content.addView(nav);

        ScrollView scroll = new ScrollView(this);
        scroll.setVerticalScrollBarEnabled(true);
        scroll.setScrollBarStyle(View.SCROLLBARS_INSIDE_OVERLAY);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            GradientDrawable thumb = new GradientDrawable();
            thumb.setColor(Color.rgb(90, 85, 85)); // #5A5555 Chirami light gray
            thumb.setCornerRadius(dp(2));
            thumb.setSize(dp(3), dp(36));
            scroll.setVerticalScrollbarThumbDrawable(thumb);
            GradientDrawable track = new GradientDrawable();
            track.setColor(Color.TRANSPARENT);
            scroll.setVerticalScrollbarTrackDrawable(track);
        }
        LinearLayout folders = new LinearLayout(this);
        folders.setOrientation(LinearLayout.VERTICAL);
        scroll.addView(folders, new ScrollView.LayoutParams(-1, -2));
        content.addView(scroll, new LinearLayout.LayoutParams(-1, dp(440)));

        final Runnable[] refresh = new Runnable[1];
        final Runnable updateStorageLabel = () -> {
            BrowserStorageTarget selected = findBrowserStorageTarget(storageTargets, rootLimit[0]);
            String label = selected == null ? storageLabelForRoot(rootLimit[0]) : selected.label;
            storageSelector.setText(label + "  ▾");
        };

        refresh[0] = () -> {
            final File dir = currentDir[0];
            final int generation = fileManagerGeneration.incrementAndGet();
            pathView.setText(dir.getAbsolutePath());
            updateStorageLabel.run();
            folders.removeAllViews();
            TextView loading = new TextView(this);
            loading.setText("読み込み中…");
            loading.setTextColor(Color.rgb(160, 155, 155));
            loading.setPadding(dp(12), dp(20), dp(12), dp(20));
            folders.addView(loading);
            AppLog.d(this, "MANAGER list begin path=" + dir.getAbsolutePath());
            boolean accepted = safeExecute(fileManagerExecutor, () -> {
                long startedAt = SystemClock.elapsedRealtime();
                ArrayList<String> names = getCachedDirectoryFolders(dir);
                boolean cacheHit = names != null;
                if (names == null) names = listDirectoryFolders(dir);
                final ArrayList<String> result = names;
                if (!cacheHit) putCachedDirectoryFolders(dir, result);
                long took = SystemClock.elapsedRealtime() - startedAt;
                AppLog.d(this, "MANAGER list ready path=" + dir.getAbsolutePath() +
                        " folders=" + result.size() + " took=" + took + "ms cache=" + cacheHit);
                mainHandler.post(() -> {
                    if (generation != fileManagerGeneration.get() || isFinishing()) return;
                    if (!sameFilePath(currentDir[0], dir)) return;
                    folders.removeAllViews();
                    if (result.isEmpty()) {
                        TextView empty = new TextView(this);
                        empty.setText("フォルダはありません");
                        empty.setTextColor(Color.rgb(160, 155, 155));
                        empty.setPadding(dp(12), dp(22), dp(12), dp(22));
                        folders.addView(empty);
                    }
                    for (String name : result) {
                        final File child = new File(dir, name);
                        LinearLayout row = makeManagerFolderRow(name, accent, rowPanel);
                        row.setOnClickListener(v -> {
                            currentDir[0] = child;
                            refresh[0].run();
                        });
                        LinearLayout.LayoutParams rp = new LinearLayout.LayoutParams(-1, dp(46));
                        rp.bottomMargin = dp(1);
                        folders.addView(row, rp);
                    }
                });
            });
            if (!accepted) {
                folders.removeAllViews();
                TextView failed = new TextView(this);
                failed.setText("フォルダを読み込めませんでした");
                failed.setTextColor(Color.rgb(190, 170, 170));
                failed.setPadding(dp(12), dp(20), dp(12), dp(20));
                folders.addView(failed);
            }
        };

        storageSelector.setOnClickListener(v -> showStorageSelectorPopup(storageSelector, storageTargets, target -> {
            if (target == null || target.root == null) return;
            rootLimit[0] = target.root;
            currentDir[0] = target.root;
            AppLog.d(this, "MANAGER storage selected label=" + target.label + " root=" + target.root.getAbsolutePath());
            refresh[0].run();
        }));

        parentButton.setOnClickListener(v -> {
            File parent = currentDir[0].getParentFile();
            if (parent == null) return;
            if (rootLimit[0] != null && !isWithinRoot(parent, rootLimit[0])) return;
            currentDir[0] = parent;
            refresh[0].run();
        });
        newFolderButton.setOnClickListener(v -> showCreateFolderDialog(currentDir[0], refresh[0]));

        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle(move ? "移動先" : "コピー先")
                .setView(content)
                .setNegativeButton("キャンセル", null)
                .setPositiveButton(move ? "移動" : "コピー", null)
                .create();
        prepareDialogBeforeShow(dialog, panel);
        if (dialog.getWindow() != null) {
            android.view.WindowManager.LayoutParams lp = new android.view.WindowManager.LayoutParams();
            lp.copyFrom(dialog.getWindow().getAttributes());
            lp.width = (int) (getResources().getDisplayMetrics().widthPixels * 0.94f);
            dialog.getWindow().setAttributes(lp);
        }
        dialog.setOnShowListener(v -> {
            int titleId = getResources().getIdentifier("alertTitle", "id", "android");
            TextView title = dialog.findViewById(titleId);
            if (title != null) {
                title.setTextColor(Color.WHITE);
                title.setTextSize(18);
            }
            styleManagerTextAction(dialog, AlertDialog.BUTTON_NEGATIVE, Color.WHITE);
            styleManagerTextAction(dialog, AlertDialog.BUTTON_POSITIVE, Color.WHITE);
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v2 -> {
                File chosen = currentDir[0];
                AppLog.d(this, "MANAGER destination selected mode=" + (move ? "move" : "copy") +
                        " path=" + chosen.getAbsolutePath());
                dialog.dismiss();
                requestFileTransfer(chosen, move);
            });
            refresh[0].run();
        });
        dialog.setOnDismissListener(v -> fileManagerGeneration.incrementAndGet());
        dialog.show();
    }

    private LinearLayout makeManagerFolderRow(String name, int accent, int rowPanel) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(dp(8), 0, dp(8), 0);
        row.setBackgroundColor(rowPanel);

        ImageView icon = new ImageView(this);
        icon.setImageResource(R.drawable.ic_chirami_folder);
        icon.setPadding(dp(6), dp(6), dp(6), dp(6));
        GradientDrawable ibg = new GradientDrawable(); ibg.setColor(accent); ibg.setCornerRadius(dp(9));
        icon.setBackground(ibg);
        row.addView(icon, new LinearLayout.LayoutParams(dp(32), dp(32)));

        LinearLayout textBox = new LinearLayout(this);
        textBox.setOrientation(LinearLayout.VERTICAL);
        textBox.setGravity(Gravity.CENTER_VERTICAL);
        textBox.setPadding(dp(10), 0, 0, 0);
        TextView title = new TextView(this);
        title.setText(name); title.setTextColor(Color.WHITE); title.setTextSize(14); title.setSingleLine(true);
        title.setEllipsize(android.text.TextUtils.TruncateAt.END);
        textBox.addView(title, new LinearLayout.LayoutParams(-1, dp(30)));
        row.addView(textBox, new LinearLayout.LayoutParams(0, dp(38), 1f));
        return row;
    }

    private ArrayList<BrowserStorageTarget> discoverBrowserStorageTargets(File current) {
        ArrayList<BrowserStorageTarget> out = new ArrayList<>();
        HashMap<String, Boolean> seen = new HashMap<>();
        try {
            StorageManager sm = (StorageManager) getSystemService(STORAGE_SERVICE);
            if (sm != null && Build.VERSION.SDK_INT >= 30) {
                int externalNo = 1;
                for (StorageVolume volume : sm.getStorageVolumes()) {
                    File dir = volume.getDirectory();
                    if (dir == null || !dir.exists() || !dir.canRead()) continue;
                    String key = dir.getAbsolutePath();
                    if (seen.put(key, Boolean.TRUE) != null) continue;
                    String label;
                    if (volume.isPrimary()) label = "内蔵ストレージ";
                    else {
                        String desc = volume.getDescription(this);
                        String lower = desc == null ? "" : desc.toLowerCase(Locale.ROOT);
                        if (lower.contains("sd") || (desc != null && desc.contains("カード"))) label = "SDカード";
                        else label = externalNo++ == 1 ? "外部ストレージ" : "外部ストレージ " + (externalNo - 1);
                    }
                    out.add(new BrowserStorageTarget(label, dir));
                }
            }
        } catch (Throwable e) {
            AppLog.d(this, "MANAGER storage enumerate error " + e.getClass().getSimpleName());
        }
        File currentRoot = storageRootFor(current);
        if (currentRoot != null && currentRoot.exists()) {
            String key = currentRoot.getAbsolutePath();
            if (!seen.containsKey(key)) out.add(0, new BrowserStorageTarget(storageLabelForRoot(currentRoot), currentRoot));
        }
        if (out.isEmpty()) {
            File fallback = Environment.getExternalStorageDirectory();
            if (fallback != null) out.add(new BrowserStorageTarget("内蔵ストレージ", fallback));
        }
        return out;
    }

    private String storageLabelForRoot(File root) {
        if (root == null) return "ストレージ";
        String p = root.getAbsolutePath();
        if (p.startsWith("/storage/emulated/0")) return "内蔵ストレージ";
        return "SDカード";
    }

    private BrowserStorageTarget findBrowserStorageTarget(List<BrowserStorageTarget> targets, File root) {
        if (targets == null || root == null) return null;
        for (BrowserStorageTarget target : targets) if (target != null && sameFilePath(target.root, root)) return target;
        return null;
    }

    private interface BrowserStorageSelection { void onSelected(BrowserStorageTarget target); }

    private void showStorageSelectorPopup(View anchor, List<BrowserStorageTarget> targets, BrowserStorageSelection callback) {
        if (targets == null || targets.isEmpty()) return;
        final int panel = Color.rgb(58, 51, 51);
        LinearLayout list = new LinearLayout(this);
        list.setOrientation(LinearLayout.VERTICAL);
        list.setBackgroundColor(panel);
        final PopupWindow[] holder = new PopupWindow[1];
        for (BrowserStorageTarget target : targets) {
            TextView row = new TextView(this);
            row.setText(target.label); row.setTextColor(Color.WHITE); row.setTextSize(16);
            row.setGravity(Gravity.CENTER_VERTICAL); row.setPadding(dp(16), 0, dp(16), 0);
            row.setOnClickListener(v -> {
                if (holder[0] != null) holder[0].dismiss();
                if (callback != null) callback.onSelected(target);
            });
            list.addView(row, new LinearLayout.LayoutParams(dp(260), dp(52)));
        }
        PopupWindow popup = new PopupWindow(list, dp(260), -2, true);
        holder[0] = popup;
        popup.setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(panel));
        popup.setOutsideTouchable(true);
        popup.setElevation(dp(8));
        popup.showAsDropDown(anchor, 0, dp(2));
    }

    private ArrayList<String> listDirectoryFolders(File dir) {
        ArrayList<String> out = new ArrayList<>();
        if (dir == null) return out;
        try {
            String[] names = dir.list();
            if (names == null) return out;
            for (String name : names) {
                if (name == null || name.isEmpty()) continue;
                try {
                    if (new File(dir, name).isDirectory()) out.add(name);
                } catch (Throwable ignored) { }
            }
            Collections.sort(out, String.CASE_INSENSITIVE_ORDER);
        } catch (Throwable e) {
            AppLog.d(this, "MANAGER list error path=" + dir.getAbsolutePath() + " " + e);
        }
        return out;
    }

    private ArrayList<String> getCachedDirectoryFolders(File dir) {
        if (dir == null) return null;
        String key = dir.getAbsolutePath();
        synchronized (DIRECTORY_CACHE_LOCK) {
            DirectoryCacheEntry entry = DIRECTORY_CACHE.get(key);
            if (entry == null) return null;
            if (SystemClock.elapsedRealtime() - entry.createdAt > DIRECTORY_CACHE_TTL_MS) {
                DIRECTORY_CACHE.remove(key);
                return null;
            }
            return new ArrayList<>(entry.folderNames);
        }
    }

    private void putCachedDirectoryFolders(File dir, List<String> names) {
        if (dir == null || names == null) return;
        synchronized (DIRECTORY_CACHE_LOCK) {
            DIRECTORY_CACHE.put(dir.getAbsolutePath(),
                    new DirectoryCacheEntry(SystemClock.elapsedRealtime(), names));
        }
    }

    private void invalidateDirectoryCache(File dir) {
        if (dir == null) return;
        synchronized (DIRECTORY_CACHE_LOCK) { DIRECTORY_CACHE.remove(dir.getAbsolutePath()); }
    }

    private boolean sameFilePath(File a, File b) {
        if (a == null || b == null) return false;
        try { return a.getCanonicalFile().equals(b.getCanonicalFile()); }
        catch (Throwable ignored) { return a.getAbsolutePath().equals(b.getAbsolutePath()); }
    }

    private TextView makeManagerButton(String text) {
        TextView b = new TextView(this);
        b.setText(text); b.setTextColor(Color.WHITE); b.setTextSize(14); b.setGravity(Gravity.CENTER);
        return b;
    }

    private File storageRootFor(File dir) {
        if (dir == null) return null;
        String path = dir.getAbsolutePath().replace('\\', '/');
        if (path.startsWith("/storage/emulated/0")) return new File("/storage/emulated/0");
        if (path.startsWith("/storage/")) {
            String rest = path.substring("/storage/".length());
            int slash = rest.indexOf('/');
            String volume = slash >= 0 ? rest.substring(0, slash) : rest;
            if (!volume.isEmpty()) return new File("/storage/" + volume);
        }
        return dir;
    }

    private boolean isWithinRoot(File candidate, File root) {
        try {
            String c = candidate.getCanonicalPath();
            String r = root.getCanonicalPath();
            return c.equals(r) || c.startsWith(r + File.separator);
        } catch (Throwable e) { return false; }
    }

    private void showCreateFolderDialog(File parent, Runnable refresh) {
        if (parent == null) return;
        final int panel = Color.rgb(58, 51, 51);
        EditText input = makeSaveField("フォルダ名", "");
        input.setSelectAllOnFocus(false);
        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle("新規フォルダ")
                .setView(input)
                .setNegativeButton("キャンセル", null)
                .setPositiveButton("作成", null)
                .create();
        prepareDialogBeforeShow(dialog, panel);
        dialog.setOnShowListener(v -> {
            int titleId = getResources().getIdentifier("alertTitle", "id", "android");
            TextView title = dialog.findViewById(titleId);
            if (title != null) title.setTextColor(Color.WHITE);
            styleDialogButton(dialog, AlertDialog.BUTTON_NEGATIVE, Color.WHITE, panel);
            styleDialogButton(dialog, AlertDialog.BUTTON_POSITIVE, Color.WHITE, panel);
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v2 -> {
                String name = input.getText().toString().trim();
                if (name.isEmpty()) { input.setError("フォルダ名を入力してください"); return; }
                String clean = sanitizeFileName(name);
                final File created = new File(parent, clean);
                dialog.getButton(AlertDialog.BUTTON_POSITIVE).setEnabled(false);
                AppLog.d(this, "MANAGER mkdir begin path=" + created.getAbsolutePath());
                safeExecute(fileManagerExecutor, () -> {
                    boolean exists;
                    boolean ok = false;
                    try {
                        exists = created.exists();
                        if (!exists) ok = created.mkdir();
                    } catch (Throwable e) {
                        exists = false;
                        AppLog.d(this, "MANAGER mkdir error path=" + created.getAbsolutePath() + " " + e);
                    }
                    final boolean existed = exists;
                    final boolean made = ok;
                    mainHandler.post(() -> {
                        if (isFinishing()) return;
                        if (existed) {
                            input.setError("同名フォルダがあります");
                            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setEnabled(true);
                            return;
                        }
                        if (!made) {
                            Toast.makeText(this, "この場所にはフォルダを作成できません", Toast.LENGTH_LONG).show();
                            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setEnabled(true);
                            return;
                        }
                        AppLog.d(this, "MANAGER mkdir success path=" + created.getAbsolutePath());
                        invalidateDirectoryCache(parent);
                        dialog.dismiss();
                        if (refresh != null) refresh.run();
                    });
                });
            });
        });
        dialog.show();
    }


    private void requestFileTransfer(File destinationDir, boolean move) {
        if (destinationDir == null || currentUri == null || currentName == null) return;
        AppLog.d(this, "FILE transfer request mode=" + (move ? "move" : "copy") +
                " source=" + currentName + " destDir=" + destinationDir.getAbsolutePath());
        String sourcePath = inferAbsolutePathFromAnyUri(currentUri);
        if (move && sourcePath != null) {
            File sourceParent = new File(sourcePath).getParentFile();
            try {
                if (sourceParent != null && sourceParent.getCanonicalFile().equals(destinationDir.getCanonicalFile())) {
                    Toast.makeText(this, "すでにこのフォルダにあります", Toast.LENGTH_SHORT).show();
                    return;
                }
            } catch (Throwable ignored) { }
        }
        File destination = new File(destinationDir, currentName);
        if (destination.exists()) {
            if (conflictPolicyThisSession == CONFLICT_ASK) {
                showConflictDialog(destinationDir, move);
                return;
            }
            performFileTransfer(destinationDir, move, conflictPolicyThisSession);
            return;
        }
        performFileTransfer(destinationDir, move, CONFLICT_OVERWRITE);
    }

    private void showConflictDialog(File destinationDir, boolean move) {
        final int panel = Color.rgb(58, 51, 51);
        CheckBox skip = new CheckBox(this);
        skip.setText("このセッションでは再度確認しない");
        skip.setTextColor(Color.WHITE);
        skip.setPadding(dp(18), dp(4), dp(18), dp(4));
        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle("同名ファイルがあります")
                .setMessage(currentName)
                .setView(skip)
                .setNegativeButton("キャンセル", null)
                .setNeutralButton("別名保存", null)
                .setPositiveButton("上書き", null)
                .create();
        prepareDialogBeforeShow(dialog, panel);
        dialog.setOnShowListener(v -> {
            int titleId = getResources().getIdentifier("alertTitle", "id", "android");
            TextView title = dialog.findViewById(titleId);
            if (title != null) title.setTextColor(Color.WHITE);
            int messageId = getResources().getIdentifier("message", "id", "android");
            TextView message = dialog.findViewById(messageId);
            if (message != null) message.setTextColor(Color.WHITE);
            styleDialogButton(dialog, AlertDialog.BUTTON_NEGATIVE, Color.WHITE, panel);
            styleDialogButton(dialog, AlertDialog.BUTTON_NEUTRAL, Color.WHITE, panel);
            styleDialogButton(dialog, AlertDialog.BUTTON_POSITIVE, Color.WHITE, panel);
            dialog.getButton(AlertDialog.BUTTON_NEUTRAL).setOnClickListener(v2 -> {
                if (skip.isChecked()) conflictPolicyThisSession = CONFLICT_RENAME;
                dialog.dismiss();
                performFileTransfer(destinationDir, move, CONFLICT_RENAME);
            });
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v2 -> {
                if (skip.isChecked()) conflictPolicyThisSession = CONFLICT_OVERWRITE;
                dialog.dismiss();
                performFileTransfer(destinationDir, move, CONFLICT_OVERWRITE);
            });
        });
        dialog.show();
    }

    private void performFileTransfer(File destinationDir, boolean move, int policy) {
        final Uri sourceUri = currentUri;
        final String sourcePath = inferAbsolutePathFromAnyUri(sourceUri);
        final String sourceName = currentName;
        if (sourceUri == null || sourceName == null) return;
        File requested = new File(destinationDir, sourceName);
        final File destination = policy == CONFLICT_RENAME ? uniqueFile(destinationDir, sourceName) : requested;
        if (sourcePath != null && policy == CONFLICT_OVERWRITE) {
            try {
                if (new File(sourcePath).getCanonicalFile().equals(destination.getCanonicalFile())) {
                    Toast.makeText(this, "同じファイルには上書きできません。別名保存を選んでください", Toast.LENGTH_LONG).show();
                    return;
                }
            } catch (Throwable ignored) { }
        }
        Toast.makeText(this, move ? "移動しています" : "コピーしています", Toast.LENGTH_SHORT).show();
        AppLog.d(this, "FILE transfer begin mode=" + (move ? "move" : "copy") +
                " source=" + sourceName + " destination=" + destination.getAbsolutePath() + " policy=" + policy);
        safeExecute(editExecutor, () -> {
            Uri copiedUri = null;
            boolean sourceDeleted = !move;
            try {
                copiedUri = copyToDestination(sourceUri, destination, policy == CONFLICT_OVERWRITE);
                if (copiedUri == null) throw new IOException("destination unavailable");
                if (move) sourceDeleted = deleteSourceForMove(sourceUri, sourcePath);
            } catch (Throwable e) {
                AppLog.d(this, "FILE " + (move ? "move" : "copy") + " error " + e);
                final boolean partial = copiedUri != null && move && !sourceDeleted;
                mainHandler.post(() -> Toast.makeText(this,
                        partial ? "コピーは完了しましたが元ファイルを削除できませんでした" : (move ? "移動できませんでした" : "コピーできませんでした"),
                        Toast.LENGTH_LONG).show());
                return;
            }
            final Uri resultUri = copiedUri;
            final boolean movedOk = sourceDeleted;
            mainHandler.post(() -> {
                synchronized (FOLDER_CACHE_LOCK) { FOLDER_INDEX_CACHE.evictAll(); }
                invalidateDirectoryCache(destinationDir);
                if (sourcePath != null) invalidateDirectoryCache(new File(sourcePath).getParentFile());
                AppLog.d(this, "FILE " + (move ? "move" : "copy") + " success source=" + sourceName + " dest=" + destination);
                if (move && movedOk) {
                    currentUri = resultUri;
                    currentName = destination.getName();
                    currentMime = mimeFromName(currentName);
                    clearPendingRotationState();
                    titleView.setText(currentName);
                    showCurrentUri(false, 0);
                    discoverSiblingImagesAsync();
                    Toast.makeText(this, "移動しました", Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(this, destination.getName().equals(sourceName) ? "コピーしました" : "別名でコピーしました", Toast.LENGTH_SHORT).show();
                }
            });
        });
    }

    private Uri copyToDestination(Uri sourceUri, File destination, boolean overwrite) throws IOException {
        File parent = destination.getParentFile();
        if (parent == null || !parent.isDirectory()) throw new IOException("missing destination directory");
        Throwable mediaFailure = null;

        // Android 10+ shared storage is MediaStore-first. This avoids relying on canWrite(),
        // which can report a path optimistically even when scoped-storage blocks FileOutputStream.
        if (Build.VERSION.SDK_INT >= 29) {
            StorageTarget target = storageTargetForPath(destination.getAbsolutePath());
            if (target != null) {
                try {
                    Uri out = copyToMediaStore(sourceUri, destination, target, overwrite);
                    if (out != null) {
                        AppLog.d(this, "FILE transfer backend=mediastore destination=" + destination.getAbsolutePath());
                        return out;
                    }
                } catch (Throwable e) {
                    mediaFailure = e;
                    AppLog.d(this, "FILE transfer mediastore failed destination=" + destination.getAbsolutePath() + " " + e);
                }
            }
        }

        // Direct file write is the fallback for app-writable/custom locations and older Android.
        try {
            if (destination.exists() && !overwrite) throw new IOException("destination exists");
            try (InputStream in = openSourceInputStream(sourceUri);
                 OutputStream out = new FileOutputStream(destination, false)) {
                copyStream(in, out);
            }
            AppLog.d(this, "FILE transfer backend=direct destination=" + destination.getAbsolutePath());
            return Uri.fromFile(destination);
        } catch (Throwable directFailure) {
            AppLog.d(this, "FILE transfer direct failed destination=" + destination.getAbsolutePath() + " " + directFailure);
            IOException failure = new IOException("No writable copy backend for " + destination.getAbsolutePath(), directFailure);
            if (mediaFailure != null) failure.addSuppressed(mediaFailure);
            throw failure;
        }
    }

    private Uri copyToMediaStore(Uri sourceUri, File destination, StorageTarget target, boolean overwrite) throws IOException {
        Uri collection = mediaCollectionForTarget(target, destination.getName());
        if (collection == null) return null;
        if (overwrite) deleteMediaStoreDestination(target, destination.getName(), collection);

        ContentValues values = new ContentValues();
        values.put(MediaStore.MediaColumns.DISPLAY_NAME, destination.getName());
        values.put(MediaStore.MediaColumns.MIME_TYPE, mimeFromName(destination.getName()));
        values.put(MediaStore.MediaColumns.RELATIVE_PATH, target.relativeDirectory);
        values.put(MediaStore.MediaColumns.IS_PENDING, 1);
        Uri outUri = getContentResolver().insert(collection, values);
        if (outUri == null) throw new IOException("MediaStore insert failed");
        try {
            try (InputStream in = openSourceInputStream(sourceUri);
                 OutputStream out = getContentResolver().openOutputStream(outUri, "w")) {
                if (out == null) throw new IOException("MediaStore output failed");
                copyStream(in, out);
            }
            ContentValues done = new ContentValues();
            done.put(MediaStore.MediaColumns.IS_PENDING, 0);
            getContentResolver().update(outUri, done, null, null);
            return outUri;
        } catch (Throwable e) {
            try { getContentResolver().delete(outUri, null, null); } catch (Throwable ignored) { }
            if (e instanceof IOException) throw (IOException)e;
            throw new IOException(e);
        }
    }

    private Uri mediaCollectionForTarget(StorageTarget target, String fileName) {
        if (target == null) return null;
        String rel = target.relativeDirectory == null ? "" : target.relativeDirectory.replace('\\', '/');
        String lower = rel.toLowerCase(Locale.ROOT);
        if (Build.VERSION.SDK_INT >= 29 && (lower.equals("download/") || lower.startsWith("download/"))) {
            return MediaStore.Downloads.getContentUri(target.volumeName);
        }
        if (fileName != null && fileName.toLowerCase(Locale.ROOT).endsWith(".pdf")) {
            if (Build.VERSION.SDK_INT >= 29) return MediaStore.Downloads.getContentUri(target.volumeName);
            return null;
        }
        return MediaStore.Images.Media.getContentUri(target.volumeName);
    }


    private InputStream openSourceInputStream(Uri sourceUri) throws IOException {
        String path = inferAbsolutePathFromAnyUri(sourceUri);
        if (path != null) {
            try { return new FileInputStream(new File(path)); }
            catch (Throwable ignored) { }
        }
        InputStream in = getContentResolver().openInputStream(sourceUri);
        if (in == null) throw new IOException("source stream unavailable");
        return in;
    }

    private void copyStream(InputStream in, OutputStream out) throws IOException {
        byte[] buffer = new byte[128 * 1024];
        int read;
        while ((read = in.read(buffer)) >= 0) {
            if (read > 0) out.write(buffer, 0, read);
        }
        out.flush();
    }

    private void deleteMediaStoreDestination(StorageTarget target, String name, Uri collection) {
        try {
            getContentResolver().delete(collection,
                    MediaStore.MediaColumns.RELATIVE_PATH + "=? AND " + MediaStore.MediaColumns.DISPLAY_NAME + "=? COLLATE NOCASE",
                    new String[]{target.relativeDirectory, name});
        } catch (Throwable e) {
            AppLog.d(this, "FILE overwrite delete miss " + e.getClass().getSimpleName());
        }
    }


    private boolean deleteSourceForMove(Uri uri, String path) {
        try {
            if ("content".equalsIgnoreCase(uri.getScheme())) {
                try {
                    if (getContentResolver().delete(uri, null, null) > 0) return true;
                } catch (Throwable ignored) { }
            }
            if (path != null) {
                File f = new File(path);
                return !f.exists() || f.delete();
            }
        } catch (Throwable ignored) { }
        return false;
    }

    private void shareCurrent() {
        if (currentUri == null) return;
        if (pendingRotationDegrees != 0) {
            shareRotatedCurrent();
            return;
        }
        try {
            Uri shareUri = currentUri;
            if ("file".equalsIgnoreCase(currentUri.getScheme())) {
                File f = new File(currentUri.getPath());
                shareUri = androidx.core.content.FileProvider.getUriForFile(
                        this, getPackageName() + ".fileprovider", f);
            }
            android.content.Intent share = new android.content.Intent(android.content.Intent.ACTION_SEND);
            share.setType(currentMime == null ? "image/*" : currentMime);
            share.putExtra(android.content.Intent.EXTRA_STREAM, shareUri);
            share.addFlags(android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION);
            startActivity(android.content.Intent.createChooser(share, "共有"));
        } catch (Throwable e) {
            AppLog.d(this, "SHARE error " + e);
            Toast.makeText(this, "共有できませんでした", Toast.LENGTH_SHORT).show();
        }
    }

    private void shareRotatedCurrent() {
        final int degrees = pendingRotationDegrees;
        final Bitmap ready = pendingRotationBitmap;
        final Uri sourceUri = currentUri;
        final String sourceName = currentName;
        if (degrees == 0 || sourceUri == null) { shareCurrent(); return; }
        Toast.makeText(this, "回転画像を準備しています", Toast.LENGTH_SHORT).show();
        safeExecute(editExecutor, () -> {
            try {
                Bitmap bitmap = ready != null ? ready : decodeRotatedBitmap(sourceUri, degrees);
                OutputSpec spec = outputSpec(extensionOf(sourceName));
                File dir = new File(getCacheDir(), "shared-edits");
                if (!dir.exists() && !dir.mkdirs()) throw new IOException("Cannot create share cache");
                String base = baseNameOf(sourceName);
                File out = new File(dir, sanitizeFileName(base) + "_rotated." + spec.extension);
                try (OutputStream os = new FileOutputStream(out)) {
                    if (!bitmap.compress(spec.format, spec.quality, os)) throw new IOException("Bitmap compress failed");
                }
                Uri shareUri = androidx.core.content.FileProvider.getUriForFile(
                        this, getPackageName() + ".fileprovider", out);
                mainHandler.post(() -> {
                    try {
                        Intent share = new Intent(Intent.ACTION_SEND);
                        share.setType(spec.mime);
                        share.putExtra(Intent.EXTRA_STREAM, shareUri);
                        share.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                        startActivity(Intent.createChooser(share, "保存せず共有"));
                    } catch (Throwable e) {
                        AppLog.d(this, "SHARE rotated chooser error " + e);
                        Toast.makeText(this, "共有できませんでした", Toast.LENGTH_SHORT).show();
                    }
                });
            } catch (Throwable e) {
                AppLog.d(this, "SHARE rotated error " + e);
                mainHandler.post(() -> Toast.makeText(this, "回転画像を共有できませんでした", Toast.LENGTH_SHORT).show());
            }
        });
    }

    private void showPropertiesDialog() {
        if (currentUri == null) return;
        final int panel = Color.rgb(58, 51, 51);
        final int label = Color.rgb(180, 180, 190);
        LinearLayout content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(dp(24), dp(18), dp(24), dp(10));
        content.setBackground(makeRoundedPanel(panel));

        TextView title = new TextView(this);
        title.setText("プロパティ");
        title.setTextColor(Color.WHITE);
        title.setTextSize(20);
        title.setTypeface(null, android.graphics.Typeface.BOLD);
        LinearLayout.LayoutParams titleParams = new LinearLayout.LayoutParams(-1, -2);
        titleParams.bottomMargin = dp(16);
        content.addView(title, titleParams);

        addPropertyRow(content, "名前", currentName == null ? resolveDisplayName(currentUri) : currentName, label);
        String absolute = inferAbsolutePathFromAnyUri(currentUri);
        String shownPath = absolute != null ? absolute : currentUri.toString();
        addPropertyRow(content, "パス", shownPath, label);

        long size = resolveCurrentSize();
        addPropertyRow(content, "サイズ", formatFileSize(size), label);
        int[] dimensions = currentImageDimensions();
        String resolution = dimensions[0] > 0 && dimensions[1] > 0
                ? String.format(Locale.ROOT, "%d × %d (%.1fMP)", dimensions[0], dimensions[1],
                (dimensions[0] * (double) dimensions[1]) / 1_000_000d)
                : "-";
        addPropertyRow(content, "解像度", resolution, label);
        long modified = resolveCurrentModified();
        addPropertyRow(content, "最終更新日時", formatModified(modified), label);

        TextView ok = new TextView(this);
        ok.setText("OK");
        ok.setTextColor(Color.WHITE);
        ok.setTextSize(15);
        ok.setGravity(Gravity.CENTER);
        ok.setBackground(new android.graphics.drawable.ColorDrawable(Color.TRANSPARENT));
        LinearLayout.LayoutParams okParams = new LinearLayout.LayoutParams(dp(64), dp(44));
        okParams.gravity = Gravity.END;
        content.addView(ok, okParams);

        AlertDialog dialog = new AlertDialog.Builder(this).setView(content).create();
        dialog.setCanceledOnTouchOutside(true);
        prepareDialogBeforeShow(dialog, panel);
        ok.setOnClickListener(v -> dialog.dismiss());
        AppLog.d(this, "DIALOG properties show-prepared");
        dialog.show();
    }

    private void addPropertyRow(LinearLayout parent, String labelText, String value, int labelColor) {
        TextView label = new TextView(this);
        label.setText(labelText);
        label.setTextColor(labelColor);
        label.setTextSize(14);
        parent.addView(label, new LinearLayout.LayoutParams(-1, -2));
        TextView valueView = new TextView(this);
        valueView.setText(value == null || value.isEmpty() ? "-" : value);
        valueView.setTextColor(Color.WHITE);
        valueView.setTextSize(17);
        valueView.setTextIsSelectable(true);
        LinearLayout.LayoutParams vp = new LinearLayout.LayoutParams(-1, -2);
        vp.bottomMargin = dp(16);
        parent.addView(valueView, vp);
    }

    private long resolveCurrentSize() {
        try {
            String path = inferAbsolutePathFromAnyUri(currentUri);
            if (path != null) {
                File f = new File(path);
                if (f.isFile()) return f.length();
            }
            try (Cursor c = getContentResolver().query(currentUri,
                    new String[]{OpenableColumns.SIZE}, null, null, null)) {
                if (c != null && c.moveToFirst()) {
                    int col = c.getColumnIndex(OpenableColumns.SIZE);
                    if (col >= 0 && !c.isNull(col)) return c.getLong(col);
                }
            }
        } catch (Throwable ignored) { }
        MediaItem item = currentMediaItem();
        return item == null ? -1L : item.size;
    }

    private long resolveCurrentModified() {
        try {
            String path = inferAbsolutePathFromAnyUri(currentUri);
            if (path != null) {
                long v = new File(path).lastModified();
                if (v > 0L) return v;
            }
            try (Cursor c = getContentResolver().query(currentUri,
                    new String[]{MediaStore.MediaColumns.DATE_MODIFIED}, null, null, null)) {
                if (c != null && c.moveToFirst()) {
                    int col = c.getColumnIndex(MediaStore.MediaColumns.DATE_MODIFIED);
                    if (col >= 0 && !c.isNull(col)) {
                        long v = c.getLong(col);
                        return v > 0L && v < 10_000_000_000L ? v * 1000L : v;
                    }
                }
            }
        } catch (Throwable ignored) { }
        MediaItem item = currentMediaItem();
        if (item == null || item.modified < 0L) return -1L;
        return item.modified < 10_000_000_000L ? item.modified * 1000L : item.modified;
    }

    private MediaItem currentMediaItem() {
        if (currentIndex >= 0 && currentIndex < siblings.size()) return siblings.get(currentIndex);
        for (MediaItem item : siblings) {
            if (item != null && currentName != null && currentName.equalsIgnoreCase(item.name)) return item;
        }
        return null;
    }

    private int[] currentImageDimensions() {
        Drawable d = imageView == null ? null : imageView.getDrawable();
        if (d != null) return new int[]{Math.max(0, d.getIntrinsicWidth()), Math.max(0, d.getIntrinsicHeight())};
        return new int[]{0, 0};
    }

    private String formatFileSize(long bytes) {
        if (bytes < 0L) return "-";
        if (bytes < 1024L) return bytes + " B";
        if (bytes < 1024L * 1024L) return String.format(Locale.ROOT, "%.1f kB", bytes / 1024d);
        if (bytes < 1024L * 1024L * 1024L) return String.format(Locale.ROOT, "%.1f MB", bytes / (1024d * 1024d));
        return String.format(Locale.ROOT, "%.2f GB", bytes / (1024d * 1024d * 1024d));
    }

    private String formatModified(long millis) {
        if (millis <= 0L) return "-";
        return new SimpleDateFormat("yyyy/MM/dd HH:mm:ss", Locale.getDefault()).format(new Date(millis));
    }

    private void showRotatePopup(View anchor) {
        if (currentUri == null || isPdf(currentMime, currentUri)) {
            Toast.makeText(this, "このファイルは回転できません", Toast.LENGTH_SHORT).show();
            return;
        }
        final int panel = Color.rgb(58, 51, 51);
        LinearLayout list = new LinearLayout(this);
        list.setOrientation(LinearLayout.VERTICAL);
        list.setPadding(dp(6), dp(6), dp(6), dp(6));
        list.setBackgroundColor(panel);
        PopupWindow popup = new PopupWindow(list, dp(190), -2, true);
        popup.setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(panel));
        popup.setOutsideTouchable(true);
        popup.setElevation(dp(8));
        addRotatePopupItem(list, popup, "右に回転", 90);
        addRotatePopupItem(list, popup, "左に回転", -90);
        addRotatePopupItem(list, popup, "180度回転", 180);
        popup.showAsDropDown(anchor, -dp(142), -dp(6));
    }

    private void addRotatePopupItem(LinearLayout list, PopupWindow popup, String text, int degrees) {
        TextView row = new TextView(this);
        row.setText(text);
        row.setTextColor(Color.WHITE);
        row.setTextSize(18);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(dp(18), 0, dp(18), 0);
        row.setOnClickListener(v -> {
            popup.dismiss();
            applyRotationPreview(degrees);
        });
        list.addView(row, new LinearLayout.LayoutParams(-1, dp(54)));
    }

    private void applyRotationPreview(int deltaDegrees) {
        if (currentUri == null || pageAnimating || rotationAnimating) return;
        final int next = ((pendingRotationDegrees + deltaDegrees) % 360 + 360) % 360;
        final int generation = rotationGeneration.incrementAndGet();
        final Uri target = currentUri;
        final float zoomMultiplier = imageView.getViewerZoomMultiplier();
        final float currentFit = imageView.getViewerFitScale();
        final float targetFit = imageView.fitScaleForViewerRotation(next);
        final float targetViewScale = currentFit > 0f && Float.isFinite(targetFit)
                ? Math.max(0.05f, targetFit / currentFit) : 1f;

        pendingRotationDegrees = next;
        pendingRotationBitmap = null;
        if (saveRotationButton != null) saveRotationButton.setVisibility(next == 0 ? View.GONE : View.VISIBLE);
        AppLog.d(this, "ROTATE smooth start delta=" + deltaDegrees + " target=" + next +
                " fit=" + currentFit + "->" + targetFit + " viewScale=" + targetViewScale);

        rotationAnimating = true;
        imageView.animate().cancel();
        imageView.setPivotX(imageView.getWidth() / 2f);
        imageView.setPivotY(imageView.getHeight() / 2f);
        imageView.setLayerType(View.LAYER_TYPE_HARDWARE, null);
        imageView.animate()
                .rotationBy(deltaDegrees)
                .scaleX(targetViewScale)
                .scaleY(targetViewScale)
                .setDuration(Math.abs(deltaDegrees) == 180 ? 300L : 240L)
                .setInterpolator(new PathInterpolator(0.20f, 0.0f, 0.0f, 1.0f))
                .withEndAction(() -> {
                    if (generation != rotationGeneration.get() || currentUri == null || !target.equals(currentUri)) {
                        rotationAnimating = false;
                        imageView.setRotation(0f);
                        imageView.setScaleX(1f);
                        imageView.setScaleY(1f);
                        imageView.setLayerType(View.LAYER_TYPE_NONE, null);
                        return;
                    }
                    // Commit the rotated FIT matrix in the same UI callback in which the temporary
                    // view transform returns to identity. There is no re-decoded drawable swap, so
                    // the last animation frame and the steady state have the same geometry.
                    imageView.commitViewerRotation(next, zoomMultiplier);
                    imageView.setRotation(0f);
                    imageView.setScaleX(1f);
                    imageView.setScaleY(1f);
                    imageView.setLayerType(View.LAYER_TYPE_NONE, null);
                    rotationAnimating = false;
                    AppLog.d(this, "ROTATE smooth committed degrees=" + next);
                })
                .start();
    }

    private Bitmap decodeRotatedBitmap(Uri uri, int degrees) throws IOException {
        ImageDecoder.Source source = createImageSource(uri);
        Bitmap sourceBitmap = ImageDecoder.decodeBitmap(source, (decoder, info, src) ->
                decoder.setAllocator(ImageDecoder.ALLOCATOR_SOFTWARE));
        if (degrees % 360 == 0) return sourceBitmap;
        Matrix matrix = new Matrix();
        matrix.postRotate(degrees);
        return Bitmap.createBitmap(sourceBitmap, 0, 0, sourceBitmap.getWidth(), sourceBitmap.getHeight(), matrix, true);
    }

    private void clearPendingRotationState() {
        pendingRotationDegrees = 0;
        pendingRotationBitmap = null;
        rotationGeneration.incrementAndGet();
        rotationAnimating = false;
        if (imageView != null) {
            imageView.animate().cancel();
            imageView.setRotation(0f);
            imageView.setScaleX(1f);
            imageView.setScaleY(1f);
            imageView.setLayerType(View.LAYER_TYPE_NONE, null);
            imageView.commitViewerRotation(0, 1f);
        }
        if (saveRotationButton != null) saveRotationButton.setVisibility(View.GONE);
    }

    private void showSaveRotatedDialog() {
        if (pendingRotationDegrees == 0) return;
        final int panel = Color.rgb(58, 51, 51);
        final int outline = Color.rgb(160, 160, 170);
        String sourcePath = inferAbsolutePathFromAnyUri(currentUri);
        String parentPath = sourcePath == null ? "元ファイルと同じフォルダ" : new File(sourcePath).getParent();
        String defaultBase = baseNameOf(currentName);
        String defaultExt = extensionOf(currentName);
        if (defaultExt.isEmpty()) defaultExt = "jpg";

        LinearLayout content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(dp(22), dp(8), dp(22), dp(8));
        content.setBackgroundColor(panel);

        TextView pathLabel = new TextView(this);
        pathLabel.setText("パス"); pathLabel.setTextColor(outline); pathLabel.setTextSize(14);
        content.addView(pathLabel);
        TextView pathValue = new TextView(this);
        pathValue.setText(parentPath); pathValue.setTextColor(Color.WHITE); pathValue.setTextSize(16);
        pathValue.setPadding(dp(12), dp(10), dp(12), dp(14));
        content.addView(pathValue, new LinearLayout.LayoutParams(-1, -2));

        EditText nameInput = makeSaveField("ファイル名", defaultBase);
        content.addView(nameInput, new LinearLayout.LayoutParams(-1, dp(58)));
        EditText extInput = makeSaveField("拡張子", defaultExt);
        LinearLayout.LayoutParams ep = new LinearLayout.LayoutParams(-1, dp(58)); ep.topMargin = dp(10);
        content.addView(extInput, ep);

        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle("名前を付けて保存")
                .setView(content)
                .setNeutralButton("保存せず共有", null)
                .setNegativeButton("キャンセル", null)
                .setPositiveButton("OK", null)
                .create();
        prepareDialogBeforeShow(dialog, panel);
        dialog.setOnShowListener(v -> {
            int titleId = getResources().getIdentifier("alertTitle", "id", "android");
            TextView title = dialog.findViewById(titleId);
            if (title != null) title.setTextColor(Color.WHITE);
            styleDialogButton(dialog, AlertDialog.BUTTON_NEUTRAL, Color.WHITE, panel);
            styleDialogButton(dialog, AlertDialog.BUTTON_NEGATIVE, Color.WHITE, panel);
            styleDialogButton(dialog, AlertDialog.BUTTON_POSITIVE, Color.WHITE, panel);
            dialog.getButton(AlertDialog.BUTTON_NEUTRAL).setOnClickListener(v2 -> {
                dialog.dismiss();
                shareRotatedCurrent();
            });
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v2 -> {
                String base = nameInput.getText().toString().trim();
                String ext = extInput.getText().toString().trim().toLowerCase(Locale.ROOT).replace(".", "");
                if (base.isEmpty()) { nameInput.setError("ファイル名を入力してください"); return; }
                if (!isWritableRotationExtension(ext)) {
                    extInput.setError("jpg / jpeg / png / webp を指定してください");
                    return;
                }
                dialog.dismiss();
                saveRotatedCurrent(base, ext);
            });
        });
        dialog.show();
    }

    private EditText makeSaveField(String hint, String value) {
        EditText field = new EditText(this);
        field.setHint(hint);
        field.setText(value);
        field.setTextColor(Color.WHITE);
        field.setHintTextColor(Color.rgb(165, 165, 175));
        field.setTextSize(17);
        field.setSingleLine(true);
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(Color.TRANSPARENT);
        bg.setStroke(dp(1), Color.rgb(160, 160, 170));
        bg.setCornerRadius(dp(10));
        field.setBackground(bg);
        field.setPadding(dp(12), 0, dp(12), 0);
        return field;
    }

    private void saveRotatedCurrent(String base, String ext) {
        final int degrees = pendingRotationDegrees;
        final Bitmap ready = pendingRotationBitmap;
        final Uri sourceUri = currentUri;
        if (degrees == 0 || sourceUri == null) return;
        Toast.makeText(this, "保存しています", Toast.LENGTH_SHORT).show();
        safeExecute(editExecutor, () -> {
            try {
                Bitmap bitmap = ready != null ? ready : decodeRotatedBitmap(sourceUri, degrees);
                OutputSpec spec = outputSpec(ext);
                String requestedName = sanitizeFileName(base) + "." + spec.extension;
                Uri saved = saveBitmapToSourceFolder(bitmap, requestedName, spec, sourceUri);
                if (saved == null) throw new IOException("No writable destination");
                mainHandler.post(() -> {
                    currentUri = saved;
                    currentName = requestedName;
                    currentMime = spec.mime;
                    titleView.setText(currentName);
                    // The saved file already contains rotated pixels. Keep the current rotated
                    // matrix on-screen until that new file is decoded, then hand off directly to
                    // an identity/FIT matrix so save does not visually snap back to the original.
                    pendingRotationDegrees = 0;
                    pendingRotationBitmap = null;
                    rotationGeneration.incrementAndGet();
                    rotationAnimating = false;
                    if (saveRotationButton != null) saveRotationButton.setVisibility(View.GONE);
                    openImageAsync(saved, false, 0);
                    AppLog.d(this, "ROTATE saved uri=" + saved + " name=" + requestedName);
                    Toast.makeText(this, "保存しました", Toast.LENGTH_SHORT).show();
                    discoverSiblingImagesAsync();
                });
            } catch (Throwable e) {
                AppLog.d(this, "ROTATE save error " + e);
                mainHandler.post(() -> Toast.makeText(this, "保存できませんでした", Toast.LENGTH_LONG).show());
            }
        });
    }

    private Uri saveBitmapToSourceFolder(Bitmap bitmap, String fileName, OutputSpec spec, Uri sourceUri) throws IOException {
        String sourcePath = inferAbsolutePathFromAnyUri(sourceUri);
        if (Build.VERSION.SDK_INT >= 29 && sourcePath != null) {
            StorageTarget target = storageTargetForPath(sourcePath);
            if (target != null) {
                ContentValues values = new ContentValues();
                values.put(MediaStore.Images.Media.DISPLAY_NAME, fileName);
                values.put(MediaStore.Images.Media.MIME_TYPE, spec.mime);
                values.put(MediaStore.Images.Media.RELATIVE_PATH, target.relativeDirectory);
                values.put(MediaStore.Images.Media.IS_PENDING, 1);
                Uri collection = MediaStore.Images.Media.getContentUri(target.volumeName);
                Uri out = getContentResolver().insert(collection, values);
                if (out != null) {
                    try {
                        try (OutputStream os = getContentResolver().openOutputStream(out, "w")) {
                            if (os == null || !bitmap.compress(spec.format, spec.quality, os))
                                throw new IOException("Bitmap compress failed");
                        }
                        ContentValues done = new ContentValues();
                        done.put(MediaStore.Images.Media.IS_PENDING, 0);
                        getContentResolver().update(out, done, null, null);
                        return out;
                    } catch (Throwable e) {
                        try { getContentResolver().delete(out, null, null); } catch (Throwable ignored) { }
                        if (e instanceof IOException) throw (IOException)e;
                        throw new IOException(e);
                    }
                }
            }
        }
        if (sourcePath != null) {
            File parent = new File(sourcePath).getParentFile();
            if (parent != null && parent.canWrite()) {
                File out = uniqueFile(parent, fileName);
                try (OutputStream os = new FileOutputStream(out)) {
                    if (!bitmap.compress(spec.format, spec.quality, os)) throw new IOException("Bitmap compress failed");
                }
                return Uri.fromFile(out);
            }
        }
        throw new IOException("Source folder is not writable");
    }

    private StorageTarget storageTargetForPath(String absolutePath) {
        if (absolutePath == null) return null;
        String normalized = absolutePath.replace('\\', '/');
        String primary = "/storage/emulated/0/";
        if (normalized.startsWith(primary)) {
            String tail = normalized.substring(primary.length());
            int slash = tail.lastIndexOf('/');
            String rel = slash >= 0 ? tail.substring(0, slash + 1) : "Pictures/";
            return new StorageTarget(MediaStore.VOLUME_EXTERNAL_PRIMARY, rel);
        }
        String prefix = "/storage/";
        if (normalized.startsWith(prefix)) {
            String tail = normalized.substring(prefix.length());
            int firstSlash = tail.indexOf('/');
            if (firstSlash > 0) {
                String volumeId = tail.substring(0, firstSlash);
                String fileTail = tail.substring(firstSlash + 1);
                int slash = fileTail.lastIndexOf('/');
                String rel = slash >= 0 ? fileTail.substring(0, slash + 1) : "Pictures/";
                if (!"emulated".equalsIgnoreCase(volumeId) && !"self".equalsIgnoreCase(volumeId)) {
                    String volumeName = volumeId.toLowerCase(Locale.ROOT);
                    if (Build.VERSION.SDK_INT >= 29) {
                        try {
                            for (String available : MediaStore.getExternalVolumeNames(this)) {
                                if (available != null && available.equalsIgnoreCase(volumeId)) {
                                    volumeName = available;
                                    break;
                                }
                            }
                        } catch (Throwable ignored) { }
                    }
                    return new StorageTarget(volumeName, rel);
                }
            }
        }
        return null;
    }

    private File uniqueFile(File parent, String fileName) {
        File candidate = new File(parent, fileName);
        if (!candidate.exists()) return candidate;
        String base = baseNameOf(fileName); String ext = extensionOf(fileName);
        for (int i = 1; i < 10000; i++) {
            String numbered = ext.isEmpty() ? base + " (" + i + ")" : base + " (" + i + ")." + ext;
            File f = new File(parent, numbered);
            if (!f.exists()) return f;
        }
        return candidate;
    }

    private boolean isWritableRotationExtension(String ext) {
        return "jpg".equals(ext) || "jpeg".equals(ext) || "png".equals(ext) || "webp".equals(ext);
    }

    private String extensionOf(String name) {
        if (name == null) return "";
        int dot = name.lastIndexOf('.');
        return dot >= 0 && dot < name.length() - 1 ? name.substring(dot + 1).toLowerCase(Locale.ROOT) : "";
    }

    private String baseNameOf(String name) {
        if (name == null || name.isEmpty()) return "image";
        int dot = name.lastIndexOf('.');
        return dot > 0 ? name.substring(0, dot) : name;
    }

    private String sanitizeFileName(String name) {
        String clean = name == null ? "image" : name.replaceAll("[\\\\/:*?\"<>|]", "_").trim();
        return clean.isEmpty() ? "image" : clean;
    }

    private OutputSpec outputSpec(String extension) {
        String ext = extension == null ? "jpg" : extension.toLowerCase(Locale.ROOT);
        if ("jpeg".equals(ext) || "jpg".equals(ext)) return new OutputSpec(Bitmap.CompressFormat.JPEG, 95, "jpg", "image/jpeg");
        if ("png".equals(ext)) return new OutputSpec(Bitmap.CompressFormat.PNG, 100, "png", "image/png");
        if ("webp".equals(ext)) {
            Bitmap.CompressFormat fmt = Build.VERSION.SDK_INT >= 30 ? Bitmap.CompressFormat.WEBP_LOSSLESS : Bitmap.CompressFormat.WEBP;
            return new OutputSpec(fmt, 100, "webp", "image/webp");
        }
        return new OutputSpec(Bitmap.CompressFormat.PNG, 100, "png", "image/png");
    }

    private static class OutputSpec {
        final Bitmap.CompressFormat format; final int quality; final String extension; final String mime;
        OutputSpec(Bitmap.CompressFormat format, int quality, String extension, String mime) {
            this.format = format; this.quality = quality; this.extension = extension; this.mime = mime;
        }
    }

    private static class StorageTarget {
        final String volumeName; final String relativeDirectory;
        StorageTarget(String volumeName, String relativeDirectory) {
            this.volumeName = volumeName; this.relativeDirectory = relativeDirectory;
        }
    }

    private void showCurrentUri(boolean fromSwipe, int direction) {
        closePdf();
        titleView.setText(currentName == null ? resolveDisplayName(currentUri) : currentName);
        if (isPdf(currentMime, currentUri)) {
            openPdf(currentUri);
        } else {
            openImageAsync(currentUri, fromSwipe, direction);
            updatePositionLabel();
        }
    }

    private ImageDecoder.Source createImageSource(Uri uri) throws IOException {
        if (uri != null && "file".equalsIgnoreCase(uri.getScheme())) {
            String path = uri.getPath();
            if (path == null) throw new IOException("Missing file path");
            return ImageDecoder.createSource(new File(path));
        }
        return ImageDecoder.createSource(getContentResolver(), uri);
    }

    private void openImageAsync(Uri uri, boolean fromSwipe, int direction) {
        final int generation = decodeGeneration.incrementAndGet();
        final long begin = SystemClock.elapsedRealtime();
        AppLog.d(this, "IMAGE decode queued +" + elapsed() + "ms uri=" + uri);
        decodeExecutor.execute(() -> {
            try {
                ImageDecoder.Source source = createImageSource(uri);
                Drawable drawable = ImageDecoder.decodeDrawable(source, (decoder, info, src) -> {
                    // Keep ImageDecoder's default allocator/memory policy. Forcing software + LOW_RAM
                    // made adjacent full-resolution images substantially slower to become swipe-ready.
                });
                long decodeMs = SystemClock.elapsedRealtime() - begin;
                mainHandler.post(() -> {
                    if (generation != decodeGeneration.get() || isFinishing()) return;
                    imageView.setImageForViewer(drawable);
                    if (fromSwipe) {
                        float startX = direction > 0 ? imageView.getWidth() * 0.18f : -imageView.getWidth() * 0.18f;
                        imageView.setTranslationX(startX);
                        imageView.setAlpha(0.82f);
                        imageView.animate().translationX(0f).alpha(1f).setDuration(130).withEndAction(() -> pageAnimating = false).start();
                    } else pageAnimating = false;
                    if (drawable instanceof AnimatedImageDrawable) ((AnimatedImageDrawable) drawable).start();
                    AppLog.d(this, "IMAGE first paint +" + elapsed() + "ms decode=" + decodeMs + "ms class=" + drawable.getClass().getSimpleName());
                    if (!firstFrameLogged) { firstFrameLogged = true; AppLog.d(this, "PERF FIRST_IMAGE_VISIBLE=" + elapsed() + "ms"); }
                });
            } catch (Throwable e) {
                AppLog.d(this, "IMAGE decode ERROR +" + elapsed() + "ms " + e);
                mainHandler.post(() -> {
                    if (generation == decodeGeneration.get()) {
                        pageAnimating = false;
                        Toast.makeText(this, "この画像を表示できませんでした", Toast.LENGTH_LONG).show();
                    }
                });
            }
        });
    }

    private boolean hasIndexedSiblingWindow() {
        return currentIndex >= 0 && !siblings.isEmpty() && (fullListReady || progressiveListActive);
    }

    // direction is physical: +1 = page arrives from the right, -1 = from the left.
    // The siblings array itself is the single source of truth for left-to-right order.
    // Never reverse again here: doing so caused the old sort-direction double inversion.
    private int indexDeltaForPhysicalDirection(int direction) {
        return direction;
    }

    private boolean canMoveSibling(int direction) {
        if (pageAnimating) return false;
        int delta = indexDeltaForPhysicalDirection(direction);
        if (hasIndexedSiblingWindow()) {
            int next = currentIndex + delta;
            return next >= 0 && next < siblings.size();
        }
        return delta > 0 ? quickNextItem != null : quickPreviousItem != null;
    }

    private MediaItem itemForDirection(int direction) {
        int delta = indexDeltaForPhysicalDirection(direction);
        if (hasIndexedSiblingWindow()) {
            int next = currentIndex + delta;
            return (next >= 0 && next < siblings.size()) ? siblings.get(next) : null;
        }
        return delta > 0 ? quickNextItem : quickPreviousItem;
    }

    private Drawable previewForDirection(int direction) {
        return indexDeltaForPhysicalDirection(direction) > 0 ? nextPreviewDrawable : previousPreviewDrawable;
    }

    private void showPagePreview(int direction, float translationX) {
        if (!canMoveSibling(direction) || pagePreviewView == null) {
            hidePagePreview();
            return;
        }
        Drawable preview = previewForDirection(direction);
        if (preview == null) {
            pagePreviewView.setVisibility(View.GONE);
            return;
        }
        if (pagePreviewView.getDrawable() != preview) pagePreviewView.setImageDrawable(preview);
        imageView.setLayerType(View.LAYER_TYPE_HARDWARE, null);
        pagePreviewView.setLayerType(View.LAYER_TYPE_HARDWARE, null);
        pagePreviewView.setVisibility(View.VISIBLE);
        float start = direction > 0 ? imageView.getWidth() : -imageView.getWidth();
        pagePreviewView.setTranslationX(start + translationX);
        pagePreviewView.setAlpha(1f);
    }

    private void hidePagePreview() {
        if (pagePreviewView == null) return;
        pagePreviewView.animate().cancel();
        pagePreviewView.setVisibility(View.GONE);
        pagePreviewView.setTranslationX(0f);
        imageView.setLayerType(View.LAYER_TYPE_NONE, null);
        pagePreviewView.setLayerType(View.LAYER_TYPE_NONE, null);
    }

    private final PathInterpolator pageInterpolator = new PathInterpolator(0.20f, 0f, 0f, 1f);

    private void cancelPageAnimationsForTouch() {
        imageView.animate().cancel();
        if (pagePreviewView != null) pagePreviewView.animate().cancel();
        // A new finger-down owns X from this point onward. Never let an old
        // ViewPropertyAnimator continue writing translationX during ACTION_MOVE.
        imageView.setTranslationX(0f);
        hidePagePreview();
        pageAnimating = false;
    }

    private void animatePageReset() {
        float tx = imageView.getTranslationX();
        if (Math.abs(tx) < 1f) { hidePagePreview(); return; }
        int direction = tx < 0 ? 1 : -1;
        float previewTarget = direction > 0 ? imageView.getWidth() : -imageView.getWidth();
        imageView.setLayerType(View.LAYER_TYPE_HARDWARE, null);
        pagePreviewView.setLayerType(View.LAYER_TYPE_HARDWARE, null);
        imageView.animate().cancel();
        pagePreviewView.animate().cancel();
        imageView.animate().translationX(0f).setDuration(150).setInterpolator(pageInterpolator).start();
        if (pagePreviewView.getVisibility() == View.VISIBLE) {
            pagePreviewView.animate().translationX(previewTarget).setDuration(150).setInterpolator(pageInterpolator)
                    .withEndAction(this::hidePagePreview).start();
        } else {
            mainHandler.postDelayed(this::hidePagePreview, 155);
        }
    }

    private long pageDuration(float velocityX, float remainingPx) {
        float width = Math.max(1f, imageView.getWidth());
        if (Math.abs(velocityX) > 900f) {
            long byVelocity = (long)(1000f * remainingPx / Math.max(1200f, Math.abs(velocityX)));
            return Math.max(75L, Math.min(165L, byVelocity));
        }
        return (long)(105f + 60f * Math.min(1f, remainingPx / width));
    }

    private void animateToSibling(int direction, float velocityX) {
        MediaItem targetItem = itemForDirection(direction);
        if (targetItem == null || !canMoveSibling(direction)) {
            animatePageReset();
            return;
        }
        pageAnimating = true;
        final int targetIndex = hasIndexedSiblingWindow() ? currentIndex + indexDeltaForPhysicalDirection(direction) : -1;
        Drawable preview = previewForDirection(direction);
        float target = direction > 0 ? -imageView.getWidth() : imageView.getWidth();
        float remaining = Math.abs(target - imageView.getTranslationX());
        long duration = pageDuration(velocityX, remaining);

        imageView.setLayerType(View.LAYER_TYPE_HARDWARE, null);
        pagePreviewView.setLayerType(View.LAYER_TYPE_HARDWARE, null);
        imageView.animate().cancel();
        pagePreviewView.animate().cancel();

        if (preview != null) {
            if (pagePreviewView.getVisibility() != View.VISIBLE || pagePreviewView.getDrawable() != preview) {
                pagePreviewView.setImageDrawable(preview);
                pagePreviewView.setVisibility(View.VISIBLE);
                pagePreviewView.setTranslationX(direction > 0 ? imageView.getWidth() : -imageView.getWidth());
            }
            pagePreviewView.animate().translationX(0f).setDuration(duration).setInterpolator(pageInterpolator).start();
            imageView.animate().translationX(target).setDuration(duration).setInterpolator(pageInterpolator).withEndAction(() -> {
                currentUri = targetItem.uri; currentName = targetItem.name; currentMime = targetItem.mime;
                clearPendingRotationState();
                if (targetIndex >= 0 && hasIndexedSiblingWindow()) currentIndex = targetIndex;

                // Keep the centered preview covering the hand-off for one display frame.
                // The main ImageView gets its final FIT matrix while still off-screen, so
                // users never see an old matrix / temporary wrong-size frame.
                imageView.setImageForViewerKeepingTranslation(preview);
                imageView.setTranslationX(0f);
                titleView.setText(currentName);
                updatePositionLabel();
                pagePreviewView.postOnAnimation(() -> {
                    hidePagePreview();
                    pageAnimating = false;
                });
                AppLog.d(this, "SWIPE move cached +" + elapsed() + "ms direction=" + direction + " duration=" + duration);

                // The swipe used a screen-sized preview for speed. Upgrade the now-current
                // page to the original resolution in the background without blocking touch.
                openImageAsync(currentUri, false, 0);
                if (hasIndexedSiblingWindow()) prefetchAdjacent();
                else discoverSiblingImagesAsync();
            }).start();
        } else {
            imageView.animate().translationX(target).setDuration(duration).setInterpolator(pageInterpolator).withEndAction(() -> {
                currentUri = targetItem.uri; currentName = targetItem.name; currentMime = targetItem.mime;
                clearPendingRotationState();
                if (targetIndex >= 0 && hasIndexedSiblingWindow()) currentIndex = targetIndex;
                imageView.setTranslationX(0f);
                AppLog.d(this, "SWIPE move decode +" + elapsed() + "ms direction=" + direction);
                showCurrentUri(true, direction);
                if (hasIndexedSiblingWindow()) prefetchAdjacent();
                else discoverSiblingImagesAsync();
            }).start();
        }
    }

    private String previewKey(Uri uri) {
        return uri == null ? "" : uri.toString();
    }

    private Drawable getCachedPreview(Uri uri) {
        return previewCache.get(previewKey(uri));
    }

    private void putCachedPreview(Uri uri, Drawable drawable) {
        if (uri != null && drawable != null) previewCache.put(previewKey(uri), drawable);
    }

    /**
     * Decode only enough pixels for an on-screen swipe preview. The previous code decoded
     * the original full-resolution file here, which made the FIRST swipe wait on large photos.
     * The full-resolution drawable is loaded only after the page has actually become current.
     */
    private Drawable decodePreviewDrawable(Uri uri) throws IOException {
        ImageDecoder.Source source = createImageSource(uri);
        final int maxW = Math.max(1, getResources().getDisplayMetrics().widthPixels);
        final int maxH = Math.max(1, getResources().getDisplayMetrics().heightPixels);
        return ImageDecoder.decodeDrawable(source, (decoder, info, src) -> {
            int srcW = Math.max(1, info.getSize().getWidth());
            int srcH = Math.max(1, info.getSize().getHeight());
            float scale = Math.min((float) maxW / srcW, (float) maxH / srcH);
            if (scale < 1f) {
                int targetW = Math.max(1, Math.round(srcW * scale));
                int targetH = Math.max(1, Math.round(srcH * scale));
                decoder.setTargetSize(targetW, targetH);
            }
        });
    }

    private void prefetchQuick(MediaItem item, int direction, int generation) {
        if (item == null) return;
        Drawable cached = getCachedPreview(item.uri);
        if (cached != null) {
            if (direction > 0) nextPreviewDrawable = cached; else previousPreviewDrawable = cached;
            AppLog.d(this, "PREFETCH quick cache " + (direction > 0 ? "next" : "prev") + " +" + elapsed() + "ms");
            return;
        }
        prefetchExecutor.execute(() -> {
            long started = SystemClock.elapsedRealtime();
            try {
                Drawable d = decodePreviewDrawable(item.uri);
                putCachedPreview(item.uri, d);
                mainHandler.post(() -> {
                    if (generation != prefetchGeneration.get() || isFinishing()) return;
                    if (direction > 0) nextPreviewDrawable = d; else previousPreviewDrawable = d;
                    AppLog.d(this, "PREFETCH quick " + (direction > 0 ? "next" : "prev") + " ready +" + elapsed() + "ms took=" + (SystemClock.elapsedRealtime()-started) + "ms");
                });
            } catch (Throwable e) { AppLog.d(this, "PREFETCH quick error " + e); }
        });
    }

    private void prefetchAdjacent() {
        final int generation = prefetchGeneration.incrementAndGet();
        final int index = currentIndex;
        if (index < 0 || siblings.isEmpty()) {
            previousPreviewDrawable = null;
            nextPreviewDrawable = null;
            return;
        }
        previousPreviewDrawable = null;
        nextPreviewDrawable = null;
        final MediaItem prev = index > 0 ? siblings.get(index - 1) : null;
        final MediaItem next = index + 1 < siblings.size() ? siblings.get(index + 1) : null;

        if (prev != null) {
            Drawable cached = getCachedPreview(prev.uri);
            if (cached != null) {
                previousPreviewDrawable = cached;
            } else prefetchExecutor.execute(() -> {
                long started = SystemClock.elapsedRealtime();
                try {
                    Drawable d = decodePreviewDrawable(prev.uri);
                    putCachedPreview(prev.uri, d);
                    mainHandler.post(() -> {
                        if (generation != prefetchGeneration.get() || isFinishing()) return;
                        previousPreviewDrawable = d;
                        AppLog.d(this, "PREFETCH prev ready +" + elapsed() + "ms took=" + (SystemClock.elapsedRealtime()-started) + "ms");
                    });
                } catch (Throwable e) { AppLog.d(this, "PREFETCH prev error " + e); }
            });
        }
        if (next != null) {
            Drawable cached = getCachedPreview(next.uri);
            if (cached != null) {
                nextPreviewDrawable = cached;
            } else prefetchExecutor.execute(() -> {
                long started = SystemClock.elapsedRealtime();
                try {
                    Drawable d = decodePreviewDrawable(next.uri);
                    putCachedPreview(next.uri, d);
                    mainHandler.post(() -> {
                        if (generation != prefetchGeneration.get() || isFinishing()) return;
                        nextPreviewDrawable = d;
                        AppLog.d(this, "PREFETCH next ready +" + elapsed() + "ms took=" + (SystemClock.elapsedRealtime()-started) + "ms");
                    });
                } catch (Throwable e) { AppLog.d(this, "PREFETCH next error " + e); }
            });
        }
    }

    private void openPdf(Uri uri) {
        // PDF path remains synchronous for now; image opening is the performance priority for this build.
        try {
            AppLog.d(this, "PDF open begin uri=" + uri);
            pdfFd = getContentResolver().openFileDescriptor(uri, "r");
            if (pdfFd == null) throw new IOException("No file descriptor");
            pdfRenderer = new PdfRenderer(pdfFd);
            if (pdfRenderer.getPageCount() == 0) throw new IOException("Empty PDF");
            renderPdfPage(0);
        } catch (Throwable e) { AppLog.d(this, "PDF open ERROR " + e); Toast.makeText(this, "PDFを表示できませんでした", Toast.LENGTH_LONG).show(); }
    }

    private void renderPdfPage(int index) {
        closePdfPage(); pdfPage = pdfRenderer.openPage(index);
        int screenWidth = Math.max(1, getResources().getDisplayMetrics().widthPixels);
        float ratio = (float) pdfPage.getHeight() / (float) pdfPage.getWidth();
        int bitmapWidth = Math.min(screenWidth * 2, 2200); int bitmapHeight = Math.max(1, Math.round(bitmapWidth * ratio));
        Bitmap bitmap = Bitmap.createBitmap(bitmapWidth, bitmapHeight, Bitmap.Config.ARGB_8888); bitmap.eraseColor(Color.WHITE);
        pdfPage.render(bitmap, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY);
        imageView.setImageForViewer(new android.graphics.drawable.BitmapDrawable(getResources(), bitmap));
        pageView.setText((index + 1) + "/" + pdfRenderer.getPageCount());
    }

    private void updatePositionLabel() {
        if (progressiveListActive && !siblings.isEmpty()) {
            // left: selected-order range proven around the tapped/current image
            // middle: absolute current position once the previous chain reaches folder start
            // right: selected-order rows discovered so far, updated batch by batch
            int discovered = siblings.size();
            int centeredReady = (progressivePrevComplete || progressiveNextComplete)
                    ? discovered
                    : 1 + 2 * Math.min(progressivePrevLoaded, progressiveNextLoaded);
            String pos = progressivePrevComplete ? Integer.toString(currentIndex + 1) : "?";
            pageView.setText(centeredReady + "/" + pos + "/" + discovered);
            return;
        }
        if (currentIndex >= 0 && siblings.size() > 1) pageView.setText((currentIndex + 1) + "/" + siblings.size());
        else pageView.setText("");
    }

    private boolean hasMediaPermission() {
        if (Build.VERSION.SDK_INT >= 33) return checkSelfPermission(Manifest.permission.READ_MEDIA_IMAGES) == PackageManager.PERMISSION_GRANTED;
        return checkSelfPermission(Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED;
    }

    private void requestMediaPermission() {
        if (Build.VERSION.SDK_INT >= 33) requestPermissions(new String[]{Manifest.permission.READ_MEDIA_IMAGES}, REQ_MEDIA);
        else requestPermissions(new String[]{Manifest.permission.READ_EXTERNAL_STORAGE}, REQ_MEDIA);
    }

    @Override public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQ_MEDIA && grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            AppLog.d(this, "PERMISSION media granted"); discoverSiblingImagesAsync();
        } else if (requestCode == REQ_MEDIA) AppLog.d(this, "PERMISSION media denied");
    }

    private static class SeedSortKey {
        final long id;
        final String name;
        final long size;
        final long created;
        final long modified;
        SeedSortKey(long id, String name, long size, long created, long modified) {
            this.id = id; this.name = name; this.size = size; this.created = created; this.modified = modified;
        }
        SeedSortKey(long id, String name, long size, long modified) {
            this(id, name, size, modified, modified);
        }
    }

    private static class ResolvedSeed {
        final String relativePath;
        final SeedSortKey key;
        final String mime;
        final String strategy;
        ResolvedSeed(String relativePath, SeedSortKey key, String mime, String strategy) {
            this.relativePath = relativePath;
            this.key = key;
            this.mime = mime;
            this.strategy = strategy;
        }
    }

    private static class IncomingMeta {
        String name;
        String relativePath;
        String rawPath;
        long size = -1L;
        long modified = -1L;
    }

    private MediaItem queryNeighbor(String relativePath, SeedSortKey seed, boolean next, String field, boolean ascending) {
        if (seed == null) return null;
        String[] projection = new String[]{MediaStore.Images.Media._ID, MediaStore.Images.Media.DISPLAY_NAME, MediaStore.Images.Media.MIME_TYPE, MediaStore.Images.Media.SIZE, MediaStore.Images.Media.DATE_ADDED, MediaStore.Images.Media.DATE_MODIFIED};

        // "next" means forward in the currently selected slide order. Previous uses the
        // exact inverse. _ID is the stable tie-breaker for every sort mode so the quick
        // LIMIT-1 route and the later full-folder list can never disagree on neighbors.
        boolean forwardAscending = next == ascending;
        String cmp = forwardAscending ? ">" : "<";
        String order = forwardAscending ? " ASC" : " DESC";
        String selection;
        String[] args;
        String sort;

        if (SortPrefs.FIELD_NAME.equals(field)) {
            selection = MediaStore.Images.Media.RELATIVE_PATH + "=? AND ((" +
                    MediaStore.Images.Media.DISPLAY_NAME + " COLLATE NOCASE " + cmp + " ?) OR (" +
                    MediaStore.Images.Media.DISPLAY_NAME + " = ? COLLATE NOCASE AND " +
                    MediaStore.Images.Media._ID + " " + cmp + " ?))";
            args = new String[]{relativePath, seed.name, seed.name, Long.toString(seed.id)};
            sort = MediaStore.Images.Media.DISPLAY_NAME + " COLLATE NOCASE" + order + ", " +
                    MediaStore.Images.Media._ID + order;
        } else {
            String col = SortPrefs.sqlColumn(field);
            long seedValue = SortPrefs.FIELD_SIZE.equals(field) ? seed.size : (SortPrefs.FIELD_CREATED.equals(field) ? seed.created : seed.modified);
            selection = MediaStore.Images.Media.RELATIVE_PATH + "=? AND ((" + col + " " + cmp + " ?) OR (" +
                    col + "=? AND " + MediaStore.Images.Media._ID + " " + cmp + " ?))";
            args = new String[]{relativePath, Long.toString(seedValue), Long.toString(seedValue), Long.toString(seed.id)};
            sort = col + order + ", " + MediaStore.Images.Media._ID + order;
        }

        long started = SystemClock.elapsedRealtime();
        MediaItem item = queryFirstMediaItemLimited(projection, selection, args, sort);
        AppLog.d(this, "SIBLINGS neighbor " + (next ? "next" : "prev") +
                " field=" + field + " asc=" + ascending + " took=" +
                (SystemClock.elapsedRealtime() - started) + "ms ready=" + (item != null));
        return item;
    }

    private MediaItem queryFirstMediaItemLimited(String[] projection, String selection, String[] args, String sort) {
        try {
            Bundle queryArgs = new Bundle();
            queryArgs.putString(ContentResolver.QUERY_ARG_SQL_SELECTION, selection);
            queryArgs.putStringArray(ContentResolver.QUERY_ARG_SQL_SELECTION_ARGS, args);
            queryArgs.putString(ContentResolver.QUERY_ARG_SQL_SORT_ORDER, sort);
            queryArgs.putInt(ContentResolver.QUERY_ARG_LIMIT, 1);
            try (Cursor c = getContentResolver().query(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, projection, queryArgs, null)) {
                return firstMediaItemFromCursor(c);
            }
        } catch (Throwable e) {
            AppLog.d(this, "SIBLINGS neighbor bundle query error " + e);
            // Compatibility fallback: same selection/sort, but never append SQL LIMIT to
            // sortOrder. We only read the first row from the returned cursor.
            try (Cursor c = getContentResolver().query(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, projection, selection, args, sort)) {
                return firstMediaItemFromCursor(c);
            } catch (Throwable fallbackError) {
                AppLog.d(this, "SIBLINGS neighbor fallback error " + fallbackError);
            }
        }
        return null;
    }

    private MediaItem firstMediaItemFromCursor(Cursor c) {
        if (c != null && c.moveToFirst()) {
            long id = c.getLong(c.getColumnIndexOrThrow(MediaStore.Images.Media._ID));
            String name = c.getString(c.getColumnIndexOrThrow(MediaStore.Images.Media.DISPLAY_NAME));
            String mime = c.getString(c.getColumnIndexOrThrow(MediaStore.Images.Media.MIME_TYPE));
            long size = c.getLong(c.getColumnIndexOrThrow(MediaStore.Images.Media.SIZE));
            long created = c.getLong(c.getColumnIndexOrThrow(MediaStore.Images.Media.DATE_ADDED));
            long modified = c.getLong(c.getColumnIndexOrThrow(MediaStore.Images.Media.DATE_MODIFIED));
            return new MediaItem(ContentUris.withAppendedId(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, id), name, mime, size, created, modified);
        }
        return null;
    }

    private SeedSortKey lookupSeedSortKey(String relativePath, String seedName) {
        String[] projection = new String[]{MediaStore.Images.Media._ID, MediaStore.Images.Media.DISPLAY_NAME, MediaStore.Images.Media.SIZE, MediaStore.Images.Media.DATE_ADDED, MediaStore.Images.Media.DATE_MODIFIED};
        try (Cursor c = getContentResolver().query(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, projection,
                MediaStore.Images.Media.RELATIVE_PATH + "=? AND " + MediaStore.Images.Media.DISPLAY_NAME + "=? COLLATE NOCASE",
                new String[]{relativePath, seedName}, MediaStore.Images.Media._ID + " ASC")) {
            if (c != null && c.moveToFirst()) {
                return new SeedSortKey(
                        c.getLong(c.getColumnIndexOrThrow(MediaStore.Images.Media._ID)),
                        c.getString(c.getColumnIndexOrThrow(MediaStore.Images.Media.DISPLAY_NAME)),
                        c.getLong(c.getColumnIndexOrThrow(MediaStore.Images.Media.SIZE)),
                        c.getLong(c.getColumnIndexOrThrow(MediaStore.Images.Media.DATE_ADDED)),
                        c.getLong(c.getColumnIndexOrThrow(MediaStore.Images.Media.DATE_MODIFIED)));
            }
        } catch (Throwable e) {
            AppLog.d(this, "SIBLINGS seed sort lookup error " + e);
        }
        return null;
    }

    private void discoverSiblingImagesAsync() {
        if (ENABLE_CURSOR_OUT_EXPERIMENT) discoverSiblingImagesCursorOut();
        else if (ENABLE_CENTER_OUT_EXPERIMENT) discoverSiblingImagesCenterOut();
        else if (ENABLE_EXTERNAL_FAST_PATH_EXPERIMENT) discoverSiblingImagesExperimental();
        else discoverSiblingImagesLegacy();
    }

    /**
     * v0.1.19: generic external-URI resolver + two long-lived ordered cursors.
     *
     * Critical path:
     *   incoming URI -> exact MediaStore seed row -> previous cursor + next cursor
     * Each cursor is queried once, then consumed outward from the current image. There is
     * no LIMIT/paging loop and therefore no repeated 300-1000 ms provider round-trip.
     */
    private void discoverSiblingImagesCursorOut() {
        cancelSiblingQuerySignals();
        final int generation = siblingGeneration.incrementAndGet();
        prefetchGeneration.incrementAndGet();
        final Uri seedUri = currentUri;
        final String seedName = currentName;
        final String sortField = SortPrefs.field(this);
        final boolean sortAscending = SortPrefs.ascending(this);

        fullListReady = false;
        progressiveListActive = true;
        progressivePrevComplete = false;
        progressiveNextComplete = false;
        progressivePrevLoaded = 0;
        progressiveNextLoaded = 0;
        quickPreviousItem = null;
        quickNextItem = null;
        previousPreviewDrawable = null;
        nextPreviewDrawable = null;

        final CancellationSignal seedSignal = new CancellationSignal();
        seedResolveSignal = seedSignal;
        safeExecute(scanExecutor, () -> {
            try {
                AppLog.d(this, "SIBLINGS locate begin +" + elapsed() + "ms seed=" + seedName + " mode=cursor-out");

                // Preserve the v0.1.17 win: for path-style launchers, a same-folder reopen
                // can hit the completed RAM index before any MediaStore seed query.
                String cachePath = inferRelativePathFromAnyUri(seedUri);
                if (cachePath != null && !cachePath.isEmpty()) {
                    if (!cachePath.endsWith("/")) cachePath += "/";
                    ArrayList<MediaItem> instantCache = getFolderCache(cachePath, sortField, sortAscending);
                    if (instantCache != null && publishFullList(generation, seedName, instantCache, "ram-cache-preseed", 0L)) {
                        progressiveListActive = false;
                        AppLog.d(this, "CURSOR RAM cache preseed hit +" + elapsed() + "ms found=" + instantCache.size());
                        return;
                    }
                }

                // v0.1.20 fast route: if the incoming URI exposes a real shared-storage path,
                // enumerate only lightweight file metadata directly. No MediaStore seed query.
                if (ENABLE_DIRECT_FILE_ENUM_EXPERIMENT &&
                        tryDirectFilesystemIndex(generation, seedUri, seedName, cachePath, sortField, sortAscending)) {
                    progressiveListActive = false;
                    return;
                }

                // Type order is extension-group order, not a MediaStore scalar column. If a direct
                // filesystem path is unavailable, build the folder list once and sort client-side.
                if (SortPrefs.FIELD_TYPE.equals(sortField) && cachePath != null && !cachePath.isEmpty()) {
                    final String typePath = cachePath.endsWith("/") ? cachePath : cachePath + "/";
                    progressiveListActive = false;
                    safeExecute(fullScanExecutor, () -> buildFullSiblingList(
                            generation, seedName, typePath, sortField, sortAscending));
                    return;
                }

                long started = SystemClock.elapsedRealtime();
                ResolvedSeed resolved = resolveIncomingSeed(seedUri, seedName, seedSignal);
                long took = SystemClock.elapsedRealtime() - started;
                if (generation != siblingGeneration.get() || seedSignal.isCanceled()) return;
                if (resolved == null || resolved.key == null || resolved.relativePath == null) {
                    progressiveListActive = false;
                    AppLog.d(this, "CURSOR seed unresolved +" + elapsed() + "ms took=" + took + "ms");
                    return;
                }
                String path = resolved.relativePath.endsWith("/") ? resolved.relativePath : resolved.relativePath + "/";
                AppLog.d(this, "CURSOR seed ready +" + elapsed() + "ms took=" + took + "ms strategy=" +
                        resolved.strategy + " path=" + path + " id=" + resolved.key.id);

                ArrayList<MediaItem> cached = getFolderCache(path, sortField, sortAscending);
                if (cached != null && publishFullList(generation, resolved.key.name, cached, "ram-cache", 0L)) {
                    progressiveListActive = false;
                    AppLog.d(this, "CURSOR RAM cache hit +" + elapsed() + "ms found=" + cached.size());
                    return;
                }

                if (SortPrefs.FIELD_TYPE.equals(sortField)) {
                    progressiveListActive = false;
                    safeExecute(fullScanExecutor, () -> buildFullSiblingList(
                            generation, resolved.key.name, path, sortField, sortAscending));
                    return;
                }

                String centerMime = resolved.mime != null ? resolved.mime : currentMime;
                MediaItem center = new MediaItem(
                        ContentUris.withAppendedId(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, resolved.key.id),
                        resolved.key.name, centerMime, resolved.key.size, resolved.key.created, resolved.key.modified);
                mainHandler.post(() -> {
                    if (generation != siblingGeneration.get() || isFinishing()) return;
                    siblings.clear();
                    siblings.add(center);
                    currentIndex = 0;
                    progressiveListActive = true;
                    updateProgressivePositionLabel();
                });

                AtomicInteger sidesDone = new AtomicInteger(0);
                CancellationSignal prevSignal = new CancellationSignal();
                CancellationSignal nextSignal = new CancellationSignal();
                previousCursorSignal = prevSignal;
                nextCursorSignal = nextSignal;
                safeExecute(neighborExecutor, () -> streamNeighborCursor(
                        generation, path, resolved.key, false, sortField, sortAscending, sidesDone, prevSignal));
                safeExecute(neighborExecutor, () -> streamNeighborCursor(
                        generation, path, resolved.key, true, sortField, sortAscending, sidesDone, nextSignal));
            } catch (android.os.OperationCanceledException ignored) {
                AppLog.d(this, "CURSOR seed canceled +" + elapsed() + "ms");
            } catch (Throwable e) {
                if (generation == siblingGeneration.get()) {
                    progressiveListActive = false;
                    AppLog.d(this, "CURSOR seed error +" + elapsed() + "ms " + e);
                }
            }
        });
    }

    private ResolvedSeed resolveIncomingSeed(Uri uri, String fallbackName, CancellationSignal signal) {
        if (uri == null) return null;

        // Fastest possible route: the launcher already gave us a MediaStore item URI.
        ResolvedSeed direct = tryResolveDirectMediaUri(uri, signal);
        if (direct != null) return direct;

        // Path-like providers (Solid Explorer, external-storage DocumentsProvider, etc.)
        // often encode enough location information in the URI itself. This needs no IPC.
        String inferredPath = inferRelativePathFromAnyUri(uri);
        String name = fallbackName;
        // If the URI itself already exposes the shared-storage path (Solid Explorer and many
        // DocumentsProvider URIs do), avoid another provider IPC and go straight to MediaStore.
        if (inferredPath != null && !inferredPath.isEmpty() && name != null && !name.isEmpty()) {
            ResolvedSeed byPath = queryExactSeedByPath(inferredPath, name, signal, "uri-path+name");
            if (byPath != null) return byPath;
        }

        IncomingMeta meta = readIncomingMeta(uri, signal);
        if (meta != null && meta.name != null && !meta.name.isEmpty()) name = meta.name;
        if ((inferredPath == null || inferredPath.isEmpty()) && meta != null) {
            if (meta.relativePath != null && !meta.relativePath.isEmpty()) inferredPath = meta.relativePath;
            else if (meta.rawPath != null) inferredPath = relativePathFromAbsolute(meta.rawPath);
        }
        if (inferredPath != null && !inferredPath.isEmpty() && name != null && !name.isEmpty()) {
            ResolvedSeed byPath = queryExactSeedByPath(inferredPath, name, signal, "provider-path+name");
            if (byPath != null) return byPath;
        }

        // Opaque provider URI: use metadata from the single granted file to narrow MediaStore.
        if (name != null && meta != null) {
            ResolvedSeed byMeta = querySeedByMetadata(name, meta.size, meta.modified, signal);
            if (byMeta != null) return byMeta;
        }

        // Last safe fallback: a unique display name in MediaStore. If ambiguous we refuse to
        // guess a folder, because a wrong sibling chain is worse than no chain.
        if (name != null && !name.isEmpty()) return queryUniqueSeedByName(name, signal);
        return null;
    }

    private ResolvedSeed tryResolveDirectMediaUri(Uri uri, CancellationSignal signal) {
        String authority = uri.getAuthority();
        if (authority == null || !authority.toLowerCase(Locale.ROOT).contains("media")) return null;
        String[] projection = new String[]{MediaStore.Images.Media._ID, MediaStore.Images.Media.DISPLAY_NAME,
                MediaStore.Images.Media.MIME_TYPE, MediaStore.Images.Media.SIZE,
                MediaStore.Images.Media.DATE_ADDED, MediaStore.Images.Media.DATE_MODIFIED, MediaStore.Images.Media.RELATIVE_PATH};
        try (Cursor c = getContentResolver().query(uri, projection, null, null, null, signal)) {
            if (c != null && c.moveToFirst()) return resolvedSeedFromCursor(c, "direct-media-uri");
        } catch (Throwable e) {
            if (!(e instanceof android.os.OperationCanceledException))
                AppLog.d(this, "URI direct media miss " + e.getClass().getSimpleName());
        }
        return null;
    }

    private IncomingMeta readIncomingMeta(Uri uri, CancellationSignal signal) {
        if (uri == null || !"content".equalsIgnoreCase(uri.getScheme())) return null;
        IncomingMeta out = new IncomingMeta();
        try (Cursor c = getContentResolver().query(uri, null, null, null, null, signal)) {
            if (c == null || !c.moveToFirst()) return out;
            int nameCol = findColumn(c, OpenableColumns.DISPLAY_NAME, MediaStore.MediaColumns.DISPLAY_NAME,
                    "display_name", "name", "_display_name");
            int sizeCol = findColumn(c, OpenableColumns.SIZE, MediaStore.MediaColumns.SIZE, "size", "_size");
            int modifiedCol = findColumn(c, MediaStore.MediaColumns.DATE_MODIFIED,
                    "last_modified", "date_modified", "modified", "mtime");
            int relativeCol = findColumn(c, MediaStore.MediaColumns.RELATIVE_PATH, "relative_path");
            int dataCol = findColumn(c, "_data", "data", "path", "file_path");
            if (nameCol >= 0 && !c.isNull(nameCol)) out.name = c.getString(nameCol);
            if (sizeCol >= 0 && !c.isNull(sizeCol)) out.size = c.getLong(sizeCol);
            if (modifiedCol >= 0 && !c.isNull(modifiedCol)) out.modified = c.getLong(modifiedCol);
            if (relativeCol >= 0 && !c.isNull(relativeCol)) out.relativePath = c.getString(relativeCol);
            if (dataCol >= 0 && !c.isNull(dataCol)) out.rawPath = c.getString(dataCol);
            AppLog.d(this, "URI meta authority=" + uri.getAuthority() + " cols=" + Arrays.toString(c.getColumnNames()) +
                    " name=" + out.name + " size=" + out.size + " modified=" + out.modified +
                    " rel=" + out.relativePath + " raw=" + (out.rawPath != null));
        } catch (Throwable e) {
            if (!(e instanceof android.os.OperationCanceledException))
                AppLog.d(this, "URI meta unavailable authority=" + uri.getAuthority() + " " + e.getClass().getSimpleName());
        }
        return out;
    }

    private String inferRelativePathFromAnyUri(Uri uri) {
        if (uri == null) return null;
        try {
            String raw = Uri.decode(uri.getPath());
            if (raw != null) {
                String absoluteRelative = relativePathFromAbsolute(raw);
                if (absoluteRelative != null) return absoluteRelative;
                int primary = raw.indexOf("primary:");
                if (primary >= 0) {
                    String relativeFile = raw.substring(primary + "primary:".length());
                    int slash = relativeFile.lastIndexOf('/');
                    if (slash >= 0) return relativeFile.substring(0, slash + 1);
                }
            }
            if (Build.VERSION.SDK_INT >= 19 && DocumentsContract.isDocumentUri(this, uri)) {
                String docId = DocumentsContract.getDocumentId(uri);
                if (docId != null) {
                    if (docId.startsWith("primary:")) {
                        String relativeFile = docId.substring("primary:".length());
                        int slash = relativeFile.lastIndexOf('/');
                        if (slash >= 0) return relativeFile.substring(0, slash + 1);
                    }
                    if (docId.startsWith("raw:")) return relativePathFromAbsolute(docId.substring(4));
                }
            }
        } catch (Throwable e) {
            AppLog.d(this, "URI path inference miss " + e.getClass().getSimpleName());
        }
        return null;
    }

    private String relativePathFromAbsolute(String absolute) {
        if (absolute == null) return null;
        String[] markers = new String[]{"/storage/emulated/0/", "/storage/self/primary/", "/sdcard/"};
        for (String marker : markers) {
            int idx = absolute.indexOf(marker);
            if (idx < 0) continue;
            String relativeFile = absolute.substring(idx + marker.length());
            int slash = relativeFile.lastIndexOf('/');
            if (slash >= 0) return relativeFile.substring(0, slash + 1);
        }
        return null;
    }

    private ResolvedSeed queryExactSeedByPath(String relativePath, String name,
                                               CancellationSignal signal, String strategy) {
        if (!relativePath.endsWith("/")) relativePath += "/";
        String selection = MediaStore.Images.Media.RELATIVE_PATH + "=? AND " +
                MediaStore.Images.Media.DISPLAY_NAME + "=? COLLATE NOCASE";
        return querySingleResolvedSeed(selection, new String[]{relativePath, name}, signal, strategy);
    }

    private ResolvedSeed querySeedByMetadata(String name, long size, long providerModified,
                                             CancellationSignal signal) {
        String selection;
        String[] args;
        if (size >= 0) {
            selection = MediaStore.Images.Media.DISPLAY_NAME + "=? COLLATE NOCASE AND " +
                    MediaStore.Images.Media.SIZE + "=?";
            args = new String[]{name, Long.toString(size)};
        } else {
            return null;
        }
        ArrayList<ResolvedSeed> candidates = queryResolvedSeeds(selection, args, signal, 8);
        if (candidates.size() == 1) {
            ResolvedSeed r = candidates.get(0);
            return new ResolvedSeed(r.relativePath, r.key, r.mime, "name+size");
        }
        if (candidates.size() > 1 && providerModified >= 0) {
            long seconds = providerModified > 100000000000L ? providerModified / 1000L : providerModified;
            ResolvedSeed best = null;
            long bestDelta = Long.MAX_VALUE;
            for (ResolvedSeed r : candidates) {
                long delta = Math.abs(r.key.modified - seconds);
                if (delta < bestDelta) { bestDelta = delta; best = r; }
            }
            if (best != null && bestDelta <= 2L)
                return new ResolvedSeed(best.relativePath, best.key, best.mime, "name+size+modified");
        }
        if (candidates.size() > 1) AppLog.d(this, "URI metadata ambiguous name=" + name + " matches=" + candidates.size());
        return null;
    }

    private ResolvedSeed queryUniqueSeedByName(String name, CancellationSignal signal) {
        ArrayList<ResolvedSeed> candidates = queryResolvedSeeds(
                MediaStore.Images.Media.DISPLAY_NAME + "=? COLLATE NOCASE", new String[]{name}, signal, 2);
        if (candidates.size() == 1) {
            ResolvedSeed r = candidates.get(0);
            return new ResolvedSeed(r.relativePath, r.key, r.mime, "unique-name");
        }
        if (candidates.size() > 1) AppLog.d(this, "URI name ambiguous name=" + name);
        return null;
    }

    private ResolvedSeed querySingleResolvedSeed(String selection, String[] args,
                                                 CancellationSignal signal, String strategy) {
        ArrayList<ResolvedSeed> rows = queryResolvedSeeds(selection, args, signal, 1);
        if (rows.isEmpty()) return null;
        ResolvedSeed r = rows.get(0);
        return new ResolvedSeed(r.relativePath, r.key, r.mime, strategy);
    }

    private ArrayList<ResolvedSeed> queryResolvedSeeds(String selection, String[] args,
                                                       CancellationSignal signal, int limit) {
        ArrayList<ResolvedSeed> rows = new ArrayList<>();
        String[] projection = new String[]{MediaStore.Images.Media._ID, MediaStore.Images.Media.DISPLAY_NAME,
                MediaStore.Images.Media.MIME_TYPE, MediaStore.Images.Media.SIZE,
                MediaStore.Images.Media.DATE_ADDED, MediaStore.Images.Media.DATE_MODIFIED, MediaStore.Images.Media.RELATIVE_PATH};
        Bundle queryArgs = new Bundle();
        queryArgs.putString(ContentResolver.QUERY_ARG_SQL_SELECTION, selection);
        queryArgs.putStringArray(ContentResolver.QUERY_ARG_SQL_SELECTION_ARGS, args);
        queryArgs.putString(ContentResolver.QUERY_ARG_SQL_SORT_ORDER, MediaStore.Images.Media._ID + " ASC");
        queryArgs.putInt(ContentResolver.QUERY_ARG_LIMIT, Math.max(1, limit));
        try (Cursor c = getContentResolver().query(MediaStore.Images.Media.EXTERNAL_CONTENT_URI,
                projection, queryArgs, signal)) {
            while (c != null && c.moveToNext() && rows.size() < limit) {
                ResolvedSeed r = resolvedSeedFromCursor(c, "candidate");
                if (r != null) rows.add(r);
            }
        } catch (Throwable e) {
            if (!(e instanceof android.os.OperationCanceledException))
                AppLog.d(this, "URI MediaStore resolver error " + e);
        }
        return rows;
    }

    private ResolvedSeed resolvedSeedFromCursor(Cursor c, String strategy) {
        if (c == null) return null;
        int idCol = c.getColumnIndex(MediaStore.Images.Media._ID);
        int nameCol = c.getColumnIndex(MediaStore.Images.Media.DISPLAY_NAME);
        int mimeCol = c.getColumnIndex(MediaStore.Images.Media.MIME_TYPE);
        int sizeCol = c.getColumnIndex(MediaStore.Images.Media.SIZE);
        int createdCol = c.getColumnIndex(MediaStore.Images.Media.DATE_ADDED);
        int modifiedCol = c.getColumnIndex(MediaStore.Images.Media.DATE_MODIFIED);
        int pathCol = c.getColumnIndex(MediaStore.Images.Media.RELATIVE_PATH);
        if (idCol < 0 || nameCol < 0 || pathCol < 0) return null;
        long id = c.getLong(idCol);
        String name = c.getString(nameCol);
        long size = sizeCol >= 0 && !c.isNull(sizeCol) ? c.getLong(sizeCol) : 0L;
        long created = createdCol >= 0 && !c.isNull(createdCol) ? c.getLong(createdCol) : 0L;
        long modified = modifiedCol >= 0 && !c.isNull(modifiedCol) ? c.getLong(modifiedCol) : 0L;
        String mime = mimeCol >= 0 && !c.isNull(mimeCol) ? c.getString(mimeCol) : mimeFromName(name);
        String path = c.getString(pathCol);
        return new ResolvedSeed(path, new SeedSortKey(id, name, size, created, modified), mime, strategy);
    }

    private void streamNeighborCursor(int generation, String path, SeedSortKey seedKey, boolean next,
                                      String field, boolean ascending, AtomicInteger sidesDone,
                                      CancellationSignal signal) {
        long openedAt = SystemClock.elapsedRealtime();
        int total = 0;
        try (Cursor c = openNeighborCursor(path, seedKey, next, field, ascending, signal)) {
            long openMs = SystemClock.elapsedRealtime() - openedAt;
            if (generation != siblingGeneration.get() || signal.isCanceled()) return;
            AppLog.d(this, "CURSOR " + (next ? "next" : "prev") + " opened +" + elapsed() +
                    "ms took=" + openMs + "ms");
            if (c == null) {
                markCursorSideComplete(generation, next, path, field, ascending, sidesDone, 0);
                return;
            }
            ArrayList<MediaItem> chunk = new ArrayList<>(CURSOR_MERGE_CHUNK_SIZE);
            while (generation == siblingGeneration.get() && !signal.isCanceled() && c.moveToNext()) {
                MediaItem item = mediaItemFromCurrentCursorRow(c);
                if (item != null) {
                    total++;
                    if (total == 1) {
                        // Publish the actual adjacent item immediately; do not wait for a 24-row
                        // UI batch before allowing the first swipe on this side.
                        ArrayList<MediaItem> adjacent = new ArrayList<>(1);
                        adjacent.add(item);
                        mergeProgressiveBatch(generation, adjacent, next);
                    } else {
                        chunk.add(item);
                    }
                }
                if (chunk.size() >= CURSOR_MERGE_CHUNK_SIZE) {
                    mergeProgressiveBatch(generation, chunk, next);
                    chunk = new ArrayList<>(CURSOR_MERGE_CHUNK_SIZE);
                }
            }
            if (!chunk.isEmpty()) mergeProgressiveBatch(generation, chunk, next);
            if (generation == siblingGeneration.get() && !signal.isCanceled())
                markCursorSideComplete(generation, next, path, field, ascending, sidesDone, total);
        } catch (android.os.OperationCanceledException ignored) {
            AppLog.d(this, "CURSOR " + (next ? "next" : "prev") + " canceled +" + elapsed() + "ms");
        } catch (Throwable e) {
            if (generation == siblingGeneration.get()) {
                AppLog.d(this, "CURSOR " + (next ? "next" : "prev") + " error " + e);
                markCursorSideComplete(generation, next, path, field, ascending, sidesDone, total);
            }
        }
    }

    private Cursor openNeighborCursor(String relativePath, SeedSortKey anchor, boolean next,
                                      String field, boolean ascending, CancellationSignal signal) {
        String[] projection = new String[]{MediaStore.Images.Media._ID, MediaStore.Images.Media.DISPLAY_NAME,
                MediaStore.Images.Media.MIME_TYPE, MediaStore.Images.Media.SIZE,
                MediaStore.Images.Media.DATE_ADDED, MediaStore.Images.Media.DATE_MODIFIED};
        boolean outwardAscending = next == ascending;
        String cmp = outwardAscending ? ">" : "<";
        String order = outwardAscending ? " ASC" : " DESC";
        String selection;
        String[] args;
        String sort;
        if (SortPrefs.FIELD_NAME.equals(field)) {
            selection = MediaStore.Images.Media.RELATIVE_PATH + "=? AND ((" +
                    MediaStore.Images.Media.DISPLAY_NAME + " COLLATE NOCASE " + cmp + " ?) OR (" +
                    MediaStore.Images.Media.DISPLAY_NAME + " = ? COLLATE NOCASE AND " +
                    MediaStore.Images.Media._ID + " " + cmp + " ?))";
            args = new String[]{relativePath, anchor.name, anchor.name, Long.toString(anchor.id)};
            sort = MediaStore.Images.Media.DISPLAY_NAME + " COLLATE NOCASE" + order + ", " +
                    MediaStore.Images.Media._ID + order;
        } else {
            String col = SortPrefs.sqlColumn(field);
            long value = SortPrefs.FIELD_SIZE.equals(field) ? anchor.size : (SortPrefs.FIELD_CREATED.equals(field) ? anchor.created : anchor.modified);
            selection = MediaStore.Images.Media.RELATIVE_PATH + "=? AND ((" + col + " " + cmp + " ?) OR (" +
                    col + "=? AND " + MediaStore.Images.Media._ID + " " + cmp + " ?))";
            args = new String[]{relativePath, Long.toString(value), Long.toString(value), Long.toString(anchor.id)};
            sort = col + order + ", " + MediaStore.Images.Media._ID + order;
        }
        Bundle queryArgs = new Bundle();
        queryArgs.putString(ContentResolver.QUERY_ARG_SQL_SELECTION, selection);
        queryArgs.putStringArray(ContentResolver.QUERY_ARG_SQL_SELECTION_ARGS, args);
        queryArgs.putString(ContentResolver.QUERY_ARG_SQL_SORT_ORDER, sort);
        // Deliberately no QUERY_ARG_LIMIT: one ordered cursor per side replaces dozens of
        // LIMIT-24 queries. CursorWindow streams the rows as they are consumed.
        return getContentResolver().query(MediaStore.Images.Media.EXTERNAL_CONTENT_URI,
                projection, queryArgs, signal);
    }

    private MediaItem mediaItemFromCurrentCursorRow(Cursor c) {
        int idCol = c.getColumnIndex(MediaStore.Images.Media._ID);
        int nameCol = c.getColumnIndex(MediaStore.Images.Media.DISPLAY_NAME);
        int mimeCol = c.getColumnIndex(MediaStore.Images.Media.MIME_TYPE);
        int sizeCol = c.getColumnIndex(MediaStore.Images.Media.SIZE);
        int createdCol = c.getColumnIndex(MediaStore.Images.Media.DATE_ADDED);
        int modifiedCol = c.getColumnIndex(MediaStore.Images.Media.DATE_MODIFIED);
        if (idCol < 0 || nameCol < 0) return null;
        long id = c.getLong(idCol);
        String name = c.getString(nameCol);
        String mime = mimeCol >= 0 && !c.isNull(mimeCol) ? c.getString(mimeCol) : mimeFromName(name);
        long size = sizeCol >= 0 && !c.isNull(sizeCol) ? c.getLong(sizeCol) : 0L;
        long created = createdCol >= 0 && !c.isNull(createdCol) ? c.getLong(createdCol) : 0L;
        long modified = modifiedCol >= 0 && !c.isNull(modifiedCol) ? c.getLong(modifiedCol) : 0L;
        return new MediaItem(ContentUris.withAppendedId(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, id),
                name, mime, size, created, modified);
    }

    private void markCursorSideComplete(int generation, boolean next, String path, String field,
                                        boolean ascending, AtomicInteger sidesDone, int total) {
        mainHandler.post(() -> {
            if (generation != siblingGeneration.get() || isFinishing()) return;
            if (next) progressiveNextComplete = true; else progressivePrevComplete = true;
            updateProgressivePositionLabel();
            AppLog.d(this, "CURSOR side complete +" + elapsed() + "ms side=" + (next ? "next" : "prev") +
                    " rows=" + total + " prevLoaded=" + progressivePrevLoaded + " nextLoaded=" + progressiveNextLoaded);
            if (sidesDone.incrementAndGet() == 2) {
                fullListReady = true;
                progressiveListActive = false;
                putFolderCache(path, field, ascending, siblings);
                AppLog.d(this, "CURSOR full ready +" + elapsed() + "ms found=" + siblings.size() +
                        " currentIndex=" + currentIndex);
                updatePositionLabel();
                prefetchAdjacent();
            }
        });
    }

    private void cancelSiblingQuerySignals() {
        CancellationSignal a = seedResolveSignal;
        CancellationSignal b = previousCursorSignal;
        CancellationSignal c = nextCursorSignal;
        seedResolveSignal = null;
        previousCursorSignal = null;
        nextCursorSignal = null;
        try { if (a != null && !a.isCanceled()) a.cancel(); } catch (Throwable ignored) { }
        try { if (b != null && !b.isCanceled()) b.cancel(); } catch (Throwable ignored) { }
        try { if (c != null && !c.isCanceled()) c.cancel(); } catch (Throwable ignored) { }
    }

    // Exact v0.1.16-style path retained for one-flag rollback.
    private void discoverSiblingImagesLegacy() {
        final int generation = siblingGeneration.incrementAndGet();
        final int prefetchToken = prefetchGeneration.incrementAndGet();
        final Uri seedUri = currentUri;
        final String seedName = currentName;
        final String sortField = SortPrefs.field(this);
        final boolean sortAscending = SortPrefs.ascending(this);

        fullListReady = false;
        quickPreviousItem = null; quickNextItem = null;
        previousPreviewDrawable = null; nextPreviewDrawable = null;

        safeExecute(scanExecutor, () -> {
            try {
                AppLog.d(this, "SIBLINGS locate begin +" + elapsed() + "ms seed=" + seedName + " mode=legacy");
                String relativePath = resolveRelativePath(seedUri);
                if (generation != siblingGeneration.get()) return;
                if (relativePath == null || relativePath.isEmpty()) return;
                if (!relativePath.endsWith("/")) relativePath += "/";
                final String path = relativePath;
                final SeedSortKey seedKey = lookupSeedSortKey(path, seedName);
                if (generation != siblingGeneration.get()) return;
                if (seedKey == null) {
                    safeExecute(scanExecutor, () -> buildFullSiblingList(generation, seedName, path, sortField, sortAscending));
                    return;
                }
                final AtomicInteger remaining = new AtomicInteger(2);
                final AtomicReference<MediaItem> prevRef = new AtomicReference<>();
                final AtomicReference<MediaItem> nextRef = new AtomicReference<>();
                Runnable done = () -> {
                    if (remaining.decrementAndGet() == 0 && generation == siblingGeneration.get()) {
                        publishQuickPair(generation, prevRef.get(), nextRef.get(), prefetchToken, "media-legacy");
                        safeExecute(scanExecutor, () -> buildFullSiblingList(generation, seedName, path, sortField, sortAscending));
                    }
                };
                safeExecute(neighborExecutor, () -> { try { prevRef.set(queryNeighbor(path, seedKey, false, sortField, sortAscending)); } finally { done.run(); } });
                safeExecute(neighborExecutor, () -> { try { nextRef.set(queryNeighbor(path, seedKey, true, sortField, sortAscending)); } finally { done.run(); } });
            } catch (Throwable e) { AppLog.d(this, "SIBLINGS legacy error +" + elapsed() + "ms " + e); }
        });
    }

    private void discoverSiblingImagesExperimental() {
        final int generation = siblingGeneration.incrementAndGet();
        final int prefetchToken = prefetchGeneration.incrementAndGet();
        final Uri seedUri = currentUri;
        final String seedName = currentName;
        final String sortField = SortPrefs.field(this);
        final boolean sortAscending = SortPrefs.ascending(this);

        fullListReady = false;
        quickPreviousItem = null; quickNextItem = null;
        previousPreviewDrawable = null; nextPreviewDrawable = null;

        safeExecute(scanExecutor, () -> {
            try {
                AppLog.d(this, "SIBLINGS locate begin +" + elapsed() + "ms seed=" + seedName + " mode=external-race");
                String relativePath = resolveRelativePath(seedUri);
                if (generation != siblingGeneration.get()) return;
                if (relativePath == null || relativePath.isEmpty()) {
                    AppLog.d(this, "SIBLINGS no relative path +" + elapsed() + "ms");
                    return;
                }
                if (!relativePath.endsWith("/")) relativePath += "/";
                final String path = relativePath;
                AppLog.d(this, "SIBLINGS path=" + path + " +" + elapsed() + "ms race=cache/provider/full/neighbor");

                // 0) Process-memory cache. Reopening another image from the same folder/order
                // can become swipe-ready without touching MediaStore at all.
                ArrayList<MediaItem> cached = getFolderCache(path, sortField, sortAscending);
                if (cached != null && publishFullList(generation, seedName, cached, "ram-cache", 0L)) {
                    AppLog.d(this, "SIBLINGS RAM cache hit +" + elapsed() + "ms found=" + cached.size());
                    return;
                }

                // 1) Solid Explorer (or another path-style provider) parent-URI directory query.
                // It is fully isolated; failure never blocks the standard MediaStore paths.
                safeExecute(providerDirectoryExecutor, () -> tryProviderDirectoryFastPath(
                        generation, prefetchToken, seedUri, seedName, path, sortField, sortAscending));

                // 2) Full minimal MediaStore index starts immediately, instead of waiting for
                // seed lookup / neighbor queries. Logs showed this can beat LIMIT-1 on some runs.
                safeExecute(fullScanExecutor, () -> buildFullSiblingList(
                        generation, seedName, path, sortField, sortAscending));

                // 3) Existing selected-order previous/next MediaStore queries run in parallel.
                // This remains useful when the folder is huge but the indexed comparison is cheap.
                final long seedLookupStarted = SystemClock.elapsedRealtime();
                final SeedSortKey seedKey = lookupSeedSortKey(path, seedName);
                AppLog.d(this, "SIBLINGS seed lookup +" + elapsed() + "ms took=" +
                        (SystemClock.elapsedRealtime() - seedLookupStarted) + "ms ready=" + (seedKey != null));
                if (generation != siblingGeneration.get() || seedKey == null) return;

                final AtomicInteger remaining = new AtomicInteger(2);
                final AtomicReference<MediaItem> prevRef = new AtomicReference<>();
                final AtomicReference<MediaItem> nextRef = new AtomicReference<>();
                Runnable done = () -> {
                    if (remaining.decrementAndGet() == 0 && generation == siblingGeneration.get()) {
                        publishQuickPair(generation, prevRef.get(), nextRef.get(), prefetchToken, "media-neighbor");
                    }
                };
                safeExecute(neighborExecutor, () -> { try { prevRef.set(queryNeighbor(path, seedKey, false, sortField, sortAscending)); } finally { done.run(); } });
                safeExecute(neighborExecutor, () -> { try { nextRef.set(queryNeighbor(path, seedKey, true, sortField, sortAscending)); } finally { done.run(); } });
            } catch (Throwable e) { AppLog.d(this, "SIBLINGS experimental error +" + elapsed() + "ms " + e); }
        });
    }

    /**
     * v0.1.18: no full-folder scan is on the critical path. Resolve the tapped MediaStore
     * row once, then grow two keyset-paginated chains outward in the selected slide order:
     * -1/+1, then farther previous/next items. Each batch becomes swipeable immediately.
     */
    private void discoverSiblingImagesCenterOut() {
        final int generation = siblingGeneration.incrementAndGet();
        prefetchGeneration.incrementAndGet();
        final Uri seedUri = currentUri;
        final String seedName = currentName;
        final String sortField = SortPrefs.field(this);
        final boolean sortAscending = SortPrefs.ascending(this);

        fullListReady = false;
        progressiveListActive = true;
        progressivePrevComplete = false;
        progressiveNextComplete = false;
        progressivePrevLoaded = 0;
        progressiveNextLoaded = 0;
        quickPreviousItem = null; quickNextItem = null;
        previousPreviewDrawable = null; nextPreviewDrawable = null;

        safeExecute(scanExecutor, () -> {
            try {
                AppLog.d(this, "SIBLINGS locate begin +" + elapsed() + "ms seed=" + seedName + " mode=center-out");
                String relativePath = resolveRelativePath(seedUri);
                if (generation != siblingGeneration.get()) return;
                if (relativePath == null || relativePath.isEmpty()) {
                    AppLog.d(this, "CENTER no relative path +" + elapsed() + "ms");
                    return;
                }
                if (!relativePath.endsWith("/")) relativePath += "/";
                final String path = relativePath;

                ArrayList<MediaItem> cached = getFolderCache(path, sortField, sortAscending);
                if (cached != null && publishFullList(generation, seedName, cached, "ram-cache", 0L)) {
                    progressiveListActive = false;
                    AppLog.d(this, "CENTER RAM cache hit +" + elapsed() + "ms found=" + cached.size());
                    return;
                }

                long seedStarted = SystemClock.elapsedRealtime();
                SeedSortKey seedKey = lookupSeedSortKeyFast(path, seedName);
                AppLog.d(this, "CENTER seed ready +" + elapsed() + "ms took=" +
                        (SystemClock.elapsedRealtime() - seedStarted) + "ms ready=" + (seedKey != null));
                if (generation != siblingGeneration.get() || seedKey == null) {
                    progressiveListActive = false;
                    return;
                }

                MediaItem center = new MediaItem(
                        ContentUris.withAppendedId(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, seedKey.id),
                        seedKey.name, currentMime, seedKey.size, seedKey.created, seedKey.modified);
                mainHandler.post(() -> {
                    if (generation != siblingGeneration.get() || isFinishing()) return;
                    siblings.clear();
                    siblings.add(center);
                    currentIndex = 0;
                    progressiveListActive = true;
                    updateProgressivePositionLabel();
                });

                AtomicInteger sidesDone = new AtomicInteger(0);
                safeExecute(neighborExecutor, () -> expandCenterOutSide(
                        generation, path, seedKey, false, sortField, sortAscending, sidesDone));
                safeExecute(neighborExecutor, () -> expandCenterOutSide(
                        generation, path, seedKey, true, sortField, sortAscending, sidesDone));
            } catch (Throwable e) {
                progressiveListActive = false;
                AppLog.d(this, "CENTER error +" + elapsed() + "ms " + e);
            }
        });
    }

    private SeedSortKey lookupSeedSortKeyFast(String relativePath, String seedName) {
        String[] projection = new String[]{MediaStore.Images.Media._ID, MediaStore.Images.Media.DISPLAY_NAME,
                MediaStore.Images.Media.SIZE, MediaStore.Images.Media.DATE_ADDED, MediaStore.Images.Media.DATE_MODIFIED};
        String selection = MediaStore.Images.Media.RELATIVE_PATH + "=? AND " +
                MediaStore.Images.Media.DISPLAY_NAME + "=? COLLATE NOCASE";
        String[] args = new String[]{relativePath, seedName};
        try {
            Bundle queryArgs = new Bundle();
            queryArgs.putString(ContentResolver.QUERY_ARG_SQL_SELECTION, selection);
            queryArgs.putStringArray(ContentResolver.QUERY_ARG_SQL_SELECTION_ARGS, args);
            queryArgs.putString(ContentResolver.QUERY_ARG_SQL_SORT_ORDER, MediaStore.Images.Media._ID + " ASC");
            queryArgs.putInt(ContentResolver.QUERY_ARG_LIMIT, 1);
            try (Cursor c = getContentResolver().query(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, projection, queryArgs, null)) {
                if (c != null && c.moveToFirst()) {
                    return new SeedSortKey(
                            c.getLong(c.getColumnIndexOrThrow(MediaStore.Images.Media._ID)),
                            c.getString(c.getColumnIndexOrThrow(MediaStore.Images.Media.DISPLAY_NAME)),
                            c.getLong(c.getColumnIndexOrThrow(MediaStore.Images.Media.SIZE)),
                            c.getLong(c.getColumnIndexOrThrow(MediaStore.Images.Media.DATE_ADDED)),
                            c.getLong(c.getColumnIndexOrThrow(MediaStore.Images.Media.DATE_MODIFIED)));
                }
            }
        } catch (Throwable e) {
            AppLog.d(this, "CENTER seed bundle error " + e);
        }
        return lookupSeedSortKey(relativePath, seedName);
    }

    private void expandCenterOutSide(int generation, String path, SeedSortKey seedKey, boolean next,
                                     String field, boolean ascending, AtomicInteger sidesDone) {
        SeedSortKey anchor = seedKey;
        int batchNo = 0;
        try {
            while (generation == siblingGeneration.get() && !Thread.currentThread().isInterrupted()) {
                long started = SystemClock.elapsedRealtime();
                ArrayList<MediaItem> batch = queryNeighborBatch(path, anchor, next, field, ascending, CENTER_OUT_BATCH_SIZE);
                long took = SystemClock.elapsedRealtime() - started;
                batchNo++;
                AppLog.d(this, "CENTER " + (next ? "next" : "prev") + " batch=" + batchNo +
                        " took=" + took + "ms found=" + batch.size());
                if (batch.isEmpty()) {
                    markCenterOutSideComplete(generation, next, path, field, ascending, sidesDone);
                    return;
                }
                mergeProgressiveBatch(generation, batch, next);
                MediaItem farthest = batch.get(batch.size() - 1);
                anchor = seedKeyFromMediaItem(farthest);
                if (anchor == null || batch.size() < CENTER_OUT_BATCH_SIZE) {
                    markCenterOutSideComplete(generation, next, path, field, ascending, sidesDone);
                    return;
                }
                // Let image decoding and UI work breathe between metadata batches.
                try { Thread.sleep(8L); } catch (InterruptedException e) { Thread.currentThread().interrupt(); return; }
            }
        } catch (Throwable e) {
            AppLog.d(this, "CENTER " + (next ? "next" : "prev") + " error " + e);
            markCenterOutSideComplete(generation, next, path, field, ascending, sidesDone);
        }
    }

    private SeedSortKey seedKeyFromMediaItem(MediaItem item) {
        if (item == null || item.uri == null) return null;
        try {
            long id = ContentUris.parseId(item.uri);
            return new SeedSortKey(id, item.name, item.size, item.created, item.modified);
        } catch (Throwable e) {
            AppLog.d(this, "CENTER anchor id error " + e);
            return null;
        }
    }

    private ArrayList<MediaItem> queryNeighborBatch(String relativePath, SeedSortKey anchor, boolean next,
                                                     String field, boolean ascending, int limit) {
        ArrayList<MediaItem> out = new ArrayList<>();
        if (anchor == null) return out;
        String[] projection = new String[]{MediaStore.Images.Media._ID, MediaStore.Images.Media.DISPLAY_NAME,
                MediaStore.Images.Media.MIME_TYPE, MediaStore.Images.Media.SIZE, MediaStore.Images.Media.DATE_ADDED, MediaStore.Images.Media.DATE_MODIFIED};
        boolean forwardAscending = next == ascending;
        String cmp = forwardAscending ? ">" : "<";
        String order = forwardAscending ? " ASC" : " DESC";
        String selection;
        String[] args;
        String sort;
        if (SortPrefs.FIELD_NAME.equals(field)) {
            selection = MediaStore.Images.Media.RELATIVE_PATH + "=? AND ((" +
                    MediaStore.Images.Media.DISPLAY_NAME + " COLLATE NOCASE " + cmp + " ?) OR (" +
                    MediaStore.Images.Media.DISPLAY_NAME + " = ? COLLATE NOCASE AND " +
                    MediaStore.Images.Media._ID + " " + cmp + " ?))";
            args = new String[]{relativePath, anchor.name, anchor.name, Long.toString(anchor.id)};
            sort = MediaStore.Images.Media.DISPLAY_NAME + " COLLATE NOCASE" + order + ", " +
                    MediaStore.Images.Media._ID + order;
        } else {
            String col = SortPrefs.sqlColumn(field);
            long value = SortPrefs.FIELD_SIZE.equals(field) ? anchor.size : (SortPrefs.FIELD_CREATED.equals(field) ? anchor.created : anchor.modified);
            selection = MediaStore.Images.Media.RELATIVE_PATH + "=? AND ((" + col + " " + cmp + " ?) OR (" +
                    col + "=? AND " + MediaStore.Images.Media._ID + " " + cmp + " ?))";
            args = new String[]{relativePath, Long.toString(value), Long.toString(value), Long.toString(anchor.id)};
            sort = col + order + ", " + MediaStore.Images.Media._ID + order;
        }
        try {
            Bundle queryArgs = new Bundle();
            queryArgs.putString(ContentResolver.QUERY_ARG_SQL_SELECTION, selection);
            queryArgs.putStringArray(ContentResolver.QUERY_ARG_SQL_SELECTION_ARGS, args);
            queryArgs.putString(ContentResolver.QUERY_ARG_SQL_SORT_ORDER, sort);
            queryArgs.putInt(ContentResolver.QUERY_ARG_LIMIT, limit);
            try (Cursor c = getContentResolver().query(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, projection, queryArgs, null)) {
                appendMediaItemsFromCursor(c, out, limit);
            }
        } catch (Throwable bundleError) {
            AppLog.d(this, "CENTER batch bundle error " + bundleError);
            try (Cursor c = getContentResolver().query(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, projection, selection, args, sort)) {
                appendMediaItemsFromCursor(c, out, limit);
            } catch (Throwable fallbackError) {
                AppLog.d(this, "CENTER batch fallback error " + fallbackError);
            }
        }
        return out;
    }

    private void appendMediaItemsFromCursor(Cursor c, ArrayList<MediaItem> out, int limit) {
        if (c == null) return;
        int idCol = c.getColumnIndexOrThrow(MediaStore.Images.Media._ID);
        int nameCol = c.getColumnIndexOrThrow(MediaStore.Images.Media.DISPLAY_NAME);
        int mimeCol = c.getColumnIndexOrThrow(MediaStore.Images.Media.MIME_TYPE);
        int sizeCol = c.getColumnIndexOrThrow(MediaStore.Images.Media.SIZE);
        int createdCol = c.getColumnIndexOrThrow(MediaStore.Images.Media.DATE_ADDED);
        int modifiedCol = c.getColumnIndexOrThrow(MediaStore.Images.Media.DATE_MODIFIED);
        while (out.size() < limit && c.moveToNext()) {
            long id = c.getLong(idCol);
            out.add(new MediaItem(ContentUris.withAppendedId(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, id),
                    c.getString(nameCol), c.getString(mimeCol), c.getLong(sizeCol), c.getLong(createdCol), c.getLong(modifiedCol)));
        }
    }

    private void mergeProgressiveBatch(int generation, ArrayList<MediaItem> batch, boolean next) {
        if (batch == null || batch.isEmpty()) return;
        final ArrayList<MediaItem> copy = new ArrayList<>(batch);
        mainHandler.post(() -> {
            if (generation != siblingGeneration.get() || isFinishing() || !progressiveListActive) return;
            boolean wasAtExpandingEdge = next ? currentIndex == siblings.size() - 1 : currentIndex == 0;
            if (next) {
                siblings.addAll(copy);
                progressiveNextLoaded += copy.size();
            } else {
                ArrayList<MediaItem> ordered = new ArrayList<>(copy);
                Collections.reverse(ordered);
                siblings.addAll(0, ordered);
                currentIndex += ordered.size();
                progressivePrevLoaded += ordered.size();
            }
            AppLog.d(this, "CENTER merge +" + elapsed() + "ms side=" + (next ? "next" : "prev") +
                    " loaded=" + siblings.size() + " currentWindowIndex=" + currentIndex);
            updateProgressivePositionLabel();
            // Do not restart preview decoding for every far-away metadata batch. Only when
            // this batch actually created a new adjacent page at the user's current edge.
            if (wasAtExpandingEdge) prefetchAdjacent();
        });
    }

    private void markCenterOutSideComplete(int generation, boolean next, String path, String field,
                                           boolean ascending, AtomicInteger sidesDone) {
        mainHandler.post(() -> {
            if (generation != siblingGeneration.get() || isFinishing()) return;
            if (next) progressiveNextComplete = true; else progressivePrevComplete = true;
            updateProgressivePositionLabel();
            AppLog.d(this, "CENTER side complete +" + elapsed() + "ms side=" + (next ? "next" : "prev") +
                    " prevLoaded=" + progressivePrevLoaded + " nextLoaded=" + progressiveNextLoaded);
            if (sidesDone.incrementAndGet() == 2) {
                fullListReady = true;
                progressiveListActive = false;
                putFolderCache(path, field, ascending, siblings);
                AppLog.d(this, "CENTER full ready +" + elapsed() + "ms found=" + siblings.size() +
                        " currentIndex=" + currentIndex);
                updatePositionLabel();
                prefetchAdjacent();
            }
        });
    }

    private void updateProgressivePositionLabel() {
        updatePositionLabel();
    }

    private void publishQuickPair(int generation, MediaItem prev, MediaItem next, int prefetchToken, String source) {
        mainHandler.post(() -> {
            if (generation != siblingGeneration.get() || isFinishing() || fullListReady) return;
            quickPreviousItem = prev;
            quickNextItem = next;
            AppLog.d(this, "SIBLINGS quick pair +" + elapsed() + "ms source=" + source +
                    " prev=" + (prev != null) + " next=" + (next != null));
            if (prev != null) prefetchQuick(prev, -1, prefetchToken);
            if (next != null) prefetchQuick(next, 1, prefetchToken);
        });
    }

    private boolean publishFullList(int generation, String seedName, List<MediaItem> found, String source, long scanMs) {
        if (generation != siblingGeneration.get() || found == null || found.isEmpty()) return false;
        int idx = -1;
        for (int i = 0; i < found.size(); i++) {
            if (sameName(found.get(i).name, seedName)) { idx = i; break; }
        }
        if (idx < 0) return false;
        final int finalIndex = idx;
        final ArrayList<MediaItem> copy = new ArrayList<>(found);
        mainHandler.post(() -> {
            if (generation != siblingGeneration.get() || isFinishing()) return;
            siblings.clear(); siblings.addAll(copy); currentIndex = finalIndex;
            fullListReady = true;
            quickPreviousItem = null; quickNextItem = null;
            AppLog.d(this, "SIBLINGS full ready +" + elapsed() + "ms source=" + source +
                    " scan=" + scanMs + "ms found=" + siblings.size() + " currentIndex=" + currentIndex);
            updatePositionLabel();
            prefetchAdjacent();
        });
        return true;
    }

    // Cache identity is the folder only. Sort field/direction never invalidates a warm folder index.
    private String folderCacheKey(String path) {
        return path == null ? "" : path;
    }

    private boolean cacheSupportsSort(FolderCacheEntry entry, String field) {
        if (entry == null) return false;
        if (SortPrefs.FIELD_NAME.equals(field) || SortPrefs.FIELD_TYPE.equals(field)) return true;
        final boolean needSize = SortPrefs.FIELD_SIZE.equals(field);
        final boolean needCreated = SortPrefs.FIELD_CREATED.equals(field);
        final boolean needModified = SortPrefs.FIELD_MODIFIED.equals(field);
        for (MediaItem item : entry.items) {
            if (item == null) continue;
            if (needSize && item.size < 0L) return false;
            if (needCreated && item.created < 0L) return false;
            if (needModified && item.modified < 0L) return false;
        }
        return true;
    }

    private ArrayList<MediaItem> getFolderCache(String path, String field, boolean asc) {
        String key = folderCacheKey(path);
        synchronized (FOLDER_CACHE_LOCK) {
            FolderCacheEntry e = FOLDER_INDEX_CACHE.get(key);
            if (e == null) return null;
            if (SystemClock.elapsedRealtime() - e.createdAt > FOLDER_CACHE_TTL_MS) {
                FOLDER_INDEX_CACHE.remove(key);
                return null;
            }
            // A name-only scan is intentionally incomplete for size/modified sorting.
            // If that metadata is missing, force one direct rescan that enriches this same cache.
            if (!cacheSupportsSort(e, field)) return null;
            ArrayList<MediaItem> out = new ArrayList<>(e.items);
            sortProviderItems(out, field, asc);
            return out;
        }
    }

    private void putFolderCache(String path, String field, boolean asc, List<MediaItem> items) {
        if (path == null || items == null || items.isEmpty()) return;
        String key = folderCacheKey(path);
        synchronized (FOLDER_CACHE_LOCK) {
            FolderCacheEntry previous = FOLDER_INDEX_CACHE.get(key);
            HashMap<String, MediaItem> oldByName = new HashMap<>();
            if (previous != null) {
                for (MediaItem old : previous.items) {
                    if (old != null && old.name != null) oldByName.put(old.name, old);
                }
            }

            ArrayList<MediaItem> merged = new ArrayList<>(items.size());
            for (MediaItem item : items) {
                if (item == null || item.name == null) continue;
                MediaItem old = oldByName.get(item.name);
                long size = item.size >= 0L ? item.size : (old == null ? -1L : old.size);
                long created = item.created >= 0L ? item.created : (old == null ? -1L : old.created);
                long modified = item.modified >= 0L ? item.modified : (old == null ? -1L : old.modified);
                Uri uri = item.uri != null ? item.uri : (old == null ? null : old.uri);
                String mime = item.mime != null ? item.mime : (old == null ? null : old.mime);
                merged.add(new MediaItem(uri, item.name, mime, size, created, modified));
            }
            FOLDER_INDEX_CACHE.put(key, new FolderCacheEntry(SystemClock.elapsedRealtime(), merged));
        }
    }

    private boolean tryDirectFilesystemIndex(int generation, Uri seedUri, String seedName,
                                             String relativePath, String sortField, boolean sortAscending) {
        long started = SystemClock.elapsedRealtime();
        try {
            String absoluteSeed = inferAbsolutePathFromAnyUri(seedUri);
            if (absoluteSeed == null || absoluteSeed.isEmpty()) {
                AppLog.d(this, "FILE fast skip +" + elapsed() + "ms reason=no-absolute-path");
                return false;
            }
            File seedFile = new File(absoluteSeed);
            File parent = seedFile.getParentFile();
            if (parent == null || !parent.isDirectory() || !parent.canRead()) {
                AppLog.d(this, "FILE fast skip +" + elapsed() + "ms reason=unreadable-parent path=" +
                        (parent == null ? "null" : parent.getAbsolutePath()));
                return false;
            }
            // File.list() returns names without doing a per-entry stat. This matters for large folders:
            // name sort must not call isFile(), length(), or lastModified() for every item.
            String[] names = parent.list((dir, name) -> isSupportedImageName(name));
            if (names == null) {
                AppLog.d(this, "FILE fast skip +" + elapsed() + "ms reason=list-null");
                return false;
            }
            final boolean needSize = SortPrefs.FIELD_SIZE.equals(sortField);
            final boolean needCreated = SortPrefs.FIELD_CREATED.equals(sortField);
            final boolean needModified = SortPrefs.FIELD_MODIFIED.equals(sortField);
            ArrayList<MediaItem> found = new ArrayList<>(names.length);
            for (String name : names) {
                if (generation != siblingGeneration.get()) return true;
                if (name == null || name.isEmpty()) continue;
                File f = new File(parent, name);
                long size = needSize ? Math.max(0L, f.length()) : -1L;
                long created = needCreated ? fileCreationTimeMillis(f) : -1L;
                long modified = needModified ? Math.max(0L, f.lastModified()) : -1L;
                found.add(new MediaItem(Uri.fromFile(f), name, mimeFromName(name), size, created, modified));
            }
            if (found.isEmpty()) {
                AppLog.d(this, "FILE fast skip +" + elapsed() + "ms reason=no-images");
                return false;
            }
            sortProviderItems(found, sortField, sortAscending);
            // Name/type order is fully determined from File.list() alone. Start decoding the exact
            // two neighbors before any later folder bookkeeping, so the tapped image becomes
            // swipe-ready from the center outward. Size/date order must wait for all required stats.
            if (SortPrefs.FIELD_NAME.equals(sortField) || SortPrefs.FIELD_TYPE.equals(sortField)) {
                int seedIndex = -1;
                for (int i = 0; i < found.size(); i++) {
                    if (sameName(found.get(i).name, seedName)) { seedIndex = i; break; }
                }
                if (seedIndex >= 0) {
                    MediaItem prev = seedIndex > 0 ? found.get(seedIndex - 1) : null;
                    MediaItem next = seedIndex + 1 < found.size() ? found.get(seedIndex + 1) : null;
                    publishQuickPair(generation, prev, next, prefetchGeneration.get(), "filesystem-order-neighbors");
                    AppLog.d(this, "PREFETCH order neighbors queued +" + elapsed() + "ms field=" + sortField);
                }
            }
            String cachePath = relativePath;
            if (cachePath == null || cachePath.isEmpty()) cachePath = relativePathFromAbsolute(absoluteSeed);
            if (cachePath == null || cachePath.isEmpty()) cachePath = parent.getAbsolutePath() + "/";
            if (!cachePath.endsWith("/")) cachePath += "/";
            putFolderCache(cachePath, sortField, sortAscending, found);
            long took = SystemClock.elapsedRealtime() - started;
            boolean published = publishFullList(generation, seedName, found, "filesystem-direct", took);
            AppLog.d(this, "FILE fast ready +" + elapsed() + "ms took=" + took + "ms found=" +
                    found.size() + " published=" + published + " metadata=" +
                    (needSize ? "size-only" : (needCreated ? "created-only" : (needModified ? "modified-only" : (SortPrefs.FIELD_TYPE.equals(sortField) ? "type-name-only" : "name-only")))) +
                    " parent=" + parent.getAbsolutePath());
            return published;
        } catch (SecurityException e) {
            AppLog.d(this, "FILE fast denied +" + elapsed() + "ms " + e.getClass().getSimpleName());
            return false;
        } catch (Throwable e) {
            AppLog.d(this, "FILE fast error +" + elapsed() + "ms " + e);
            return false;
        }
    }

    private long fileCreationTimeMillis(File file) {
        if (file == null) return -1L;
        try {
            BasicFileAttributes attrs = Files.readAttributes(file.toPath(), BasicFileAttributes.class);
            long value = attrs.creationTime().toMillis();
            if (value > 0L) return value;
        } catch (Throwable ignored) { }
        // Some Android/storage providers do not expose birth time. In that case the best
        // deterministic fallback is mtime, while keeping it distinct when birth time exists.
        try {
            long modified = file.lastModified();
            return modified > 0L ? modified : -1L;
        } catch (Throwable ignored) { return -1L; }
    }

    private String inferAbsolutePathFromAnyUri(Uri uri) {
        if (uri == null) return null;
        try {
            if ("file".equalsIgnoreCase(uri.getScheme())) return uri.getPath();
            String raw = Uri.decode(uri.getPath());
            if (raw != null) {
                // Solid Explorer and other path-style providers may expose removable storage
                // directly as /storage/XXXX-XXXX/... . Preserve that absolute path too.
                if (raw.startsWith("/storage/") && !raw.endsWith("/")) return raw;
                String[] markers = new String[]{"/storage/emulated/0/", "/storage/self/primary/", "/sdcard/"};
                for (String marker : markers) {
                    int idx = raw.indexOf(marker);
                    if (idx >= 0) {
                        String tail = raw.substring(idx + marker.length());
                        return new File(android.os.Environment.getExternalStorageDirectory(), tail).getAbsolutePath();
                    }
                }
                int primary = raw.indexOf("primary:");
                if (primary >= 0) {
                    String tail = raw.substring(primary + "primary:".length());
                    return new File(android.os.Environment.getExternalStorageDirectory(), tail).getAbsolutePath();
                }
            }
            if (Build.VERSION.SDK_INT >= 19 && DocumentsContract.isDocumentUri(this, uri)) {
                String docId = DocumentsContract.getDocumentId(uri);
                if (docId != null) {
                    if (docId.startsWith("primary:")) {
                        return new File(android.os.Environment.getExternalStorageDirectory(),
                                docId.substring("primary:".length())).getAbsolutePath();
                    }
                    if (docId.startsWith("raw:")) return docId.substring(4);
                }
            }
        } catch (Throwable e) {
            AppLog.d(this, "FILE absolute path inference miss " + e.getClass().getSimpleName());
        }
        return null;
    }

    private void tryProviderDirectoryFastPath(int generation, int prefetchToken, Uri seedUri,
                                              String seedName, String relativePath,
                                              String sortField, boolean sortAscending) {
        if (generation != siblingGeneration.get() || seedUri == null) return;
        String authority = seedUri.getAuthority();
        if (authority == null || !authority.equals("pl.solidexplorer2.files")) {
            AppLog.d(this, "PROVIDER fast skip authority=" + authority);
            return;
        }
        Uri parent = parentProviderUri(seedUri);
        if (parent == null) return;
        long started = SystemClock.elapsedRealtime();
        AppLog.d(this, "PROVIDER parent query begin +" + elapsed() + "ms uri=" + parent);
        try (Cursor c = getContentResolver().query(parent, null, null, null, null)) {
            if (c == null) {
                AppLog.d(this, "PROVIDER parent query null +" + elapsed() + "ms");
                return;
            }
            AppLog.d(this, "PROVIDER parent columns=" + Arrays.toString(c.getColumnNames()));
            int nameCol = findColumn(c, OpenableColumns.DISPLAY_NAME, "display_name", "name", "_display_name");
            int mimeCol = findColumn(c, "mime_type", "mimetype", "type");
            int sizeCol = findColumn(c, OpenableColumns.SIZE, "size", "_size");
            int createdCol = findColumn(c, "date_added", "created", "creation_time", "birthtime");
            int modifiedCol = findColumn(c, "last_modified", "date_modified", "modified", "mtime");
            if (nameCol < 0) {
                AppLog.d(this, "PROVIDER parent unusable: no display-name column");
                return;
            }
            if ((SortPrefs.FIELD_SIZE.equals(sortField) && sizeCol < 0) ||
                    (SortPrefs.FIELD_CREATED.equals(sortField) && createdCol < 0) ||
                    (SortPrefs.FIELD_MODIFIED.equals(sortField) && modifiedCol < 0)) {
                AppLog.d(this, "PROVIDER parent unusable for sort=" + sortField +
                        " sizeCol=" + sizeCol + " createdCol=" + createdCol + " modifiedCol=" + modifiedCol);
                return;
            }
            ArrayList<MediaItem> found = new ArrayList<>();
            int rows = 0;
            while (c.moveToNext() && rows < 5000) {
                rows++;
                String name = c.isNull(nameCol) ? null : c.getString(nameCol);
                if (name == null || !looksLikeImage(name)) continue;
                String mime = (mimeCol >= 0 && !c.isNull(mimeCol)) ? c.getString(mimeCol) : mimeFromName(name);
                long size = (sizeCol >= 0 && !c.isNull(sizeCol)) ? c.getLong(sizeCol) : -1L;
                long created = (createdCol >= 0 && !c.isNull(createdCol)) ? c.getLong(createdCol) : -1L;
                long modified = (modifiedCol >= 0 && !c.isNull(modifiedCol)) ? c.getLong(modifiedCol) : -1L;
                Uri child = sameName(name, seedName) ? seedUri : parent.buildUpon().appendPath(name).build();
                found.add(new MediaItem(child, name, mime, size, created, modified));
            }
            sortProviderItems(found, sortField, sortAscending);
            long took = SystemClock.elapsedRealtime() - started;
            boolean accepted = publishFullList(generation, seedName, found, "provider-parent", took);
            AppLog.d(this, "PROVIDER parent query end +" + elapsed() + "ms took=" + took +
                    "ms rows=" + rows + " images=" + found.size() + " accepted=" + accepted);
            if (accepted) {
                // Provider list is intentionally not kept in the cross-activity cache; a URI
                // grant may be tied to this incoming Intent. MediaStore full-scan will populate
                // the safe process cache when/if it finishes.
            }
        } catch (Throwable e) {
            AppLog.d(this, "PROVIDER parent query error +" + elapsed() + "ms " + e);
        }
    }

    private Uri parentProviderUri(Uri seedUri) {
        String encoded = seedUri.getEncodedPath();
        if (encoded == null) return null;
        int slash = encoded.lastIndexOf('/');
        if (slash <= 0) return null;
        return seedUri.buildUpon().encodedPath(encoded.substring(0, slash + 1)).clearQuery().fragment(null).build();
    }

    private int findColumn(Cursor c, String... candidates) {
        String[] cols = c.getColumnNames();
        for (String candidate : candidates) {
            if (candidate == null) continue;
            for (int i = 0; i < cols.length; i++) if (candidate.equalsIgnoreCase(cols[i])) return i;
        }
        return -1;
    }

    private boolean looksLikeImage(String name) {
        if (name == null) return false;
        String n = name.toLowerCase(Locale.ROOT);
        return n.endsWith(".jpg") || n.endsWith(".jpeg") || n.endsWith(".png") ||
                n.endsWith(".gif") || n.endsWith(".bmp") || n.endsWith(".webp") ||
                n.endsWith(".heic") || n.endsWith(".heif") || n.endsWith(".avif");
    }

    private boolean isSupportedImageName(String name) {
        if (name == null) return false;
        String n = name.toLowerCase(Locale.ROOT);
        return looksLikeImage(name) || n.endsWith(".pdf");
    }

    private String mimeFromName(String name) {
        String n = name.toLowerCase(Locale.ROOT);
        if (n.endsWith(".png")) return "image/png";
        if (n.endsWith(".gif")) return "image/gif";
        if (n.endsWith(".bmp")) return "image/bmp";
        if (n.endsWith(".webp")) return "image/webp";
        if (n.endsWith(".heic") || n.endsWith(".heif")) return "image/heic";
        if (n.endsWith(".avif")) return "image/avif";
        if (n.endsWith(".pdf")) return "application/pdf";
        return "image/jpeg";
    }

    private String fileTypeKey(String name) {
        if (name == null) return "";
        String n = name.toLowerCase(Locale.ROOT);
        int dot = n.lastIndexOf('.');
        if (dot < 0 || dot >= n.length() - 1) return "";
        String ext = n.substring(dot + 1);
        // Treat equivalent container extensions as one file kind.
        if ("jpeg".equals(ext)) return "jpg";
        if ("heif".equals(ext)) return "heic";
        return ext;
    }

    private void sortProviderItems(List<MediaItem> list, String field, boolean asc) {
        Comparator<MediaItem> byName = (a, b) -> String.CASE_INSENSITIVE_ORDER.compare(
                a.name == null ? "" : a.name, b.name == null ? "" : b.name);
        Comparator<MediaItem> cmp;
        if (SortPrefs.FIELD_SIZE.equals(field)) {
            cmp = (a, b) -> { int x = Long.compare(a.size, b.size); return x != 0 ? x : byName.compare(a, b); };
        } else if (SortPrefs.FIELD_TYPE.equals(field)) {
            cmp = (a, b) -> {
                int x = fileTypeKey(a == null ? null : a.name).compareToIgnoreCase(fileTypeKey(b == null ? null : b.name));
                return x != 0 ? x : byName.compare(a, b);
            };
        } else if (SortPrefs.FIELD_CREATED.equals(field)) {
            cmp = (a, b) -> { int x = Long.compare(a.created, b.created); return x != 0 ? x : byName.compare(a, b); };
        } else if (SortPrefs.FIELD_MODIFIED.equals(field)) {
            cmp = (a, b) -> { int x = Long.compare(a.modified, b.modified); return x != 0 ? x : byName.compare(a, b); };
        } else cmp = byName;
        if (!asc) cmp = cmp.reversed();
        Collections.sort(list, cmp);
    }

    private boolean safeExecute(ExecutorService executor, Runnable task) {
        if (executor == null || task == null || executor.isShutdown() || executor.isTerminated()) return false;
        try { executor.execute(task); return true; }
        catch (java.util.concurrent.RejectedExecutionException e) {
            AppLog.d(this, "EXECUTOR rejected +" + elapsed() + "ms " + e.getClass().getSimpleName());
            return false;
        }
    }

    private void logLaunchIntentDetails() {
        try {
            Intent i = getIntent();
            ClipData clip = i.getClipData();
            Bundle extras = i.getExtras();
            AppLog.d(this, "INTENT flags=0x" + Integer.toHexString(i.getFlags()) +
                    " referrer=" + getReferrer() +
                    " clipCount=" + (clip == null ? 0 : clip.getItemCount()) +
                    " extras=" + (extras == null ? "[]" : extras.keySet().toString()));
            if (clip != null) {
                for (int n = 0; n < Math.min(clip.getItemCount(), 8); n++) {
                    ClipData.Item item = clip.getItemAt(n);
                    AppLog.d(this, "INTENT clip[" + n + "] uri=" + item.getUri());
                }
            }
        } catch (Throwable e) { AppLog.d(this, "INTENT detail error " + e); }
    }

    private void buildFullSiblingList(int generation, String seedName, String relativePath, String sortField, boolean sortAscending) {
        long started = SystemClock.elapsedRealtime();
        try {
            String[] projection = new String[]{MediaStore.Images.Media._ID, MediaStore.Images.Media.DISPLAY_NAME, MediaStore.Images.Media.MIME_TYPE, MediaStore.Images.Media.SIZE, MediaStore.Images.Media.DATE_ADDED, MediaStore.Images.Media.DATE_MODIFIED};
            String selection = MediaStore.Images.Media.RELATIVE_PATH + "=?";
            String direction = sortAscending ? " ASC" : " DESC";
            String col = SortPrefs.sqlColumn(sortField);
            String sort = SortPrefs.FIELD_NAME.equals(sortField)
                    ? MediaStore.Images.Media.DISPLAY_NAME + " COLLATE NOCASE" + direction + ", " + MediaStore.Images.Media._ID + direction
                    : col + direction + ", " + MediaStore.Images.Media._ID + direction;
            ArrayList<MediaItem> found = new ArrayList<>();
            try (Cursor c = getContentResolver().query(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, projection, selection, new String[]{relativePath}, sort)) {
                if (c != null) {
                    int idCol = c.getColumnIndexOrThrow(MediaStore.Images.Media._ID);
                    int nameCol = c.getColumnIndexOrThrow(MediaStore.Images.Media.DISPLAY_NAME);
                    int mimeCol = c.getColumnIndexOrThrow(MediaStore.Images.Media.MIME_TYPE);
                    int sizeCol = c.getColumnIndexOrThrow(MediaStore.Images.Media.SIZE);
                    int createdCol = c.getColumnIndexOrThrow(MediaStore.Images.Media.DATE_ADDED);
                    int modifiedCol = c.getColumnIndexOrThrow(MediaStore.Images.Media.DATE_MODIFIED);
                    while (c.moveToNext()) {
                        if (generation != siblingGeneration.get()) return;
                        long id = c.getLong(idCol); String name = c.getString(nameCol); String mime = c.getString(mimeCol);
                        long size = c.getLong(sizeCol); long created = c.getLong(createdCol); long modified = c.getLong(modifiedCol);
                        found.add(new MediaItem(ContentUris.withAppendedId(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, id), name, mime, size, created, modified));
                    }
                }
            }
            sortProviderItems(found, sortField, sortAscending);
            long scanMs = SystemClock.elapsedRealtime() - started;
            putFolderCache(relativePath, sortField, sortAscending, found);
            publishFullList(generation, seedName, found, "mediastore-full", scanMs);
        } catch (Throwable e) { AppLog.d(this, "SIBLINGS full error +" + elapsed() + "ms " + e); }
    }

    private String resolveRelativePath(Uri uri) {
        // Some file managers (including Solid Explorer) expose a provider URI whose path contains
        // the actual shared-storage path, but do not implement RELATIVE_PATH on that provider.
        try {
            String rawPath = uri.getPath();
            if (rawPath != null) {
                String marker = "/storage/emulated/0/";
                int idx = rawPath.indexOf(marker);
                if (idx >= 0) {
                    String relativeFile = rawPath.substring(idx + marker.length());
                    int slash = relativeFile.lastIndexOf('/');
                    if (slash >= 0) {
                        String inferred = relativeFile.substring(0, slash + 1);
                        AppLog.d(this, "SIBLINGS inferred path from provider=" + inferred);
                        return inferred;
                    }
                }
            }
        } catch (Throwable e) { AppLog.d(this, "SIBLINGS provider path parse error " + e); }

        try (Cursor c = getContentResolver().query(uri, new String[]{MediaStore.MediaColumns.RELATIVE_PATH}, null, null, null)) {
            if (c != null && c.moveToFirst()) {
                int col = c.getColumnIndex(MediaStore.MediaColumns.RELATIVE_PATH);
                if (col >= 0) {
                    String v = c.getString(col);
                    if (v != null && !v.isEmpty()) return v;
                }
            }
        } catch (Throwable e) { AppLog.d(this, "SIBLINGS seed RELATIVE_PATH unavailable " + e.getClass().getSimpleName()); }

        String name = resolveDisplayName(uri); if (name == null) return null;
        try (Cursor c = getContentResolver().query(MediaStore.Images.Media.EXTERNAL_CONTENT_URI,
                new String[]{MediaStore.Images.Media.RELATIVE_PATH, MediaStore.Images.Media.DISPLAY_NAME},
                MediaStore.Images.Media.DISPLAY_NAME + "=?", new String[]{name}, MediaStore.Images.Media.DATE_MODIFIED + " DESC")) {
            if (c != null && c.moveToFirst()) {
                int col = c.getColumnIndex(MediaStore.Images.Media.RELATIVE_PATH);
                if (col >= 0) return c.getString(col);
            }
        } catch (Throwable e) { AppLog.d(this, "SIBLINGS MediaStore name lookup error " + e); }
        return null;
    }

    private boolean sameName(String a, String b) { return a != null && b != null && a.equalsIgnoreCase(b); }
    private boolean isPdf(String mime, Uri uri) { return "application/pdf".equalsIgnoreCase(mime) || (uri != null && uri.toString().toLowerCase().endsWith(".pdf")); }

    private String resolveDisplayName(Uri uri) {
        String name = null;
        if ("content".equals(uri.getScheme())) {
            try (Cursor cursor = getContentResolver().query(uri, new String[]{OpenableColumns.DISPLAY_NAME}, null, null, null)) {
                if (cursor != null && cursor.moveToFirst()) { int index = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME); if (index >= 0) name = cursor.getString(index); }
            } catch (Exception ignored) { }
        }
        if (name == null || name.isEmpty()) name = uri.getLastPathSegment();
        return name == null ? "Chirami" : name;
    }

    private void closePdfPage() { if (pdfPage != null) { pdfPage.close(); pdfPage = null; } }
    private void closePdf() {
        closePdfPage(); if (pdfRenderer != null) { pdfRenderer.close(); pdfRenderer = null; }
        if (pdfFd != null) { try { pdfFd.close(); } catch (IOException ignored) { } pdfFd = null; }
    }

    @Override protected void onDestroy() {
        AppLog.d(this, "VIEWER onDestroy");
        siblingGeneration.incrementAndGet();
        cancelSiblingQuerySignals();
        closePdf();
        decodeGeneration.incrementAndGet();
        decodeExecutor.shutdownNow(); editExecutor.shutdownNow(); fileManagerExecutor.shutdownNow(); scanExecutor.shutdownNow(); neighborExecutor.shutdownNow();
        providerDirectoryExecutor.shutdownNow(); fullScanExecutor.shutdownNow(); prefetchExecutor.shutdownNow();
        super.onDestroy();
    }

    /** White, label-free bottom toolbar icons drawn in code so the visual weight stays consistent. */
    private static class BottomActionIconView extends View {
        static final int SHARE = 0;
        static final int DELETE = 1;

        private final int kind;
        private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final RectF rect = new RectF();

        BottomActionIconView(Activity context, int kind) {
            super(context);
            this.kind = kind;
            setClickable(true);
            setFocusable(true);
        }

        @Override protected void onDraw(Canvas canvas) {
            super.onDraw(canvas);
            final float d = getResources().getDisplayMetrics().density;
            final float cx = getWidth() * 0.5f;
            final float cy = getHeight() * 0.5f;
            final float visualScale = 0.85f; // smaller glyph only; keep the full 72dp tap cell
            canvas.save();
            canvas.scale(visualScale, visualScale, cx, cy);
            paint.setColor(Color.WHITE);
            paint.setStyle(Paint.Style.STROKE);
            paint.setStrokeWidth(2.35f * d);
            paint.setStrokeCap(Paint.Cap.ROUND);
            paint.setStrokeJoin(Paint.Join.ROUND);

            if (kind == SHARE) {
                float r = 3.25f * d;
                float lx = cx - 8.5f * d;
                float ly = cy;
                float rx = cx + 7.5f * d;
                float ty = cy - 8.0f * d;
                float by = cy + 8.0f * d;
                canvas.drawLine(lx + r * 0.65f, ly - r * 0.35f, rx - r * 0.75f, ty + r * 0.45f, paint);
                canvas.drawLine(lx + r * 0.65f, ly + r * 0.35f, rx - r * 0.75f, by - r * 0.45f, paint);
                canvas.drawCircle(lx, ly, r, paint);
                canvas.drawCircle(rx, ty, r, paint);
                canvas.drawCircle(rx, by, r, paint);
                canvas.restore();
                return;
            }

            // Trash can: simple rounded outline, lid and handle, matching the share icon's weight.
            rect.set(cx - 8.0f * d, cy - 4.5f * d, cx + 8.0f * d, cy + 10.5f * d);
            canvas.drawRoundRect(rect, 2.2f * d, 2.2f * d, paint);
            canvas.drawLine(cx - 10.0f * d, cy - 8.0f * d, cx + 10.0f * d, cy - 8.0f * d, paint);
            rect.set(cx - 3.6f * d, cy - 11.0f * d, cx + 3.6f * d, cy - 8.0f * d);
            canvas.drawRoundRect(rect, 1.4f * d, 1.4f * d, paint);
            canvas.restore();
        }
    }

    /**
     * Font-independent toolbar glyphs. The rotate and info icons intentionally share the same
     * outer diameter so their circles line up exactly; back/more also use the same vertical center.
     */
    private static class ToolbarIconView extends View {
        static final int BACK = 0;
        static final int ROTATE = 1;
        static final int INFO = 2;
        static final int MORE = 3;

        private final int kind;
        private final float requestedDiameterPx;
        private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final RectF arc = new RectF();

        ToolbarIconView(Activity context, int kind, int requestedDiameterPx) {
            super(context);
            this.kind = kind;
            this.requestedDiameterPx = requestedDiameterPx;
            setClickable(true);
            setFocusable(true);
        }

        @Override protected void onDraw(Canvas canvas) {
            super.onDraw(canvas);
            final float cx = getWidth() * 0.5f;
            final float cy = getHeight() * 0.5f;
            final float density = getResources().getDisplayMetrics().density;
            // Keep touch targets/layout unchanged. Back/rotate/info are another 30% smaller
            // than v0.1.28 (0.70 * 0.70 = 0.49 of the original visual size).
            // Overflow deliberately stays at the v0.1.28 visual size (0.70).
            final float visualScale = (kind == MORE) ? 0.70f : 0.49f;
            final int iconSave = canvas.save();
            canvas.scale(visualScale, visualScale, cx, cy);
            paint.setColor(Color.WHITE);
            paint.setStrokeCap(Paint.Cap.ROUND);
            paint.setStrokeJoin(Paint.Join.ROUND);

            if (kind == BACK) {
                paint.setStyle(Paint.Style.STROKE);
                paint.setStrokeWidth(2.7f * density);
                float halfH = 13f * density;
                float halfW = 8f * density;
                canvas.drawLine(cx + halfW * 0.55f, cy - halfH, cx - halfW, cy, paint);
                canvas.drawLine(cx - halfW, cy, cx + halfW * 0.55f, cy + halfH, paint);
                canvas.restoreToCount(iconSave);
                return;
            }

            if (kind == MORE) {
                paint.setStyle(Paint.Style.FILL);
                float r = 2.15f * density;
                canvas.drawCircle(cx, cy - 9f * density, r, paint);
                canvas.drawCircle(cx, cy, r, paint);
                canvas.drawCircle(cx, cy + 9f * density, r, paint);
                canvas.restoreToCount(iconSave);
                return;
            }

            // ROTATE and INFO use the exact same diameter and center.
            float diameter = Math.min(requestedDiameterPx, Math.min(getWidth(), getHeight()) - 4f * density);
            float radius = diameter * 0.5f;
            float stroke = 2.1f * density;
            paint.setStyle(Paint.Style.STROKE);
            paint.setStrokeWidth(stroke);

            if (kind == INFO) {
                canvas.drawCircle(cx, cy, radius - stroke * 0.5f, paint);
                paint.setStyle(Paint.Style.FILL);
                canvas.drawCircle(cx, cy - 7.2f * density, 1.7f * density, paint);
                paint.setStrokeWidth(2.2f * density);
                paint.setStrokeCap(Paint.Cap.ROUND);
                canvas.drawRoundRect(cx - 1.1f * density, cy - 1.5f * density,
                        cx + 1.1f * density, cy + 8.4f * density, 1.1f * density, 1.1f * density, paint);
                canvas.restoreToCount(iconSave);
                return;
            }

            float inset = stroke * 0.5f;
            arc.set(cx - radius + inset, cy - radius + inset, cx + radius - inset, cy + radius - inset);
            // Leave a deliberate gap at the top-right for the arrow head.
            canvas.drawArc(arc, 42f, 292f, false, paint);
            paint.setStyle(Paint.Style.FILL);
            android.graphics.Path arrow = new android.graphics.Path();
            float ax = cx + radius * 0.74f;
            float ay = cy - radius * 0.56f;
            arrow.moveTo(ax + 5.0f * density, ay - 4.2f * density);
            arrow.lineTo(ax + 4.0f * density, ay + 5.5f * density);
            arrow.lineTo(ax - 5.4f * density, ay + 2.7f * density);
            arrow.close();
            canvas.drawPath(arrow, paint);
            canvas.restoreToCount(iconSave);
        }
    }

    /** Lightweight zoom/pan/page view. No external image-view dependency: keeps Chirami small and startup cheap. */
    private class ZoomImageView extends ImageView {
        interface PageListener { boolean canPage(int direction); void onPageDrag(int direction, float translationX); void onPageReset(); void onPage(int direction, float velocityX); void onSingleTap(); }
        private PageListener pageListener;
        private final Matrix matrix = new Matrix();
        private final float[] values = new float[9];
        private final ScaleGestureDetector scaleDetector;
        private float fitScale = 1f;
        private float userScale = 1f;
        private int viewerRotationDegrees = 0;
        private float lastX, lastY, downX, downY;
        private long lastTapUp = 0;
        private float lastTapX, lastTapY;
        private boolean secondTap = false;
        private boolean doubleTapZoomDrag = false;
        private float doubleTapStartY, doubleTapStartScale;
        private boolean paging = false;
        private boolean moved = false;
        private VelocityTracker velocityTracker;
        private final int touchSlop = ViewConfiguration.get(ViewerActivity.this).getScaledTouchSlop();
        private Runnable pendingSingleTap;

        ZoomImageView() {
            super(ViewerActivity.this);
            setScaleType(ScaleType.MATRIX);
            setClickable(true);
            scaleDetector = new ScaleGestureDetector(ViewerActivity.this, new ScaleGestureDetector.SimpleOnScaleGestureListener() {
                @Override public boolean onScaleBegin(ScaleGestureDetector detector) { paging = false; cancelSingleTap(); if (zoomAnimator != null) zoomAnimator.cancel(); return true; }
                @Override public boolean onScale(ScaleGestureDetector detector) {
                    float factor = detector.getScaleFactor();
                    setUserScale(userScale * factor, detector.getFocusX(), detector.getFocusY());
                    return true;
                }
            });
        }

        void setPageListener(PageListener listener) { pageListener = listener; }

        void setImageForViewer(Drawable drawable) {
            setTranslationX(0f); setAlpha(1f);
            setImageForViewerKeepingTranslation(drawable);
        }

        void setImageForViewerKeepingTranslation(Drawable drawable) {
            viewerRotationDegrees = pendingRotationDegrees;
            super.setImageDrawable(drawable);
            // Compute the final FIT matrix synchronously whenever the view is measured.
            // This prevents a temporary frame rendered with the previous image's matrix.
            if (getWidth() > 0 && getHeight() > 0) resetToFit();
            else post(this::resetToFit);
        }

        private void resetToFit() { resetToFit(1f); }

        private void resetToFit(float zoomMultiplier) {
            Drawable d = getDrawable(); if (d == null || getWidth() <= 0 || getHeight() <= 0) return;
            int iw = Math.max(1, d.getIntrinsicWidth()); int ih = Math.max(1, d.getIntrinsicHeight());
            fitScale = fitScaleForViewerRotation(viewerRotationDegrees);
            if (!Float.isFinite(fitScale) || fitScale <= 0f) fitScale = 1f;

            matrix.reset();
            matrix.setRotate(viewerRotationDegrees, iw / 2f, ih / 2f);
            RectF bounds = new RectF(0, 0, iw, ih);
            matrix.mapRect(bounds);
            matrix.postScale(fitScale, fitScale, bounds.centerX(), bounds.centerY());
            bounds.set(0, 0, iw, ih);
            matrix.mapRect(bounds);
            matrix.postTranslate(getWidth() / 2f - bounds.centerX(), getHeight() / 2f - bounds.centerY());

            float zoom = Math.max(1f, zoomMultiplier);
            userScale = fitScale;
            if (zoom > 1.0001f) {
                matrix.postScale(zoom, zoom, getWidth() / 2f, getHeight() / 2f);
                userScale = fitScale * zoom;
                constrain();
            }
            setImageMatrix(matrix);
            notifyImageBoundsChanged();
        }

        float fitScaleForViewerRotation(int degrees) {
            Drawable d = getDrawable();
            if (d == null || getWidth() <= 0 || getHeight() <= 0) return fitScale;
            int iw = Math.max(1, d.getIntrinsicWidth());
            int ih = Math.max(1, d.getIntrinsicHeight());
            int normalized = ((degrees % 360) + 360) % 360;
            float rw = (normalized % 180 == 0) ? iw : ih;
            float rh = (normalized % 180 == 0) ? ih : iw;
            float result = Math.min(getWidth() / rw, getHeight() / rh);
            return (!Float.isFinite(result) || result <= 0f) ? 1f : result;
        }

        float getViewerFitScale() { return fitScale; }

        float getViewerZoomMultiplier() {
            if (!Float.isFinite(fitScale) || fitScale <= 0f) return 1f;
            float value = userScale / fitScale;
            return (!Float.isFinite(value) || value < 1f) ? 1f : value;
        }

        void commitViewerRotation(int degrees, float zoomMultiplier) {
            viewerRotationDegrees = ((degrees % 360) + 360) % 360;
            resetToFit(zoomMultiplier);
        }

        void notifyImageBoundsChanged() {
            Drawable d = getDrawable(); if (d == null) return;
            RectF r = new RectF(0, 0, Math.max(1,d.getIntrinsicWidth()), Math.max(1,d.getIntrinsicHeight()));
            matrix.mapRect(r);
            ViewerActivity.this.updateChromeShadeBounds(r);
        }

        private void setUserScale(float target, float focusX, float focusY) {
            float max = Math.max(8f, fitScale * 12f);
            target = Math.max(fitScale, Math.min(max, target));
            float factor = target / userScale;
            matrix.postScale(factor, factor, focusX, focusY);
            userScale = target;
            constrain(); setImageMatrix(matrix);
        }

        private boolean isAtFit() { return userScale <= fitScale * 1.015f; }

        private ValueAnimator zoomAnimator;

        private void toggleOriginal(float x, float y) {
            final float start = userScale;
            final boolean zoomingIn = Math.abs(userScale - fitScale) < Math.max(0.02f, fitScale * 0.02f);
            final float target = zoomingIn ? Math.max(1f, fitScale) : fitScale;
            if (Math.abs(target - start) < 0.001f) return;
            if (zoomAnimator != null) zoomAnimator.cancel();
            zoomAnimator = ValueAnimator.ofFloat(start, target);
            zoomAnimator.setDuration(210L);
            zoomAnimator.setInterpolator(new DecelerateInterpolator(1.8f));
            zoomAnimator.addUpdateListener(a -> setUserScale((float)a.getAnimatedValue(), x, y));
            zoomAnimator.addListener(new android.animation.AnimatorListenerAdapter() {
                @Override public void onAnimationEnd(android.animation.Animator animation) {
                    if (!zoomingIn) resetToFit();
                    zoomAnimator = null;
                }
                @Override public void onAnimationCancel(android.animation.Animator animation) { zoomAnimator = null; }
            });
            zoomAnimator.start();
            AppLog.d(ViewerActivity.this, "ZOOM doubleTap animate " + start + " -> " + target + " fit=" + fitScale);
        }

        private void pan(float dx, float dy) { matrix.postTranslate(dx, dy); constrain(); setImageMatrix(matrix); }

        private void constrain() {
            Drawable d = getDrawable(); if (d == null) return;
            RectF r = new RectF(0, 0, Math.max(1,d.getIntrinsicWidth()), Math.max(1,d.getIntrinsicHeight())); matrix.mapRect(r);
            float dx = 0, dy = 0;
            if (r.width() <= getWidth()) dx = getWidth()/2f - r.centerX(); else if (r.left > 0) dx = -r.left; else if (r.right < getWidth()) dx = getWidth() - r.right;
            if (r.height() <= getHeight()) dy = getHeight()/2f - r.centerY(); else if (r.top > 0) dy = -r.top; else if (r.bottom < getHeight()) dy = getHeight() - r.bottom;
            matrix.postTranslate(dx, dy);
            notifyImageBoundsChanged();
        }

        @Override public boolean onTouchEvent(MotionEvent e) {
            if (pageAnimating) return true;
            scaleDetector.onTouchEvent(e);
            int action = e.getActionMasked();
            if (action == MotionEvent.ACTION_DOWN) {
                ViewerActivity.this.cancelPageAnimationsForTouch();
                if (velocityTracker != null) velocityTracker.recycle(); velocityTracker = VelocityTracker.obtain(); velocityTracker.addMovement(e);
                downX = lastX = e.getX(); downY = lastY = e.getY(); moved = false; paging = false;
                long now = SystemClock.uptimeMillis();
                secondTap = (now - lastTapUp <= DOUBLE_TAP_MS && distance(e.getX(), e.getY(), lastTapX, lastTapY) < dp(48));
                if (secondTap) { cancelSingleTap(); doubleTapZoomDrag = false; doubleTapStartY = e.getY(); doubleTapStartScale = userScale; }
                return true;
            }
            if (velocityTracker != null) velocityTracker.addMovement(e);
            if (action == MotionEvent.ACTION_MOVE) {
                float x=e.getX(), y=e.getY(); float dx=x-lastX, dy=y-lastY;
                if (Math.abs(x-downX)>touchSlop || Math.abs(y-downY)>touchSlop) moved=true;
                if (secondTap && !scaleDetector.isInProgress()) {
                    float totalY = y-doubleTapStartY;
                    if (Math.abs(totalY) > touchSlop) {
                        doubleTapZoomDrag = true;
                        // Up = zoom in, down = zoom out. Exponential response feels natural over the whole screen.
                        float factor = (float)Math.exp(-totalY / Math.max(220f, getHeight()*0.42f));
                        setUserScale(doubleTapStartScale * factor, downX, downY);
                    }
                } else if (scaleDetector.isInProgress()) {
                    // handled by ScaleGestureDetector
                } else if (!isAtFit()) {
                    pan(dx, dy);
                } else {
                    float totalX=x-downX, totalY=y-downY;
                    if (!paging && Math.abs(totalX)>touchSlop && Math.abs(totalX)>Math.abs(totalY)*1.15f) paging=true;
                    if (paging) {
                        int direction = totalX < 0 ? 1 : -1;
                        float resistance = (pageListener != null && pageListener.canPage(direction)) ? 1f : 0.23f;
                        float translation = totalX * resistance;
                        setTranslationX(translation);
                        if (pageListener != null) pageListener.onPageDrag(direction, translation);
                    }
                }
                lastX=x; lastY=y; return true;
            }
            if (action == MotionEvent.ACTION_UP || action == MotionEvent.ACTION_CANCEL) {
                float vx=0f; if (velocityTracker != null) { velocityTracker.computeCurrentVelocity(1000); vx=velocityTracker.getXVelocity(); velocityTracker.recycle(); velocityTracker=null; }
                if (secondTap) {
                    if (!doubleTapZoomDrag && action==MotionEvent.ACTION_UP) toggleOriginal(e.getX(), e.getY());
                    AppLog.d(ViewerActivity.this, doubleTapZoomDrag ? "ZOOM doubleTapHold end scale="+userScale : "ZOOM doubleTap toggle scale="+userScale);
                    secondTap=false; doubleTapZoomDrag=false; setTranslationX(0f); return true;
                }
                if (paging) {
                    float tx=getTranslationX(); int direction = tx<0 ? 1 : -1;
                    boolean commit = Math.abs(tx) > getWidth()*0.12f || Math.abs(vx)>550f;
                    if (commit && pageListener != null && pageListener.canPage(direction)) pageListener.onPage(direction, vx);
                    else {
                        if (pageListener != null) pageListener.onPageReset();
                        else animate().translationX(0f).setDuration(150).start();
                    }
                    paging=false; return true;
                }
                if (!moved && action==MotionEvent.ACTION_UP && !scaleDetector.isInProgress()) {
                    lastTapUp=SystemClock.uptimeMillis(); lastTapX=e.getX(); lastTapY=e.getY();
                    scheduleSingleTap();
                }
                return true;
            }
            return true;
        }

        private void scheduleSingleTap() {
            cancelSingleTap();
            pendingSingleTap = () -> { pendingSingleTap=null; if (pageListener!=null) pageListener.onSingleTap(); };
            mainHandler.postDelayed(pendingSingleTap, DOUBLE_TAP_MS + 20);
        }
        private void cancelSingleTap() { if (pendingSingleTap != null) { mainHandler.removeCallbacks(pendingSingleTap); pendingSingleTap=null; } }
        private float distance(float x1,float y1,float x2,float y2) { float dx=x1-x2, dy=y1-y2; return (float)Math.sqrt(dx*dx+dy*dy); }
    }
}
