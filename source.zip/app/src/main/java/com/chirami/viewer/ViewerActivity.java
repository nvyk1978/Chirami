package com.chirami.viewer;

import android.Manifest;
import android.app.Activity;
import android.content.ContentUris;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Color;
import android.graphics.ImageDecoder;
import android.graphics.Matrix;
import android.animation.ValueAnimator;
import android.graphics.RectF;
import android.graphics.drawable.AnimatedImageDrawable;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.graphics.pdf.PdfRenderer;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.ParcelFileDescriptor;
import android.os.SystemClock;
import android.provider.MediaStore;
import android.provider.OpenableColumns;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.animation.PathInterpolator;
import android.view.animation.DecelerateInterpolator;
import android.view.ScaleGestureDetector;
import android.view.VelocityTracker;
import android.view.View;
import android.view.ViewConfiguration;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicInteger;

public class ViewerActivity extends Activity {
    private static final int REQ_MEDIA = 1001;
    private static final long DOUBLE_TAP_MS = 300;

    private LinearLayout topBar;
    private LinearLayout bottomBar;
    private ChromeShadeOverlay shadeOverlay;
    private ZoomImageView imageView;
    private ImageView pagePreviewView;
    private TextView titleView;
    private TextView pageView;

    private ParcelFileDescriptor pdfFd;
    private PdfRenderer pdfRenderer;
    private PdfRenderer.Page pdfPage;

    private final List<MediaItem> siblings = new ArrayList<>();
    private int currentIndex = -1;
    private Uri currentUri;
    private String currentMime;
    private String currentName;

    private final ExecutorService decodeExecutor = Executors.newSingleThreadExecutor();
    private final ExecutorService scanExecutor = Executors.newSingleThreadExecutor();
    private final ExecutorService neighborExecutor = Executors.newFixedThreadPool(2);
    private final ExecutorService prefetchExecutor = Executors.newFixedThreadPool(2);
    private final Handler mainHandler = new Handler(Looper.getMainLooper());
    private final AtomicInteger decodeGeneration = new AtomicInteger();
    private final AtomicInteger prefetchGeneration = new AtomicInteger();
    private final AtomicInteger siblingGeneration = new AtomicInteger();
    private long launchStartedMs;
    private boolean firstFrameLogged = false;
    private boolean pageAnimating = false;
    private volatile Drawable previousPreviewDrawable;
    private volatile Drawable nextPreviewDrawable;
    private volatile MediaItem quickPreviousItem;
    private volatile MediaItem quickNextItem;
    private volatile boolean fullListReady = false;
    private int topShadeExtentPx;
    private int bottomShadeExtentPx;

    private static class MediaItem {
        final Uri uri;
        final String name;
        final String mime;
        MediaItem(Uri uri, String name, String mime) {
            this.uri = uri; this.name = name; this.mime = mime;
        }
    }

    private int dp(float value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        launchStartedMs = SystemClock.elapsedRealtime();
        super.onCreate(savedInstanceState);
        AppLog.d(this, "VIEWER onCreate action=" + getIntent().getAction() + " type=" + getIntent().getType() + " data=" + getIntent().getData());
        getWindow().setStatusBarColor(Color.BLACK);
        getWindow().setNavigationBarColor(Color.BLACK);
        buildUi();

        Uri uri = getIntent().getData();
        if (uri == null) {
            AppLog.d(this, "VIEWER no URI");
            Toast.makeText(this, "ファイルを開けませんでした", Toast.LENGTH_SHORT).show();
            finish();
            return;
        }

        currentUri = uri;
        currentName = resolveDisplayName(uri);
        currentMime = getIntent().getType();
        if (currentMime == null) currentMime = getContentResolver().getType(uri);
        AppLog.d(this, "VIEWER open +" + elapsed() + "ms name=" + currentName + " mime=" + currentMime + " uri=" + currentUri);

        // Most important rule in Chirami: render the tapped file first. Folder scanning is never allowed to delay it.
        showCurrentUri(false, 0);

        if (!isPdf(currentMime, uri)) {
            if (hasMediaPermission()) discoverSiblingImagesAsync();
            else requestMediaPermission();
        }
    }

    private long elapsed() { return SystemClock.elapsedRealtime() - launchStartedMs; }

    private void buildUi() {
        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(Color.BLACK);

        pagePreviewView = new ImageView(this);
        pagePreviewView.setBackgroundColor(Color.BLACK);
        pagePreviewView.setScaleType(ImageView.ScaleType.FIT_CENTER);
        pagePreviewView.setVisibility(View.GONE);
        root.addView(pagePreviewView, new FrameLayout.LayoutParams(-1, -1));

        imageView = new ZoomImageView();
        imageView.setBackgroundColor(Color.BLACK);
        imageView.setPageListener(new ZoomImageView.PageListener() {
            @Override public boolean canPage(int direction) { return canMoveSibling(direction); }
            @Override public void onPageDrag(int direction, float translationX) { showPagePreview(direction, translationX); }
            @Override public void onPageReset() { animatePageReset(); }
            @Override public void onPage(int direction, float velocityX) { animateToSibling(direction, velocityX); }
            @Override public void onSingleTap() { toggleChrome(); }
        });
        root.addView(imageView, new FrameLayout.LayoutParams(-1, -1));

        // Menus are kept away from the physical edges in dp. The previous request
        // was ~200px inward, then 50px back toward each edge; on this density that
        // is about 50dp. The translucent gray is not a detached band: it continues
        // without a gap all the way beyond the physical screen edge.
        final int chromeInset = dp(50);
        topShadeExtentPx = chromeInset + dp(60) + dp(24);
        bottomShadeExtentPx = chromeInset + dp(72) + dp(24);

        // One transparent full-screen overlay paints gray ONLY where the actual image
        // intersects the chrome zones. Letterbox/outside-image space stays default black.
        shadeOverlay = new ChromeShadeOverlay();
        root.addView(shadeOverlay, new FrameLayout.LayoutParams(-1, -1));

        topBar = new LinearLayout(this);
        topBar.setOrientation(LinearLayout.HORIZONTAL);
        topBar.setGravity(Gravity.CENTER_VERTICAL);
        topBar.setPadding(dp(8), 0, dp(8), 0);
        topBar.setBackgroundColor(Color.TRANSPARENT);

        TextView back = new TextView(this);
        back.setText("‹"); back.setTextColor(Color.WHITE); back.setTextSize(42); back.setGravity(Gravity.CENTER);
        back.setOnClickListener(v -> returnToCaller());
        topBar.addView(back, new LinearLayout.LayoutParams(dp(48), dp(60)));

        titleView = new TextView(this);
        titleView.setTextColor(Color.WHITE); titleView.setTextSize(19); titleView.setSingleLine(true);
        titleView.setEllipsize(android.text.TextUtils.TruncateAt.END); titleView.setGravity(Gravity.CENTER_VERTICAL);
        topBar.addView(titleView, new LinearLayout.LayoutParams(0, dp(60), 1f));

        pageView = new TextView(this);
        pageView.setTextColor(Color.WHITE); pageView.setTextSize(12); pageView.setGravity(Gravity.CENTER);
        topBar.addView(pageView, new LinearLayout.LayoutParams(dp(62), dp(60)));

        TextView info = new TextView(this);
        info.setText("ⓘ"); info.setTextColor(Color.WHITE); info.setTextSize(27); info.setGravity(Gravity.CENTER);
        info.setOnClickListener(v -> Toast.makeText(this, currentName == null ? "" : currentName, Toast.LENGTH_SHORT).show());
        topBar.addView(info, new LinearLayout.LayoutParams(dp(46), dp(60)));

        TextView more = new TextView(this);
        more.setText("⋮"); more.setTextColor(Color.WHITE); more.setTextSize(30); more.setGravity(Gravity.CENTER);
        more.setOnClickListener(v -> Toast.makeText(this, "リネーム・回転・リサイズ・トリミングは順次追加します", Toast.LENGTH_SHORT).show());
        topBar.addView(more, new LinearLayout.LayoutParams(dp(42), dp(60)));
        FrameLayout.LayoutParams topParams = new FrameLayout.LayoutParams(-1, dp(60), Gravity.TOP);
        topParams.topMargin = chromeInset;
        root.addView(topBar, topParams);


        bottomBar = new LinearLayout(this);
        bottomBar.setOrientation(LinearLayout.HORIZONTAL); bottomBar.setGravity(Gravity.CENTER);
        bottomBar.setPadding(dp(38), 0, dp(38), 0); bottomBar.setBackgroundColor(Color.TRANSPARENT);

        TextView edit = makeBottomAction("✎", "編集");
        edit.setOnClickListener(v -> Toast.makeText(this, "注釈・編集は次の段階で追加します", Toast.LENGTH_SHORT).show());
        bottomBar.addView(edit, new LinearLayout.LayoutParams(0, dp(72), 1f));

        TextView share = makeBottomAction("↗", "共有");
        share.setOnClickListener(v -> shareCurrent());
        bottomBar.addView(share, new LinearLayout.LayoutParams(0, dp(72), 1f));

        TextView delete = makeBottomAction("⌫", "削除");
        delete.setOnClickListener(v -> Toast.makeText(this, "削除は確認ダイアログ付きで追加します", Toast.LENGTH_SHORT).show());
        bottomBar.addView(delete, new LinearLayout.LayoutParams(0, dp(72), 1f));
        FrameLayout.LayoutParams bottomParams = new FrameLayout.LayoutParams(-1, dp(72), Gravity.BOTTOM);
        bottomParams.bottomMargin = chromeInset;
        root.addView(bottomBar, bottomParams);

        setContentView(root);
        AppLog.d(this, "VIEWER UI ready +" + elapsed() + "ms");
    }

    private void returnToCaller() {
        AppLog.d(this, "VIEWER returnToCaller taskRoot=" + isTaskRoot());
        try {
            // ViewerActivity has an empty taskAffinity, so finishing its affinity never
            // walks back into Chirami's launcher/settings task. It reveals the app that
            // launched ACTION_VIEW (file manager, browser, etc.).
            if (isTaskRoot()) finishAndRemoveTask();
            else finishAffinity();
        } catch (Throwable ignored) {
            finish();
        }
    }

    @Override
    public void onBackPressed() {
        returnToCaller();
    }

    private TextView makeBottomAction(String icon, String label) {
        TextView view = new TextView(this);
        view.setText(icon + "\n" + label); view.setTextColor(Color.WHITE); view.setTextSize(13);
        view.setGravity(Gravity.CENTER); view.setLines(2); return view;
    }

    private void toggleChrome() {
        boolean showing = topBar.getVisibility() == View.VISIBLE;
        topBar.setVisibility(showing ? View.GONE : View.VISIBLE);
        bottomBar.setVisibility(showing ? View.GONE : View.VISIBLE);
        if (shadeOverlay != null) {
            shadeOverlay.setChromeVisible(!showing);
        }
        if (!showing && imageView != null) imageView.notifyImageBoundsChanged();
        if (showing) {
            getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_FULLSCREEN | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION);
        } else {
            getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_VISIBLE);
        }
    }

    private void updateChromeShadeBounds(RectF imageBounds) {
        if (shadeOverlay != null) shadeOverlay.setImageBounds(imageBounds);
    }

    private class ChromeShadeOverlay extends View {
        private final Paint paint = new Paint();
        private final RectF bounds = new RectF();
        private boolean hasBounds = false;
        private boolean chromeVisible = true;

        ChromeShadeOverlay() {
            super(ViewerActivity.this);
            paint.setColor(Color.argb(150, 58, 51, 51));
            setClickable(false);
            setFocusable(false);
        }

        void setChromeVisible(boolean visible) {
            chromeVisible = visible;
            invalidate();
        }

        void setImageBounds(RectF imageBounds) {
            if (imageBounds == null) { hasBounds = false; }
            else { bounds.set(imageBounds); hasBounds = true; }
            invalidate();
        }

        @Override protected void onDraw(Canvas canvas) {
            super.onDraw(canvas);
            if (!chromeVisible || !hasBounds) return;
            float w = getWidth(), h = getHeight();
            float left = Math.max(0f, bounds.left);
            float right = Math.min(w, bounds.right);
            if (right <= left) return;

            // Top gray exists only inside the actual displayed image rectangle.
            float topA = Math.max(0f, bounds.top);
            float topB = Math.min(Math.min((float)topShadeExtentPx, h), bounds.bottom);
            if (topB > topA) canvas.drawRect(left, topA, right, topB, paint);

            // Bottom gray follows the same rule. Everything outside image remains black.
            float bandStart = Math.max(0f, h - bottomShadeExtentPx);
            float bottomA = Math.max(bandStart, bounds.top);
            float bottomB = Math.min(h, bounds.bottom);
            if (bottomB > bottomA) canvas.drawRect(left, bottomA, right, bottomB, paint);
        }
    }

    private void shareCurrent() {
        if (currentUri == null) return;
        try {
            android.content.Intent share = new android.content.Intent(android.content.Intent.ACTION_SEND);
            share.setType(currentMime == null ? "image/*" : currentMime);
            share.putExtra(android.content.Intent.EXTRA_STREAM, currentUri);
            share.addFlags(android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION);
            startActivity(android.content.Intent.createChooser(share, "共有"));
        } catch (Throwable e) { Toast.makeText(this, "共有できませんでした", Toast.LENGTH_SHORT).show(); }
    }

    private void showCurrentUri(boolean fromSwipe, int direction) {
        closePdf();
        titleView.setText(currentName == null ? resolveDisplayName(currentUri) : currentName);
        if (isPdf(currentMime, currentUri)) {
            openPdf(currentUri);
        } else {
            openImageAsync(currentUri, fromSwipe, direction);
            updatePositionLabel();
        }
    }

    private void openImageAsync(Uri uri, boolean fromSwipe, int direction) {
        final int generation = decodeGeneration.incrementAndGet();
        final long begin = SystemClock.elapsedRealtime();
        AppLog.d(this, "IMAGE decode queued +" + elapsed() + "ms uri=" + uri);
        decodeExecutor.execute(() -> {
            try {
                ImageDecoder.Source source = ImageDecoder.createSource(getContentResolver(), uri);
                Drawable drawable = ImageDecoder.decodeDrawable(source, (decoder, info, src) -> {
                    // Keep ImageDecoder's default allocator/memory policy. Forcing software + LOW_RAM
                    // made adjacent full-resolution images substantially slower to become swipe-ready.
                });
                long decodeMs = SystemClock.elapsedRealtime() - begin;
                mainHandler.post(() -> {
                    if (generation != decodeGeneration.get() || isFinishing()) return;
                    imageView.setImageForViewer(drawable);
                    if (fromSwipe) {
                        float startX = direction > 0 ? imageView.getWidth() * 0.18f : -imageView.getWidth() * 0.18f;
                        imageView.setTranslationX(startX);
                        imageView.setAlpha(0.82f);
                        imageView.animate().translationX(0f).alpha(1f).setDuration(130).withEndAction(() -> pageAnimating = false).start();
                    } else pageAnimating = false;
                    if (drawable instanceof AnimatedImageDrawable) ((AnimatedImageDrawable) drawable).start();
                    AppLog.d(this, "IMAGE first paint +" + elapsed() + "ms decode=" + decodeMs + "ms class=" + drawable.getClass().getSimpleName());
                    if (!firstFrameLogged) { firstFrameLogged = true; AppLog.d(this, "PERF FIRST_IMAGE_VISIBLE=" + elapsed() + "ms"); }
                });
            } catch (Throwable e) {
                AppLog.d(this, "IMAGE decode ERROR +" + elapsed() + "ms " + e);
                mainHandler.post(() -> {
                    if (generation == decodeGeneration.get()) {
                        pageAnimating = false;
                        Toast.makeText(this, "この画像を表示できませんでした", Toast.LENGTH_LONG).show();
                    }
                });
            }
        });
    }

    private boolean canMoveSibling(int direction) {
        if (pageAnimating) return false;
        if (fullListReady && currentIndex >= 0) {
            int next = currentIndex + direction;
            return next >= 0 && next < siblings.size();
        }
        return direction > 0 ? quickNextItem != null : quickPreviousItem != null;
    }

    private MediaItem itemForDirection(int direction) {
        if (fullListReady && currentIndex >= 0) {
            int next = currentIndex + direction;
            return (next >= 0 && next < siblings.size()) ? siblings.get(next) : null;
        }
        return direction > 0 ? quickNextItem : quickPreviousItem;
    }

    private Drawable previewForDirection(int direction) {
        return direction > 0 ? nextPreviewDrawable : previousPreviewDrawable;
    }

    private void showPagePreview(int direction, float translationX) {
        if (!canMoveSibling(direction) || pagePreviewView == null) {
            hidePagePreview();
            return;
        }
        Drawable preview = previewForDirection(direction);
        if (preview == null) {
            pagePreviewView.setVisibility(View.GONE);
            return;
        }
        if (pagePreviewView.getDrawable() != preview) pagePreviewView.setImageDrawable(preview);
        imageView.setLayerType(View.LAYER_TYPE_HARDWARE, null);
        pagePreviewView.setLayerType(View.LAYER_TYPE_HARDWARE, null);
        pagePreviewView.setVisibility(View.VISIBLE);
        float start = direction > 0 ? imageView.getWidth() : -imageView.getWidth();
        pagePreviewView.setTranslationX(start + translationX);
        pagePreviewView.setAlpha(1f);
    }

    private void hidePagePreview() {
        if (pagePreviewView == null) return;
        pagePreviewView.animate().cancel();
        pagePreviewView.setVisibility(View.GONE);
        pagePreviewView.setTranslationX(0f);
        imageView.setLayerType(View.LAYER_TYPE_NONE, null);
        pagePreviewView.setLayerType(View.LAYER_TYPE_NONE, null);
    }

    private final PathInterpolator pageInterpolator = new PathInterpolator(0.20f, 0f, 0f, 1f);

    private void cancelPageAnimationsForTouch() {
        imageView.animate().cancel();
        if (pagePreviewView != null) pagePreviewView.animate().cancel();
        // A new finger-down owns X from this point onward. Never let an old
        // ViewPropertyAnimator continue writing translationX during ACTION_MOVE.
        imageView.setTranslationX(0f);
        hidePagePreview();
        pageAnimating = false;
    }

    private void animatePageReset() {
        float tx = imageView.getTranslationX();
        if (Math.abs(tx) < 1f) { hidePagePreview(); return; }
        int direction = tx < 0 ? 1 : -1;
        float previewTarget = direction > 0 ? imageView.getWidth() : -imageView.getWidth();
        imageView.setLayerType(View.LAYER_TYPE_HARDWARE, null);
        pagePreviewView.setLayerType(View.LAYER_TYPE_HARDWARE, null);
        imageView.animate().cancel();
        pagePreviewView.animate().cancel();
        imageView.animate().translationX(0f).setDuration(150).setInterpolator(pageInterpolator).start();
        if (pagePreviewView.getVisibility() == View.VISIBLE) {
            pagePreviewView.animate().translationX(previewTarget).setDuration(150).setInterpolator(pageInterpolator)
                    .withEndAction(this::hidePagePreview).start();
        } else {
            mainHandler.postDelayed(this::hidePagePreview, 155);
        }
    }

    private long pageDuration(float velocityX, float remainingPx) {
        float width = Math.max(1f, imageView.getWidth());
        if (Math.abs(velocityX) > 900f) {
            long byVelocity = (long)(1000f * remainingPx / Math.max(1200f, Math.abs(velocityX)));
            return Math.max(75L, Math.min(165L, byVelocity));
        }
        return (long)(105f + 60f * Math.min(1f, remainingPx / width));
    }

    private void animateToSibling(int direction, float velocityX) {
        MediaItem targetItem = itemForDirection(direction);
        if (targetItem == null || !canMoveSibling(direction)) {
            animatePageReset();
            return;
        }
        pageAnimating = true;
        final int targetIndex = (fullListReady && currentIndex >= 0) ? currentIndex + direction : -1;
        Drawable preview = previewForDirection(direction);
        float target = direction > 0 ? -imageView.getWidth() : imageView.getWidth();
        float remaining = Math.abs(target - imageView.getTranslationX());
        long duration = pageDuration(velocityX, remaining);

        imageView.setLayerType(View.LAYER_TYPE_HARDWARE, null);
        pagePreviewView.setLayerType(View.LAYER_TYPE_HARDWARE, null);
        imageView.animate().cancel();
        pagePreviewView.animate().cancel();

        if (preview != null) {
            if (pagePreviewView.getVisibility() != View.VISIBLE || pagePreviewView.getDrawable() != preview) {
                pagePreviewView.setImageDrawable(preview);
                pagePreviewView.setVisibility(View.VISIBLE);
                pagePreviewView.setTranslationX(direction > 0 ? imageView.getWidth() : -imageView.getWidth());
            }
            pagePreviewView.animate().translationX(0f).setDuration(duration).setInterpolator(pageInterpolator).start();
            imageView.animate().translationX(target).setDuration(duration).setInterpolator(pageInterpolator).withEndAction(() -> {
                currentUri = targetItem.uri; currentName = targetItem.name; currentMime = targetItem.mime;
                if (targetIndex >= 0 && fullListReady) currentIndex = targetIndex;

                // Keep the centered preview covering the hand-off for one display frame.
                // The main ImageView gets its final FIT matrix while still off-screen, so
                // users never see an old matrix / temporary wrong-size frame.
                imageView.setImageForViewerKeepingTranslation(preview);
                imageView.setTranslationX(0f);
                titleView.setText(currentName);
                updatePositionLabel();
                pagePreviewView.postOnAnimation(() -> {
                    hidePagePreview();
                    pageAnimating = false;
                });
                AppLog.d(this, "SWIPE move cached +" + elapsed() + "ms direction=" + direction + " duration=" + duration);

                if (fullListReady) prefetchAdjacent();
                else discoverSiblingImagesAsync();
            }).start();
        } else {
            imageView.animate().translationX(target).setDuration(duration).setInterpolator(pageInterpolator).withEndAction(() -> {
                currentUri = targetItem.uri; currentName = targetItem.name; currentMime = targetItem.mime;
                if (targetIndex >= 0 && fullListReady) currentIndex = targetIndex;
                imageView.setTranslationX(0f);
                AppLog.d(this, "SWIPE move decode +" + elapsed() + "ms direction=" + direction);
                showCurrentUri(true, direction);
                discoverSiblingImagesAsync();
            }).start();
        }
    }

    private Drawable decodeDrawable(Uri uri) throws IOException {
        ImageDecoder.Source source = ImageDecoder.createSource(getContentResolver(), uri);
        return ImageDecoder.decodeDrawable(source, (decoder, info, src) -> {
            // Default allocator is intentionally used for smoother adjacent-image prefetch.
        });
    }

    private void prefetchQuick(MediaItem item, int direction, int generation) {
        if (item == null) return;
        prefetchExecutor.execute(() -> {
            long started = SystemClock.elapsedRealtime();
            try {
                Drawable d = decodeDrawable(item.uri);
                mainHandler.post(() -> {
                    if (generation != prefetchGeneration.get() || isFinishing()) return;
                    if (direction > 0) nextPreviewDrawable = d; else previousPreviewDrawable = d;
                    AppLog.d(this, "PREFETCH quick " + (direction > 0 ? "next" : "prev") + " ready +" + elapsed() + "ms took=" + (SystemClock.elapsedRealtime()-started) + "ms");
                });
            } catch (Throwable e) { AppLog.d(this, "PREFETCH quick error " + e); }
        });
    }

    private void prefetchAdjacent() {
        final int generation = prefetchGeneration.incrementAndGet();
        final int index = currentIndex;
        if (index < 0 || siblings.isEmpty()) {
            previousPreviewDrawable = null;
            nextPreviewDrawable = null;
            return;
        }
        previousPreviewDrawable = null;
        nextPreviewDrawable = null;
        final MediaItem prev = index > 0 ? siblings.get(index - 1) : null;
        final MediaItem next = index + 1 < siblings.size() ? siblings.get(index + 1) : null;

        if (prev != null) prefetchExecutor.execute(() -> {
            long started = SystemClock.elapsedRealtime();
            try {
                Drawable d = decodeDrawable(prev.uri);
                mainHandler.post(() -> {
                    if (generation != prefetchGeneration.get() || isFinishing()) return;
                    previousPreviewDrawable = d;
                    AppLog.d(this, "PREFETCH prev ready +" + elapsed() + "ms took=" + (SystemClock.elapsedRealtime()-started) + "ms");
                });
            } catch (Throwable e) { AppLog.d(this, "PREFETCH prev error " + e); }
        });
        if (next != null) prefetchExecutor.execute(() -> {
            long started = SystemClock.elapsedRealtime();
            try {
                Drawable d = decodeDrawable(next.uri);
                mainHandler.post(() -> {
                    if (generation != prefetchGeneration.get() || isFinishing()) return;
                    nextPreviewDrawable = d;
                    AppLog.d(this, "PREFETCH next ready +" + elapsed() + "ms took=" + (SystemClock.elapsedRealtime()-started) + "ms");
                });
            } catch (Throwable e) { AppLog.d(this, "PREFETCH next error " + e); }
        });
    }

    private void openPdf(Uri uri) {
        // PDF path remains synchronous for now; image opening is the performance priority for this build.
        try {
            AppLog.d(this, "PDF open begin uri=" + uri);
            pdfFd = getContentResolver().openFileDescriptor(uri, "r");
            if (pdfFd == null) throw new IOException("No file descriptor");
            pdfRenderer = new PdfRenderer(pdfFd);
            if (pdfRenderer.getPageCount() == 0) throw new IOException("Empty PDF");
            renderPdfPage(0);
        } catch (Throwable e) { AppLog.d(this, "PDF open ERROR " + e); Toast.makeText(this, "PDFを表示できませんでした", Toast.LENGTH_LONG).show(); }
    }

    private void renderPdfPage(int index) {
        closePdfPage(); pdfPage = pdfRenderer.openPage(index);
        int screenWidth = Math.max(1, getResources().getDisplayMetrics().widthPixels);
        float ratio = (float) pdfPage.getHeight() / (float) pdfPage.getWidth();
        int bitmapWidth = Math.min(screenWidth * 2, 2200); int bitmapHeight = Math.max(1, Math.round(bitmapWidth * ratio));
        Bitmap bitmap = Bitmap.createBitmap(bitmapWidth, bitmapHeight, Bitmap.Config.ARGB_8888); bitmap.eraseColor(Color.WHITE);
        pdfPage.render(bitmap, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY);
        imageView.setImageForViewer(new android.graphics.drawable.BitmapDrawable(getResources(), bitmap));
        pageView.setText((index + 1) + " / " + pdfRenderer.getPageCount());
    }

    private void updatePositionLabel() {
        if (currentIndex >= 0 && siblings.size() > 1) pageView.setText((currentIndex + 1) + " / " + siblings.size());
        else pageView.setText("");
    }

    private boolean hasMediaPermission() {
        if (Build.VERSION.SDK_INT >= 33) return checkSelfPermission(Manifest.permission.READ_MEDIA_IMAGES) == PackageManager.PERMISSION_GRANTED;
        return checkSelfPermission(Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED;
    }

    private void requestMediaPermission() {
        if (Build.VERSION.SDK_INT >= 33) requestPermissions(new String[]{Manifest.permission.READ_MEDIA_IMAGES}, REQ_MEDIA);
        else requestPermissions(new String[]{Manifest.permission.READ_EXTERNAL_STORAGE}, REQ_MEDIA);
    }

    @Override public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQ_MEDIA && grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            AppLog.d(this, "PERMISSION media granted"); discoverSiblingImagesAsync();
        } else if (requestCode == REQ_MEDIA) AppLog.d(this, "PERMISSION media denied");
    }

    private MediaItem queryNeighbor(String relativePath, String seedName, boolean next) {
        String[] projection = new String[]{MediaStore.Images.Media._ID, MediaStore.Images.Media.DISPLAY_NAME, MediaStore.Images.Media.MIME_TYPE};
        String op = next ? ">" : "<";
        String order = next ? " ASC" : " DESC";
        String selection = MediaStore.Images.Media.RELATIVE_PATH + "=? AND " + MediaStore.Images.Media.DISPLAY_NAME + " " + op + " ? COLLATE NOCASE";
        String sort = MediaStore.Images.Media.DISPLAY_NAME + " COLLATE NOCASE" + order + " LIMIT 1";
        try (Cursor c = getContentResolver().query(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, projection, selection, new String[]{relativePath, seedName}, sort)) {
            if (c != null && c.moveToFirst()) {
                long id = c.getLong(c.getColumnIndexOrThrow(MediaStore.Images.Media._ID));
                String name = c.getString(c.getColumnIndexOrThrow(MediaStore.Images.Media.DISPLAY_NAME));
                String mime = c.getString(c.getColumnIndexOrThrow(MediaStore.Images.Media.MIME_TYPE));
                return new MediaItem(ContentUris.withAppendedId(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, id), name, mime);
            }
        } catch (Throwable first) {
            // Some MediaStore implementations reject LIMIT in sortOrder. Retry without it;
            // moveToFirst still avoids materialising the result set in Java.
            String fallbackSort = MediaStore.Images.Media.DISPLAY_NAME + " COLLATE NOCASE" + order;
            try (Cursor c = getContentResolver().query(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, projection, selection, new String[]{relativePath, seedName}, fallbackSort)) {
                if (c != null && c.moveToFirst()) {
                    long id = c.getLong(c.getColumnIndexOrThrow(MediaStore.Images.Media._ID));
                    String name = c.getString(c.getColumnIndexOrThrow(MediaStore.Images.Media.DISPLAY_NAME));
                    String mime = c.getString(c.getColumnIndexOrThrow(MediaStore.Images.Media.MIME_TYPE));
                    return new MediaItem(ContentUris.withAppendedId(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, id), name, mime);
                }
            } catch (Throwable second) { AppLog.d(this, "SIBLINGS neighbor query error " + second); }
        }
        return null;
    }

    private void discoverSiblingImagesAsync() {
        final int generation = siblingGeneration.incrementAndGet();
        final int prefetchToken = prefetchGeneration.incrementAndGet();
        final Uri seedUri = currentUri;
        final String seedName = currentName;
        final String seedMime = currentMime;

        fullListReady = false;
        quickPreviousItem = null; quickNextItem = null;
        previousPreviewDrawable = null; nextPreviewDrawable = null;

        scanExecutor.execute(() -> {
            try {
                AppLog.d(this, "SIBLINGS locate begin +" + elapsed() + "ms seed=" + seedName);
                String relativePath = resolveRelativePath(seedUri);
                if (generation != siblingGeneration.get()) return;
                if (relativePath == null || relativePath.isEmpty()) {
                    AppLog.d(this, "SIBLINGS no relative path +" + elapsed() + "ms");
                    return;
                }
                if (!relativePath.endsWith("/")) relativePath += "/";
                final String path = relativePath;
                AppLog.d(this, "SIBLINGS path=" + path + " +" + elapsed() + "ms");

                // Highest priority: previous and next are queried IN PARALLEL. Each side
                // becomes pageable immediately when its URI is known; we never wait for
                // the opposite side or the complete folder list.
                neighborExecutor.execute(() -> {
                    MediaItem item = queryNeighbor(path, seedName, false);
                    if (generation != siblingGeneration.get()) return;
                    mainHandler.post(() -> {
                        if (generation != siblingGeneration.get() || isFinishing()) return;
                        quickPreviousItem = item;
                        AppLog.d(this, "SIBLINGS quick prev +" + elapsed() + "ms ready=" + (item != null));
                        if (item != null) prefetchQuick(item, -1, prefetchToken);
                    });
                });
                neighborExecutor.execute(() -> {
                    MediaItem item = queryNeighbor(path, seedName, true);
                    if (generation != siblingGeneration.get()) return;
                    mainHandler.post(() -> {
                        if (generation != siblingGeneration.get() || isFinishing()) return;
                        quickNextItem = item;
                        AppLog.d(this, "SIBLINGS quick next +" + elapsed() + "ms ready=" + (item != null));
                        if (item != null) prefetchQuick(item, 1, prefetchToken);
                    });
                });

                // Give the two LIMIT-1 queries a head start before the heavy full-folder
                // cursor. This avoids ContentProvider contention during the user's first swipe.
                mainHandler.postDelayed(() -> {
                    if (generation != siblingGeneration.get() || isFinishing()) return;
                    scanExecutor.execute(() -> buildFullSiblingList(generation, seedName, path));
                }, 280L);
            } catch (Throwable e) { AppLog.d(this, "SIBLINGS locate error +" + elapsed() + "ms " + e); }
        });
    }

    private void buildFullSiblingList(int generation, String seedName, String relativePath) {
        long started = SystemClock.elapsedRealtime();
        try {
            String[] projection = new String[]{MediaStore.Images.Media._ID, MediaStore.Images.Media.DISPLAY_NAME, MediaStore.Images.Media.MIME_TYPE};
            String selection = MediaStore.Images.Media.RELATIVE_PATH + "=?";
            String sort = MediaStore.Images.Media.DISPLAY_NAME + " COLLATE NOCASE ASC";
            ArrayList<MediaItem> found = new ArrayList<>();
            try (Cursor c = getContentResolver().query(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, projection, selection, new String[]{relativePath}, sort)) {
                if (c != null) {
                    int idCol = c.getColumnIndexOrThrow(MediaStore.Images.Media._ID);
                    int nameCol = c.getColumnIndexOrThrow(MediaStore.Images.Media.DISPLAY_NAME);
                    int mimeCol = c.getColumnIndexOrThrow(MediaStore.Images.Media.MIME_TYPE);
                    while (c.moveToNext()) {
                        if (generation != siblingGeneration.get()) return;
                        long id = c.getLong(idCol); String name = c.getString(nameCol); String mime = c.getString(mimeCol);
                        found.add(new MediaItem(ContentUris.withAppendedId(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, id), name, mime));
                    }
                }
            }
            mainHandler.post(() -> {
                if (generation != siblingGeneration.get() || isFinishing()) return;
                String activeName = currentName;
                siblings.clear(); siblings.addAll(found); currentIndex = -1;
                for (int i = 0; i < siblings.size(); i++) if (sameName(siblings.get(i).name, activeName)) { currentIndex = i; break; }
                fullListReady = currentIndex >= 0;
                AppLog.d(this, "SIBLINGS full ready +" + elapsed() + "ms scan=" + (SystemClock.elapsedRealtime()-started) + "ms found=" + siblings.size() + " currentIndex=" + currentIndex);
                updatePositionLabel();
                if (fullListReady) prefetchAdjacent();
            });
        } catch (Throwable e) { AppLog.d(this, "SIBLINGS full error +" + elapsed() + "ms " + e); }
    }

    private String resolveRelativePath(Uri uri) {
        // Some file managers (including Solid Explorer) expose a provider URI whose path contains
        // the actual shared-storage path, but do not implement RELATIVE_PATH on that provider.
        try {
            String rawPath = uri.getPath();
            if (rawPath != null) {
                String marker = "/storage/emulated/0/";
                int idx = rawPath.indexOf(marker);
                if (idx >= 0) {
                    String relativeFile = rawPath.substring(idx + marker.length());
                    int slash = relativeFile.lastIndexOf('/');
                    if (slash >= 0) {
                        String inferred = relativeFile.substring(0, slash + 1);
                        AppLog.d(this, "SIBLINGS inferred path from provider=" + inferred);
                        return inferred;
                    }
                }
            }
        } catch (Throwable e) { AppLog.d(this, "SIBLINGS provider path parse error " + e); }

        try (Cursor c = getContentResolver().query(uri, new String[]{MediaStore.MediaColumns.RELATIVE_PATH}, null, null, null)) {
            if (c != null && c.moveToFirst()) {
                int col = c.getColumnIndex(MediaStore.MediaColumns.RELATIVE_PATH);
                if (col >= 0) {
                    String v = c.getString(col);
                    if (v != null && !v.isEmpty()) return v;
                }
            }
        } catch (Throwable e) { AppLog.d(this, "SIBLINGS seed RELATIVE_PATH unavailable " + e.getClass().getSimpleName()); }

        String name = resolveDisplayName(uri); if (name == null) return null;
        try (Cursor c = getContentResolver().query(MediaStore.Images.Media.EXTERNAL_CONTENT_URI,
                new String[]{MediaStore.Images.Media.RELATIVE_PATH, MediaStore.Images.Media.DISPLAY_NAME},
                MediaStore.Images.Media.DISPLAY_NAME + "=?", new String[]{name}, MediaStore.Images.Media.DATE_MODIFIED + " DESC")) {
            if (c != null && c.moveToFirst()) {
                int col = c.getColumnIndex(MediaStore.Images.Media.RELATIVE_PATH);
                if (col >= 0) return c.getString(col);
            }
        } catch (Throwable e) { AppLog.d(this, "SIBLINGS MediaStore name lookup error " + e); }
        return null;
    }

    private boolean sameName(String a, String b) { return a != null && b != null && a.equalsIgnoreCase(b); }
    private boolean isPdf(String mime, Uri uri) { return "application/pdf".equalsIgnoreCase(mime) || (uri != null && uri.toString().toLowerCase().endsWith(".pdf")); }

    private String resolveDisplayName(Uri uri) {
        String name = null;
        if ("content".equals(uri.getScheme())) {
            try (Cursor cursor = getContentResolver().query(uri, new String[]{OpenableColumns.DISPLAY_NAME}, null, null, null)) {
                if (cursor != null && cursor.moveToFirst()) { int index = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME); if (index >= 0) name = cursor.getString(index); }
            } catch (Exception ignored) { }
        }
        if (name == null || name.isEmpty()) name = uri.getLastPathSegment();
        return name == null ? "Chirami" : name;
    }

    private void closePdfPage() { if (pdfPage != null) { pdfPage.close(); pdfPage = null; } }
    private void closePdf() {
        closePdfPage(); if (pdfRenderer != null) { pdfRenderer.close(); pdfRenderer = null; }
        if (pdfFd != null) { try { pdfFd.close(); } catch (IOException ignored) { } pdfFd = null; }
    }

    @Override protected void onDestroy() {
        AppLog.d(this, "VIEWER onDestroy"); closePdf(); decodeGeneration.incrementAndGet(); decodeExecutor.shutdownNow(); scanExecutor.shutdownNow(); neighborExecutor.shutdownNow(); prefetchExecutor.shutdownNow(); super.onDestroy();
    }

    /** Lightweight zoom/pan/page view. No external image-view dependency: keeps Chirami small and startup cheap. */
    private class ZoomImageView extends ImageView {
        interface PageListener { boolean canPage(int direction); void onPageDrag(int direction, float translationX); void onPageReset(); void onPage(int direction, float velocityX); void onSingleTap(); }
        private PageListener pageListener;
        private final Matrix matrix = new Matrix();
        private final float[] values = new float[9];
        private final ScaleGestureDetector scaleDetector;
        private float fitScale = 1f;
        private float userScale = 1f;
        private float lastX, lastY, downX, downY;
        private long lastTapUp = 0;
        private float lastTapX, lastTapY;
        private boolean secondTap = false;
        private boolean doubleTapZoomDrag = false;
        private float doubleTapStartY, doubleTapStartScale;
        private boolean paging = false;
        private boolean moved = false;
        private VelocityTracker velocityTracker;
        private final int touchSlop = ViewConfiguration.get(ViewerActivity.this).getScaledTouchSlop();
        private Runnable pendingSingleTap;

        ZoomImageView() {
            super(ViewerActivity.this);
            setScaleType(ScaleType.MATRIX);
            setClickable(true);
            scaleDetector = new ScaleGestureDetector(ViewerActivity.this, new ScaleGestureDetector.SimpleOnScaleGestureListener() {
                @Override public boolean onScaleBegin(ScaleGestureDetector detector) { paging = false; cancelSingleTap(); if (zoomAnimator != null) zoomAnimator.cancel(); return true; }
                @Override public boolean onScale(ScaleGestureDetector detector) {
                    float factor = detector.getScaleFactor();
                    setUserScale(userScale * factor, detector.getFocusX(), detector.getFocusY());
                    return true;
                }
            });
        }

        void setPageListener(PageListener listener) { pageListener = listener; }

        void setImageForViewer(Drawable drawable) {
            setTranslationX(0f); setAlpha(1f);
            setImageForViewerKeepingTranslation(drawable);
        }

        void setImageForViewerKeepingTranslation(Drawable drawable) {
            super.setImageDrawable(drawable);
            // Compute the final FIT matrix synchronously whenever the view is measured.
            // This prevents a temporary frame rendered with the previous image's matrix.
            if (getWidth() > 0 && getHeight() > 0) resetToFit();
            else post(this::resetToFit);
        }

        private void resetToFit() {
            Drawable d = getDrawable(); if (d == null || getWidth() <= 0 || getHeight() <= 0) return;
            int iw = Math.max(1, d.getIntrinsicWidth()); int ih = Math.max(1, d.getIntrinsicHeight());
            fitScale = Math.min((float)getWidth()/iw, (float)getHeight()/ih);
            if (!Float.isFinite(fitScale) || fitScale <= 0f) fitScale = 1f;
            userScale = fitScale;
            matrix.reset();
            matrix.postScale(fitScale, fitScale);
            matrix.postTranslate((getWidth()-iw*fitScale)/2f, (getHeight()-ih*fitScale)/2f);
            setImageMatrix(matrix);
            notifyImageBoundsChanged();
        }

        void notifyImageBoundsChanged() {
            Drawable d = getDrawable(); if (d == null) return;
            RectF r = new RectF(0, 0, Math.max(1,d.getIntrinsicWidth()), Math.max(1,d.getIntrinsicHeight()));
            matrix.mapRect(r);
            ViewerActivity.this.updateChromeShadeBounds(r);
        }

        private void setUserScale(float target, float focusX, float focusY) {
            float max = Math.max(8f, fitScale * 12f);
            target = Math.max(fitScale, Math.min(max, target));
            float factor = target / userScale;
            matrix.postScale(factor, factor, focusX, focusY);
            userScale = target;
            constrain(); setImageMatrix(matrix);
        }

        private boolean isAtFit() { return userScale <= fitScale * 1.015f; }

        private ValueAnimator zoomAnimator;

        private void toggleOriginal(float x, float y) {
            final float start = userScale;
            final boolean zoomingIn = Math.abs(userScale - fitScale) < Math.max(0.02f, fitScale * 0.02f);
            final float target = zoomingIn ? Math.max(1f, fitScale) : fitScale;
            if (Math.abs(target - start) < 0.001f) return;
            if (zoomAnimator != null) zoomAnimator.cancel();
            zoomAnimator = ValueAnimator.ofFloat(start, target);
            zoomAnimator.setDuration(210L);
            zoomAnimator.setInterpolator(new DecelerateInterpolator(1.8f));
            zoomAnimator.addUpdateListener(a -> setUserScale((float)a.getAnimatedValue(), x, y));
            zoomAnimator.addListener(new android.animation.AnimatorListenerAdapter() {
                @Override public void onAnimationEnd(android.animation.Animator animation) {
                    if (!zoomingIn) resetToFit();
                    zoomAnimator = null;
                }
                @Override public void onAnimationCancel(android.animation.Animator animation) { zoomAnimator = null; }
            });
            zoomAnimator.start();
            AppLog.d(ViewerActivity.this, "ZOOM doubleTap animate " + start + " -> " + target + " fit=" + fitScale);
        }

        private void pan(float dx, float dy) { matrix.postTranslate(dx, dy); constrain(); setImageMatrix(matrix); }

        private void constrain() {
            Drawable d = getDrawable(); if (d == null) return;
            RectF r = new RectF(0, 0, Math.max(1,d.getIntrinsicWidth()), Math.max(1,d.getIntrinsicHeight())); matrix.mapRect(r);
            float dx = 0, dy = 0;
            if (r.width() <= getWidth()) dx = getWidth()/2f - r.centerX(); else if (r.left > 0) dx = -r.left; else if (r.right < getWidth()) dx = getWidth() - r.right;
            if (r.height() <= getHeight()) dy = getHeight()/2f - r.centerY(); else if (r.top > 0) dy = -r.top; else if (r.bottom < getHeight()) dy = getHeight() - r.bottom;
            matrix.postTranslate(dx, dy);
            notifyImageBoundsChanged();
        }

        @Override public boolean onTouchEvent(MotionEvent e) {
            if (pageAnimating) return true;
            scaleDetector.onTouchEvent(e);
            int action = e.getActionMasked();
            if (action == MotionEvent.ACTION_DOWN) {
                ViewerActivity.this.cancelPageAnimationsForTouch();
                if (velocityTracker != null) velocityTracker.recycle(); velocityTracker = VelocityTracker.obtain(); velocityTracker.addMovement(e);
                downX = lastX = e.getX(); downY = lastY = e.getY(); moved = false; paging = false;
                long now = SystemClock.uptimeMillis();
                secondTap = (now - lastTapUp <= DOUBLE_TAP_MS && distance(e.getX(), e.getY(), lastTapX, lastTapY) < dp(48));
                if (secondTap) { cancelSingleTap(); doubleTapZoomDrag = false; doubleTapStartY = e.getY(); doubleTapStartScale = userScale; }
                return true;
            }
            if (velocityTracker != null) velocityTracker.addMovement(e);
            if (action == MotionEvent.ACTION_MOVE) {
                float x=e.getX(), y=e.getY(); float dx=x-lastX, dy=y-lastY;
                if (Math.abs(x-downX)>touchSlop || Math.abs(y-downY)>touchSlop) moved=true;
                if (secondTap && !scaleDetector.isInProgress()) {
                    float totalY = y-doubleTapStartY;
                    if (Math.abs(totalY) > touchSlop) {
                        doubleTapZoomDrag = true;
                        // Up = zoom in, down = zoom out. Exponential response feels natural over the whole screen.
                        float factor = (float)Math.exp(-totalY / Math.max(220f, getHeight()*0.42f));
                        setUserScale(doubleTapStartScale * factor, downX, downY);
                    }
                } else if (scaleDetector.isInProgress()) {
                    // handled by ScaleGestureDetector
                } else if (!isAtFit()) {
                    pan(dx, dy);
                } else {
                    float totalX=x-downX, totalY=y-downY;
                    if (!paging && Math.abs(totalX)>touchSlop && Math.abs(totalX)>Math.abs(totalY)*1.15f) paging=true;
                    if (paging) {
                        int direction = totalX < 0 ? 1 : -1;
                        float resistance = (pageListener != null && pageListener.canPage(direction)) ? 1f : 0.23f;
                        float translation = totalX * resistance;
                        setTranslationX(translation);
                        if (pageListener != null) pageListener.onPageDrag(direction, translation);
                    }
                }
                lastX=x; lastY=y; return true;
            }
            if (action == MotionEvent.ACTION_UP || action == MotionEvent.ACTION_CANCEL) {
                float vx=0f; if (velocityTracker != null) { velocityTracker.computeCurrentVelocity(1000); vx=velocityTracker.getXVelocity(); velocityTracker.recycle(); velocityTracker=null; }
                if (secondTap) {
                    if (!doubleTapZoomDrag && action==MotionEvent.ACTION_UP) toggleOriginal(e.getX(), e.getY());
                    AppLog.d(ViewerActivity.this, doubleTapZoomDrag ? "ZOOM doubleTapHold end scale="+userScale : "ZOOM doubleTap toggle scale="+userScale);
                    secondTap=false; doubleTapZoomDrag=false; setTranslationX(0f); return true;
                }
                if (paging) {
                    float tx=getTranslationX(); int direction = tx<0 ? 1 : -1;
                    boolean commit = Math.abs(tx) > getWidth()*0.16f || Math.abs(vx)>650f;
                    if (commit && pageListener != null && pageListener.canPage(direction)) pageListener.onPage(direction, vx);
                    else {
                        if (pageListener != null) pageListener.onPageReset();
                        else animate().translationX(0f).setDuration(150).start();
                    }
                    paging=false; return true;
                }
                if (!moved && action==MotionEvent.ACTION_UP && !scaleDetector.isInProgress()) {
                    lastTapUp=SystemClock.uptimeMillis(); lastTapX=e.getX(); lastTapY=e.getY();
                    scheduleSingleTap();
                }
                return true;
            }
            return true;
        }

        private void scheduleSingleTap() {
            cancelSingleTap();
            pendingSingleTap = () -> { pendingSingleTap=null; if (pageListener!=null) pageListener.onSingleTap(); };
            mainHandler.postDelayed(pendingSingleTap, DOUBLE_TAP_MS + 20);
        }
        private void cancelSingleTap() { if (pendingSingleTap != null) { mainHandler.removeCallbacks(pendingSingleTap); pendingSingleTap=null; } }
        private float distance(float x1,float y1,float x2,float y2) { float dx=x1-x2, dy=y1-y2; return (float)Math.sqrt(dx*dx+dy*dy); }
    }
}
